
import { Sidebar } from './components/Sidebar';
import { MainViewer } from './components/MainViewer';
import { AIChat } from './components/AIChat';
import { useMoleculeStore } from './store/moleculeStore';

function App() {
  const { chatOpen } = useMoleculeStore();

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-900 text-white">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div
        className={`flex-1 flex overflow-hidden transition-all duration-300 ${
          chatOpen ? 'mr-[420px]' : ''
        }`}
      >
        <MainViewer />
      </div>

      {/* AI Chat Panel */}
      <AIChat />
    </div>
  );
}

export default App;
