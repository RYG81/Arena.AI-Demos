import { create } from 'zustand';

export interface MoleculeProperty {
  molecularFormula: string;
  molecularWeight: string;
  iupacName: string;
  smiles: string;
  inchiKey: string;
  xLogP: string;
  hBondDonorCount: string;
  hBondAcceptorCount: string;
  rotatableBondCount: string;
  topologicalPolarSurfaceArea: string;
  heavyAtomCount: string;
  charge: string;
  cid: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
}

export interface VisualizationStyle {
  type: 'stick' | 'sphere' | 'cartoon' | 'surface' | 'line' | 'cross';
  colorScheme: 'element' | 'chain' | 'residue' | 'spectrum';
  backgroundColor: string;
  opacity: number;
  showLabels: boolean;
  showHydrogens: boolean;
  wireframe: boolean;
}

export interface MoleculeData {
  name: string;
  sdfData: string;
  properties: MoleculeProperty | null;
  timestamp: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

export type ActivePanel = 'viewer' | 'builder' | 'learn' | 'compare' | 'quiz' | 'settings';
export type AIProvider = 'openai' | 'deepseek' | 'demo';

interface MoleculeStore {
  // Current molecule
  currentMolecule: MoleculeData | null;
  compareMolecule: MoleculeData | null;
  isLoading: boolean;
  error: string | null;

  // Cache (IndexedDB-like in memory)
  moleculeCache: Map<string, MoleculeData>;

  // Chat
  chatMessages: ChatMessage[];
  isChatLoading: boolean;

  // Visualization
  vizStyle: VisualizationStyle;

  // UI state
  activePanel: ActivePanel;
  sidebarOpen: boolean;
  chatOpen: boolean;

  // AI Settings
  aiProvider: AIProvider;
  openaiKey: string;
  deepseekKey: string;
  selectedModel: string;

  // Quiz
  quizQuestions: QuizQuestion[];
  quizAnswers: Record<string, number>;
  quizSubmitted: boolean;

  // Search history
  searchHistory: string[];

  // Actions
  setCurrentMolecule: (mol: MoleculeData | null) => void;
  setCompareMolecule: (mol: MoleculeData | null) => void;
  setIsLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  addToCache: (key: string, mol: MoleculeData) => void;
  getFromCache: (key: string) => MoleculeData | undefined;
  addChatMessage: (msg: ChatMessage) => void;
  clearChat: () => void;
  setIsChatLoading: (loading: boolean) => void;
  updateVizStyle: (style: Partial<VisualizationStyle>) => void;
  setActivePanel: (panel: ActivePanel) => void;
  setSidebarOpen: (open: boolean) => void;
  setChatOpen: (open: boolean) => void;
  setAIProvider: (provider: AIProvider) => void;
  setOpenAIKey: (key: string) => void;
  setDeepseekKey: (key: string) => void;
  setSelectedModel: (model: string) => void;
  setQuizQuestions: (questions: QuizQuestion[]) => void;
  setQuizAnswer: (questionId: string, answer: number) => void;
  submitQuiz: () => void;
  resetQuiz: () => void;
  addToSearchHistory: (term: string) => void;
}

export const useMoleculeStore = create<MoleculeStore>((set, get) => ({
  currentMolecule: null,
  compareMolecule: null,
  isLoading: false,
  error: null,
  moleculeCache: new Map(),
  chatMessages: [],
  isChatLoading: false,
  vizStyle: {
    type: 'stick',
    colorScheme: 'element',
    backgroundColor: '#0f172a',
    opacity: 1,
    showLabels: false,
    showHydrogens: true,
    wireframe: false,
  },
  activePanel: 'viewer',
  sidebarOpen: true,
  chatOpen: false,
  aiProvider: 'demo',
  openaiKey: '',
  deepseekKey: '',
  selectedModel: 'gpt-4o-mini',
  quizQuestions: [],
  quizAnswers: {},
  quizSubmitted: false,
  searchHistory: ['Water', 'Caffeine', 'Aspirin', 'Ethanol', 'Glucose'],

  setCurrentMolecule: (mol) => set({ currentMolecule: mol }),
  setCompareMolecule: (mol) => set({ compareMolecule: mol }),
  setIsLoading: (loading) => set({ isLoading: loading }),
  setError: (error) => set({ error }),
  addToCache: (key, mol) => {
    const cache = get().moleculeCache;
    cache.set(key.toLowerCase(), mol);
    set({ moleculeCache: cache });
  },
  getFromCache: (key) => get().moleculeCache.get(key.toLowerCase()),
  addChatMessage: (msg) =>
    set((state) => ({ chatMessages: [...state.chatMessages, msg] })),
  clearChat: () => set({ chatMessages: [] }),
  setIsChatLoading: (loading) => set({ isChatLoading: loading }),
  updateVizStyle: (style) =>
    set((state) => ({ vizStyle: { ...state.vizStyle, ...style } })),
  setActivePanel: (panel) => set({ activePanel: panel }),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setChatOpen: (open) => set({ chatOpen: open }),
  setAIProvider: (provider) => set({ aiProvider: provider }),
  setOpenAIKey: (key) => set({ openaiKey: key }),
  setDeepseekKey: (key) => set({ deepseekKey: key }),
  setSelectedModel: (model) => set({ selectedModel: model }),
  setQuizQuestions: (questions) =>
    set({ quizQuestions: questions, quizAnswers: {}, quizSubmitted: false }),
  setQuizAnswer: (questionId, answer) =>
    set((state) => ({
      quizAnswers: { ...state.quizAnswers, [questionId]: answer },
    })),
  submitQuiz: () => set({ quizSubmitted: true }),
  resetQuiz: () => set({ quizAnswers: {}, quizSubmitted: false }),
  addToSearchHistory: (term) =>
    set((state) => ({
      searchHistory: [
        term,
        ...state.searchHistory.filter((t) => t !== term),
      ].slice(0, 20),
    })),
}));
