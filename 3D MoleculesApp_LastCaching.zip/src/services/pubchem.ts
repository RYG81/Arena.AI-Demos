import { MoleculeData, MoleculeProperty } from '../store/moleculeStore';

const PUBCHEM_BASE = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug';

export async function fetchMoleculeByName(name: string): Promise<MoleculeData> {
  const encodedName = encodeURIComponent(name.trim());

  // Step 1: Get CID
  const cidRes = await fetch(
    `${PUBCHEM_BASE}/compound/name/${encodedName}/cids/JSON`
  );
  if (!cidRes.ok) throw new Error(`Molecule "${name}" not found in PubChem`);
  const cidData = await cidRes.json();
  const cid = cidData.IdentifierList?.CID?.[0];
  if (!cid) throw new Error(`No CID found for "${name}"`);

  // Step 2: Fetch properties and 3D SDF in parallel
  const [propsRes, sdfRes] = await Promise.all([
    fetch(
      `${PUBCHEM_BASE}/compound/cid/${cid}/property/MolecularFormula,MolecularWeight,IUPACName,CanonicalSMILES,InChIKey,XLogP,HBondDonorCount,HBondAcceptorCount,RotatableBondCount,TopologicalPolarSurfaceArea,HeavyAtomCount,FormalCharge/JSON`
    ),
    fetch(
      `${PUBCHEM_BASE}/compound/cid/${cid}/SDF?record_type=3d`
    ),
  ]);

  let sdfData = '';
  if (sdfRes.ok) {
    sdfData = await sdfRes.text();
  } else {
    // Fallback to 2D SDF
    const sdf2dRes = await fetch(`${PUBCHEM_BASE}/compound/cid/${cid}/SDF`);
    if (sdf2dRes.ok) sdfData = await sdf2dRes.text();
  }

  let properties: MoleculeProperty | null = null;
  if (propsRes.ok) {
    const propsData = await propsRes.json();
    const p = propsData.PropertyTable?.Properties?.[0];
    if (p) {
      properties = {
        molecularFormula: p.MolecularFormula ?? 'N/A',
        molecularWeight: p.MolecularWeight?.toString() ?? 'N/A',
        iupacName: p.IUPACName ?? name,
        smiles: p.CanonicalSMILES ?? 'N/A',
        inchiKey: p.InChIKey ?? 'N/A',
        xLogP: p.XLogP?.toString() ?? 'N/A',
        hBondDonorCount: p.HBondDonorCount?.toString() ?? 'N/A',
        hBondAcceptorCount: p.HBondAcceptorCount?.toString() ?? 'N/A',
        rotatableBondCount: p.RotatableBondCount?.toString() ?? 'N/A',
        topologicalPolarSurfaceArea: p.TopologicalPolarSurfaceArea?.toString() ?? 'N/A',
        heavyAtomCount: p.HeavyAtomCount?.toString() ?? 'N/A',
        charge: p.FormalCharge?.toString() ?? '0',
        cid: cid.toString(),
      };
    }
  }

  return {
    name: properties?.iupacName || name,
    sdfData,
    properties,
    timestamp: Date.now(),
  };
}

export async function fetchMoleculeBySMILES(smiles: string): Promise<MoleculeData> {
  const encodedSmiles = encodeURIComponent(smiles.trim());

  const cidRes = await fetch(
    `${PUBCHEM_BASE}/compound/smiles/${encodedSmiles}/cids/JSON`
  );
  if (!cidRes.ok) throw new Error(`Invalid SMILES or molecule not found`);
  const cidData = await cidRes.json();
  const cid = cidData.IdentifierList?.CID?.[0];
  if (!cid) throw new Error(`No CID found for SMILES`);

  // Get name
  const nameRes = await fetch(
    `${PUBCHEM_BASE}/compound/cid/${cid}/property/IUPACName/JSON`
  );
  let name = smiles;
  if (nameRes.ok) {
    const nameData = await nameRes.json();
    name = nameData.PropertyTable?.Properties?.[0]?.IUPACName || smiles;
  }

  return fetchMoleculeByName(name);
}

export async function searchMoleculesByFormula(formula: string): Promise<string[]> {
  const res = await fetch(
    `${PUBCHEM_BASE}/compound/formula/${encodeURIComponent(formula)}/cids/JSON?MaxRecords=10`
  );
  if (!res.ok) return [];
  const data = await res.json();
  const cids = data.IdentifierList?.CID?.slice(0, 5) ?? [];

  // Get names for these CIDs
  const names: string[] = [];
  for (const cid of cids) {
    const nameRes = await fetch(
      `${PUBCHEM_BASE}/compound/cid/${cid}/property/IUPACName/JSON`
    );
    if (nameRes.ok) {
      const nameData = await nameRes.json();
      const iupac = nameData.PropertyTable?.Properties?.[0]?.IUPACName;
      if (iupac) names.push(iupac);
    }
  }
  return names;
}

export async function getSimilarMolecules(cid: string): Promise<string[]> {
  try {
    const res = await fetch(
      `${PUBCHEM_BASE}/compound/fastsimilarity_2d/cid/${cid}/cids/JSON?Threshold=90&MaxRecords=5`
    );
    if (!res.ok) return [];
    const data = await res.json();
    const cids = data.IdentifierList?.CID?.slice(0, 5) ?? [];
    const names: string[] = [];
    for (const c of cids.slice(0, 3)) {
      const nr = await fetch(`${PUBCHEM_BASE}/compound/cid/${c}/property/IUPACName/JSON`);
      if (nr.ok) {
        const nd = await nr.json();
        const iupac = nd.PropertyTable?.Properties?.[0]?.IUPACName;
        if (iupac) names.push(iupac);
      }
    }
    return names;
  } catch {
    return [];
  }
}
