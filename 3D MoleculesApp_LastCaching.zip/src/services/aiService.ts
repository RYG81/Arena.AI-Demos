import { MoleculeData, AIProvider, QuizQuestion } from '../store/moleculeStore';

interface AIMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export async function callAI(
  messages: AIMessage[],
  provider: AIProvider,
  apiKey: string,
  model: string
): Promise<string> {
  if (provider === 'demo') {
    return getDemoResponse(messages);
  }

  if (provider === 'openai') {
    return callOpenAI(messages, apiKey, model);
  }

  if (provider === 'deepseek') {
    return callDeepSeek(messages, apiKey, model);
  }

  return getDemoResponse(messages);
}

async function callOpenAI(messages: AIMessage[], apiKey: string, model: string): Promise<string> {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: model || 'gpt-4o-mini',
      messages,
      temperature: 0.7,
      max_tokens: 1000,
    }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error?.message || 'OpenAI API error');
  }
  const data = await res.json();
  return data.choices[0].message.content;
}

async function callDeepSeek(messages: AIMessage[], apiKey: string, model: string): Promise<string> {
  const res = await fetch('https://api.deepseek.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: model || 'deepseek-chat',
      messages,
      temperature: 0.7,
      max_tokens: 1000,
    }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error?.message || 'DeepSeek API error');
  }
  const data = await res.json();
  return data.choices[0].message.content;
}

function getDemoResponse(messages: AIMessage[]): string {
  const lastMsg = messages[messages.length - 1]?.content?.toLowerCase() ?? '';

  if (lastMsg.includes('bond') || lastMsg.includes('hybridization')) {
    return `## Bond & Hybridization Analysis

Great question about molecular bonding! Here's what I can tell you:

**Bond Types in this molecule:**
- **Single bonds (σ)**: Formed by head-on orbital overlap, allowing free rotation
- **Double bonds (σ + π)**: Restrict rotation, causing rigidity in the molecule
- **Triple bonds (σ + 2π)**: Highest bond order, shortest and strongest

**Hybridization:**
- **sp³**: Tetrahedral geometry (109.5°), like carbon in methane
- **sp²**: Trigonal planar (120°), seen in alkenes and aromatic rings
- **sp**: Linear geometry (180°), found in alkynes and CO₂

💡 *Add your OpenAI or DeepSeek API key in Settings for real AI-powered analysis!*`;
  }

  if (lastMsg.includes('polarity') || lastMsg.includes('polar')) {
    return `## Molecular Polarity

**What determines polarity?**
1. **Electronegativity differences** between bonded atoms
2. **Molecular geometry** — even polar bonds can cancel in symmetric molecules
3. **Lone pairs** that shift electron density

**Key indicators:**
- Molecules with O-H, N-H bonds are typically polar
- Symmetric molecules (like CO₂, CCl₄) can be nonpolar despite polar bonds
- Polarity affects **boiling point**, **solubility**, and **reactivity**

**Dipole moment (μ)**: Measured in Debyes (D). A value > 0 indicates a polar molecule.

💡 *Connect an AI provider in Settings for molecule-specific analysis!*`;
  }

  if (lastMsg.includes('reaction') || lastMsg.includes('react')) {
    return `## Reaction Chemistry

**Common reaction mechanisms:**
1. **Nucleophilic Substitution (SN1/SN2)** — Nucleophile attacks electrophilic carbon
2. **Electrophilic Addition** — Common in alkenes; π bond breaks, new σ bonds form
3. **Elimination (E1/E2)** — Removes atoms to form double bonds
4. **Oxidation/Reduction** — Change in oxidation state

**Predicting reactivity:**
- Look for **functional groups** — they determine reaction types
- Check **HOMO/LUMO** interactions for reactivity sites
- Consider **steric effects** and **electronic effects**

⚗️ *Use the Compare panel to study reaction partners side-by-side!*`;
  }

  if (lastMsg.includes('explain') || lastMsg.includes('what is') || lastMsg.includes('describe')) {
    return `## Molecular Overview

This molecule is a fascinating chemical compound! Here's a structured breakdown:

**🧬 Structure:**
The molecular architecture determines all chemical and physical properties. The 3D structure you see is calculated from quantum mechanical principles.

**⚡ Electronic Properties:**
- Electron distribution follows **electronegativity** rules
- **Formal charges** show electron bookkeeping
- **Resonance structures** may exist for delocalized electrons

**🧪 Physical Properties:**
- **Molecular weight** influences boiling/melting points
- **LogP** indicates fat vs water solubility (lipophilicity)
- **TPSA** predicts membrane permeability (important in drug design!)

**💊 Applications:**
Many molecules have real-world uses in medicine, materials, and industry.

💡 *Add an API key in Settings for molecule-specific AI explanations!*`;
  }

  if (lastMsg.includes('quiz') || lastMsg.includes('test')) {
    return `## Ready to Test Your Knowledge?

I can generate quiz questions about this molecule! Head to the **Quiz** panel to get started.

Quiz topics I can cover:
- 🔬 Molecular geometry and bond angles
- ⚡ Hybridization states  
- 🧲 Polarity and intermolecular forces
- 🧪 Chemical properties and reactivity
- 💊 Applications and importance

*Switch to Quiz mode using the panel selector above!*`;
  }

  return `## MoleculeAI Assistant

Hello! I'm your AI chemistry tutor. I can help you understand:

🔬 **Molecular Structure** — geometry, hybridization, bond types
⚡ **Electronic Properties** — polarity, formal charges, resonance  
🧪 **Chemical Reactions** — mechanisms, reactivity, products
📚 **Learning** — explanations at any complexity level
🎯 **Quizzes** — test your understanding

**Try asking me:**
- "Explain the hybridization of this molecule"
- "What makes this molecule polar?"
- "How does this molecule react with water?"
- "Compare this with a similar molecule"

> 💡 **Tip:** Add your OpenAI or DeepSeek API key in **Settings** for real AI-powered responses tailored to the specific molecule you're viewing!`;
}

export function buildSystemPrompt(molecule: MoleculeData | null): string {
  if (!molecule) {
    return `You are MoleculeAI, an expert chemistry tutor and molecular scientist. 
You provide accurate, scientifically grounded explanations about chemistry, molecules, and related topics.
Never hallucinate chemical data. If you're unsure, say so.
Format responses with markdown. Be educational but engaging.`;
  }

  const p = molecule.properties;
  return `You are MoleculeAI, an expert chemistry tutor analyzing the molecule: ${molecule.name}.

MOLECULAR DATA (use this as ground truth — do NOT invent data):
- IUPAC Name: ${p?.iupacName || molecule.name}
- Molecular Formula: ${p?.molecularFormula || 'unknown'}
- Molecular Weight: ${p?.molecularWeight || 'unknown'} g/mol
- Canonical SMILES: ${p?.smiles || 'unknown'}
- InChIKey: ${p?.inchiKey || 'unknown'}
- LogP (XLogP): ${p?.xLogP || 'unknown'}
- H-Bond Donors: ${p?.hBondDonorCount || 'unknown'}
- H-Bond Acceptors: ${p?.hBondAcceptorCount || 'unknown'}
- Rotatable Bonds: ${p?.rotatableBondCount || 'unknown'}
- TPSA: ${p?.topologicalPolarSurfaceArea || 'unknown'} Ų
- Heavy Atom Count: ${p?.heavyAtomCount || 'unknown'}
- Formal Charge: ${p?.charge || '0'}
- PubChem CID: ${p?.cid || 'unknown'}

RULES:
1. Only use the provided molecular data — never hallucinate properties
2. If asked about data not provided, say "that data isn't available in the current dataset"
3. Format responses with markdown headers and bullet points
4. Be scientifically accurate but pedagogically engaging
5. Connect molecular properties to real-world applications`;
}

export async function generateQuizQuestions(
  molecule: MoleculeData,
  provider: AIProvider,
  apiKey: string,
  model: string
): Promise<QuizQuestion[]> {
  const systemPrompt = buildSystemPrompt(molecule);
  const userPrompt = `Generate exactly 5 multiple-choice quiz questions about ${molecule.name} based on the molecular data provided.

Return ONLY a valid JSON array with this exact structure:
[
  {
    "id": "q1",
    "question": "Question text here?",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correct": 0,
    "explanation": "Explanation of why the answer is correct"
  }
]

Make questions progressively harder. Cover: molecular formula, physical properties, bonding, and applications.`;

  if (provider === 'demo') {
    return getDemoQuiz(molecule);
  }

  try {
    const response = await callAI(
      [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      provider,
      apiKey,
      model
    );

    // Extract JSON from response
    const jsonMatch = response.match(/\[[\s\S]*\]/);
    if (!jsonMatch) throw new Error('No JSON found in response');
    return JSON.parse(jsonMatch[0]);
  } catch {
    return getDemoQuiz(molecule);
  }
}

function getDemoQuiz(molecule: MoleculeData): QuizQuestion[] {
  const p = molecule.properties;
  const name = molecule.name;
  const formula = p?.molecularFormula || 'unknown';
  const mw = p?.molecularWeight || 'unknown';
  const logP = parseFloat(p?.xLogP || '0');

  return [
    {
      id: 'q1',
      question: `What is the molecular formula of ${name}?`,
      options: [
        formula,
        formula.replace(/\d/g, (n) => String(parseInt(n) + 1)),
        formula.replace(/\d/g, (n) => String(Math.max(1, parseInt(n) - 1))),
        'C₆H₁₂O₆',
      ].slice(0, 4),
      correct: 0,
      explanation: `The molecular formula of ${name} is ${formula}, which tells us the exact number of each type of atom in one molecule.`,
    },
    {
      id: 'q2',
      question: `Approximately how many H-bond donors does ${name} have?`,
      options: [
        p?.hBondDonorCount || '0',
        String((parseInt(p?.hBondDonorCount || '0') + 2)),
        String((parseInt(p?.hBondDonorCount || '0') + 4)),
        'None — it cannot form H-bonds',
      ],
      correct: 0,
      explanation: `${name} has ${p?.hBondDonorCount || '0'} H-bond donor(s). H-bond donors are typically N-H and O-H groups that can donate hydrogen bonds to acceptors.`,
    },
    {
      id: 'q3',
      question: `Based on its LogP value (${p?.xLogP || '?'}), how would you classify ${name}?`,
      options: [
        logP > 0 ? 'More lipophilic (fat-soluble)' : 'More hydrophilic (water-soluble)',
        logP > 0 ? 'More hydrophilic (water-soluble)' : 'More lipophilic (fat-soluble)',
        'It is perfectly amphiphilic',
        'LogP cannot predict solubility',
      ],
      correct: 0,
      explanation: `LogP (${p?.xLogP}) measures lipophilicity. Values > 0 indicate lipophilicity (fat-soluble); values < 0 indicate hydrophilicity (water-soluble). This affects absorption and distribution in biological systems.`,
    },
    {
      id: 'q4',
      question: `What does the molecular weight of ${mw} g/mol tell us about ${name}?`,
      options: [
        'It is a relatively small organic molecule',
        'It must be a large protein',
        'It cannot cross biological membranes',
        'It is necessarily volatile at room temperature',
      ],
      correct: parseFloat(mw) < 500 ? 0 : 1,
      explanation: `A molecular weight of ${mw} g/mol ${parseFloat(mw) < 500 ? 'falls within the typical small molecule range (< 500 Da, Lipinski\'s Rule of Five), suggesting potential oral bioavailability' : 'is above 500 Da, which is typical of larger molecules like peptides or natural products'}.`,
    },
    {
      id: 'q5',
      question: `${name} has a TPSA of ${p?.topologicalPolarSurfaceArea || '?'} Ų. What does this primarily predict?`,
      options: [
        'Membrane permeability and oral absorption',
        'Molecular boiling point',
        'Reaction rate with oxygen',
        'Number of stereoisomers',
      ],
      correct: 0,
      explanation: `Topological Polar Surface Area (TPSA) predicts a molecule's ability to cross biological membranes. TPSA < 90 Ų suggests good oral absorption; TPSA < 140 Ų suggests blood-brain barrier crossing.`,
    },
  ];
}
