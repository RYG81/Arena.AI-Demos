import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Send, Bot, User, Trash2, Loader2, Sparkles, X } from 'lucide-react';
import { useMoleculeStore, ChatMessage } from '../store/moleculeStore';
import { callAI, buildSystemPrompt } from '../services/aiService';

export const AIChat: React.FC = () => {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const {
    chatMessages,
    addChatMessage,
    clearChat,
    isChatLoading,
    setIsChatLoading,
    currentMolecule,
    aiProvider,
    openaiKey,
    deepseekKey,
    selectedModel,
    chatOpen,
    setChatOpen,
  } = useMoleculeStore();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isChatLoading]);

  const getApiKey = () => {
    if (aiProvider === 'openai') return openaiKey;
    if (aiProvider === 'deepseek') return deepseekKey;
    return '';
  };

  const handleSend = async () => {
    const text = input.trim();
    if (!text || isChatLoading) return;
    setInput('');

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date(),
    };
    addChatMessage(userMsg);
    setIsChatLoading(true);

    try {
      const systemPrompt = buildSystemPrompt(currentMolecule);
      const history = chatMessages.slice(-10).map((m) => ({
        role: m.role as 'user' | 'assistant' | 'system',
        content: m.content,
      }));

      const response = await callAI(
        [
          { role: 'system', content: systemPrompt },
          ...history,
          { role: 'user', content: text },
        ],
        aiProvider,
        getApiKey(),
        selectedModel
      );

      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      };
      addChatMessage(assistantMsg);
    } catch (err: unknown) {
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `❌ **Error:** ${err instanceof Error ? err.message : 'AI request failed. Check your API key in Settings.'}`,
        timestamp: new Date(),
      };
      addChatMessage(errorMsg);
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const quickPrompts = currentMolecule
    ? [
        `Explain the structure of ${currentMolecule.name}`,
        `What is the polarity of ${currentMolecule.name}?`,
        `What are the uses of ${currentMolecule.name}?`,
        `Explain the bonding in ${currentMolecule.name}`,
      ]
    : [
        'What is hybridization?',
        'Explain molecular polarity',
        'How do H-bonds work?',
        'What is VSEPR theory?',
      ];

  if (!chatOpen) return null;

  return (
    <div className="fixed bottom-0 right-0 top-0 w-[420px] bg-slate-900 border-l border-slate-700 flex flex-col z-50 shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-cyan-500 to-purple-600 rounded-lg flex items-center justify-center">
            <Sparkles size={16} className="text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white text-sm">MoleculeAI Tutor</h3>
            <p className="text-xs text-slate-400">
              {aiProvider === 'demo' ? 'Demo Mode' : `${aiProvider} • ${selectedModel}`}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={clearChat}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-all"
            title="Clear chat"
          >
            <Trash2 size={15} />
          </button>
          <button
            onClick={() => setChatOpen(false)}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-all"
          >
            <X size={15} />
          </button>
        </div>
      </div>

      {/* Provider badge */}
      {aiProvider === 'demo' && (
        <div className="px-4 py-2 bg-amber-900/30 border-b border-amber-700/30 text-xs text-amber-400 flex items-center gap-1">
          <span>⚡</span>
          <span>Demo mode — Add API key in Settings for real AI responses</span>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
        {chatMessages.length === 0 && (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-gradient-to-br from-cyan-500/20 to-purple-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Sparkles size={24} className="text-cyan-400" />
            </div>
            <p className="text-slate-300 font-medium mb-1">Ask MoleculeAI anything</p>
            <p className="text-slate-500 text-sm">Chemistry tutor powered by AI</p>
          </div>
        )}

        {chatMessages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} />
        ))}

        {isChatLoading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-cyan-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
              <Bot size={14} className="text-white" />
            </div>
            <div className="bg-slate-800 rounded-xl px-4 py-3 flex items-center gap-2">
              <Loader2 size={14} className="text-cyan-400 animate-spin" />
              <span className="text-slate-400 text-sm">Thinking...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick prompts */}
      <div className="px-4 py-2 border-t border-slate-700/50">
        <div className="flex flex-wrap gap-1">
          {quickPrompts.map((prompt) => (
            <button
              key={prompt}
              onClick={() => setInput(prompt)}
              className="text-xs px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-cyan-400 rounded-lg transition-all border border-slate-700 hover:border-cyan-500/30"
            >
              {prompt.length > 30 ? prompt.slice(0, 30) + '…' : prompt}
            </button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div className="px-4 py-3 border-t border-slate-700 bg-slate-800/50">
        <div className="flex gap-2 items-end">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask about this molecule..."
            rows={1}
            className="flex-1 bg-slate-700 border border-slate-600 text-white placeholder-slate-400 rounded-xl px-4 py-2.5 text-sm resize-none focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/20 transition-all"
            style={{ maxHeight: '120px' }}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isChatLoading}
            className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl flex items-center justify-center flex-shrink-0 transition-all shadow-lg"
          >
            <Send size={16} />
          </button>
        </div>
        <p className="text-xs text-slate-600 mt-1 text-center">Shift+Enter for new line</p>
      </div>
    </div>
  );
};

const MessageBubble: React.FC<{ message: ChatMessage }> = ({ message }) => {
  const isUser = message.role === 'user';

  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
      <div
        className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
          isUser
            ? 'bg-gradient-to-br from-purple-500 to-pink-500'
            : 'bg-gradient-to-br from-cyan-500 to-blue-600'
        }`}
      >
        {isUser ? <User size={14} className="text-white" /> : <Bot size={14} className="text-white" />}
      </div>
      <div
        className={`max-w-[85%] rounded-xl px-4 py-3 ${
          isUser
            ? 'bg-gradient-to-br from-purple-600 to-purple-700 text-white'
            : 'bg-slate-800 text-slate-200'
        }`}
      >
        {isUser ? (
          <p className="text-sm">{message.content}</p>
        ) : (
          <div className="text-sm prose prose-invert prose-sm max-w-none">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{message.content}</ReactMarkdown>
          </div>
        )}
        <p className={`text-xs mt-1 ${isUser ? 'text-purple-300' : 'text-slate-500'}`}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
    </div>
  );
};
