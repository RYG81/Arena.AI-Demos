import React, { useState, useRef } from 'react';
import { Search, Clock, Beaker, Loader2, X, ChevronDown } from 'lucide-react';
import { useMoleculeStore } from '../store/moleculeStore';
import { fetchMoleculeByName } from '../services/pubchem';

const POPULAR_MOLECULES = [
  { name: 'Water', formula: 'H₂O', emoji: '💧' },
  { name: 'Caffeine', formula: 'C₈H₁₀N₄O₂', emoji: '☕' },
  { name: 'Aspirin', formula: 'C₉H₈O₄', emoji: '💊' },
  { name: 'Ethanol', formula: 'C₂H₅OH', emoji: '🍺' },
  { name: 'Glucose', formula: 'C₆H₁₂O₆', emoji: '🍬' },
  { name: 'Dopamine', formula: 'C₈H₁₁NO₂', emoji: '🧠' },
  { name: 'Penicillin', formula: 'C₁₆H₁₈N₂O₄S', emoji: '💉' },
  { name: 'Cholesterol', formula: 'C₂₇H₄₆O', emoji: '🫀' },
  { name: 'Serotonin', formula: 'C₁₀H₁₂N₂O', emoji: '😊' },
  { name: 'Acetaminophen', formula: 'C₈H₉NO₂', emoji: '🩺' },
  { name: 'Capsaicin', formula: 'C₁₈H₂₇NO₃', emoji: '🌶️' },
  { name: 'Adenine', formula: 'C₅H₅N₅', emoji: '🧬' },
];

export const MoleculeSearch: React.FC = () => {
  const [query, setQuery] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [showPopular, setShowPopular] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const {
    isLoading,
    setIsLoading,
    setError,
    setCurrentMolecule,
    addToCache,
    getFromCache,
    searchHistory,
    addToSearchHistory,
    error,
  } = useMoleculeStore();

  const fetchMolecule = async (name: string) => {
    if (!name.trim()) return;
    setShowDropdown(false);
    setShowPopular(false);

    const cached = getFromCache(name);
    if (cached) {
      setCurrentMolecule(cached);
      addToSearchHistory(name);
      setQuery('');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const mol = await fetchMoleculeByName(name);
      addToCache(name, mol);
      setCurrentMolecule(mol);
      addToSearchHistory(name);
      setQuery('');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to fetch molecule');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) fetchMolecule(query.trim());
  };

  const filteredHistory = searchHistory.filter((item) =>
    item.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="relative">
      <form onSubmit={handleSubmit} className="relative">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search
              size={16}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
            />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setShowDropdown(e.target.value.length > 0);
              }}
              onFocus={() => {
                if (query.length > 0) setShowDropdown(true);
              }}
              onBlur={() => setTimeout(() => setShowDropdown(false), 150)}
              placeholder="Search molecule (name, formula, IUPAC)..."
              className="w-full bg-slate-800 border border-slate-600 hover:border-slate-500 focus:border-cyan-500 text-white placeholder-slate-400 rounded-xl pl-9 pr-4 py-3 text-sm transition-all focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
            />
            {query && (
              <button
                type="button"
                onClick={() => { setQuery(''); setShowDropdown(false); }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X size={14} />
              </button>
            )}
          </div>
          <button
            type="submit"
            disabled={isLoading || !query.trim()}
            className="px-5 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold rounded-xl text-sm transition-all shadow-lg hover:shadow-cyan-500/25 flex items-center gap-2"
          >
            {isLoading ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <Beaker size={16} />
            )}
            {isLoading ? 'Loading...' : 'Analyze'}
          </button>
        </div>

        {/* Dropdown */}
        {showDropdown && filteredHistory.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-1 bg-slate-800 border border-slate-600 rounded-xl shadow-2xl z-50 overflow-hidden">
            <div className="p-2">
              <p className="text-xs text-slate-500 px-2 py-1 flex items-center gap-1">
                <Clock size={11} /> Recent searches
              </p>
              {filteredHistory.slice(0, 6).map((item) => (
                <button
                  key={item}
                  type="button"
                  onMouseDown={() => fetchMolecule(item)}
                  className="w-full text-left px-3 py-2 text-sm text-slate-300 hover:bg-slate-700 hover:text-white rounded-lg transition-all flex items-center gap-2"
                >
                  <Clock size={12} className="text-slate-500" />
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}
      </form>

      {/* Error */}
      {error && (
        <div className="mt-2 p-3 bg-red-900/30 border border-red-700/50 rounded-xl text-sm text-red-400 flex items-center gap-2">
          <span>⚠️</span>
          <span>{error}</span>
          <button onClick={() => setError(null)} className="ml-auto">
            <X size={14} />
          </button>
        </div>
      )}

      {/* Popular molecules toggle */}
      <div className="mt-3">
        <button
          type="button"
          onClick={() => setShowPopular(!showPopular)}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-cyan-400 transition-colors"
        >
          <ChevronDown
            size={12}
            className={`transition-transform ${showPopular ? 'rotate-180' : ''}`}
          />
          Popular molecules
        </button>

        {showPopular && (
          <div className="mt-2 grid grid-cols-2 gap-1">
            {POPULAR_MOLECULES.map((mol) => (
              <button
                key={mol.name}
                onClick={() => fetchMolecule(mol.name)}
                disabled={isLoading}
                className="flex items-center gap-2 px-3 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-cyan-500/40 rounded-xl text-left transition-all disabled:opacity-50"
              >
                <span className="text-lg">{mol.emoji}</span>
                <div>
                  <p className="text-xs font-medium text-white">{mol.name}</p>
                  <p className="text-xs text-slate-500">{mol.formula}</p>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
