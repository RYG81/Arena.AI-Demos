import React from 'react';
import { useMoleculeStore } from '../store/moleculeStore';
import { Atom, Droplets, Scale, Activity, Link, Copy, ExternalLink } from 'lucide-react';

const PropertyCard: React.FC<{
  label: string;
  value: string;
  unit?: string;
  color?: string;
  tooltip?: string;
}> = ({ label, value, unit, color = 'text-white', tooltip }) => (
  <div
    className="bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 hover:border-slate-600 rounded-xl p-3 transition-all group"
    title={tooltip}
  >
    <p className="text-xs text-slate-400 mb-1">{label}</p>
    <p className={`text-sm font-bold ${color} flex items-baseline gap-1`}>
      {value}
      {unit && <span className="text-xs font-normal text-slate-500">{unit}</span>}
    </p>
  </div>
);

const getLogPColor = (val: string): string => {
  const n = parseFloat(val);
  if (isNaN(n)) return 'text-white';
  if (n < 0) return 'text-blue-400';
  if (n < 2) return 'text-green-400';
  if (n < 5) return 'text-yellow-400';
  return 'text-red-400';
};

const getTPSAColor = (val: string): string => {
  const n = parseFloat(val);
  if (isNaN(n)) return 'text-white';
  if (n < 60) return 'text-green-400';
  if (n < 90) return 'text-yellow-400';
  if (n < 140) return 'text-orange-400';
  return 'text-red-400';
};

const getMWColor = (val: string): string => {
  const n = parseFloat(val);
  if (isNaN(n)) return 'text-white';
  if (n < 300) return 'text-green-400';
  if (n < 500) return 'text-yellow-400';
  return 'text-red-400';
};

export const MoleculeProperties: React.FC = () => {
  const { currentMolecule } = useMoleculeStore();
  const p = currentMolecule?.properties;

  if (!currentMolecule || !p) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="text-5xl mb-3">🔬</div>
        <p className="text-slate-400 text-sm">Search for a molecule to see its properties</p>
      </div>
    );
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  // Lipinski Rule of Five check
  const lipinskiPass = {
    mw: parseFloat(p.molecularWeight) <= 500,
    logP: parseFloat(p.xLogP) <= 5,
    hbd: parseInt(p.hBondDonorCount) <= 5,
    hba: parseInt(p.hBondAcceptorCount) <= 10,
  };
  const lipinskiScore = Object.values(lipinskiPass).filter(Boolean).length;

  return (
    <div className="space-y-4">
      {/* Identity */}
      <div className="bg-gradient-to-r from-cyan-500/10 to-blue-600/10 border border-cyan-500/20 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
            <Atom size={20} className="text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-white text-base leading-tight">{currentMolecule.name}</h3>
            <p className="text-cyan-400 font-mono text-sm mt-0.5">{p.molecularFormula}</p>
            <p className="text-slate-400 text-xs mt-1 line-clamp-2">{p.iupacName}</p>
          </div>
        </div>

        {/* PubChem link */}
        <a
          href={`https://pubchem.ncbi.nlm.nih.gov/compound/${p.cid}`}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-3 flex items-center gap-1 text-xs text-slate-400 hover:text-cyan-400 transition-colors"
        >
          <ExternalLink size={11} />
          PubChem CID: {p.cid}
        </a>
      </div>

      {/* SMILES */}
      <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-3">
        <div className="flex items-center justify-between mb-1">
          <p className="text-xs text-slate-400 flex items-center gap-1"><Link size={11} /> SMILES</p>
          <button
            onClick={() => copyToClipboard(p.smiles)}
            className="text-slate-500 hover:text-cyan-400 transition-colors"
            title="Copy SMILES"
          >
            <Copy size={12} />
          </button>
        </div>
        <p className="text-xs font-mono text-green-400 break-all">{p.smiles}</p>
      </div>

      {/* Key Properties Grid */}
      <div>
        <h4 className="text-xs text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1">
          <Scale size={12} /> Physical Properties
        </h4>
        <div className="grid grid-cols-2 gap-2">
          <PropertyCard
            label="Molecular Weight"
            value={parseFloat(p.molecularWeight).toFixed(2)}
            unit="g/mol"
            color={getMWColor(p.molecularWeight)}
            tooltip="Lipinski Rule: ≤ 500 g/mol for drug-likeness"
          />
          <PropertyCard
            label="Heavy Atoms"
            value={p.heavyAtomCount}
            color="text-purple-400"
            tooltip="Number of non-hydrogen atoms"
          />
          <PropertyCard
            label="LogP (XLogP)"
            value={p.xLogP}
            color={getLogPColor(p.xLogP)}
            tooltip="Lipophilicity. <0: hydrophilic, >5: lipophilic"
          />
          <PropertyCard
            label="Formal Charge"
            value={p.charge === '0' ? '0 (neutral)' : p.charge}
            color={p.charge === '0' ? 'text-green-400' : 'text-yellow-400'}
          />
        </div>
      </div>

      {/* H-bonding */}
      <div>
        <h4 className="text-xs text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1">
          <Droplets size={12} /> Hydrogen Bonding
        </h4>
        <div className="grid grid-cols-2 gap-2">
          <PropertyCard
            label="H-Bond Donors"
            value={p.hBondDonorCount}
            color="text-blue-400"
            tooltip="N-H and O-H groups that donate H-bonds (Rule of Five: ≤5)"
          />
          <PropertyCard
            label="H-Bond Acceptors"
            value={p.hBondAcceptorCount}
            color="text-cyan-400"
            tooltip="N and O atoms that accept H-bonds (Rule of Five: ≤10)"
          />
          <PropertyCard
            label="Rotatable Bonds"
            value={p.rotatableBondCount}
            color="text-orange-400"
            tooltip="Single bonds allowing free rotation, affects flexibility"
          />
          <PropertyCard
            label="TPSA"
            value={parseFloat(p.topologicalPolarSurfaceArea).toFixed(1)}
            unit="Ų"
            color={getTPSAColor(p.topologicalPolarSurfaceArea)}
            tooltip="Topological Polar Surface Area: <90Ų good oral absorption"
          />
        </div>
      </div>

      {/* Drug-likeness */}
      <div>
        <h4 className="text-xs text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1">
          <Activity size={12} /> Lipinski Rule of Five
        </h4>
        <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-3">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-white font-medium">Drug-likeness Score</span>
            <div className="flex items-center gap-1">
              <span className={`text-lg font-bold ${lipinskiScore >= 3 ? 'text-green-400' : 'text-yellow-400'}`}>
                {lipinskiScore}/4
              </span>
              <span className="text-xs text-slate-500">rules passed</span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="w-full bg-slate-700 rounded-full h-2 mb-3">
            <div
              className={`h-2 rounded-full transition-all ${
                lipinskiScore === 4 ? 'bg-green-500' :
                lipinskiScore === 3 ? 'bg-yellow-500' : 'bg-red-500'
              }`}
              style={{ width: `${(lipinskiScore / 4) * 100}%` }}
            />
          </div>

          <div className="space-y-1.5">
            {[
              { rule: 'MW ≤ 500 g/mol', pass: lipinskiPass.mw, val: `${parseFloat(p.molecularWeight).toFixed(0)} g/mol` },
              { rule: 'LogP ≤ 5', pass: lipinskiPass.logP, val: `LogP = ${p.xLogP}` },
              { rule: 'H-donors ≤ 5', pass: lipinskiPass.hbd, val: `${p.hBondDonorCount} donors` },
              { rule: 'H-acceptors ≤ 10', pass: lipinskiPass.hba, val: `${p.hBondAcceptorCount} acceptors` },
            ].map((r) => (
              <div key={r.rule} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className={r.pass ? 'text-green-400' : 'text-red-400'}>
                    {r.pass ? '✓' : '✗'}
                  </span>
                  <span className="text-slate-400">{r.rule}</span>
                </div>
                <span className={r.pass ? 'text-green-400' : 'text-red-400'}>{r.val}</span>
              </div>
            ))}
          </div>

          {lipinskiScore >= 3 && (
            <p className="mt-2 text-xs text-green-400 bg-green-900/20 rounded-lg px-2 py-1">
              ✓ Good oral bioavailability predicted
            </p>
          )}
        </div>
      </div>

      {/* InChIKey */}
      <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-3">
        <div className="flex items-center justify-between mb-1">
          <p className="text-xs text-slate-400">InChIKey</p>
          <button
            onClick={() => copyToClipboard(p.inchiKey)}
            className="text-slate-500 hover:text-cyan-400 transition-colors"
          >
            <Copy size={12} />
          </button>
        </div>
        <p className="text-xs font-mono text-slate-300">{p.inchiKey}</p>
      </div>
    </div>
  );
};
