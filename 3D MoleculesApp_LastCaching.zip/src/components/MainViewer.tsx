import React, { useState } from 'react';
import { useMoleculeStore } from '../store/moleculeStore';
import { MoleculeViewer3D } from './MoleculeViewer3D';
import {
  MessageSquare,
  Sparkles,
  ChevronDown,
  Database,
  Cpu,
  Zap,
  FlaskConical,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const ELEMENT_COLORS: Record<string, string> = {
  C: 'bg-gray-500',
  H: 'bg-white',
  O: 'bg-red-500',
  N: 'bg-blue-500',
  S: 'bg-yellow-400',
  P: 'bg-orange-500',
  F: 'bg-green-400',
  Cl: 'bg-green-500',
  Br: 'bg-red-700',
  I: 'bg-purple-600',
};

const extractElements = (formula: string): Array<{ el: string; count: string }> => {
  const regex = /([A-Z][a-z]?)(\d*)/g;
  const elements: Array<{ el: string; count: string }> = [];
  let match;
  while ((match = regex.exec(formula)) !== null) {
    if (match[1]) {
      elements.push({ el: match[1], count: match[2] || '1' });
    }
  }
  return elements;
};

export const MainViewer: React.FC = () => {
  const {
    currentMolecule,
    isLoading,
    setChatOpen,
    chatOpen,
    aiProvider,
    moleculeCache,
  } = useMoleculeStore();

  const [showInfo, setShowInfo] = useState(false);


  const elements = currentMolecule?.properties?.molecularFormula
    ? extractElements(currentMolecule.properties.molecularFormula)
    : [];

  return (
    <main className="flex-1 flex flex-col bg-slate-900 overflow-hidden relative">
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900/80 backdrop-blur border-b border-slate-800 flex-shrink-0 z-10">
        <div className="flex items-center gap-3">
          {/* Molecule title */}
          <AnimatePresence mode="wait">
            {currentMolecule ? (
              <motion.div
                key={currentMolecule.name}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="flex items-center gap-3"
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-white font-semibold">{currentMolecule.name}</span>
                  <span className="text-xs text-slate-400 font-mono bg-slate-800 px-2 py-0.5 rounded-lg border border-slate-700">
                    {currentMolecule.properties?.molecularFormula}
                  </span>
                </div>

                {/* Element badges */}
                <div className="hidden md:flex gap-1">
                  {elements.slice(0, 5).map(({ el, count }) => (
                    <span
                      key={el}
                      className={`text-xs px-1.5 py-0.5 rounded-md font-mono font-bold ${
                        ELEMENT_COLORS[el] || 'bg-slate-600'
                      } ${el === 'H' ? 'text-slate-800' : 'text-white'}`}
                    >
                      {el}{count !== '1' && count}
                    </span>
                  ))}
                </div>

                <button
                  onClick={() => setShowInfo(!showInfo)}
                  className="text-slate-400 hover:text-white transition-colors"
                >
                  <ChevronDown size={14} className={`transition-transform ${showInfo ? 'rotate-180' : ''}`} />
                </button>
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-2"
              >
                <FlaskConical size={16} className="text-slate-500" />
                <span className="text-slate-400 text-sm">No molecule loaded</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right side controls */}
        <div className="flex items-center gap-2">
          {/* Cache indicator */}
          <div className="hidden sm:flex items-center gap-1 text-xs text-slate-500">
            <Database size={11} />
            <span>{moleculeCache.size} cached</span>
          </div>

          {/* AI provider badge */}
          <div
            className={`hidden sm:flex items-center gap-1 text-xs px-2 py-1 rounded-lg border ${
              aiProvider === 'demo'
                ? 'border-amber-700/50 text-amber-400 bg-amber-900/20'
                : 'border-green-700/50 text-green-400 bg-green-900/20'
            }`}
          >
            <Cpu size={11} />
            {aiProvider === 'demo' ? 'Demo AI' : aiProvider}
          </div>

          {/* AI Chat toggle */}
          <button
            onClick={() => setChatOpen(!chatOpen)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-medium transition-all ${
              chatOpen
                ? 'bg-purple-600 text-white'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
            }`}
          >
            <MessageSquare size={15} />
            <span className="hidden sm:inline">AI Chat</span>
            <Sparkles size={12} className="text-yellow-400" />
          </button>
        </div>
      </div>

      {/* Quick info dropdown */}
      <AnimatePresence>
        {showInfo && currentMolecule?.properties && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex gap-6 px-4 py-3 bg-slate-800/60 border-b border-slate-700/50 overflow-hidden flex-shrink-0"
          >
            {[
              { label: 'MW', value: `${parseFloat(currentMolecule.properties.molecularWeight).toFixed(1)} g/mol` },
              { label: 'LogP', value: currentMolecule.properties.xLogP },
              { label: 'H-donors', value: currentMolecule.properties.hBondDonorCount },
              { label: 'H-acceptors', value: currentMolecule.properties.hBondAcceptorCount },
              { label: 'TPSA', value: `${parseFloat(currentMolecule.properties.topologicalPolarSurfaceArea).toFixed(0)} Ų` },
              { label: 'Rot. bonds', value: currentMolecule.properties.rotatableBondCount },
            ].map(({ label, value }) => (
              <div key={label}>
                <p className="text-xs text-slate-500">{label}</p>
                <p className="text-sm font-semibold text-white">{value}</p>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3D Viewer */}
      <div className="flex-1 relative overflow-hidden">
        {isLoading && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/80 backdrop-blur-sm z-20">
            <div className="relative">
              <div className="w-24 h-24 border-4 border-cyan-500/30 rounded-full animate-ping absolute inset-0" />
              <div className="w-24 h-24 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                <FlaskConical size={28} className="text-cyan-400" />
              </div>
            </div>
            <div className="mt-6 text-center">
              <p className="text-white font-semibold mb-1">Fetching Molecular Data</p>
              <p className="text-slate-400 text-sm">Querying PubChem database...</p>
              <div className="mt-3 flex gap-1 justify-center">
                {[0, 1, 2].map((i) => (
                  <div
                    key={i}
                    className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce"
                    style={{ animationDelay: `${i * 0.15}s` }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {!currentMolecule && !isLoading ? (
          <WelcomeScreen />
        ) : (
          <MoleculeViewer3D
            sdfData={currentMolecule?.sdfData || ''}
            title={currentMolecule?.name}
          />
        )}
      </div>

      {/* Bottom status bar */}
      <div className="flex items-center justify-between px-4 py-1.5 bg-slate-950 border-t border-slate-800 text-xs text-slate-600 flex-shrink-0">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            PubChem Connected
          </span>
          {currentMolecule && (
            <span>CID: {currentMolecule.properties?.cid}</span>
          )}
        </div>
        <div className="flex items-center gap-3">
          <span>3Dmol.js Engine</span>
          <span className="flex items-center gap-1">
            <Zap size={10} className="text-yellow-500" />
            Real-time 3D
          </span>
        </div>
      </div>
    </main>
  );
};

const WelcomeScreen: React.FC = () => {
  const { } = useMoleculeStore();

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800">
      {/* Animated background dots */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full opacity-10"
            style={{
              width: Math.random() * 6 + 2 + 'px',
              height: Math.random() * 6 + 2 + 'px',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              backgroundColor: i % 3 === 0 ? '#06b6d4' : i % 3 === 1 ? '#a855f7' : '#3b82f6',
              animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="text-center max-w-lg px-6 relative z-10"
      >
        {/* Logo */}
        <div className="w-24 h-24 bg-gradient-to-br from-cyan-500 via-blue-600 to-purple-700 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-cyan-500/20">
          <FlaskConical size={44} className="text-white" />
        </div>

        <h2 className="text-4xl font-black text-white mb-2">
          Molecule<span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">AI</span>
        </h2>
        <p className="text-slate-300 text-lg mb-2">3D Molecular Intelligence Platform</p>
        <p className="text-slate-500 text-sm mb-8 max-w-md mx-auto">
          Search any molecule to instantly view its 3D structure, explore chemical properties,
          chat with AI, and learn chemistry interactively.
        </p>

        {/* Feature cards */}
        <div className="grid grid-cols-2 gap-3 mb-8">
          {[
            { icon: '🔬', title: 'Real 3D Structures', desc: 'PubChem quantum-computed geometries' },
            { icon: '🤖', title: 'AI Chemistry Tutor', desc: 'Powered by GPT-4 or DeepSeek' },
            { icon: '⚡', title: 'Smart Caching', desc: 'Instant re-access with local cache' },
            { icon: '🎓', title: 'Interactive Learning', desc: 'Quizzes, lessons & comparisons' },
          ].map((f) => (
            <div
              key={f.title}
              className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3 text-left"
            >
              <div className="text-2xl mb-1">{f.icon}</div>
              <p className="text-sm font-semibold text-white">{f.title}</p>
              <p className="text-xs text-slate-500">{f.desc}</p>
            </div>
          ))}
        </div>

        {/* Quick start suggestions */}
        <div>
          <p className="text-xs text-slate-500 mb-3">Try these molecules to get started:</p>
          <div className="flex flex-wrap gap-2 justify-center">
            {[
              { name: 'Caffeine', emoji: '☕' },
              { name: 'Aspirin', emoji: '💊' },
              { name: 'Dopamine', emoji: '🧠' },
              { name: 'Penicillin', emoji: '💉' },
              { name: 'Cholesterol', emoji: '🫀' },
            ].map(({ name, emoji }) => (
              <QuickMoleculeButton key={name} name={name} emoji={emoji} />
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const QuickMoleculeButton: React.FC<{ name: string; emoji: string }> = ({ name, emoji }) => {
  const { setIsLoading, setError, setCurrentMolecule, addToCache, getFromCache, addToSearchHistory } = useMoleculeStore();

  const load = async () => {
    const cached = getFromCache(name);
    if (cached) {
      setCurrentMolecule(cached);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const { fetchMoleculeByName } = await import('../services/pubchem');
      const mol = await fetchMoleculeByName(name);
      addToCache(name, mol);
      setCurrentMolecule(mol);
      addToSearchHistory(name);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to load');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <button
      onClick={load}
      className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-cyan-500/50 text-slate-300 hover:text-white rounded-xl text-sm transition-all hover:shadow-lg hover:shadow-cyan-500/10"
    >
      <span>{emoji}</span>
      <span>{name}</span>
    </button>
  );
};
