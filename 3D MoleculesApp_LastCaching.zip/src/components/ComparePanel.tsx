import React, { useState } from 'react';
import { useMoleculeStore } from '../store/moleculeStore';
import { fetchMoleculeByName } from '../services/pubchem';
import { MoleculeViewer3D } from './MoleculeViewer3D';
import { Search, Loader2, ArrowLeftRight, X } from 'lucide-react';

const COMPARE_SUGGESTIONS = [
  'Benzene', 'Toluene', 'Phenol', 'Aniline', 'Naphthalene',
  'Methanol', 'Ethanol', 'Propanol', 'Butanol',
  'Acetone', 'Acetaldehyde', 'Acetic acid',
];

export const ComparePanel: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState('');

  const {
    currentMolecule,
    compareMolecule,
    setCompareMolecule,
    addToCache,
    getFromCache,
    addToSearchHistory,
  } = useMoleculeStore();

  const searchMolecule = async (name: string) => {
    if (!name.trim()) return;
    setIsSearching(true);
    setSearchError('');

    try {
      const cached = getFromCache(name);
      if (cached) {
        setCompareMolecule(cached);
        addToSearchHistory(name);
        setSearchQuery('');
        return;
      }
      const mol = await fetchMoleculeByName(name);
      addToCache(name, mol);
      setCompareMolecule(mol);
      addToSearchHistory(name);
      setSearchQuery('');
    } catch (err: unknown) {
      setSearchError(err instanceof Error ? err.message : 'Not found');
    } finally {
      setIsSearching(false);
    }
  };



  const CompareRow: React.FC<{
    label: string;
    val1: string;
    val2: string;
    unit?: string;
    higherIsBetter?: boolean;
  }> = ({ label, val1, val2, unit = '', higherIsBetter }) => {
    const n1 = parseFloat(val1);
    const n2 = parseFloat(val2);
    const bothNumeric = !isNaN(n1) && !isNaN(n2);
    const comparison = bothNumeric ? (n1 > n2 ? 1 : n1 < n2 ? -1 : 0) : 0;

    const getHighlight = (isFirst: boolean) => {
      if (!bothNumeric || n1 === n2) return '';
      const isHigher = isFirst ? comparison > 0 : comparison < 0;
      if (higherIsBetter === undefined) return '';
      return isHigher === higherIsBetter ? 'text-green-400' : 'text-red-400';
    };

    return (
      <div className="grid grid-cols-[1fr,auto,1fr] items-center gap-2 py-2 border-b border-slate-700/30">
        <div className={`text-right text-sm font-medium ${getHighlight(true)}`}>
          {val1 !== 'N/A' ? val1 + (unit ? ` ${unit}` : '') : '—'}
        </div>
        <div className="text-xs text-slate-500 px-2 text-center min-w-[100px]">{label}</div>
        <div className={`text-left text-sm font-medium ${getHighlight(false)}`}>
          {val2 !== 'N/A' ? val2 + (unit ? ` ${unit}` : '') : '—'}
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full">
      {!compareMolecule ? (
        <div className="space-y-4">
          <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-700/50">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <ArrowLeftRight size={16} className="text-cyan-400" />
              Compare Molecules Side-by-Side
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Load a primary molecule using the search above, then search for a second molecule here to compare.
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                searchMolecule(searchQuery);
              }}
              className="flex gap-2"
            >
              <div className="relative flex-1">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search molecule to compare..."
                  className="w-full bg-slate-700 border border-slate-600 text-white placeholder-slate-400 rounded-xl pl-8 pr-3 py-2.5 text-sm focus:outline-none focus:border-purple-500 transition-all"
                />
              </div>
              <button
                type="submit"
                disabled={isSearching || !searchQuery.trim()}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white rounded-xl text-sm font-medium flex items-center gap-1 transition-all"
              >
                {isSearching ? <Loader2 size={14} className="animate-spin" /> : <Search size={14} />}
              </button>
            </form>

            {searchError && (
              <p className="mt-2 text-xs text-red-400">⚠️ {searchError}</p>
            )}
          </div>

          {/* Suggestions */}
          <div>
            <p className="text-xs text-slate-400 mb-2">Try comparing with:</p>
            <div className="flex flex-wrap gap-1.5">
              {COMPARE_SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => searchMolecule(s)}
                  disabled={isSearching}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-purple-500/40 text-slate-400 hover:text-white rounded-lg text-xs transition-all disabled:opacity-50"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {/* Clear button */}
          <button
            onClick={() => setCompareMolecule(null)}
            className="flex items-center gap-1 text-xs text-slate-400 hover:text-red-400 transition-colors ml-auto"
          >
            <X size={12} /> Clear comparison
          </button>

          {/* Side-by-side viewers */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <p className="text-xs font-medium text-cyan-400 text-center truncate">
                {currentMolecule?.properties?.molecularFormula || '—'} — {currentMolecule?.name || 'Primary'}
              </p>
              <div className="h-40 rounded-xl overflow-hidden bg-slate-900">
                {currentMolecule?.sdfData ? (
                  <MoleculeViewer3D sdfData={currentMolecule.sdfData} compact />
                ) : (
                  <div className="h-full flex items-center justify-center text-slate-500 text-sm">
                    No molecule loaded
                  </div>
                )}
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-xs font-medium text-purple-400 text-center truncate">
                {compareMolecule.properties?.molecularFormula || '—'} — {compareMolecule.name}
              </p>
              <div className="h-40 rounded-xl overflow-hidden bg-slate-900">
                <MoleculeViewer3D sdfData={compareMolecule.sdfData} compact />
              </div>
            </div>
          </div>

          {/* Property comparison table */}
          {currentMolecule?.properties && compareMolecule.properties && (
            <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl overflow-hidden">
              <div className="grid grid-cols-[1fr,auto,1fr] bg-slate-800 px-3 py-2">
                <p className="text-xs font-semibold text-cyan-400 text-right truncate pr-2">
                  {currentMolecule.name}
                </p>
                <div className="w-[100px]" />
                <p className="text-xs font-semibold text-purple-400 text-left truncate pl-2">
                  {compareMolecule.name}
                </p>
              </div>
              <div className="px-3">
                <CompareRow
                  label="Formula"
                  val1={currentMolecule.properties.molecularFormula}
                  val2={compareMolecule.properties.molecularFormula}
                />
                <CompareRow
                  label="MW (g/mol)"
                  val1={parseFloat(currentMolecule.properties.molecularWeight).toFixed(2)}
                  val2={parseFloat(compareMolecule.properties.molecularWeight).toFixed(2)}
                />
                <CompareRow
                  label="LogP"
                  val1={currentMolecule.properties.xLogP}
                  val2={compareMolecule.properties.xLogP}
                />
                <CompareRow
                  label="H-Bond Donors"
                  val1={currentMolecule.properties.hBondDonorCount}
                  val2={compareMolecule.properties.hBondDonorCount}
                />
                <CompareRow
                  label="H-Bond Acceptors"
                  val1={currentMolecule.properties.hBondAcceptorCount}
                  val2={compareMolecule.properties.hBondAcceptorCount}
                />
                <CompareRow
                  label="TPSA (Ų)"
                  val1={parseFloat(currentMolecule.properties.topologicalPolarSurfaceArea).toFixed(1)}
                  val2={parseFloat(compareMolecule.properties.topologicalPolarSurfaceArea).toFixed(1)}
                />
                <CompareRow
                  label="Rotatable Bonds"
                  val1={currentMolecule.properties.rotatableBondCount}
                  val2={compareMolecule.properties.rotatableBondCount}
                />
                <CompareRow
                  label="Heavy Atoms"
                  val1={currentMolecule.properties.heavyAtomCount}
                  val2={compareMolecule.properties.heavyAtomCount}
                />
              </div>
            </div>
          )}

          {/* Add another molecule search */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              searchMolecule(searchQuery);
            }}
            className="flex gap-2"
          >
            <div className="relative flex-1">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Compare with a different molecule..."
                className="w-full bg-slate-700 border border-slate-600 text-white placeholder-slate-400 rounded-xl pl-8 pr-3 py-2 text-sm focus:outline-none focus:border-purple-500 transition-all"
              />
            </div>
            <button
              type="submit"
              disabled={isSearching || !searchQuery.trim()}
              className="px-3 py-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white rounded-xl text-sm font-medium flex items-center gap-1 transition-all"
            >
              {isSearching ? <Loader2 size={14} className="animate-spin" /> : 'Swap'}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
