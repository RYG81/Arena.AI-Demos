import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useMoleculeStore } from '../store/moleculeStore';
import { RotateCw, ZoomIn, ZoomOut, Maximize2, Eye } from 'lucide-react';

declare global {
  interface Window {
    $3Dmol: {
      createViewer: (element: HTMLElement, config?: Record<string, unknown>) => Viewer3D;
      elementColors: { Jmol: Record<string, string> };
    };
  }
}

interface Viewer3D {
  addModel: (data: string, format: string) => void;
  setStyle: (sel: object, style: object) => void;
  zoomTo: () => void;
  render: () => void;
  zoom: (factor: number, animationDuration?: number) => void;
  rotate: (angle: number, axis: string) => void;
  clear: () => void;
  setBackgroundColor: (color: string, opacity?: number) => void;
  addSurface: (type: number, style: object, sel?: object) => void;
  removeAllSurfaces: () => void;
  removeAllLabels: () => void;
  addLabel: (text: string, style: object, sel: object) => void;
  setSlab: (near: number, far: number) => void;
  getView: () => number[];
  setView: (view: number[]) => void;
  stopAnimate: () => void;
  animate: (config: object) => void;
}

interface MoleculeViewer3DProps {
  sdfData: string;
  title?: string;
  compact?: boolean;
}

const STYLE_OPTIONS = [
  { value: 'stick', label: 'Stick', icon: '─' },
  { value: 'sphere', label: 'Space Fill', icon: '●' },
  { value: 'line', label: 'Wire', icon: '╌' },
  { value: 'cross', label: 'Cross', icon: '✚' },
];

export const MoleculeViewer3D: React.FC<MoleculeViewer3DProps> = ({
  sdfData,
  title,
  compact = false,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<Viewer3D | null>(null);
  const [viewerReady, setViewerReady] = useState(false);
  // const [isAnimating, setIsAnimating] = useState(false);
  const [showSurface, setShowSurface] = useState(false);
  const [loading3dmol, setLoading3dmol] = useState(true);
  const { vizStyle, updateVizStyle } = useMoleculeStore();

  // Load 3Dmol.js from CDN
  useEffect(() => {
    if (window.$3Dmol) {
      setLoading3dmol(false);
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://3dmol.org/build/3Dmol-min.js';
    script.async = true;
    script.onload = () => setLoading3dmol(false);
    script.onerror = () => setLoading3dmol(false);
    document.head.appendChild(script);
  }, []);

  const initViewer = useCallback(() => {
    if (!containerRef.current || !window.$3Dmol || !sdfData) return;

    try {
      if (viewerRef.current) {
        viewerRef.current.clear();
      } else {
        viewerRef.current = window.$3Dmol.createViewer(containerRef.current, {
          backgroundColor: vizStyle.backgroundColor,
          antialias: true,
          disableFog: false,
        });
      }

      const viewer = viewerRef.current;
      viewer.setBackgroundColor(vizStyle.backgroundColor);
      viewer.addModel(sdfData, 'sdf');

      applyStyle(viewer);

      viewer.zoomTo();
      viewer.render();
      setViewerReady(true);
    } catch (e) {
      console.error('3Dmol viewer error:', e);
    }
  }, [sdfData, vizStyle.backgroundColor]);

  const applyStyle = (viewer: Viewer3D) => {
    viewer.removeAllLabels();

    const styleConfig: Record<string, unknown> = {};

    if (vizStyle.type === 'stick') {
      styleConfig.stick = {
        radius: 0.15,
        colorscheme: vizStyle.colorScheme === 'element' ? 'Jmol' : vizStyle.colorScheme,
        opacity: vizStyle.opacity,
      };
      styleConfig.sphere = {
        radius: 0.3,
        colorscheme: vizStyle.colorScheme === 'element' ? 'Jmol' : vizStyle.colorScheme,
        opacity: vizStyle.opacity,
      };
    } else if (vizStyle.type === 'sphere') {
      styleConfig.sphere = {
        colorscheme: vizStyle.colorScheme === 'element' ? 'Jmol' : vizStyle.colorScheme,
        opacity: vizStyle.opacity,
      };
    } else if (vizStyle.type === 'line') {
      styleConfig.line = {
        colorscheme: vizStyle.colorScheme === 'element' ? 'Jmol' : vizStyle.colorScheme,
        opacity: vizStyle.opacity,
      };
    } else if (vizStyle.type === 'cross') {
      styleConfig.cross = {
        linewidth: 5,
        colorscheme: vizStyle.colorScheme === 'element' ? 'Jmol' : vizStyle.colorScheme,
        opacity: vizStyle.opacity,
      };
    }

    viewer.setStyle({}, styleConfig);

    if (vizStyle.showLabels) {
      viewer.addLabel('', { fontSize: 10, fontColor: 'white', showBackground: false }, {});
    }
  };

  useEffect(() => {
    if (!loading3dmol) {
      initViewer();
    }
  }, [loading3dmol, initViewer]);

  useEffect(() => {
    if (viewerRef.current && viewerReady) {
      applyStyle(viewerRef.current);
      viewerRef.current.render();
    }
  }, [vizStyle, viewerReady]);

  useEffect(() => {
    if (viewerRef.current && viewerReady && showSurface) {
      try {
        viewerRef.current.addSurface(1, {
          opacity: 0.6,
          colorscheme: { gradient: 'rwb', min: -1, max: 1 },
        });
        viewerRef.current.render();
      } catch {
        // Surface not available
      }
    } else if (viewerRef.current && viewerReady && !showSurface) {
      try {
        viewerRef.current.removeAllSurfaces();
        viewerRef.current.render();
      } catch { /* */ }
    }
  }, [showSurface, viewerReady]);

  const handleZoomIn = () => viewerRef.current?.zoom(1.3, 300);
  const handleZoomOut = () => viewerRef.current?.zoom(0.7, 300);
  const handleReset = () => {
    if (viewerRef.current) {
      viewerRef.current.zoomTo();
      viewerRef.current.render();
    }
  };

  // const toggleAnimation = () => {
  //   if (!viewerRef.current) return;
  //   if (isAnimating) {
  //     viewerRef.current.stopAnimate();
  //   } else {
  //     viewerRef.current.animate({ loop: 'forward', reps: 0 });
  //   }
  //   setIsAnimating(!isAnimating);
  // };

  return (
    <div className="relative w-full h-full flex flex-col bg-slate-900 rounded-xl overflow-hidden">
      {/* Header */}
      {!compact && title && (
        <div className="flex items-center justify-between px-4 py-2 bg-slate-800/80 border-b border-slate-700">
          <span className="text-sm font-semibold text-cyan-400 truncate">{title}</span>
          <div className="flex gap-2">
            {STYLE_OPTIONS.map((s) => (
              <button
                key={s.value}
                onClick={() => updateVizStyle({ type: s.value as typeof vizStyle.type })}
                className={`px-2 py-1 text-xs rounded transition-all ${
                  vizStyle.type === s.value
                    ? 'bg-cyan-500 text-white'
                    : 'bg-slate-700 text-slate-400 hover:bg-slate-600'
                }`}
                title={s.label}
              >
                {s.icon} {s.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Viewer */}
      <div className="relative flex-1">
        {(loading3dmol || !sdfData) && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900 z-10">
            {loading3dmol ? (
              <>
                <div className="w-16 h-16 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mb-4" />
                <p className="text-cyan-400 text-sm">Loading 3D engine...</p>
              </>
            ) : (
              <div className="text-center">
                <div className="text-6xl mb-4">🧪</div>
                <p className="text-slate-400">Search for a molecule to visualize</p>
              </div>
            )}
          </div>
        )}
        <div
          ref={containerRef}
          className="w-full h-full"
          style={{ minHeight: compact ? '200px' : '400px' }}
        />
      </div>

      {/* Controls */}
      {!compact && (
        <div className="absolute bottom-4 right-4 flex flex-col gap-2">
          <button
            onClick={handleZoomIn}
            className="w-9 h-9 bg-slate-800/90 hover:bg-slate-700 text-white rounded-lg flex items-center justify-center border border-slate-600 transition-all shadow-lg"
            title="Zoom In"
          >
            <ZoomIn size={15} />
          </button>
          <button
            onClick={handleZoomOut}
            className="w-9 h-9 bg-slate-800/90 hover:bg-slate-700 text-white rounded-lg flex items-center justify-center border border-slate-600 transition-all shadow-lg"
            title="Zoom Out"
          >
            <ZoomOut size={15} />
          </button>
          <button
            onClick={handleReset}
            className="w-9 h-9 bg-slate-800/90 hover:bg-slate-700 text-white rounded-lg flex items-center justify-center border border-slate-600 transition-all shadow-lg"
            title="Reset View"
          >
            <RotateCw size={15} />
          </button>
          <button
            onClick={() => setShowSurface(!showSurface)}
            className={`w-9 h-9 rounded-lg flex items-center justify-center border transition-all shadow-lg ${
              showSurface
                ? 'bg-cyan-600 border-cyan-500 text-white'
                : 'bg-slate-800/90 hover:bg-slate-700 text-white border-slate-600'
            }`}
            title="Toggle Surface"
          >
            <Eye size={15} />
          </button>
          <button
            onClick={handleReset}
            className="w-9 h-9 bg-slate-800/90 hover:bg-slate-700 text-white rounded-lg flex items-center justify-center border border-slate-600 transition-all shadow-lg"
            title="Fullscreen"
          >
            <Maximize2 size={15} />
          </button>
        </div>
      )}

      {/* Color scheme selector */}
      {!compact && (
        <div className="absolute bottom-4 left-4 flex gap-2">
          {[
            { label: 'CPK', value: 'element' },
            { label: 'Rainbow', value: 'spectrum' },
            { label: 'Chain', value: 'chain' },
          ].map((cs) => (
            <button
              key={cs.value}
              onClick={() => updateVizStyle({ colorScheme: cs.value as typeof vizStyle.colorScheme })}
              className={`px-2 py-1 text-xs rounded transition-all ${
                vizStyle.colorScheme === cs.value
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-800/80 text-slate-400 hover:bg-slate-700'
              }`}
            >
              {cs.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
