import React, { useState } from 'react';
import { useMoleculeStore } from '../store/moleculeStore';
import { generateQuizQuestions } from '../services/aiService';
import { Brain, CheckCircle, XCircle, Loader2, RotateCcw, Trophy, Zap } from 'lucide-react';

export const QuizPanel: React.FC = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [genError, setGenError] = useState('');

  const {
    currentMolecule,
    quizQuestions,
    quizAnswers,
    quizSubmitted,
    setQuizQuestions,
    setQuizAnswer,
    submitQuiz,
    resetQuiz,
    aiProvider,
    openaiKey,
    deepseekKey,
    selectedModel,
  } = useMoleculeStore();

  const getApiKey = () => {
    if (aiProvider === 'openai') return openaiKey;
    if (aiProvider === 'deepseek') return deepseekKey;
    return '';
  };

  const generateQuiz = async () => {
    if (!currentMolecule) return;
    setIsGenerating(true);
    setGenError('');
    resetQuiz();

    try {
      const questions = await generateQuizQuestions(
        currentMolecule,
        aiProvider,
        getApiKey(),
        selectedModel
      );
      setQuizQuestions(questions);
    } catch (err: unknown) {
      setGenError(err instanceof Error ? err.message : 'Failed to generate quiz');
    } finally {
      setIsGenerating(false);
    }
  };

  const score = quizSubmitted
    ? quizQuestions.filter((q) => quizAnswers[q.id] === q.correct).length
    : 0;

  const allAnswered = quizQuestions.length > 0 && quizQuestions.every((q) => quizAnswers[q.id] !== undefined);

  if (!currentMolecule) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="text-5xl mb-3">🎓</div>
        <p className="text-slate-300 font-medium mb-1">No molecule loaded</p>
        <p className="text-slate-500 text-sm">Search for a molecule to generate a quiz</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Brain size={18} className="text-purple-400" />
          <h3 className="font-semibold text-white text-sm">
            Quiz: {currentMolecule.name}
          </h3>
        </div>
        {quizQuestions.length > 0 && (
          <button
            onClick={() => { resetQuiz(); setQuizQuestions([]); }}
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
          >
            <RotateCcw size={12} /> Reset
          </button>
        )}
      </div>

      {/* Generate button */}
      {quizQuestions.length === 0 && (
        <div className="space-y-3">
          <div className="p-4 bg-purple-900/20 border border-purple-700/30 rounded-xl">
            <p className="text-sm text-slate-300 mb-3">
              Test your knowledge about <strong className="text-purple-400">{currentMolecule.name}</strong>!
              The quiz covers molecular properties, bonding, and applications.
            </p>
            <div className="flex flex-wrap gap-2 text-xs text-slate-400 mb-4">
              <span className="px-2 py-1 bg-slate-800 rounded-lg">🔬 5 Questions</span>
              <span className="px-2 py-1 bg-slate-800 rounded-lg">📈 Progressive difficulty</span>
              <span className="px-2 py-1 bg-slate-800 rounded-lg">💡 Explanations included</span>
              {aiProvider !== 'demo' && (
                <span className="px-2 py-1 bg-slate-800 rounded-lg text-cyan-400">🤖 AI-generated</span>
              )}
            </div>
            <button
              onClick={generateQuiz}
              disabled={isGenerating}
              className="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 disabled:opacity-40 text-white font-semibold rounded-xl text-sm transition-all flex items-center justify-center gap-2 shadow-lg"
            >
              {isGenerating ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  Generating Questions...
                </>
              ) : (
                <>
                  <Zap size={16} />
                  Generate Quiz
                </>
              )}
            </button>

            {genError && (
              <p className="mt-2 text-xs text-red-400">⚠️ {genError}</p>
            )}
          </div>
        </div>
      )}

      {/* Score banner */}
      {quizSubmitted && (
        <div
          className={`p-4 rounded-xl border flex items-center gap-3 ${
            score >= 4
              ? 'bg-green-900/30 border-green-700/50'
              : score >= 3
              ? 'bg-yellow-900/30 border-yellow-700/50'
              : 'bg-red-900/30 border-red-700/50'
          }`}
        >
          <Trophy
            size={24}
            className={score >= 4 ? 'text-green-400' : score >= 3 ? 'text-yellow-400' : 'text-red-400'}
          />
          <div>
            <p className="font-bold text-white">
              {score}/{quizQuestions.length} Correct
            </p>
            <p className="text-sm text-slate-400">
              {score >= 4
                ? '🎉 Excellent! You really know this molecule!'
                : score >= 3
                ? '👍 Good job! Review the missed questions.'
                : '📚 Keep studying — check the explanations!'}
            </p>
          </div>
          <button
            onClick={generateQuiz}
            className="ml-auto px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white text-xs rounded-lg transition-all flex items-center gap-1"
          >
            <RotateCcw size={12} /> Retry
          </button>
        </div>
      )}

      {/* Questions */}
      {quizQuestions.map((q, idx) => {
        const answered = quizAnswers[q.id] !== undefined;
        const isCorrect = answered && quizAnswers[q.id] === q.correct;

        return (
          <div
            key={q.id}
            className={`bg-slate-800/50 border rounded-xl p-4 space-y-3 transition-all ${
              quizSubmitted
                ? isCorrect
                  ? 'border-green-500/30'
                  : answered
                  ? 'border-red-500/30'
                  : 'border-slate-700/50'
                : 'border-slate-700/50'
            }`}
          >
            <div className="flex items-start gap-2">
              <span className="text-xs font-bold text-slate-500 bg-slate-700 rounded-full w-5 h-5 flex items-center justify-center flex-shrink-0 mt-0.5">
                {idx + 1}
              </span>
              <p className="text-sm font-medium text-white">{q.question}</p>
            </div>

            <div className="space-y-2">
              {q.options.map((opt, optIdx) => {
                const isSelected = quizAnswers[q.id] === optIdx;
                const isCorrectOpt = optIdx === q.correct;
                const showResult = quizSubmitted;

                let optStyle = 'bg-slate-700/50 border-slate-600 text-slate-300 hover:bg-slate-700 hover:border-slate-500';
                if (isSelected && !showResult) {
                  optStyle = 'bg-purple-600/30 border-purple-500 text-white';
                }
                if (showResult && isCorrectOpt) {
                  optStyle = 'bg-green-600/20 border-green-500 text-green-300';
                } else if (showResult && isSelected && !isCorrectOpt) {
                  optStyle = 'bg-red-600/20 border-red-500 text-red-300';
                }

                return (
                  <button
                    key={optIdx}
                    onClick={() => !quizSubmitted && setQuizAnswer(q.id, optIdx)}
                    disabled={quizSubmitted}
                    className={`w-full text-left px-3 py-2.5 rounded-xl border text-sm transition-all flex items-center gap-2 ${optStyle}`}
                  >
                    <span className="text-xs font-bold text-slate-500 w-4 flex-shrink-0">
                      {String.fromCharCode(65 + optIdx)}
                    </span>
                    <span className="flex-1">{opt}</span>
                    {showResult && isCorrectOpt && <CheckCircle size={14} className="text-green-400 flex-shrink-0" />}
                    {showResult && isSelected && !isCorrectOpt && <XCircle size={14} className="text-red-400 flex-shrink-0" />}
                  </button>
                );
              })}
            </div>

            {/* Explanation */}
            {quizSubmitted && (
              <div className="pt-2 border-t border-slate-700/50">
                <p className="text-xs text-slate-400 leading-relaxed">
                  <span className="font-semibold text-cyan-400">Explanation: </span>
                  {q.explanation}
                </p>
              </div>
            )}
          </div>
        );
      })}

      {/* Submit button */}
      {quizQuestions.length > 0 && !quizSubmitted && (
        <button
          onClick={submitQuiz}
          disabled={!allAnswered}
          className="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold rounded-xl text-sm transition-all flex items-center justify-center gap-2 shadow-lg"
        >
          <CheckCircle size={16} />
          Submit Quiz ({Object.keys(quizAnswers).length}/{quizQuestions.length} answered)
        </button>
      )}
    </div>
  );
};
