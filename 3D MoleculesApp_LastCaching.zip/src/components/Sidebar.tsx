import React from 'react';
import { useMoleculeStore, ActivePanel } from '../store/moleculeStore';
import { MoleculeSearch } from './MoleculeSearch';
import { MoleculeProperties } from './MoleculeProperties';
import { ComparePanel } from './ComparePanel';
import { LearnPanel } from './LearnPanel';
import { QuizPanel } from './QuizPanel';
import { SettingsPanel } from './SettingsPanel';
import {
  Atom,
  ArrowLeftRight,
  BookOpen,
  Brain,
  Settings,
  ChevronLeft,
  ChevronRight,
  FlaskConical,
} from 'lucide-react';

const NAV_ITEMS: Array<{
  id: ActivePanel;
  label: string;
  icon: React.ReactNode;
  color: string;
}> = [
  { id: 'viewer', label: 'Molecule', icon: <Atom size={18} />, color: 'text-cyan-400' },
  { id: 'compare', label: 'Compare', icon: <ArrowLeftRight size={18} />, color: 'text-purple-400' },
  { id: 'learn', label: 'Learn', icon: <BookOpen size={18} />, color: 'text-green-400' },
  { id: 'quiz', label: 'Quiz', icon: <Brain size={18} />, color: 'text-yellow-400' },
  { id: 'settings', label: 'Settings', icon: <Settings size={18} />, color: 'text-slate-400' },
];

export const Sidebar: React.FC = () => {
  const { activePanel, setActivePanel, sidebarOpen, setSidebarOpen } = useMoleculeStore();

  return (
    <aside
      className={`flex flex-col bg-slate-950 border-r border-slate-800 transition-all duration-300 relative flex-shrink-0 ${
        sidebarOpen ? 'w-[340px]' : 'w-16'
      }`}
    >
      {/* Toggle button */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="absolute -right-3 top-6 z-20 w-6 h-6 bg-slate-700 hover:bg-slate-600 border border-slate-600 rounded-full flex items-center justify-center text-slate-300 hover:text-white transition-all shadow-lg"
      >
        {sidebarOpen ? <ChevronLeft size={12} /> : <ChevronRight size={12} />}
      </button>

      {/* Logo */}
      <div className={`flex items-center gap-3 px-4 py-4 border-b border-slate-800 ${!sidebarOpen ? 'justify-center' : ''}`}>
        <div className="w-9 h-9 bg-gradient-to-br from-cyan-500 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
          <FlaskConical size={20} className="text-white" />
        </div>
        {sidebarOpen && (
          <div>
            <h1 className="font-bold text-white text-base leading-none">MoleculeAI</h1>
            <p className="text-xs text-slate-400">3D Intelligence Platform</p>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className={`flex gap-1 p-2 border-b border-slate-800 ${sidebarOpen ? '' : 'flex-col'}`}>
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => setActivePanel(item.id)}
            title={!sidebarOpen ? item.label : undefined}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-all ${
              sidebarOpen ? 'flex-1' : 'w-full justify-center'
            } ${
              activePanel === item.id
                ? `bg-slate-800 ${item.color} border border-slate-700`
                : 'text-slate-500 hover:text-slate-300 hover:bg-slate-900'
            }`}
          >
            <span className={activePanel === item.id ? item.color : ''}>{item.icon}</span>
            {sidebarOpen && <span className="truncate">{item.label}</span>}
          </button>
        ))}
      </nav>

      {/* Content */}
      {sidebarOpen && (
        <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
          {/* Search (always visible) */}
          {activePanel !== 'settings' && (
            <div>
              <MoleculeSearch />
            </div>
          )}

          {/* Panel content */}
          <div>
            {activePanel === 'viewer' && <MoleculeProperties />}
            {activePanel === 'compare' && <ComparePanel />}
            {activePanel === 'learn' && <LearnPanel />}
            {activePanel === 'quiz' && <QuizPanel />}
            {activePanel === 'settings' && <SettingsPanel />}
          </div>
        </div>
      )}
    </aside>
  );
};
