import React, { useState } from 'react';
import { useMoleculeStore } from '../store/moleculeStore';
import { BookOpen, ChevronRight, Atom, Beaker, Zap, Globe, Pill, FlaskConical } from 'lucide-react';

interface LessonModule {
  id: string;
  title: string;
  icon: React.ReactNode;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  color: string;
  content: string;
}

const CHEMISTRY_LESSONS: LessonModule[] = [
  {
    id: 'bonding',
    title: 'Chemical Bonding',
    icon: <Atom size={18} />,
    level: 'Beginner',
    color: 'from-blue-500 to-cyan-500',
    content: `## Chemical Bonding

**What holds molecules together?**

Chemical bonds form because atoms seek a lower energy state by sharing or transferring electrons.

### Types of Bonds:

**🔵 Ionic Bonds**
- Electron transfer from metal to nonmetal
- Form crystal lattice structures
- High melting points, conduct electricity when dissolved
- Example: NaCl (table salt)

**🟢 Covalent Bonds**
- Electrons *shared* between atoms
- Form discrete molecules
- Can be single (σ), double (σ+π), or triple (σ+2π)
- Example: H₂O, CO₂, CH₄

**🟡 Metallic Bonds**
- Electrons delocalized in a "sea"
- Explain conductivity and malleability of metals
- Example: Iron, copper, aluminum

### Bond Strength:
Triple > Double > Single (stronger = shorter = higher energy to break)

### Bond Polarity:
When atoms have different **electronegativities**, the shared electrons are pulled more toward one atom, creating a *polar bond*.
- Δχ < 0.5: Nonpolar covalent
- 0.5 < Δχ < 1.7: Polar covalent  
- Δχ > 1.7: Ionic`,
  },
  {
    id: 'vsepr',
    title: 'Molecular Geometry (VSEPR)',
    icon: <Globe size={18} />,
    level: 'Intermediate',
    color: 'from-green-500 to-emerald-500',
    content: `## VSEPR Theory

**Valence Shell Electron Pair Repulsion** explains the 3D shape of molecules.

### Core Principle:
Electron pairs (bonding and lone pairs) repel each other and arrange themselves to **maximize distance**.

### Geometry Table:

| Electron Domains | Geometry | Bond Angle | Example |
|:---:|:---:|:---:|:---:|
| 2 | Linear | 180° | CO₂, C₂H₂ |
| 3 | Trigonal Planar | 120° | BF₃, SO₃ |
| 4 | Tetrahedral | 109.5° | CH₄, SiCl₄ |
| 3+1 lone pair | Trigonal Pyramidal | <109.5° | NH₃ |
| 2+2 lone pairs | Bent | <109.5° | H₂O |
| 5 | Trigonal Bipyramidal | 90°/120° | PCl₅ |
| 6 | Octahedral | 90° | SF₆ |

### Lone Pair Effect:
Lone pairs occupy **more space** than bonding pairs!
- Each lone pair reduces bond angles by ~2.5°
- H₂O: 2 lone pairs → bent with 104.5° angle (not 109.5°)
- NH₃: 1 lone pair → pyramidal with 107° angle

### Memory Tip:
**"Lone pairs squish the bonds!"**`,
  },
  {
    id: 'hybridization',
    title: 'Hybridization',
    icon: <Zap size={18} />,
    level: 'Intermediate',
    color: 'from-yellow-500 to-orange-500',
    content: `## Orbital Hybridization

**Why do carbon atoms form 4 identical bonds?**

Pure s and p orbitals don't explain bonding geometry. **Hybridization** = mixing atomic orbitals to form new hybrid orbitals.

### sp³ Hybridization
- 1 s + 3 p orbitals → 4 equivalent sp³ orbitals
- **Tetrahedral** geometry, 109.5°
- Examples: CH₄, NH₃, H₂O, C in alkanes
- All **sigma (σ)** bonds

### sp² Hybridization  
- 1 s + 2 p orbitals → 3 sp² orbitals + 1 unhybridized p
- **Trigonal planar** geometry, 120°
- The leftover p orbital forms **π bond** (double bond)
- Examples: ethylene (C₂H₄), benzene, carbonyl groups

### sp Hybridization
- 1 s + 1 p orbital → 2 sp orbitals + 2 unhybridized p
- **Linear** geometry, 180°
- 2 unhybridized p orbitals form **2 π bonds** (triple bond)
- Examples: C₂H₂ (acetylene), CO₂, HCN

### Quick Rule:
**Count electron domains around atom:**
- 4 domains → sp³
- 3 domains → sp²
- 2 domains → sp

### Sigma vs Pi:
- σ bonds: Head-on overlap, allow rotation
- π bonds: Sideways overlap, **restrict rotation** (cis/trans isomers!)`,
  },
  {
    id: 'intermolecular',
    title: 'Intermolecular Forces',
    icon: <Beaker size={18} />,
    level: 'Intermediate',
    color: 'from-purple-500 to-pink-500',
    content: `## Intermolecular Forces

Forces between molecules (not within!) determine physical properties: **boiling point, viscosity, solubility**.

### Types (weakest → strongest):

**1. London Dispersion Forces (LDF)**
- Present in ALL molecules
- Temporary dipoles from electron fluctuations
- Strength increases with: more electrons, larger surface area
- Noble gases, alkanes, nonpolar molecules
- Example: I₂ is solid due to strong LDF

**2. Dipole-Dipole Interactions**
- Between *polar* molecules
- Positive end attracts negative end
- ~1-3 kJ/mol stronger than LDF alone
- Example: HCl, acetone

**3. Hydrogen Bonding** ⭐
- Special case: H bonded to N, O, or F
- Exceptionally strong dipole-dipole
- Explains:
  - Water's anomalously high boiling point (100°C vs expected -80°C)
  - Ice being less dense than water
  - DNA base pairing
  - Protein structure

**4. Ion-Dipole** (not IMF but important!)
- Between ions and polar molecules
- Explains why salts dissolve in water
- Very strong (~40-600 kJ/mol)

### Rule: "Like dissolves like"
Polar solvents (water) dissolve polar/ionic solutes
Nonpolar solvents (hexane) dissolve nonpolar solutes`,
  },
  {
    id: 'druglikeness',
    title: 'Drug Design & Lipinski Rules',
    icon: <Pill size={18} />,
    level: 'Advanced',
    color: 'from-red-500 to-pink-500',
    content: `## Drug Design: Lipinski's Rule of Five

**How do chemists design drugs that actually work in the body?**

### Lipinski's Rule of Five (Ro5)

For oral bioavailability, a drug candidate should have:

| Property | Limit | Why? |
|:---:|:---:|:---:|
| Molecular Weight | ≤ 500 g/mol | Must fit through membrane pores |
| LogP (lipophilicity) | ≤ 5 | Must dissolve in both water and lipids |
| H-bond donors | ≤ 5 | H-bonds slow membrane crossing |
| H-bond acceptors | ≤ 10 | Same reason |

### Why These Rules?

Oral drugs must:
1. **Dissolve** in intestinal fluid (need some hydrophilicity)
2. **Cross intestinal membrane** (need some lipophilicity)
3. **Enter bloodstream** without being pumped back out
4. **Reach target tissue** without being metabolized too fast

### The ADMET Framework:
- **A**bsorption: Getting into the bloodstream
- **D**istribution: Reaching the target organ
- **M**etabolism: How the liver processes it
- **E**xcretion: Elimination from body
- **T**oxicity: Safety profile

### Modern Drug Discovery:
Beyond Ro5, scientists now use:
- **TPSA** < 90 Ų for oral drugs
- **Rotatable bonds** < 10 for better absorption
- **Bioisosteres** to improve properties while keeping activity
- **Fragment-based** drug design starting from small pieces`,
  },
  {
    id: 'reactions',
    title: 'Organic Reaction Mechanisms',
    icon: <FlaskConical size={18} />,
    level: 'Advanced',
    color: 'from-teal-500 to-cyan-500',
    content: `## Organic Reaction Mechanisms

Understanding *how* reactions happen at the electron level.

### Core Concept: Electrons Move!
Arrow pushing shows how electrons flow:
- Curved arrow from electrons → where they go
- Full arrow = 2 electrons moving (heterolytic)
- Half arrow = 1 electron (homolytic, radicals)

### Key Reaction Types:

**SN2 (Substitution Nucleophilic Bimolecular)**
- Backside attack by nucleophile
- One step, inversion of configuration ("Walden inversion")
- Favored: primary substrates, strong nucleophile, polar aprotic solvent
- Rate = k[substrate][nucleophile]

**SN1 (Substitution Nucleophilic Unimolecular)**
- Carbocation intermediate forms first
- Racemization of stereocenter
- Favored: tertiary substrates, weak nucleophile, polar protic solvent
- Rate = k[substrate] only

**E2 (Elimination Bimolecular)**
- Concerted: base, H, and leaving group all involved at once
- Anti-periplanar requirement (180°)
- Zaitsev's rule: major product = more substituted alkene

**E1 (Elimination Unimolecular)**
- Carbocation forms first (like SN1)
- Then elimination occurs
- Competes with SN1 (temperature favors E1)

**Addition to Alkenes**
- Electrophile attacks π bond first (Markovnikov's rule)
- Carbocation intermediate (more stable = tertiary preferred)
- Nucleophile attacks carbocation

### Key Factors:
1. **Substrate structure**: 1° → SN2; 3° → SN1/E1
2. **Nucleophile strength**: Strong → SN2/E2; Weak → SN1/E1
3. **Solvent**: Polar protic → SN1; Polar aprotic → SN2
4. **Temperature**: High T favors elimination over substitution`,
  },
];

export const LearnPanel: React.FC = () => {
  const [selectedLesson, setSelectedLesson] = useState<LessonModule | null>(null);
  const { currentMolecule, setChatOpen, addChatMessage } = useMoleculeStore();

  const askAIAboutTopic = (lesson: LessonModule) => {
    const question = currentMolecule
      ? `Explain ${lesson.title} as it applies to ${currentMolecule.name}. Use the molecule's properties to give concrete examples.`
      : `Give me an in-depth explanation of ${lesson.title} with specific examples.`;

    addChatMessage({
      id: Date.now().toString(),
      role: 'user',
      content: question,
      timestamp: new Date(),
    });
    setChatOpen(true);
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Beginner': return 'text-green-400 bg-green-900/30 border-green-700/40';
      case 'Intermediate': return 'text-yellow-400 bg-yellow-900/30 border-yellow-700/40';
      case 'Advanced': return 'text-red-400 bg-red-900/30 border-red-700/40';
      default: return 'text-slate-400';
    }
  };

  if (selectedLesson) {
    return (
      <div className="space-y-4">
        <button
          onClick={() => setSelectedLesson(null)}
          className="flex items-center gap-1 text-sm text-slate-400 hover:text-white transition-colors"
        >
          ← Back to lessons
        </button>

        <div className={`p-4 bg-gradient-to-r ${selectedLesson.color} rounded-xl bg-opacity-10`}>
          <div className="flex items-center gap-3">
            <div className="text-white">{selectedLesson.icon}</div>
            <div>
              <h3 className="font-bold text-white">{selectedLesson.title}</h3>
              <span className={`text-xs px-2 py-0.5 rounded-full border ${getLevelColor(selectedLesson.level)}`}>
                {selectedLesson.level}
              </span>
            </div>
          </div>
        </div>

        <div className="prose prose-invert prose-sm max-w-none bg-slate-800/40 border border-slate-700/50 rounded-xl p-4 text-slate-300">
          {selectedLesson.content.split('\n').map((line, i) => {
            if (line.startsWith('## ')) {
              return <h2 key={i} className="text-xl font-bold text-white mt-0 mb-3">{line.slice(3)}</h2>;
            }
            if (line.startsWith('### ')) {
              return <h3 key={i} className="text-base font-semibold text-cyan-400 mt-4 mb-2">{line.slice(4)}</h3>;
            }
            if (line.startsWith('**') && line.endsWith('**')) {
              return <p key={i} className="font-bold text-white my-1">{line.slice(2, -2)}</p>;
            }
            if (line.startsWith('- ')) {
              return <li key={i} className="ml-4 text-sm text-slate-300 my-0.5">{line.slice(2)}</li>;
            }
            if (line.startsWith('| ') || line.startsWith('|:')) {
              return (
                <div key={i} className="font-mono text-xs text-slate-400 bg-slate-900/50 px-2 py-0.5">
                  {line}
                </div>
              );
            }
            if (line.trim() === '') return <br key={i} />;
            return <p key={i} className="text-sm text-slate-300 my-1">{line}</p>;
          })}
        </div>

        <button
          onClick={() => askAIAboutTopic(selectedLesson)}
          className="w-full py-3 bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-semibold rounded-xl text-sm transition-all shadow-lg flex items-center justify-center gap-2"
        >
          <BookOpen size={16} />
          Ask AI to Explain This with {currentMolecule?.name || 'Examples'}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
          <BookOpen size={16} className="text-cyan-400" />
          Chemistry Curriculum
        </h3>
        <p className="text-xs text-slate-400">
          {currentMolecule
            ? `Learn chemistry concepts illustrated with ${currentMolecule.name}`
            : 'Select any topic to start learning'}
        </p>
      </div>

      <div className="space-y-2">
        {CHEMISTRY_LESSONS.map((lesson) => (
          <button
            key={lesson.id}
            onClick={() => setSelectedLesson(lesson)}
            className="w-full flex items-center gap-3 p-3 bg-slate-800/50 hover:bg-slate-800 border border-slate-700/50 hover:border-slate-600 rounded-xl text-left transition-all group"
          >
            <div className={`w-9 h-9 bg-gradient-to-br ${lesson.color} rounded-lg flex items-center justify-center flex-shrink-0 text-white`}>
              {lesson.icon}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white group-hover:text-cyan-400 transition-colors">
                {lesson.title}
              </p>
              <span className={`text-xs px-1.5 py-0.5 rounded border ${getLevelColor(lesson.level)}`}>
                {lesson.level}
              </span>
            </div>
            <ChevronRight size={16} className="text-slate-500 group-hover:text-slate-300 transition-all group-hover:translate-x-1" />
          </button>
        ))}
      </div>

      {currentMolecule && (
        <div className="p-3 bg-cyan-900/20 border border-cyan-700/30 rounded-xl">
          <p className="text-xs text-cyan-400 font-medium mb-1">🧪 Current Molecule: {currentMolecule.name}</p>
          <p className="text-xs text-slate-400">
            Click any lesson to learn how it applies to this molecule. Use the AI chat for personalized explanations!
          </p>
        </div>
      )}
    </div>
  );
};
