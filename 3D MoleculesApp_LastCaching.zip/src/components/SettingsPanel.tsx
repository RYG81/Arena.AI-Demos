import React, { useState } from 'react';
import { useMoleculeStore, AIProvider, VisualizationStyle } from '../store/moleculeStore';
import { Settings, Eye, Key, Palette, Save, CheckCircle, ExternalLink } from 'lucide-react';

const AI_MODELS: Record<AIProvider, string[]> = {
  openai: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-3.5-turbo'],
  deepseek: ['deepseek-chat', 'deepseek-reasoner'],
  demo: ['demo'],
};

export const SettingsPanel: React.FC = () => {
  const [saved, setSaved] = useState(false);
  const [activeTab, setActiveTab] = useState<'ai' | 'display' | 'about'>('ai');

  const {
    aiProvider,
    openaiKey,
    deepseekKey,
    selectedModel,
    setAIProvider,
    setOpenAIKey,
    setDeepseekKey,
    setSelectedModel,
    vizStyle,
    updateVizStyle,
  } = useMoleculeStore();

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const STYLE_TYPES: Array<{ value: VisualizationStyle['type']; label: string; desc: string }> = [
    { value: 'stick', label: 'Ball & Stick', desc: 'Default, shows bonds clearly' },
    { value: 'sphere', label: 'Space-Filling (CPK)', desc: 'Shows relative atom sizes' },
    { value: 'line', label: 'Wireframe', desc: 'Lightweight rendering' },
    { value: 'cross', label: 'Cross', desc: 'Simple cross representation' },
  ];

  const BG_COLORS = [
    { label: 'Dark Navy', value: '#0f172a' },
    { label: 'Black', value: '#000000' },
    { label: 'Dark Gray', value: '#1a1a2e' },
    { label: 'Midnight Blue', value: '#0d0d1a' },
    { label: 'Deep Purple', value: '#1a0d2e' },
    { label: 'White', value: '#ffffff' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Settings size={18} className="text-slate-400" />
        <h3 className="font-semibold text-white text-sm">Platform Settings</h3>
      </div>

      {/* Tabs */}
      <div className="flex bg-slate-800 rounded-xl p-1 gap-1">
        {[
          { id: 'ai', label: 'AI Config', icon: <Key size={13} /> },
          { id: 'display', label: 'Display', icon: <Eye size={13} /> },
          { id: 'about', label: 'About', icon: <Palette size={13} /> },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-medium transition-all ${
              activeTab === tab.id
                ? 'bg-slate-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* AI Config */}
      {activeTab === 'ai' && (
        <div className="space-y-4">
          {/* Provider selector */}
          <div>
            <label className="text-xs text-slate-400 mb-2 block">AI Provider</label>
            <div className="grid grid-cols-3 gap-2">
              {(['openai', 'deepseek', 'demo'] as AIProvider[]).map((p) => (
                <button
                  key={p}
                  onClick={() => {
                    setAIProvider(p);
                    setSelectedModel(AI_MODELS[p][0]);
                  }}
                  className={`py-2.5 px-2 rounded-xl border text-xs font-medium transition-all ${
                    aiProvider === p
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-400'
                      : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500'
                  }`}
                >
                  {p === 'openai' && '🤖 OpenAI'}
                  {p === 'deepseek' && '🧠 DeepSeek'}
                  {p === 'demo' && '⚡ Demo'}
                </button>
              ))}
            </div>
          </div>

          {/* API Key */}
          {aiProvider !== 'demo' && (
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 mb-1.5 flex items-center justify-between">
                  <span>API Key</span>
                  <a
                    href={
                      aiProvider === 'openai'
                        ? 'https://platform.openai.com/api-keys'
                        : 'https://platform.deepseek.com/api_keys'
                    }
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 transition-colors"
                  >
                    Get key <ExternalLink size={10} />
                  </a>
                </label>
                <input
                  type="password"
                  value={aiProvider === 'openai' ? openaiKey : deepseekKey}
                  onChange={(e) =>
                    aiProvider === 'openai'
                      ? setOpenAIKey(e.target.value)
                      : setDeepseekKey(e.target.value)
                  }
                  placeholder={`${aiProvider === 'openai' ? 'sk-...' : 'sk-...'}`}
                  className="w-full bg-slate-700 border border-slate-600 focus:border-cyan-500 text-white placeholder-slate-500 rounded-xl px-3 py-2.5 text-sm font-mono focus:outline-none transition-all"
                />
                <p className="text-xs text-slate-500 mt-1">
                  🔒 Key stored locally in browser memory only — never sent to our servers
                </p>
              </div>

              {/* Model selector */}
              <div>
                <label className="text-xs text-slate-400 mb-1.5 block">Model</label>
                <select
                  value={selectedModel}
                  onChange={(e) => setSelectedModel(e.target.value)}
                  className="w-full bg-slate-700 border border-slate-600 focus:border-cyan-500 text-white rounded-xl px-3 py-2.5 text-sm focus:outline-none transition-all"
                >
                  {AI_MODELS[aiProvider].map((model) => (
                    <option key={model} value={model}>
                      {model}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {aiProvider === 'demo' && (
            <div className="p-4 bg-amber-900/20 border border-amber-700/30 rounded-xl">
              <p className="text-sm text-amber-400 font-medium mb-2">⚡ Demo Mode Active</p>
              <p className="text-xs text-slate-400">
                Demo mode provides pre-written responses for common chemistry questions.
                For real AI-powered explanations tailored to each molecule, connect an
                OpenAI or DeepSeek API key.
              </p>
              <div className="mt-3 space-y-1.5">
                <p className="text-xs text-slate-400 font-medium">Demo mode can:</p>
                <ul className="text-xs text-slate-500 space-y-1">
                  <li>✓ Answer general chemistry questions</li>
                  <li>✓ Generate molecule-based quizzes</li>
                  <li>✓ Provide educational content</li>
                  <li>✗ Give molecule-specific AI analysis</li>
                  <li>✗ Generate custom explanations</li>
                </ul>
              </div>
            </div>
          )}

          <button
            onClick={handleSave}
            className="w-full py-2.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold rounded-xl text-sm transition-all flex items-center justify-center gap-2 shadow-lg"
          >
            {saved ? (
              <>
                <CheckCircle size={16} className="text-green-400" />
                Saved!
              </>
            ) : (
              <>
                <Save size={16} />
                Save Settings
              </>
            )}
          </button>
        </div>
      )}

      {/* Display Settings */}
      {activeTab === 'display' && (
        <div className="space-y-4">
          {/* Visualization style */}
          <div>
            <label className="text-xs text-slate-400 mb-2 block">Visualization Style</label>
            <div className="space-y-2">
              {STYLE_TYPES.map((s) => (
                <button
                  key={s.value}
                  onClick={() => updateVizStyle({ type: s.value })}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border text-left transition-all ${
                    vizStyle.type === s.value
                      ? 'bg-cyan-500/20 border-cyan-500'
                      : 'bg-slate-800 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <div className={`w-3 h-3 rounded-full border-2 ${vizStyle.type === s.value ? 'border-cyan-400 bg-cyan-400' : 'border-slate-500'}`} />
                  <div>
                    <p className={`text-sm font-medium ${vizStyle.type === s.value ? 'text-cyan-400' : 'text-white'}`}>{s.label}</p>
                    <p className="text-xs text-slate-500">{s.desc}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Background color */}
          <div>
            <label className="text-xs text-slate-400 mb-2 block">Background Color</label>
            <div className="grid grid-cols-3 gap-2">
              {BG_COLORS.map((c) => (
                <button
                  key={c.value}
                  onClick={() => updateVizStyle({ backgroundColor: c.value })}
                  className={`flex items-center gap-2 px-2 py-2 rounded-xl border text-xs transition-all ${
                    vizStyle.backgroundColor === c.value
                      ? 'border-cyan-500 text-cyan-400'
                      : 'border-slate-700 text-slate-400 hover:border-slate-500'
                  }`}
                >
                  <div
                    className="w-4 h-4 rounded-full border border-slate-500 flex-shrink-0"
                    style={{ backgroundColor: c.value }}
                  />
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* Opacity */}
          <div>
            <label className="text-xs text-slate-400 mb-2 flex items-center justify-between">
              <span>Molecule Opacity</span>
              <span className="text-white">{Math.round(vizStyle.opacity * 100)}%</span>
            </label>
            <input
              type="range"
              min="0.1"
              max="1"
              step="0.05"
              value={vizStyle.opacity}
              onChange={(e) => updateVizStyle({ opacity: parseFloat(e.target.value) })}
              className="w-full accent-cyan-500"
            />
          </div>

          {/* Toggles */}
          <div className="space-y-2">
            <div className="flex items-center justify-between py-2 border-b border-slate-700/30">
              <div>
                <p className="text-sm text-white">Show Labels</p>
                <p className="text-xs text-slate-500">Display atom labels in 3D view</p>
              </div>
              <button
                onClick={() => updateVizStyle({ showLabels: !vizStyle.showLabels })}
                className={`w-11 h-6 rounded-full transition-all relative ${
                  vizStyle.showLabels ? 'bg-cyan-500' : 'bg-slate-600'
                }`}
              >
                <div
                  className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${
                    vizStyle.showLabels ? 'left-6' : 'left-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* About */}
      {activeTab === 'about' && (
        <div className="space-y-4">
          <div className="p-4 bg-gradient-to-br from-cyan-900/30 to-purple-900/30 border border-cyan-700/30 rounded-xl">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-purple-600 rounded-xl flex items-center justify-center text-xl">
                ⚗️
              </div>
              <div>
                <p className="font-bold text-white">MoleculeAI Platform</p>
                <p className="text-xs text-slate-400">v1.0.0 — Next-gen Chemistry Intelligence</p>
              </div>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              A fully interactive, AI-powered platform for 3D molecular visualization, 
              chemistry education, and scientific analysis. Powered by PubChem's extensive 
              chemical database and real AI models.
            </p>
          </div>

          <div className="space-y-2">
            <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Data Sources</p>
            <div className="space-y-1.5">
              {[
                { name: 'PubChem', desc: '3D structures, properties, identifiers', url: 'https://pubchem.ncbi.nlm.nih.gov' },
                { name: '3Dmol.js', desc: '3D molecular visualization engine', url: 'https://3dmol.org' },
                { name: 'OpenAI / DeepSeek', desc: 'AI explanations and tutoring', url: '#' },
              ].map((s) => (
                <a
                  key={s.name}
                  href={s.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition-all group"
                >
                  <div>
                    <p className="text-sm text-white group-hover:text-cyan-400 transition-colors">{s.name}</p>
                    <p className="text-xs text-slate-500">{s.desc}</p>
                  </div>
                  <ExternalLink size={12} className="text-slate-500" />
                </a>
              ))}
            </div>
          </div>

          <div className="p-3 bg-slate-800/40 border border-slate-700/50 rounded-xl">
            <p className="text-xs text-slate-400 font-medium mb-2">Platform Features</p>
            <ul className="text-xs text-slate-500 space-y-1">
              <li>✓ Real-time 3D molecular visualization</li>
              <li>✓ PubChem database integration</li>
              <li>✓ Multi-provider AI (OpenAI, DeepSeek)</li>
              <li>✓ Smart molecule caching</li>
              <li>✓ Side-by-side comparison</li>
              <li>✓ AI-generated quizzes</li>
              <li>✓ Chemistry curriculum</li>
              <li>✓ Lipinski drug-likeness analysis</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
