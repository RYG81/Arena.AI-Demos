import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  MolecularData,
  ChatMessage,
  AIConfig,
  VisualConfig,
  UserProgress,
  LessonModule,
  AppTab,
  AIMode,
  MoleculeHistoryEntry,
} from '../types/molecular';

interface MolecularStore {
  // Current molecule
  currentMolecule: MolecularData | null;
  isLoading: boolean;
  error: string | null;

  // Molecule cache (self-growing DB)
  moleculeCache: Record<string, MolecularData>;

  // History
  history: MoleculeHistoryEntry[];

  // UI State
  activeTab: AppTab;
  selectedAtomId: number | null;
  hoveredAtomId: number | null;
  compareMode: boolean;
  compareMolecule: MolecularData | null;

  // AI
  aiConfig: AIConfig;
  aiMode: AIMode;
  chatHistory: ChatMessage[];
  isChatLoading: boolean;

  // Visual
  visualConfig: VisualConfig;

  // Learning
  userProgress: UserProgress;
  lessonModules: LessonModule[];
  activeLesson: string | null;

  // Collaboration
  collaborationActive: boolean;
  sessionId: string | null;
  userName: string;

  // Search
  searchHistory: string[];
  popularMolecules: string[];

  // Panel visibility
  showInfoPanel: boolean;
  showAIPanel: boolean;
  showSettingsPanel: boolean;
  showLegend: boolean;

  // Actions
  setCurrentMolecule: (mol: MolecularData | null) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  cacheMolecule: (key: string, mol: MolecularData) => void;
  getCachedMolecule: (key: string) => MolecularData | undefined;
  setActiveTab: (tab: AppTab) => void;
  setSelectedAtom: (id: number | null) => void;
  setHoveredAtom: (id: number | null) => void;
  setCompareMode: (active: boolean, mol?: MolecularData) => void;
  setAIConfig: (config: Partial<AIConfig>) => void;
  setAIMode: (mode: AIMode) => void;
  addChatMessage: (msg: ChatMessage) => void;
  clearChat: () => void;
  setChatLoading: (loading: boolean) => void;
  updateVisualConfig: (config: Partial<VisualConfig>) => void;
  updateUserProgress: (updates: Partial<UserProgress>) => void;
  addXP: (amount: number) => void;
  setActiveLesson: (id: string | null) => void;
  addToHistory: (entry: MoleculeHistoryEntry) => void;
  addSearchHistory: (query: string) => void;
  toggleInfoPanel: () => void;
  toggleAIPanel: () => void;
  toggleSettingsPanel: () => void;
  setUserName: (name: string) => void;
  setShowLegend: (show: boolean) => void;
}

const defaultAIConfig: AIConfig = {
  provider: 'openai',
  temperature: 0.7,
  maxTokens: 1024,
  responseStyle: 'educational',
};

const defaultVisualConfig: VisualConfig = {
  renderMode: 'ball-stick',
  showHydrogens: true,
  showLabels: false,
  showBondAngles: false,
  showElectronDensity: false,
  showOrbitals: false,
  atomScale: 1.0,
  bondThickness: 1.0,
  backgroundColor: '#0a0a1a',
  lightIntensity: 1.2,
  showShadows: true,
  rotateSpeed: 1.0,
  autoRotate: true,
  colorScheme: 'jmol',
  customAtomColors: {},
};

const defaultUserProgress: UserProgress = {
  xp: 0,
  level: 1,
  completedLessons: [],
  completedQuizzes: [],
  score: 0,
  streak: 1,
  moleculesExplored: [],
  achievements: [
    { id: 'first-molecule', name: 'First Discovery', description: 'Explore your first molecule', icon: '🔬', unlocked: false },
    { id: 'ten-molecules', name: 'Molecular Explorer', description: 'Explore 10 different molecules', icon: '🧪', unlocked: false },
    { id: 'first-lesson', name: 'Student', description: 'Complete your first lesson', icon: '📚', unlocked: false },
    { id: 'ai-chat', name: 'AI Collaborator', description: 'Have your first AI conversation', icon: '🤖', unlocked: false },
    { id: 'builder', name: 'Molecule Builder', description: 'Build a molecule from scratch', icon: '⚗️', unlocked: false },
  ],
};

const defaultLessons: LessonModule[] = [
  {
    id: 'basics',
    title: 'Molecular Basics',
    description: 'Learn about atoms, bonds, and molecular structure',
    difficulty: 'beginner',
    completed: false,
    progress: 0,
    topics: [
      { id: 'atoms', title: 'What are Atoms?', content: 'Atoms are the fundamental building blocks of matter...', molecule: 'water', completed: false },
      { id: 'bonds', title: 'Chemical Bonds', content: 'Chemical bonds hold atoms together...', molecule: 'methane', completed: false },
      { id: 'geometry', title: 'Molecular Geometry', content: 'VSEPR theory explains molecular shapes...', molecule: 'ammonia', completed: false },
    ],
  },
  {
    id: 'organic',
    title: 'Organic Chemistry',
    description: 'Explore carbon-based molecules and functional groups',
    difficulty: 'intermediate',
    completed: false,
    progress: 0,
    topics: [
      { id: 'alkanes', title: 'Alkanes & Hydrocarbons', content: 'Alkanes are saturated hydrocarbons...', molecule: 'methane', completed: false },
      { id: 'functional', title: 'Functional Groups', content: 'Functional groups determine reactivity...', molecule: 'ethanol', completed: false },
      { id: 'aromatic', title: 'Aromatic Compounds', content: 'Benzene and aromatic compounds...', molecule: 'benzene', completed: false },
    ],
  },
  {
    id: 'biochem',
    title: 'Biochemistry',
    description: 'Study molecules of life - proteins, DNA, and metabolites',
    difficulty: 'advanced',
    completed: false,
    progress: 0,
    topics: [
      { id: 'glucose', title: 'Sugars & Energy', content: 'Glucose is the primary energy currency...', molecule: 'glucose', completed: false },
      { id: 'neurotransmitters', title: 'Neurotransmitters', content: 'Chemical messengers in the brain...', molecule: 'dopamine', completed: false },
      { id: 'drugs', title: 'Drug Molecules', content: 'How molecular structure determines drug action...', molecule: 'aspirin', completed: false },
    ],
  },
];

export const useMolecularStore = create<MolecularStore>()(
  persist(
    (set, get) => ({
      currentMolecule: null,
      isLoading: false,
      error: null,
      moleculeCache: {},
      history: [],
      activeTab: 'viewer',
      selectedAtomId: null,
      hoveredAtomId: null,
      compareMode: false,
      compareMolecule: null,
      aiConfig: defaultAIConfig,
      aiMode: 'explainer',
      chatHistory: [],
      isChatLoading: false,
      visualConfig: defaultVisualConfig,
      userProgress: defaultUserProgress,
      lessonModules: defaultLessons,
      activeLesson: null,
      collaborationActive: false,
      sessionId: null,
      userName: 'Scientist',
      searchHistory: [],
      popularMolecules: ['water', 'caffeine', 'aspirin', 'glucose', 'benzene'],
      showInfoPanel: true,
      showAIPanel: true,
      showSettingsPanel: false,
      showLegend: true,

      setCurrentMolecule: (mol) => {
        set({ currentMolecule: mol, selectedAtomId: null, error: null });
        if (mol) {
          const { userProgress } = get();
          const explored = userProgress.moleculesExplored;
          if (!explored.includes(mol.name)) {
            get().addXP(50);
            const newExplored = [...explored, mol.name];
            const achievements = [...userProgress.achievements];
            if (newExplored.length === 1) {
              achievements[0] = { ...achievements[0], unlocked: true, unlockedAt: Date.now() };
            }
            if (newExplored.length >= 10) {
              achievements[1] = { ...achievements[1], unlocked: true, unlockedAt: Date.now() };
            }
            set(state => ({
              userProgress: { ...state.userProgress, moleculesExplored: newExplored, achievements }
            }));
          }
          get().addToHistory({ id: Date.now().toString(), molecule: mol, timestamp: Date.now(), action: 'loaded' });
          get().cacheMolecule(mol.name.toLowerCase(), mol);
          if (mol.smiles) get().cacheMolecule(mol.smiles, mol);
        }
      },
      setLoading: (loading) => set({ isLoading: loading }),
      setError: (error) => set({ error, isLoading: false }),
      cacheMolecule: (key, mol) => set(state => ({
        moleculeCache: { ...state.moleculeCache, [key.toLowerCase()]: { ...mol, timestamp: Date.now() } }
      })),
      getCachedMolecule: (key) => get().moleculeCache[key.toLowerCase()],
      setActiveTab: (tab) => set({ activeTab: tab }),
      setSelectedAtom: (id) => set({ selectedAtomId: id }),
      setHoveredAtom: (id) => set({ hoveredAtomId: id }),
      setCompareMode: (active, mol) => set({ compareMode: active, compareMolecule: mol || null }),
      setAIConfig: (config) => set(state => ({ aiConfig: { ...state.aiConfig, ...config } })),
      setAIMode: (mode) => set({ aiMode: mode }),
      addChatMessage: (msg) => {
        set(state => ({ chatHistory: [...state.chatHistory, msg] }));
        if (msg.role === 'user') {
          const achievements = get().userProgress.achievements;
          if (!achievements[3].unlocked) {
            const newAch = [...achievements];
            newAch[3] = { ...newAch[3], unlocked: true, unlockedAt: Date.now() };
            set(state => ({ userProgress: { ...state.userProgress, achievements: newAch } }));
            get().addXP(100);
          }
        }
      },
      clearChat: () => set({ chatHistory: [] }),
      setChatLoading: (loading) => set({ isChatLoading: loading }),
      updateVisualConfig: (config) => set(state => ({ visualConfig: { ...state.visualConfig, ...config } })),
      updateUserProgress: (updates) => set(state => ({ userProgress: { ...state.userProgress, ...updates } })),
      addXP: (amount) => set(state => {
        const newXP = state.userProgress.xp + amount;
        const newLevel = Math.floor(newXP / 500) + 1;
        return { userProgress: { ...state.userProgress, xp: newXP, level: newLevel } };
      }),
      setActiveLesson: (id) => set({ activeLesson: id }),
      addToHistory: (entry) => set(state => ({
        history: [entry, ...state.history].slice(0, 50)
      })),
      addSearchHistory: (query) => set(state => ({
        searchHistory: [query, ...state.searchHistory.filter(q => q !== query)].slice(0, 20)
      })),
      toggleInfoPanel: () => set(state => ({ showInfoPanel: !state.showInfoPanel })),
      toggleAIPanel: () => set(state => ({ showAIPanel: !state.showAIPanel })),
      toggleSettingsPanel: () => set(state => ({ showSettingsPanel: !state.showSettingsPanel })),
      setUserName: (name) => set({ userName: name }),
      setShowLegend: (show) => set({ showLegend: show }),
    }),
    {
      name: 'molecular-ai-store',
      partialize: (state) => ({
        moleculeCache: state.moleculeCache,
        aiConfig: state.aiConfig,
        visualConfig: state.visualConfig,
        userProgress: state.userProgress,
        searchHistory: state.searchHistory,
        chatHistory: state.chatHistory.slice(-50),
        userName: state.userName,
        lessonModules: state.lessonModules,
      }),
    }
  )
);
