/**
 * Chemistry Engine — Core molecular computation system
 * Handles SMILES parsing, coordinate generation, property computation
 */

import type { Atom, Bond, MolecularData, MolecularProperties, BondAngle } from '../types/molecular';
import { ELEMENTS, getAtomColor } from '../data/elements';

// ─── PubChem API Integration ───────────────────────────────────────────────

const PUBCHEM_BASE = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug';

export async function fetchMoleculeByName(name: string): Promise<MolecularData> {
  const encoded = encodeURIComponent(name.trim());

  // First get CID
  const cidRes = await fetch(`${PUBCHEM_BASE}/compound/name/${encoded}/cids/JSON`);
  if (!cidRes.ok) throw new Error(`Molecule "${name}" not found`);
  const cidData = await cidRes.json();
  const cid = cidData.IdentifierList?.CID?.[0];
  if (!cid) throw new Error(`No CID found for "${name}"`);

  return fetchMoleculeByCID(cid);
}

export async function fetchMoleculeBySMILES(smiles: string): Promise<MolecularData> {
  const encoded = encodeURIComponent(smiles.trim());
  const cidRes = await fetch(`${PUBCHEM_BASE}/compound/smiles/${encoded}/cids/JSON`);
  if (!cidRes.ok) throw new Error(`SMILES "${smiles}" not found`);
  const cidData = await cidRes.json();
  const cid = cidData.IdentifierList?.CID?.[0];
  if (!cid) throw new Error(`No CID found for SMILES "${smiles}"`);
  return fetchMoleculeByCID(cid);
}

export async function fetchMoleculeByCID(cid: number): Promise<MolecularData> {
  // Fetch properties and 3D coordinates in parallel
  const [propsRes, conformerRes, nameRes] = await Promise.all([
    fetch(`${PUBCHEM_BASE}/compound/cid/${cid}/property/MolecularFormula,MolecularWeight,CanonicalSMILES,IsomericSMILES,IUPACName,InChI,InChIKey,XLogP,HBondDonorCount,HBondAcceptorCount,RotatableBondCount,TopologicalPolarSurfaceArea,HeavyAtomCount,Complexity,Charge,ExactMass,MonoisotopicMass,AtomStereoCount,BondStereoCount,CovalentUnitCount/JSON`),
    fetch(`${PUBCHEM_BASE}/compound/cid/${cid}/JSON?record_type=3d`),
    fetch(`${PUBCHEM_BASE}/compound/cid/${cid}/synonyms/JSON`),
  ]);

  let properties: Record<string, unknown> = {};
  if (propsRes.ok) {
    const pd = await propsRes.json();
    properties = pd.PropertyTable?.Properties?.[0] || {};
  }

  let synonyms: string[] = [];
  if (nameRes.ok) {
    const nd = await nameRes.json();
    synonyms = nd.InformationList?.Information?.[0]?.Synonym?.slice(0, 5) || [];
  }

  let atoms: Atom[] = [];
  let bonds: Bond[] = [];

  if (conformerRes.ok) {
    const confData = await conformerRes.json();
    const compound = confData.PC_Compounds?.[0];
    if (compound) {
      const parsed = parseCompound(compound);
      atoms = parsed.atoms;
      bonds = parsed.bonds;
    }
  }

  // Fallback: try 2D if 3D not available
  if (atoms.length === 0) {
    try {
      const res2d = await fetch(`${PUBCHEM_BASE}/compound/cid/${cid}/JSON`);
      if (res2d.ok) {
        const d2 = await res2d.json();
        const compound = d2.PC_Compounds?.[0];
        if (compound) {
          const parsed = parseCompound(compound, true);
          atoms = parsed.atoms;
          bonds = parsed.bonds;
        }
      }
    } catch { /* ignore */ }
  }

  const smiles = (properties.CanonicalSMILES as string) || '';
  const formula = (properties.MolecularFormula as string) || '';
  const name = synonyms[0] || String(properties.IUPACName || `Compound ${cid}`);

  const molProps = computeProperties(properties, atoms, bonds, smiles);

  return {
    name: capitalizeFirst(name),
    formula: formatFormula(formula),
    smiles,
    inchi: properties.InChI as string,
    inchikey: properties.InChIKey as string,
    iupacName: properties.IUPACName as string,
    synonyms,
    atoms,
    bonds,
    properties: molProps,
    cid,
    source: 'PubChem',
    timestamp: Date.now(),
  };
}

function parseCompound(compound: Record<string, unknown>, is2D = false): { atoms: Atom[]; bonds: Bond[] } {
  const atoms: Atom[] = [];
  const bonds: Bond[] = [];

  try {
    const atomSection = (compound.atoms as Record<string, unknown>) || {};
    const bondSection = (compound.bonds as Record<string, unknown>) || {};
    const coordSection = compound.coords as Array<Record<string, unknown>>;

    const aids = (atomSection.aid as number[]) || [];
    const elements = (atomSection.element as number[]) || [];

    // Atomic number to symbol mapping
    const numToSym: Record<number, string> = {};
    Object.values(ELEMENTS).forEach(el => { numToSym[el.atomicNumber] = el.symbol; });

    // Get coordinates
    let xCoords: number[] = [];
    let yCoords: number[] = [];
    let zCoords: number[] = [];

    if (coordSection?.[0]) {
      const coordConformers = coordSection[0].conformers as Array<Record<string, unknown>>;
      if (coordConformers?.[0]) {
        xCoords = (coordConformers[0].x as number[]) || [];
        yCoords = (coordConformers[0].y as number[]) || [];
        zCoords = (coordConformers[0].z as number[]) || [];
      }
    }

    for (let i = 0; i < aids.length; i++) {
      const atomNum = elements[i];
      const symbol = numToSym[atomNum] || 'C';
      const el = ELEMENTS[symbol];
      atoms.push({
        id: aids[i],
        element: el?.name || symbol,
        symbol,
        x: xCoords[i] || 0,
        y: yCoords[i] || 0,
        z: is2D ? (Math.random() - 0.5) * 0.5 : (zCoords[i] || 0),
        color: getAtomColor(symbol, 'jmol'),
        radius: (el?.covalentRadius || 0.77) * 0.35,
        mass: el?.atomicMass || 12,
        electronegativity: el?.electronegativity,
        charge: 0,
      });
    }

    // Scale coordinates to reasonable Three.js units
    const scale = 1.5;
    const cx = atoms.reduce((s, a) => s + a.x, 0) / (atoms.length || 1);
    const cy = atoms.reduce((s, a) => s + a.y, 0) / (atoms.length || 1);
    const cz = atoms.reduce((s, a) => s + a.z, 0) / (atoms.length || 1);

    atoms.forEach(a => {
      a.x = (a.x - cx) * scale;
      a.y = (a.y - cy) * scale;
      a.z = (a.z - cz) * scale;
    });

    // Parse bonds
    const aid1 = (bondSection.aid1 as number[]) || [];
    const aid2 = (bondSection.aid2 as number[]) || [];
    const order = (bondSection.order as number[]) || [];

    for (let i = 0; i < aid1.length; i++) {
      const o = order[i] || 1;
      bonds.push({
        id: i,
        atom1: aid1[i],
        atom2: aid2[i],
        order: o as 1 | 2 | 3 | 1.5,
        type: o === 1 ? 'single' : o === 2 ? 'double' : o === 3 ? 'triple' : 'aromatic',
      });
    }
  } catch (e) {
    console.warn('Error parsing compound:', e);
  }

  return { atoms, bonds };
}

function computeProperties(
  raw: Record<string, unknown>,
  atoms: Atom[],
  bonds: Bond[],
  smiles: string
): MolecularProperties {
  const functionalGroups = detectFunctionalGroups(smiles);
  const isAromatic = smiles.includes('c') || smiles.includes('n') || smiles.includes('o');
  const bondAngles = computeBondAngles(atoms, bonds);

  return {
    molecularWeight: Number(raw.MolecularWeight) || 0,
    logP: raw.XLogP !== undefined ? Number(raw.XLogP) : undefined,
    hBondDonors: Number(raw.HBondDonorCount) || 0,
    hBondAcceptors: Number(raw.HBondAcceptorCount) || 0,
    rotBonds: Number(raw.RotatableBondCount) || 0,
    polarSurfaceArea: Number(raw.TopologicalPolarSurfaceArea) || 0,
    complexity: Number(raw.Complexity) || 0,
    charge: Number(raw.Charge) || 0,
    xlogp: Number(raw.XLogP) || 0,
    exactMass: Number(raw.ExactMass) || 0,
    monoisotopicMass: Number(raw.MonoisotopicMass) || 0,
    heavyAtomCount: Number(raw.HeavyAtomCount) || 0,
    atomStereoCount: Number(raw.AtomStereoCount) || 0,
    bondStereoCount: Number(raw.BondStereoCount) || 0,
    covalentUnitCount: Number(raw.CovalentUnitCount) || 0,
    tpsa: Number(raw.TopologicalPolarSurfaceArea) || 0,
    functionalGroups,
    isAromatic,
    isChiral: (Number(raw.AtomStereoCount) || 0) > 0,
    bondAngles,
    geometry: inferGeometry(atoms, bonds),
    vseprGeometry: inferVSEPR(atoms, bonds),
  };
}

function detectFunctionalGroups(smiles: string): string[] {
  const groups: string[] = [];
  if (/[Cc](=O)[Oo]/.test(smiles) || smiles.includes('C(=O)O')) groups.push('Carboxylic Acid');
  if (/[Cc](=O)[Nn]/.test(smiles)) groups.push('Amide');
  if (/[Cc](=O)[Oo][Cc]/.test(smiles)) groups.push('Ester');
  if (/[Cc](=O)[Cc]/.test(smiles) || /C=O/.test(smiles)) groups.push('Carbonyl');
  if (/[Cc]O/.test(smiles) && !/[Cc](=O)/.test(smiles)) groups.push('Alcohol (-OH)');
  if (/[Nn]/.test(smiles)) groups.push('Amine');
  if (/[Ss]/.test(smiles)) groups.push('Sulfur group');
  if (/[Pp]/.test(smiles)) groups.push('Phosphate');
  if (/[Ff]|[Cc]l|[Bb]r|[Ii]/.test(smiles)) groups.push('Halide');
  if (/c1ccccc1/.test(smiles) || /c1cc/.test(smiles)) groups.push('Aromatic ring');
  if (/C=C/.test(smiles)) groups.push('Alkene');
  if (/C#C/.test(smiles)) groups.push('Alkyne');
  if (/C#N/.test(smiles)) groups.push('Nitrile');
  if (/\[N\+\]/.test(smiles)) groups.push('Quaternary Ammonium');
  return groups.length > 0 ? groups : ['Hydrocarbon'];
}

function computeBondAngles(atoms: Atom[], bonds: Bond[]): BondAngle[] {
  const angles: BondAngle[] = [];
  const atomMap = new Map(atoms.map(a => [a.id, a]));

  // For each atom, find all neighbors and compute angles
  const neighbors = new Map<number, number[]>();
  bonds.forEach(b => {
    if (!neighbors.has(b.atom1)) neighbors.set(b.atom1, []);
    if (!neighbors.has(b.atom2)) neighbors.set(b.atom2, []);
    neighbors.get(b.atom1)!.push(b.atom2);
    neighbors.get(b.atom2)!.push(b.atom1);
  });

  atoms.slice(0, 5).forEach(central => { // Limit to 5 central atoms for performance
    const nbrs = neighbors.get(central.id) || [];
    if (nbrs.length < 2) return;

    const a1 = atomMap.get(nbrs[0]);
    const a2 = atomMap.get(nbrs[1]);
    if (!a1 || !a2) return;

    const v1 = { x: a1.x - central.x, y: a1.y - central.y, z: a1.z - central.z };
    const v2 = { x: a2.x - central.x, y: a2.y - central.y, z: a2.z - central.z };
    const dot = v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
    const mag1 = Math.sqrt(v1.x ** 2 + v1.y ** 2 + v1.z ** 2);
    const mag2 = Math.sqrt(v2.x ** 2 + v2.y ** 2 + v2.z ** 2);
    if (mag1 === 0 || mag2 === 0) return;
    const angle = Math.acos(Math.max(-1, Math.min(1, dot / (mag1 * mag2)))) * (180 / Math.PI);

    angles.push({
      atom1: a1.symbol,
      central: central.symbol,
      atom2: a2.symbol,
      angle: Math.round(angle * 10) / 10,
    });
  });

  return angles;
}

function inferGeometry(atoms: Atom[], bonds: Bond[]): string {
  if (atoms.length <= 1) return 'Monatomic';
  if (atoms.length === 2) return 'Linear';
  if (atoms.length === 3) return 'Bent or Linear';
  if (atoms.length === 4) return 'Tetrahedral or Planar';
  if (atoms.length === 5) return 'Trigonal bipyramidal';
  if (atoms.length === 6) return 'Octahedral';
  return 'Complex polyhedral';
}

function inferVSEPR(atoms: Atom[], bonds: Bond[]): string {
  const heavyAtoms = atoms.filter(a => a.symbol !== 'H');
  if (heavyAtoms.length === 1) return 'Monatomic';
  if (heavyAtoms.length === 2) return 'Linear (180°)';

  const central = heavyAtoms[0];
  const cnMap = new Map<number, number[]>();
  bonds.forEach(b => {
    if (!cnMap.has(b.atom1)) cnMap.set(b.atom1, []);
    if (!cnMap.has(b.atom2)) cnMap.set(b.atom2, []);
    cnMap.get(b.atom1)!.push(b.atom2);
    cnMap.get(b.atom2)!.push(b.atom1);
  });
  const coordNum = cnMap.get(central.id)?.length || 0;

  switch (coordNum) {
    case 2: return 'Linear (180°)';
    case 3: return 'Trigonal Planar (120°)';
    case 4: return 'Tetrahedral (109.5°)';
    case 5: return 'Trigonal Bipyramidal';
    case 6: return 'Octahedral (90°)';
    default: return 'Complex';
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────

function capitalizeFirst(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function formatFormula(formula: string): string {
  return formula.replace(/(\d+)/g, (match) => {
    const subs: Record<string, string> = { '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉' };
    return match.split('').map(c => subs[c] || c).join('');
  });
}

// ─── Local molecule generator (for demo when API is offline) ─────────────

export function generateLocalMolecule(name: string): MolecularData | null {
  const presets = getPresetMolecule(name.toLowerCase());
  return presets;
}

function getPresetMolecule(key: string): MolecularData | null {
  const presets: Record<string, MolecularData> = {
    water: {
      name: 'Water', formula: 'H₂O', smiles: 'O',
      atoms: [
        { id: 1, element: 'Oxygen', symbol: 'O', x: 0, y: 0, z: 0, color: '#FF0D0D', radius: 0.23, mass: 16, charge: -0.834, hybridization: 'sp3' },
        { id: 2, element: 'Hydrogen', symbol: 'H', x: 0.96, y: 0.27, z: 0, color: '#FFFFFF', radius: 0.11, mass: 1, charge: 0.417 },
        { id: 3, element: 'Hydrogen', symbol: 'H', x: -0.27, y: 0.96, z: 0, color: '#FFFFFF', radius: 0.11, mass: 1, charge: 0.417 },
      ],
      bonds: [
        { id: 0, atom1: 1, atom2: 2, order: 1, type: 'single' },
        { id: 1, atom1: 1, atom2: 3, order: 1, type: 'single' },
      ],
      properties: {
        molecularWeight: 18.015, hBondDonors: 2, hBondAcceptors: 1, logP: -1.38,
        geometry: 'Bent', vseprGeometry: 'Bent (104.5°)', functionalGroups: ['Alcohol (-OH)'],
        bondAngles: [{ atom1: 'H', central: 'O', atom2: 'H', angle: 104.5 }],
        isAromatic: false, isChiral: false,
      },
      source: 'Local', timestamp: Date.now(),
    },
    methane: {
      name: 'Methane', formula: 'CH₄', smiles: 'C',
      atoms: [
        { id: 1, element: 'Carbon', symbol: 'C', x: 0, y: 0, z: 0, color: '#909090', radius: 0.27, mass: 12, hybridization: 'sp3' },
        { id: 2, element: 'Hydrogen', symbol: 'H', x: 0.63, y: 0.63, z: 0.63, color: '#FFFFFF', radius: 0.11, mass: 1 },
        { id: 3, element: 'Hydrogen', symbol: 'H', x: -0.63, y: -0.63, z: 0.63, color: '#FFFFFF', radius: 0.11, mass: 1 },
        { id: 4, element: 'Hydrogen', symbol: 'H', x: -0.63, y: 0.63, z: -0.63, color: '#FFFFFF', radius: 0.11, mass: 1 },
        { id: 5, element: 'Hydrogen', symbol: 'H', x: 0.63, y: -0.63, z: -0.63, color: '#FFFFFF', radius: 0.11, mass: 1 },
      ],
      bonds: [
        { id: 0, atom1: 1, atom2: 2, order: 1, type: 'single' },
        { id: 1, atom1: 1, atom2: 3, order: 1, type: 'single' },
        { id: 2, atom1: 1, atom2: 4, order: 1, type: 'single' },
        { id: 3, atom1: 1, atom2: 5, order: 1, type: 'single' },
      ],
      properties: {
        molecularWeight: 16.043, logP: 1.09, hBondDonors: 0, hBondAcceptors: 0,
        geometry: 'Tetrahedral', vseprGeometry: 'Tetrahedral (109.5°)',
        functionalGroups: ['Hydrocarbon'],
        bondAngles: [{ atom1: 'H', central: 'C', atom2: 'H', angle: 109.5 }],
        isAromatic: false, isChiral: false,
      },
      source: 'Local', timestamp: Date.now(),
    },
    ammonia: {
      name: 'Ammonia', formula: 'NH₃', smiles: 'N',
      atoms: [
        { id: 1, element: 'Nitrogen', symbol: 'N', x: 0, y: 0, z: 0, color: '#3050F8', radius: 0.25, mass: 14, hybridization: 'sp3' },
        { id: 2, element: 'Hydrogen', symbol: 'H', x: 0.94, y: 0.34, z: 0, color: '#FFFFFF', radius: 0.11, mass: 1 },
        { id: 3, element: 'Hydrogen', symbol: 'H', x: -0.47, y: 0.34, z: 0.81, color: '#FFFFFF', radius: 0.11, mass: 1 },
        { id: 4, element: 'Hydrogen', symbol: 'H', x: -0.47, y: 0.34, z: -0.81, color: '#FFFFFF', radius: 0.11, mass: 1 },
      ],
      bonds: [
        { id: 0, atom1: 1, atom2: 2, order: 1, type: 'single' },
        { id: 1, atom1: 1, atom2: 3, order: 1, type: 'single' },
        { id: 2, atom1: 1, atom2: 4, order: 1, type: 'single' },
      ],
      properties: {
        molecularWeight: 17.031, logP: -1.74, hBondDonors: 1, hBondAcceptors: 1,
        geometry: 'Trigonal pyramidal', vseprGeometry: 'Trigonal Pyramidal (107°)',
        functionalGroups: ['Amine'],
        bondAngles: [{ atom1: 'H', central: 'N', atom2: 'H', angle: 107.0 }],
        isAromatic: false, isChiral: false,
      },
      source: 'Local', timestamp: Date.now(),
    },
    co2: {
      name: 'Carbon Dioxide', formula: 'CO₂', smiles: 'O=C=O',
      atoms: [
        { id: 1, element: 'Oxygen', symbol: 'O', x: -1.16, y: 0, z: 0, color: '#FF0D0D', radius: 0.23, mass: 16 },
        { id: 2, element: 'Carbon', symbol: 'C', x: 0, y: 0, z: 0, color: '#909090', radius: 0.27, mass: 12, hybridization: 'sp' },
        { id: 3, element: 'Oxygen', symbol: 'O', x: 1.16, y: 0, z: 0, color: '#FF0D0D', radius: 0.23, mass: 16 },
      ],
      bonds: [
        { id: 0, atom1: 2, atom2: 1, order: 2, type: 'double' },
        { id: 1, atom1: 2, atom2: 3, order: 2, type: 'double' },
      ],
      properties: {
        molecularWeight: 44.01, logP: 0.83, hBondDonors: 0, hBondAcceptors: 0,
        geometry: 'Linear', vseprGeometry: 'Linear (180°)',
        functionalGroups: ['Carbonyl'],
        bondAngles: [{ atom1: 'O', central: 'C', atom2: 'O', angle: 180.0 }],
        isAromatic: false, isChiral: false,
      },
      source: 'Local', timestamp: Date.now(),
    },
    benzene: {
      name: 'Benzene', formula: 'C₆H₆', smiles: 'c1ccccc1',
      atoms: (() => {
        const atoms: Atom[] = [];
        for (let i = 0; i < 6; i++) {
          const angle = (i * Math.PI * 2) / 6;
          const r = 1.4;
          atoms.push({ id: i + 1, element: 'Carbon', symbol: 'C', x: r * Math.cos(angle), y: r * Math.sin(angle), z: 0, color: '#909090', radius: 0.27, mass: 12, hybridization: 'sp2' });
        }
        for (let i = 0; i < 6; i++) {
          const angle = (i * Math.PI * 2) / 6;
          const r = 2.47;
          atoms.push({ id: i + 7, element: 'Hydrogen', symbol: 'H', x: r * Math.cos(angle), y: r * Math.sin(angle), z: 0, color: '#FFFFFF', radius: 0.11, mass: 1 });
        }
        return atoms;
      })(),
      bonds: (() => {
        const bonds: Bond[] = [];
        for (let i = 0; i < 6; i++) {
          bonds.push({ id: i, atom1: i + 1, atom2: ((i + 1) % 6) + 1, order: 1.5, type: 'aromatic' });
        }
        for (let i = 0; i < 6; i++) {
          bonds.push({ id: i + 6, atom1: i + 1, atom2: i + 7, order: 1, type: 'single' });
        }
        return bonds;
      })(),
      properties: {
        molecularWeight: 78.11, logP: 2.13, hBondDonors: 0, hBondAcceptors: 0,
        geometry: 'Hexagonal planar', vseprGeometry: 'Trigonal Planar (120°)',
        functionalGroups: ['Aromatic ring'],
        bondAngles: [{ atom1: 'C', central: 'C', atom2: 'C', angle: 120.0 }],
        isAromatic: true, isChiral: false,
      },
      source: 'Local', timestamp: Date.now(),
    },
    ethanol: {
      name: 'Ethanol', formula: 'C₂H₆O', smiles: 'CCO',
      atoms: [
        { id: 1, element: 'Carbon', symbol: 'C', x: -0.7, y: 0, z: 0, color: '#909090', radius: 0.27, mass: 12, hybridization: 'sp3' },
        { id: 2, element: 'Carbon', symbol: 'C', x: 0.7, y: 0, z: 0, color: '#909090', radius: 0.27, mass: 12, hybridization: 'sp3' },
        { id: 3, element: 'Oxygen', symbol: 'O', x: 1.4, y: 1.0, z: 0, color: '#FF0D0D', radius: 0.23, mass: 16, hybridization: 'sp3' },
        { id: 4, element: 'Hydrogen', symbol: 'H', x: -1.1, y: 0.5, z: 0.87, color: '#FFFFFF', radius: 0.11, mass: 1 },
        { id: 5, element: 'Hydrogen', symbol: 'H', x: -1.1, y: 0.5, z: -0.87, color: '#FFFFFF', radius: 0.11, mass: 1 },
        { id: 6, element: 'Hydrogen', symbol: 'H', x: -1.1, y: -1.0, z: 0, color: '#FFFFFF', radius: 0.11, mass: 1 },
        { id: 7, element: 'Hydrogen', symbol: 'H', x: 1.1, y: -0.5, z: 0.87, color: '#FFFFFF', radius: 0.11, mass: 1 },
        { id: 8, element: 'Hydrogen', symbol: 'H', x: 1.1, y: -0.5, z: -0.87, color: '#FFFFFF', radius: 0.11, mass: 1 },
        { id: 9, element: 'Hydrogen', symbol: 'H', x: 2.4, y: 1.0, z: 0, color: '#FFFFFF', radius: 0.11, mass: 1 },
      ],
      bonds: [
        { id: 0, atom1: 1, atom2: 2, order: 1, type: 'single' },
        { id: 1, atom1: 2, atom2: 3, order: 1, type: 'single' },
        { id: 2, atom1: 1, atom2: 4, order: 1, type: 'single' },
        { id: 3, atom1: 1, atom2: 5, order: 1, type: 'single' },
        { id: 4, atom1: 1, atom2: 6, order: 1, type: 'single' },
        { id: 5, atom1: 2, atom2: 7, order: 1, type: 'single' },
        { id: 6, atom1: 2, atom2: 8, order: 1, type: 'single' },
        { id: 7, atom1: 3, atom2: 9, order: 1, type: 'single' },
      ],
      properties: {
        molecularWeight: 46.068, logP: -0.14, hBondDonors: 1, hBondAcceptors: 1,
        geometry: 'Extended chain', vseprGeometry: 'Tetrahedral (109.5°)',
        functionalGroups: ['Alcohol (-OH)'],
        bondAngles: [{ atom1: 'C', central: 'C', atom2: 'O', angle: 108.5 }],
        isAromatic: false, isChiral: false,
      },
      source: 'Local', timestamp: Date.now(),
    },
  };

  // Try exact match first
  if (presets[key]) return presets[key];

  // Try partial match
  for (const [k, v] of Object.entries(presets)) {
    if (k.includes(key) || key.includes(k) || v.name.toLowerCase().includes(key)) {
      return v;
    }
  }

  return null;
}
