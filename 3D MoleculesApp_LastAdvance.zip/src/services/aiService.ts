/**
 * AI Service — Multi-provider AI integration
 * Supports OpenAI, DeepSeek, and local Ollama
 */

import type { AIConfig, AIMode, MolecularData } from '../types/molecular';

const SYSTEM_PROMPTS: Record<AIMode, string> = {
  explainer: `You are MolecularAI, an expert chemistry explainer. You provide accurate, engaging explanations about molecular structure, properties, and chemistry. 
- Always ground explanations in the actual molecular data provided
- Use analogies to make complex concepts accessible
- Mention real-world applications and significance
- Keep responses educational but concise (2-4 paragraphs max unless asked for more)
- Format with clear sections using markdown
- NEVER hallucinate molecular data — only explain what's given`,

  tutor: `You are MolecularAI Tutor, a Socratic chemistry teacher. You guide students through discovery.
- Ask probing questions to check understanding
- Build on prior knowledge
- Celebrate correct answers, gently correct mistakes
- Provide hints rather than direct answers
- Use the "I do, we do, you do" teaching method
- Adapt difficulty based on student responses`,

  validator: `You are MolecularAI Validator, a rigorous chemistry fact-checker.
- Analyze molecular data for accuracy
- Identify potential errors in chemical structures
- Validate SMILES notation
- Check for chemically impossible configurations
- Provide confidence scores for assessments
- Flag concerns clearly`,

  copilot: `You are MolecularAI Copilot, an intelligent research assistant.
- Help design experiments and analyses  
- Suggest similar molecules for comparison
- Predict reactivity based on functional groups
- Propose structural modifications and their effects
- Assist with nomenclature and classification
- Generate hypotheses for investigation`,
};

interface AIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export async function sendAIMessage(
  userMessage: string,
  config: AIConfig,
  mode: AIMode,
  molecule: MolecularData | null,
  history: AIMessage[]
): Promise<string> {
  const systemPrompt = buildSystemPrompt(mode, molecule);

  const messages: AIMessage[] = [
    { role: 'system', content: systemPrompt },
    ...history.slice(-10), // Keep last 10 messages for context
    { role: 'user', content: userMessage },
  ];

  try {
    switch (config.provider) {
      case 'openai':
        return await callOpenAI(messages, config);
      case 'deepseek':
        return await callDeepSeek(messages, config);
      case 'local':
        return await callLocal(messages, config);
      default:
        return await callOpenAI(messages, config);
    }
  } catch (error) {
    // Try fallback
    console.warn('Primary AI failed, trying fallback...', error);
    if (config.provider !== 'local') {
      return generateFallbackResponse(userMessage, molecule, mode);
    }
    throw error;
  }
}

function buildSystemPrompt(mode: AIMode, molecule: MolecularData | null): string {
  let prompt = SYSTEM_PROMPTS[mode];

  if (molecule) {
    prompt += `\n\n## Current Molecule Context:
**Name:** ${molecule.name}
**Formula:** ${molecule.formula}
**SMILES:** ${molecule.smiles}
**Molecular Weight:** ${molecule.properties.molecularWeight} g/mol
**Functional Groups:** ${molecule.properties.functionalGroups?.join(', ') || 'N/A'}
**Geometry:** ${molecule.properties.vseprGeometry || 'Unknown'}
**H-Bond Donors:** ${molecule.properties.hBondDonors || 0}
**H-Bond Acceptors:** ${molecule.properties.hBondAcceptors || 0}
**LogP:** ${molecule.properties.logP?.toFixed(2) ?? 'N/A'}
**Aromatic:** ${molecule.properties.isAromatic ? 'Yes' : 'No'}
**Atoms:** ${molecule.atoms.length} | **Bonds:** ${molecule.bonds.length}
${molecule.iupacName ? `**IUPAC Name:** ${molecule.iupacName}` : ''}

Use this data as ground truth. Do not invent additional properties.`;
  }

  return prompt;
}

async function callOpenAI(messages: AIMessage[], config: AIConfig): Promise<string> {
  if (!config.openaiKey) {
    throw new Error('OpenAI API key not configured');
  }

  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${config.openaiKey}`,
    },
    body: JSON.stringify({
      model: config.model || 'gpt-4o-mini',
      messages,
      temperature: config.temperature ?? 0.7,
      max_tokens: config.maxTokens ?? 1024,
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `OpenAI error: ${res.status}`);
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content || 'No response generated';
}

async function callDeepSeek(messages: AIMessage[], config: AIConfig): Promise<string> {
  if (!config.deepseekKey) {
    throw new Error('DeepSeek API key not configured');
  }

  const res = await fetch('https://api.deepseek.com/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${config.deepseekKey}`,
    },
    body: JSON.stringify({
      model: config.model || 'deepseek-chat',
      messages,
      temperature: config.temperature ?? 0.7,
      max_tokens: config.maxTokens ?? 1024,
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `DeepSeek error: ${res.status}`);
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content || 'No response generated';
}

async function callLocal(messages: AIMessage[], config: AIConfig): Promise<string> {
  const endpoint = config.localEndpoint || 'http://localhost:11434/api/chat';

  const res = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: config.model || 'llama3',
      messages,
      stream: false,
    }),
  });

  if (!res.ok) throw new Error(`Local AI error: ${res.status}`);
  const data = await res.json();
  return data.message?.content || data.response || 'No response';
}

// Smart fallback when no API key is configured
function generateFallbackResponse(
  userMessage: string,
  molecule: MolecularData | null,
  mode: AIMode
): string {
  const msg = userMessage.toLowerCase();

  if (!molecule) {
    return `**Welcome to MolecularAI!** 🧪

I'm ready to help you explore the molecular world. To get started:
1. **Search for a molecule** in the input field (e.g., "caffeine", "water", "aspirin")
2. **Configure your AI** in Settings with an OpenAI or DeepSeek API key
3. **Ask questions** like "What makes benzene special?" or "Explain hydrogen bonds"

> 💡 *To enable AI responses, please add your API key in the Settings panel.*`;
  }

  const mol = molecule;

  if (msg.includes('what') && (msg.includes('is') || msg.includes('are'))) {
    return `## ${mol.name} — Overview 🔬

**${mol.name}** (${mol.formula}) is a ${mol.properties.isAromatic ? 'aromatic' : 'non-aromatic'} molecule with a molecular weight of **${mol.properties.molecularWeight.toFixed(2)} g/mol**.

${mol.properties.functionalGroups?.length ? `**Key functional groups:** ${mol.properties.functionalGroups.join(', ')}` : ''}

**Molecular geometry:** ${mol.properties.vseprGeometry || mol.properties.geometry || 'Unknown'}

${mol.properties.hBondDonors ? `This molecule can form **${mol.properties.hBondDonors} hydrogen bond(s)** as a donor and **${mol.properties.hBondAcceptors}** as an acceptor, making it ${mol.properties.logP && mol.properties.logP < 0 ? 'hydrophilic (water-soluble)' : 'more lipophilic'}.` : ''}

> 💡 *Configure an AI API key in Settings for detailed, personalized explanations.*`;
  }

  if (msg.includes('structure') || msg.includes('bond') || msg.includes('atom')) {
    return `## ${mol.name} — Structure Analysis ⚛️

${mol.name} contains **${mol.atoms.length} atoms** and **${mol.bonds.length} bonds**.

**Atom composition:**
${getAtomComposition(mol)}

**Bond types present:**
${getBondTypes(mol)}

**SMILES notation:** \`${mol.smiles}\`

${mol.properties.bondAngles?.length ? `**Key bond angle:** ${mol.properties.bondAngles[0].atom1}-${mol.properties.bondAngles[0].central}-${mol.properties.bondAngles[0].atom2} = **${mol.properties.bondAngles[0].angle}°**` : ''}

> 💡 *Add an API key in Settings for AI-powered structural analysis.*`;
  }

  if (msg.includes('property') || msg.includes('properties') || msg.includes('solub') || msg.includes('polar')) {
    return `## ${mol.name} — Physical Properties 📊

| Property | Value |
|----------|-------|
| Molecular Weight | ${mol.properties.molecularWeight.toFixed(2)} g/mol |
| LogP | ${mol.properties.logP?.toFixed(2) ?? 'N/A'} |
| H-Bond Donors | ${mol.properties.hBondDonors ?? 0} |
| H-Bond Acceptors | ${mol.properties.hBondAcceptors ?? 0} |
| Rotatable Bonds | ${mol.properties.rotBonds ?? 0} |
| TPSA | ${mol.properties.tpsa?.toFixed(1) ?? 'N/A'} Ų |
| Aromatic | ${mol.properties.isAromatic ? '✅ Yes' : '❌ No'} |

**Polarity:** LogP = ${mol.properties.logP?.toFixed(2) ?? 'N/A'} — ${(mol.properties.logP ?? 0) < 0 ? '💧 Hydrophilic (water-loving)' : '🧴 Lipophilic (fat-soluble)'}

> 💡 *Add an API key in Settings for deeper property analysis.*`;
  }

  // Default response
  return `## Analyzing ${mol.name} 🧬

I can see you're asking about **${mol.name}** (${mol.formula}). Here's what I know from the molecular data:

- **Structure:** ${mol.properties.geometry || 'Complex'}
- **Weight:** ${mol.properties.molecularWeight.toFixed(2)} g/mol
- **Key groups:** ${mol.properties.functionalGroups?.slice(0, 3).join(', ') || 'Hydrocarbon'}
- **Aromatic:** ${mol.properties.isAromatic ? 'Yes — contains delocalized π electrons' : 'No'}

To get detailed AI explanations tailored to your question, please:
1. Go to **Settings** → **AI Configuration**
2. Add your **OpenAI** or **DeepSeek** API key
3. Ask again for full AI-powered analysis!

> 🔬 *MolecularAI is powered by real chemistry data from PubChem.*`;
}

function getAtomComposition(mol: MolecularData): string {
  const counts: Record<string, number> = {};
  mol.atoms.forEach(a => { counts[a.symbol] = (counts[a.symbol] || 0) + 1; });
  return Object.entries(counts)
    .map(([sym, cnt]) => `- **${sym}**: ${cnt} atom${cnt > 1 ? 's' : ''}`)
    .join('\n');
}

function getBondTypes(mol: MolecularData): string {
  const types: Record<string, number> = {};
  mol.bonds.forEach(b => { types[b.type] = (types[b.type] || 0) + 1; });
  return Object.entries(types)
    .map(([type, cnt]) => `- **${type}**: ${cnt}`)
    .join('\n');
}

// Generate quiz questions for a molecule
export function generateQuizQuestions(molecule: MolecularData): Array<{
  question: string;
  options: string[];
  correct: string;
  explanation: string;
}> {
  const questions = [];
  const mol = molecule;

  questions.push({
    question: `What is the molecular formula of ${mol.name}?`,
    options: [mol.formula, 'C₆H₁₂O₆', 'H₂O₂', 'CH₄O'].sort(() => Math.random() - 0.5),
    correct: mol.formula,
    explanation: `${mol.name} has the formula ${mol.formula}, with ${mol.atoms.length} total atoms.`,
  });

  if (mol.properties.molecularWeight) {
    const mw = mol.properties.molecularWeight.toFixed(1);
    const wrong1 = (mol.properties.molecularWeight * 1.5).toFixed(1);
    const wrong2 = (mol.properties.molecularWeight * 0.5).toFixed(1);
    questions.push({
      question: `What is the approximate molecular weight of ${mol.name}?`,
      options: [`${mw} g/mol`, `${wrong1} g/mol`, `${wrong2} g/mol`, '100 g/mol'].sort(() => Math.random() - 0.5),
      correct: `${mw} g/mol`,
      explanation: `${mol.name} has a molecular weight of ${mw} g/mol, calculated from the sum of atomic masses.`,
    });
  }

  if (mol.properties.vseprGeometry) {
    questions.push({
      question: `What is the molecular geometry of ${mol.name}?`,
      options: [mol.properties.vseprGeometry, 'Linear (180°)', 'Octahedral (90°)', 'Trigonal Planar (120°)'].sort(() => Math.random() - 0.5),
      correct: mol.properties.vseprGeometry,
      explanation: `${mol.name} adopts a ${mol.properties.vseprGeometry} geometry based on VSEPR theory.`,
    });
  }

  return questions;
}
