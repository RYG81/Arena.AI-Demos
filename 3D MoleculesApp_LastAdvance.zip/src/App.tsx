import { useState, Suspense } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Atom, Bot, BookOpen, Beaker, Users, Settings,
  ChevronLeft, ChevronRight, Info, Maximize2, Minimize2,
  Database, Activity, FlaskConical, Zap, Menu, X,
  Star, Trophy, AlertCircle, Eye, EyeOff
} from 'lucide-react';
import MoleculeViewer3D from './components/MoleculeViewer3D';
import SearchPanel from './components/SearchPanel';
import AIChat from './components/AIChat';
import MoleculeInfoPanel from './components/MoleculeInfoPanel';
import SettingsPanel from './components/SettingsPanel';
import LearningPanel from './components/LearningPanel';
import VirtualLabPanel from './components/VirtualLabPanel';
import CollaborationPanel from './components/CollaborationPanel';
import { useMolecularStore } from './store/molecularStore';
import type { AppTab } from './types/molecular';

// ─── Tab Configuration ────────────────────────────────────────────────────

const TABS: Array<{ id: AppTab; label: string; icon: React.ReactNode; color: string; shortLabel: string }> = [
  { id: 'viewer', label: 'Molecule Viewer', icon: <Atom className="w-4 h-4" />, color: 'violet', shortLabel: 'Viewer' },
  { id: 'learn', label: 'Learning', icon: <BookOpen className="w-4 h-4" />, color: 'blue', shortLabel: 'Learn' },
  { id: 'lab', label: 'Virtual Lab', icon: <Beaker className="w-4 h-4" />, color: 'green', shortLabel: 'Lab' },
  { id: 'collaborate', label: 'Collaborate', icon: <Users className="w-4 h-4" />, color: 'cyan', shortLabel: 'Collab' },
  { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" />, color: 'gray', shortLabel: 'Settings' },
];

// ─── Error Banner ──────────────────────────────────────────────────────────

function ErrorBanner({ error, onDismiss }: { error: string; onDismiss: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="flex items-center gap-3 px-4 py-2.5 bg-red-900/40 border-b border-red-500/30 text-red-300 text-xs"
    >
      <AlertCircle className="w-4 h-4 flex-shrink-0" />
      <span className="flex-1">{error}</span>
      <button onClick={onDismiss} className="text-red-400 hover:text-red-200 flex-shrink-0">
        <X className="w-3.5 h-3.5" />
      </button>
    </motion.div>
  );
}

// ─── Header ───────────────────────────────────────────────────────────────

function Header() {
  const { currentMolecule, userProgress, showAIPanel, toggleAIPanel, showInfoPanel, toggleInfoPanel, activeTab, setActiveTab } = useMolecularStore();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="flex-shrink-0 bg-gray-950/95 backdrop-blur-md border-b border-white/10 z-40 relative">
      <div className="flex items-center h-12 px-3 gap-3">
        {/* Logo */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="w-7 h-7 bg-gradient-to-br from-violet-600 to-blue-600 rounded-lg flex items-center justify-center shadow-lg">
            <FlaskConical className="w-4 h-4 text-white" />
          </div>
          <div className="hidden sm:block">
            <div className="text-sm font-bold text-white leading-tight">MolecularAI</div>
            <div className="text-xs text-gray-500 leading-tight">3D Intelligence Platform</div>
          </div>
        </div>

        {/* Tab Navigation - Desktop */}
        <nav className="hidden md:flex items-center gap-1 flex-1 justify-center">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-violet-600/80 text-white shadow'
                  : 'text-gray-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {tab.icon} {tab.shortLabel}
            </button>
          ))}
        </nav>

        {/* Right Section */}
        <div className="flex items-center gap-2 ml-auto">
          {/* XP Badge */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-yellow-900/30 border border-yellow-500/30 rounded-full">
            <Trophy className="w-3.5 h-3.5 text-yellow-400" />
            <span className="text-xs text-yellow-300 font-medium">Lv.{userProgress.level}</span>
            <span className="text-xs text-yellow-500">{userProgress.xp} XP</span>
          </div>

          {/* Current molecule quick info */}
          {currentMolecule && (
            <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 bg-violet-900/30 border border-violet-500/20 rounded-full">
              <Atom className="w-3.5 h-3.5 text-violet-400" />
              <span className="text-xs text-violet-300">{currentMolecule.name}</span>
            </div>
          )}

          {/* Toggle Panels */}
          {activeTab === 'viewer' && (
            <>
              <button
                onClick={toggleInfoPanel}
                className={`p-1.5 rounded-lg transition-colors ${showInfoPanel ? 'bg-blue-600/50 text-blue-300' : 'text-gray-500 hover:text-white hover:bg-white/10'}`}
                title="Toggle Info Panel"
              >
                <Info className="w-4 h-4" />
              </button>
              <button
                onClick={toggleAIPanel}
                className={`p-1.5 rounded-lg transition-colors ${showAIPanel ? 'bg-violet-600/50 text-violet-300' : 'text-gray-500 hover:text-white hover:bg-white/10'}`}
                title="Toggle AI Panel"
              >
                <Bot className="w-4 h-4" />
              </button>
            </>
          )}

          {/* Mobile menu */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-1.5 text-gray-400 hover:text-white"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: 'auto' }}
            exit={{ height: 0 }}
            className="md:hidden overflow-hidden border-t border-white/10"
          >
            <div className="flex gap-1 p-2">
              {TABS.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => { setActiveTab(tab.id); setMobileMenuOpen(false); }}
                  className={`flex-1 flex flex-col items-center gap-1 py-2 rounded-lg text-xs transition-all ${
                    activeTab === tab.id ? 'bg-violet-600 text-white' : 'text-gray-400 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {tab.icon}
                  {tab.shortLabel}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

// ─── Status Bar ────────────────────────────────────────────────────────────

function StatusBar() {
  const { currentMolecule, isLoading, moleculeCache } = useMolecularStore();
  const cacheSize = Object.keys(moleculeCache).length;

  return (
    <div className="flex-shrink-0 flex items-center justify-between px-4 py-1 bg-black/40 border-t border-white/5 text-xs text-gray-600">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1">
          <div className={`w-1.5 h-1.5 rounded-full ${isLoading ? 'bg-yellow-400 animate-pulse' : 'bg-green-400'}`} />
          <span>{isLoading ? 'Loading...' : 'Ready'}</span>
        </div>
        {currentMolecule && (
          <>
            <span>•</span>
            <span>{currentMolecule.atoms.length} atoms • {currentMolecule.bonds.length} bonds</span>
          </>
        )}
      </div>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1">
          <Database className="w-3 h-3" />
          <span>{cacheSize} cached</span>
        </div>
        <span>•</span>
        <span>PubChem API</span>
      </div>
    </div>
  );
}

// ─── Resizable Panel ──────────────────────────────────────────────────────

interface PanelProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  collapsible?: boolean;
  defaultCollapsed?: boolean;
  accentColor?: string;
}

function Panel({ title, icon, children, className = '', collapsible = false, defaultCollapsed = false, accentColor = 'violet' }: PanelProps) {
  const [collapsed, setCollapsed] = useState(defaultCollapsed);

  return (
    <motion.div
      className={`flex flex-col bg-gray-950/80 border border-white/10 rounded-xl overflow-hidden ${className}`}
      animate={{ width: collapsed ? 'auto' : undefined }}
    >
      <div
        className={`flex items-center justify-between px-3 py-2 border-b border-white/10 flex-shrink-0 cursor-${collapsible ? 'pointer' : 'default'}`}
        onClick={() => collapsible && setCollapsed(!collapsed)}
      >
        <div className="flex items-center gap-2">
          <span className={`text-${accentColor}-400`}>{icon}</span>
          {!collapsed && <span className="text-xs font-semibold text-white">{title}</span>}
        </div>
        {collapsible && (
          <button className="text-gray-500 hover:text-white transition-colors">
            {collapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
          </button>
        )}
      </div>
      {!collapsed && <div className="flex-1 overflow-hidden">{children}</div>}
    </motion.div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────

export default function App() {
  const {
    activeTab,
    error,
    setError,
    showInfoPanel,
    showAIPanel,
    isLoading,
    currentMolecule,
  } = useMolecularStore();

  const [viewerExpanded, setViewerExpanded] = useState(false);

  return (
    <div className="h-screen flex flex-col bg-gray-950 text-white overflow-hidden">
      <Header />

      <AnimatePresence>
        {error && (
          <ErrorBanner error={error} onDismiss={() => setError(null)} />
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        <AnimatePresence mode="wait">
          {activeTab === 'viewer' && (
            <motion.div
              key="viewer"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="h-full flex gap-2 p-2"
            >
              {/* Left Panel: Search + Info */}
              <AnimatePresence>
                {showInfoPanel && !viewerExpanded && (
                  <motion.div
                    initial={{ width: 0, opacity: 0 }}
                    animate={{ width: 300, opacity: 1 }}
                    exit={{ width: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex-shrink-0 flex flex-col gap-2 overflow-hidden"
                    style={{ width: 300 }}
                  >
                    {/* Search */}
                    <div className="flex-shrink-0 bg-gray-950/80 border border-white/10 rounded-xl p-3">
                      <div className="flex items-center gap-2 mb-3">
                        <Atom className="w-4 h-4 text-violet-400" />
                        <span className="text-xs font-semibold text-white">Molecule Search</span>
                      </div>
                      <Suspense fallback={<div className="text-gray-400 text-xs">Loading...</div>}>
                        <SearchPanel />
                      </Suspense>
                    </div>

                    {/* Info */}
                    <div className="flex-1 bg-gray-950/80 border border-white/10 rounded-xl overflow-hidden min-h-0">
                      <div className="flex items-center gap-2 px-3 py-2 border-b border-white/10 flex-shrink-0">
                        <Info className="w-4 h-4 text-blue-400" />
                        <span className="text-xs font-semibold text-white">Molecular Data</span>
                        {currentMolecule && (
                          <span className="ml-auto text-xs text-gray-500">{currentMolecule.source}</span>
                        )}
                      </div>
                      <div className="h-full overflow-hidden">
                        <MoleculeInfoPanel />
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Center: 3D Viewer */}
              <div className="flex-1 relative bg-gray-950/50 border border-white/10 rounded-xl overflow-hidden">
                <Suspense fallback={
                  <div className="w-full h-full flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-12 h-12 border-2 border-violet-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                      <div className="text-sm text-gray-400">Loading 3D Engine...</div>
                    </div>
                  </div>
                }>
                  <MoleculeViewer3D className="w-full h-full" />
                </Suspense>

                {/* Viewer Overlay Controls */}
                <div className="absolute top-3 right-3 flex flex-col gap-1.5">
                  <button
                    onClick={() => setViewerExpanded(!viewerExpanded)}
                    className="p-1.5 bg-black/50 hover:bg-black/70 border border-white/10 rounded-lg text-gray-300 hover:text-white transition-all backdrop-blur-sm"
                    title={viewerExpanded ? 'Restore' : 'Expand viewer'}
                  >
                    {viewerExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                  </button>
                </div>

                {/* Welcome message */}
                {!currentMolecule && !isLoading && (
                  <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-full max-w-md px-4">
                    <div className="bg-black/70 backdrop-blur-md border border-white/10 rounded-2xl p-6 text-center">
                      <div className="text-3xl mb-3">🧬</div>
                      <h2 className="text-lg font-bold text-white mb-2">Welcome to MolecularAI</h2>
                      <p className="text-sm text-gray-400 leading-relaxed mb-4">
                        The world's most advanced 3D molecular intelligence platform. Search any molecule to begin your journey.
                      </p>
                      <div className="flex flex-wrap justify-center gap-2">
                        {['💧 Water', '☕ Caffeine', '💊 Aspirin', '🧬 Glucose'].map(m => (
                          <span key={m} className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs text-gray-300">
                            {m}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Right Panel: AI Chat */}
              <AnimatePresence>
                {showAIPanel && !viewerExpanded && (
                  <motion.div
                    initial={{ width: 0, opacity: 0 }}
                    animate={{ width: 340, opacity: 1 }}
                    exit={{ width: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex-shrink-0 bg-gray-950/80 border border-white/10 rounded-xl overflow-hidden"
                    style={{ width: 340 }}
                  >
                    <AIChat />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}

          {activeTab === 'learn' && (
            <motion.div
              key="learn"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="h-full flex gap-2 p-2"
            >
              {/* Left: Lesson panel */}
              <div className="w-80 flex-shrink-0 bg-gray-950/80 border border-white/10 rounded-xl overflow-hidden">
                <LearningPanel />
              </div>

              {/* Center: 3D viewer for molecules */}
              <div className="flex-1 bg-gray-950/50 border border-white/10 rounded-xl overflow-hidden relative">
                <Suspense fallback={<div className="w-full h-full flex items-center justify-center"><div className="w-8 h-8 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" /></div>}>
                  <MoleculeViewer3D className="w-full h-full" />
                </Suspense>
              </div>

              {/* Right: AI Tutor */}
              <div className="w-80 flex-shrink-0 bg-gray-950/80 border border-white/10 rounded-xl overflow-hidden">
                <AIChat />
              </div>
            </motion.div>
          )}

          {activeTab === 'lab' && (
            <motion.div
              key="lab"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="h-full flex gap-2 p-2"
            >
              <div className="w-96 flex-shrink-0 bg-gray-950/80 border border-white/10 rounded-xl overflow-hidden">
                <VirtualLabPanel />
              </div>
              <div className="flex-1 flex flex-col gap-2">
                <div className="flex-1 bg-gray-950/50 border border-white/10 rounded-xl overflow-hidden">
                  <Suspense fallback={<div className="w-full h-full flex items-center justify-center"><div className="w-8 h-8 border-2 border-green-500 border-t-transparent rounded-full animate-spin" /></div>}>
                    <MoleculeViewer3D className="w-full h-full" />
                  </Suspense>
                </div>
                {/* Reaction data panel */}
                <div className="flex-shrink-0 bg-gray-950/80 border border-white/10 rounded-xl p-3">
                  <div className="flex items-center gap-2 text-xs text-gray-400">
                    <Activity className="w-3.5 h-3.5 text-green-400" />
                    <span className="font-medium text-green-300">Reaction Monitor</span>
                    <div className="ml-auto flex items-center gap-1">
                      <div className="w-1.5 h-1.5 bg-green-400 rounded-full" />
                      <span>Simulation Ready</span>
                    </div>
                  </div>
                  <div className="mt-2 h-12 bg-black/30 rounded-lg flex items-center px-3 gap-4">
                    {[
                      { label: 'Temperature', value: '25°C', color: 'text-blue-400' },
                      { label: 'Pressure', value: '1 atm', color: 'text-green-400' },
                      { label: 'pH', value: '7.0', color: 'text-yellow-400' },
                      { label: 'Time', value: '0s', color: 'text-violet-400' },
                    ].map(v => (
                      <div key={v.label} className="flex flex-col">
                        <span className="text-xs text-gray-500">{v.label}</span>
                        <span className={`text-sm font-bold font-mono ${v.color}`}>{v.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="w-80 flex-shrink-0 bg-gray-950/80 border border-white/10 rounded-xl overflow-hidden">
                <AIChat />
              </div>
            </motion.div>
          )}

          {activeTab === 'collaborate' && (
            <motion.div
              key="collaborate"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="h-full flex gap-2 p-2"
            >
              <div className="w-80 flex-shrink-0 bg-gray-950/80 border border-white/10 rounded-xl overflow-hidden">
                <CollaborationPanel />
              </div>
              <div className="flex-1 bg-gray-950/50 border border-white/10 rounded-xl overflow-hidden relative">
                <Suspense fallback={<div className="w-full h-full flex items-center justify-center"><div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" /></div>}>
                  <MoleculeViewer3D className="w-full h-full" />
                </Suspense>
                {/* Collaboration Overlay */}
                <div className="absolute top-3 left-1/2 -translate-x-1/2">
                  <div className="flex items-center gap-2 bg-black/60 backdrop-blur-sm border border-white/10 rounded-full px-4 py-1.5">
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
                    <span className="text-xs text-cyan-300 font-medium">Shared Workspace</span>
                    <span className="text-xs text-gray-500">3 connected</span>
                  </div>
                </div>
              </div>
              <div className="w-80 flex-shrink-0 bg-gray-950/80 border border-white/10 rounded-xl overflow-hidden">
                <AIChat />
              </div>
            </motion.div>
          )}

          {activeTab === 'settings' && (
            <motion.div
              key="settings"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="h-full flex gap-2 p-2"
            >
              <div className="w-96 flex-shrink-0 bg-gray-950/80 border border-white/10 rounded-xl overflow-hidden">
                <SettingsPanel />
              </div>

              {/* Right: info cards */}
              <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-2 content-start overflow-y-auto">
                {/* Platform info */}
                <div className="bg-gray-950/80 border border-white/10 rounded-xl p-5">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-gradient-to-br from-violet-600 to-blue-600 rounded-xl flex items-center justify-center">
                      <FlaskConical className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="font-bold text-white">MolecularAI Platform</h3>
                      <p className="text-xs text-gray-400">v1.0 — Production Ready</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    {[
                      { label: 'Chemistry Engine', value: 'PubChem REST API', status: '✅' },
                      { label: '3D Renderer', value: 'Three.js / R3F', status: '✅' },
                      { label: 'AI System', value: 'Multi-provider', status: '✅' },
                      { label: 'Molecule Cache', value: 'IndexedDB + Memory', status: '✅' },
                      { label: 'Offline Support', value: 'Partial (cached)', status: '⚠️' },
                    ].map(item => (
                      <div key={item.label} className="flex items-center justify-between py-1.5 border-b border-white/5">
                        <span className="text-xs text-gray-400">{item.label}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-gray-300">{item.value}</span>
                          <span>{item.status}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* API Keys Guide */}
                <div className="bg-gray-950/80 border border-white/10 rounded-xl p-5">
                  <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                    <Zap className="w-4 h-4 text-yellow-400" /> AI Setup Guide
                  </h3>
                  <div className="space-y-3">
                    {[
                      {
                        provider: 'OpenAI',
                        url: 'https://platform.openai.com/api-keys',
                        models: 'GPT-4o, GPT-4o-mini',
                        color: 'text-green-400',
                        bg: 'bg-green-900/20 border-green-500/20',
                      },
                      {
                        provider: 'DeepSeek',
                        url: 'https://platform.deepseek.com',
                        models: 'deepseek-chat, deepseek-reasoner',
                        color: 'text-blue-400',
                        bg: 'bg-blue-900/20 border-blue-500/20',
                      },
                      {
                        provider: 'Ollama (Local)',
                        url: 'https://ollama.ai',
                        models: 'llama3, mistral, phi3',
                        color: 'text-orange-400',
                        bg: 'bg-orange-900/20 border-orange-500/20',
                      },
                    ].map(p => (
                      <div key={p.provider} className={`p-3 rounded-xl border ${p.bg}`}>
                        <div className={`text-xs font-bold mb-1 ${p.color}`}>{p.provider}</div>
                        <div className="text-xs text-gray-400 mb-1">Models: {p.models}</div>
                        <a href={p.url} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-400 hover:underline flex items-center gap-1">
                          Get API key →
                        </a>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Keyboard Shortcuts */}
                <div className="bg-gray-950/80 border border-white/10 rounded-xl p-5">
                  <h3 className="font-bold text-white mb-3">⌨️ Viewer Controls</h3>
                  <div className="space-y-1.5">
                    {[
                      { key: 'Left click + drag', action: 'Rotate molecule' },
                      { key: 'Right click + drag', action: 'Pan view' },
                      { key: 'Scroll wheel', action: 'Zoom in/out' },
                      { key: 'Click atom', action: 'Select & inspect' },
                      { key: 'Double click', action: 'Focus on atom' },
                    ].map(s => (
                      <div key={s.key} className="flex items-center justify-between py-1 border-b border-white/5">
                        <kbd className="text-xs bg-white/10 px-1.5 py-0.5 rounded font-mono text-gray-300">{s.key}</kbd>
                        <span className="text-xs text-gray-400">{s.action}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Data sources */}
                <div className="bg-gray-950/80 border border-white/10 rounded-xl p-5">
                  <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                    <Database className="w-4 h-4 text-blue-400" /> Data Sources
                  </h3>
                  <div className="space-y-2">
                    {[
                      { name: 'PubChem', desc: '118M+ compounds', url: 'https://pubchem.ncbi.nlm.nih.gov' },
                      { name: 'NIST WebBook', desc: 'Physical properties', url: 'https://webbook.nist.gov' },
                      { name: 'ChemSpider', desc: 'Structure search', url: 'https://www.chemspider.com' },
                    ].map(ds => (
                      <div key={ds.name} className="flex items-center justify-between py-1.5 border-b border-white/5">
                        <div>
                          <div className="text-xs font-medium text-white">{ds.name}</div>
                          <div className="text-xs text-gray-500">{ds.desc}</div>
                        </div>
                        <a href={ds.url} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-400 hover:underline">
                          Visit →
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <StatusBar />
    </div>
  );
}
