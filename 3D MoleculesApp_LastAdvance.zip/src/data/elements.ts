export interface ElementData {
  symbol: string;
  name: string;
  atomicNumber: number;
  atomicMass: number;
  color: string; // CPK coloring
  jmolColor: string;
  radius: number; // van der Waals radius in Angstroms
  covalentRadius: number;
  electronegativity: number;
  valence: number[];
  group?: number;
  period?: number;
}

export const ELEMENTS: Record<string, ElementData> = {
  H: { symbol: 'H', name: 'Hydrogen', atomicNumber: 1, atomicMass: 1.008, color: '#FFFFFF', jmolColor: '#FFFFFF', radius: 1.2, covalentRadius: 0.31, electronegativity: 2.2, valence: [1], group: 1, period: 1 },
  He: { symbol: 'He', name: 'Helium', atomicNumber: 2, atomicMass: 4.003, color: '#D9FFFF', jmolColor: '#D9FFFF', radius: 1.4, covalentRadius: 0.28, electronegativity: 0, valence: [0], group: 18, period: 1 },
  Li: { symbol: 'Li', name: 'Lithium', atomicNumber: 3, atomicMass: 6.941, color: '#CC80FF', jmolColor: '#CC80FF', radius: 1.82, covalentRadius: 1.28, electronegativity: 0.98, valence: [1], group: 1, period: 2 },
  Be: { symbol: 'Be', name: 'Beryllium', atomicNumber: 4, atomicMass: 9.012, color: '#C2FF00', jmolColor: '#C2FF00', radius: 1.53, covalentRadius: 0.96, electronegativity: 1.57, valence: [2], group: 2, period: 2 },
  B: { symbol: 'B', name: 'Boron', atomicNumber: 5, atomicMass: 10.811, color: '#FFB5B5', jmolColor: '#FFB5B5', radius: 1.92, covalentRadius: 0.84, electronegativity: 2.04, valence: [3], group: 13, period: 2 },
  C: { symbol: 'C', name: 'Carbon', atomicNumber: 6, atomicMass: 12.011, color: '#909090', jmolColor: '#909090', radius: 1.7, covalentRadius: 0.77, electronegativity: 2.55, valence: [4], group: 14, period: 2 },
  N: { symbol: 'N', name: 'Nitrogen', atomicNumber: 7, atomicMass: 14.007, color: '#3050F8', jmolColor: '#3050F8', radius: 1.55, covalentRadius: 0.71, electronegativity: 3.04, valence: [3], group: 15, period: 2 },
  O: { symbol: 'O', name: 'Oxygen', atomicNumber: 8, atomicMass: 15.999, color: '#FF0D0D', jmolColor: '#FF0D0D', radius: 1.52, covalentRadius: 0.66, electronegativity: 3.44, valence: [2], group: 16, period: 2 },
  F: { symbol: 'F', name: 'Fluorine', atomicNumber: 9, atomicMass: 18.998, color: '#90E050', jmolColor: '#90E050', radius: 1.47, covalentRadius: 0.57, electronegativity: 3.98, valence: [1], group: 17, period: 2 },
  Ne: { symbol: 'Ne', name: 'Neon', atomicNumber: 10, atomicMass: 20.180, color: '#B3E3F5', jmolColor: '#B3E3F5', radius: 1.54, covalentRadius: 0.58, electronegativity: 0, valence: [0], group: 18, period: 2 },
  Na: { symbol: 'Na', name: 'Sodium', atomicNumber: 11, atomicMass: 22.990, color: '#AB5CF2', jmolColor: '#AB5CF2', radius: 2.27, covalentRadius: 1.66, electronegativity: 0.93, valence: [1], group: 1, period: 3 },
  Mg: { symbol: 'Mg', name: 'Magnesium', atomicNumber: 12, atomicMass: 24.305, color: '#8AFF00', jmolColor: '#8AFF00', radius: 1.73, covalentRadius: 1.41, electronegativity: 1.31, valence: [2], group: 2, period: 3 },
  Al: { symbol: 'Al', name: 'Aluminum', atomicNumber: 13, atomicMass: 26.982, color: '#BFA6A6', jmolColor: '#BFA6A6', radius: 1.84, covalentRadius: 1.21, electronegativity: 1.61, valence: [3], group: 13, period: 3 },
  Si: { symbol: 'Si', name: 'Silicon', atomicNumber: 14, atomicMass: 28.086, color: '#F0C8A0', jmolColor: '#F0C8A0', radius: 2.1, covalentRadius: 1.11, electronegativity: 1.9, valence: [4], group: 14, period: 3 },
  P: { symbol: 'P', name: 'Phosphorus', atomicNumber: 15, atomicMass: 30.974, color: '#FF8000', jmolColor: '#FF8000', radius: 1.8, covalentRadius: 1.07, electronegativity: 2.19, valence: [3, 5], group: 15, period: 3 },
  S: { symbol: 'S', name: 'Sulfur', atomicNumber: 16, atomicMass: 32.065, color: '#FFFF30', jmolColor: '#FFFF30', radius: 1.8, covalentRadius: 1.05, electronegativity: 2.58, valence: [2, 4, 6], group: 16, period: 3 },
  Cl: { symbol: 'Cl', name: 'Chlorine', atomicNumber: 17, atomicMass: 35.453, color: '#1FF01F', jmolColor: '#1FF01F', radius: 1.75, covalentRadius: 1.02, electronegativity: 3.16, valence: [1, 3, 5, 7], group: 17, period: 3 },
  Ar: { symbol: 'Ar', name: 'Argon', atomicNumber: 18, atomicMass: 39.948, color: '#80D1E3', jmolColor: '#80D1E3', radius: 1.88, covalentRadius: 1.06, electronegativity: 0, valence: [0], group: 18, period: 3 },
  K: { symbol: 'K', name: 'Potassium', atomicNumber: 19, atomicMass: 39.098, color: '#8F40D4', jmolColor: '#8F40D4', radius: 2.75, covalentRadius: 2.03, electronegativity: 0.82, valence: [1], group: 1, period: 4 },
  Ca: { symbol: 'Ca', name: 'Calcium', atomicNumber: 20, atomicMass: 40.078, color: '#3DFF00', jmolColor: '#3DFF00', radius: 2.31, covalentRadius: 1.76, electronegativity: 1.0, valence: [2], group: 2, period: 4 },
  Fe: { symbol: 'Fe', name: 'Iron', atomicNumber: 26, atomicMass: 55.845, color: '#E06633', jmolColor: '#E06633', radius: 2.0, covalentRadius: 1.32, electronegativity: 1.83, valence: [2, 3], group: 8, period: 4 },
  Cu: { symbol: 'Cu', name: 'Copper', atomicNumber: 29, atomicMass: 63.546, color: '#C88033', jmolColor: '#C88033', radius: 1.4, covalentRadius: 1.32, electronegativity: 1.9, valence: [1, 2], group: 11, period: 4 },
  Zn: { symbol: 'Zn', name: 'Zinc', atomicNumber: 30, atomicMass: 65.38, color: '#7D80B0', jmolColor: '#7D80B0', radius: 1.39, covalentRadius: 1.22, electronegativity: 1.65, valence: [2], group: 12, period: 4 },
  Br: { symbol: 'Br', name: 'Bromine', atomicNumber: 35, atomicMass: 79.904, color: '#A62929', jmolColor: '#A62929', radius: 1.85, covalentRadius: 1.2, electronegativity: 2.96, valence: [1, 3, 5, 7], group: 17, period: 4 },
  I: { symbol: 'I', name: 'Iodine', atomicNumber: 53, atomicMass: 126.904, color: '#940094', jmolColor: '#940094', radius: 1.98, covalentRadius: 1.39, electronegativity: 2.66, valence: [1, 3, 5, 7], group: 17, period: 5 },
  Ag: { symbol: 'Ag', name: 'Silver', atomicNumber: 47, atomicMass: 107.868, color: '#C0C0C0', jmolColor: '#C0C0C0', radius: 1.72, covalentRadius: 1.45, electronegativity: 1.93, valence: [1], group: 11, period: 5 },
  Au: { symbol: 'Au', name: 'Gold', atomicNumber: 79, atomicMass: 196.967, color: '#FFD123', jmolColor: '#FFD123', radius: 1.66, covalentRadius: 1.36, electronegativity: 2.54, valence: [1, 3], group: 11, period: 6 },
  Hg: { symbol: 'Hg', name: 'Mercury', atomicNumber: 80, atomicMass: 200.59, color: '#B8B8D0', jmolColor: '#B8B8D0', radius: 1.55, covalentRadius: 1.49, electronegativity: 2.0, valence: [1, 2], group: 12, period: 6 },
  Pb: { symbol: 'Pb', name: 'Lead', atomicNumber: 82, atomicMass: 207.2, color: '#575961', jmolColor: '#575961', radius: 2.02, covalentRadius: 1.46, electronegativity: 2.33, valence: [2, 4], group: 14, period: 6 },
};

export function getElement(symbol: string): ElementData | undefined {
  return ELEMENTS[symbol];
}

export function getAtomColor(symbol: string, scheme: 'cpk' | 'jmol' | 'custom' = 'jmol'): string {
  const el = ELEMENTS[symbol];
  if (!el) return '#FF69B4'; // Hot pink for unknown
  return scheme === 'jmol' ? el.jmolColor : el.color;
}

export function getAtomRadius(symbol: string, mode: 'ball-stick' | 'space-filling' | 'wireframe' | 'stick' = 'ball-stick'): number {
  const el = ELEMENTS[symbol];
  const baseRadius = el?.covalentRadius || 0.77;
  switch (mode) {
    case 'space-filling': return (el?.radius || 1.5) * 0.3;
    case 'wireframe': return 0.05;
    case 'stick': return 0.1;
    case 'ball-stick':
    default: return baseRadius * 0.35;
  }
}

// Preset molecules with 3D coordinates
export const PRESET_MOLECULES: Record<string, { name: string; formula: string; smiles: string; description: string }> = {
  water: { name: 'Water', formula: 'H₂O', smiles: 'O', description: 'The most essential molecule for life' },
  methane: { name: 'Methane', formula: 'CH₄', smiles: 'C', description: 'Simplest alkane, main component of natural gas' },
  ethanol: { name: 'Ethanol', formula: 'C₂H₆O', smiles: 'CCO', description: 'Common alcohol found in beverages' },
  glucose: { name: 'Glucose', formula: 'C₆H₁₂O₆', smiles: 'OC[C@H]1OC(O)[C@H](O)[C@@H](O)[C@@H]1O', description: 'Primary energy source for cells' },
  caffeine: { name: 'Caffeine', formula: 'C₈H₁₀N₄O₂', smiles: 'CN1C=NC2=C1C(=O)N(C(=O)N2C)C', description: 'Psychoactive stimulant in coffee and tea' },
  aspirin: { name: 'Aspirin', formula: 'C₉H₈O₄', smiles: 'CC(=O)Oc1ccccc1C(=O)O', description: 'Common pain reliever and anti-inflammatory' },
  benzene: { name: 'Benzene', formula: 'C₆H₆', smiles: 'c1ccccc1', description: 'Simplest aromatic hydrocarbon' },
  co2: { name: 'Carbon Dioxide', formula: 'CO₂', smiles: 'O=C=O', description: 'Greenhouse gas produced by combustion' },
  ammonia: { name: 'Ammonia', formula: 'NH₃', smiles: 'N', description: 'Important industrial chemical and fertilizer' },
  acetone: { name: 'Acetone', formula: 'C₃H₆O', smiles: 'CC(C)=O', description: 'Common solvent and nail polish remover' },
  penicillin: { name: 'Penicillin G', formula: 'C₁₆H₁₈N₂O₄S', smiles: 'CC1(C)SC2C(NC(=O)Cc3ccccc3)C(=O)N2C1C(=O)O', description: 'Antibiotic that revolutionized medicine' },
  dna: { name: 'Adenine (DNA base)', formula: 'C₅H₅N₅', smiles: 'Nc1ncnc2[nH]cnc12', description: 'One of the four nucleobases in DNA' },
  cholesterol: { name: 'Cholesterol', formula: 'C₂₇H₄₆O', smiles: 'CC(C)CCCC(C)C1CCC2C1(CCC3C2CC=C4C3(CCC(C4)O)C)C', description: 'Essential lipid in cell membranes' },
  dopamine: { name: 'Dopamine', formula: 'C₈H₁₁NO₂', smiles: 'NCCc1ccc(O)c(O)c1', description: 'Neurotransmitter associated with reward' },
  capsaicin: { name: 'Capsaicin', formula: 'C₁₈H₂₇NO₃', smiles: 'COc1cc(CNC(=O)CCCC/C=C/C(C)C)ccc1O', description: 'Active component in chili peppers' },
};
