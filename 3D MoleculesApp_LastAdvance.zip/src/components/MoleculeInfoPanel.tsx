import { useState } from 'react';
import { Atom as AtomIcon, Link, ChevronDown, ChevronRight, ExternalLink, Copy, Check, Activity, Zap, Droplets } from 'lucide-react';
import { useMolecularStore } from '../store/molecularStore';
import type { Atom } from '../types/molecular';
import { ELEMENTS } from '../data/elements';

function PropertyRow({ label, value, unit = '' }: { label: string; value: string | number | undefined; unit?: string }) {
  if (value === undefined || value === null || value === '') return null;
  return (
    <div className="flex justify-between items-center py-1 border-b border-white/5">
      <span className="text-xs text-gray-400">{label}</span>
      <span className="text-xs text-white font-mono">{value}{unit}</span>
    </div>
  );
}

function AtomDetails({ atom }: { atom: Atom }) {
  const el = ELEMENTS[atom.symbol];
  return (
    <div className="bg-white/5 rounded-xl p-3 border border-white/10">
      <div className="flex items-center gap-3 mb-3">
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shadow-lg border-2"
          style={{ backgroundColor: atom.color + '33', borderColor: atom.color, color: atom.color }}
        >
          {atom.symbol}
        </div>
        <div>
          <div className="font-semibold text-white text-sm">{atom.element}</div>
          <div className="text-xs text-gray-400">Atom #{atom.id}</div>
        </div>
      </div>
      <div className="space-y-1">
        <PropertyRow label="Position X" value={atom.x.toFixed(3)} unit=" Å" />
        <PropertyRow label="Position Y" value={atom.y.toFixed(3)} unit=" Å" />
        <PropertyRow label="Position Z" value={atom.z.toFixed(3)} unit=" Å" />
        <PropertyRow label="Atomic Mass" value={atom.mass} unit=" u" />
        {atom.charge !== undefined && <PropertyRow label="Formal Charge" value={atom.charge === 0 ? 'Neutral' : `${atom.charge > 0 ? '+' : ''}${atom.charge}`} />}
        {atom.hybridization && <PropertyRow label="Hybridization" value={atom.hybridization} />}
        {el && (
          <>
            <PropertyRow label="Atomic Number" value={el.atomicNumber} />
            <PropertyRow label="Electronegativity" value={el.electronegativity || 'N/A'} />
            <PropertyRow label="Van der Waals r" value={el.radius} unit=" Å" />
            <PropertyRow label="Group" value={el.group} />
            <PropertyRow label="Period" value={el.period} />
          </>
        )}
      </div>
    </div>
  );
}

export default function MoleculeInfoPanel() {
  const { currentMolecule, selectedAtomId, visualConfig } = useMolecularStore();
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['overview', 'properties']));
  const [copied, setCopied] = useState<string | null>(null);

  if (!currentMolecule) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-6">
        <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
          <AtomIcon className="w-8 h-8 text-gray-500" />
        </div>
        <p className="text-sm text-gray-400 font-medium">No molecule loaded</p>
        <p className="text-xs text-gray-600 mt-1">Search for a molecule to see its properties</p>
      </div>
    );
  }

  const mol = currentMolecule;
  const selectedAtom = selectedAtomId ? mol.atoms.find(a => a.id === selectedAtomId) : null;

  function toggleSection(id: string) {
    setExpandedSections(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  function handleCopy(text: string, key: string) {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  }

  const SectionHeader = ({ id, label, icon }: { id: string; label: string; icon: React.ReactNode }) => (
    <button
      onClick={() => toggleSection(id)}
      className="w-full flex items-center justify-between py-2 text-xs font-semibold text-gray-300 hover:text-white transition-colors"
    >
      <div className="flex items-center gap-2">{icon}{label}</div>
      {expandedSections.has(id) ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
    </button>
  );

  return (
    <div className="overflow-y-auto h-full px-3 py-2 space-y-3 scrollbar-thin">
      {/* Molecule Header */}
      <div className="bg-gradient-to-r from-violet-900/40 to-blue-900/40 border border-violet-500/30 rounded-xl p-3">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h2 className="font-bold text-white text-base leading-tight">{mol.name}</h2>
            <div className="text-sm text-violet-300 mt-0.5">{mol.formula}</div>
            {mol.iupacName && <div className="text-xs text-gray-500 mt-1 leading-tight">{mol.iupacName}</div>}
          </div>
          <div className="flex flex-col gap-1">
            {mol.cid && (
              <a
                href={`https://pubchem.ncbi.nlm.nih.gov/compound/${mol.cid}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300"
              >
                PubChem <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-1.5 mt-2">
          {mol.properties.isAromatic && (
            <span className="px-2 py-0.5 bg-orange-500/20 border border-orange-500/30 text-orange-300 text-xs rounded-full">Aromatic</span>
          )}
          {mol.properties.isChiral && (
            <span className="px-2 py-0.5 bg-pink-500/20 border border-pink-500/30 text-pink-300 text-xs rounded-full">Chiral</span>
          )}
          <span className="px-2 py-0.5 bg-blue-500/20 border border-blue-500/30 text-blue-300 text-xs rounded-full">{mol.source || 'PubChem'}</span>
          <span className="px-2 py-0.5 bg-gray-500/20 border border-gray-500/30 text-gray-300 text-xs rounded-full">{mol.atoms.length} atoms</span>
        </div>
      </div>

      {/* Selected Atom Details */}
      {selectedAtom && (
        <div>
          <SectionHeader id="atom" label="Selected Atom" icon={<AtomIcon className="w-3.5 h-3.5 text-yellow-400" />} />
          {expandedSections.has('atom') && <AtomDetails atom={selectedAtom} />}
        </div>
      )}

      {/* SMILES & Identifiers */}
      <div>
        <SectionHeader id="identifiers" label="Identifiers" icon={<Link className="w-3.5 h-3.5 text-blue-400" />} />
        {expandedSections.has('identifiers') && (
          <div className="space-y-2">
            {[
              { label: 'SMILES', value: mol.smiles, key: 'smiles' },
              { label: 'InChIKey', value: mol.inchikey, key: 'inchikey' },
              ...(mol.cid ? [{ label: 'CID', value: String(mol.cid), key: 'cid' }] : []),
            ].filter(i => i.value).map(item => (
              <div key={item.key} className="bg-white/5 rounded-lg p-2 border border-white/10">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-500">{item.label}</span>
                  <button
                    onClick={() => handleCopy(item.value!, item.key)}
                    className="p-0.5 hover:bg-white/10 rounded text-gray-500 hover:text-white transition-colors"
                  >
                    {copied === item.key ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>
                <div className="text-xs font-mono text-gray-300 break-all leading-relaxed">{item.value}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Physical Properties */}
      <div>
        <SectionHeader id="properties" label="Physical Properties" icon={<Activity className="w-3.5 h-3.5 text-green-400" />} />
        {expandedSections.has('properties') && (
          <div className="bg-white/3 rounded-xl border border-white/5 divide-y divide-white/5 overflow-hidden">
            <PropertyRow label="Molecular Weight" value={mol.properties.molecularWeight?.toFixed(3)} unit=" g/mol" />
            <PropertyRow label="Exact Mass" value={mol.properties.exactMass?.toFixed(5)} unit=" Da" />
            <PropertyRow label="LogP (XLogP)" value={mol.properties.xlogp?.toFixed(2)} />
            <PropertyRow label="H-Bond Donors" value={mol.properties.hBondDonors} />
            <PropertyRow label="H-Bond Acceptors" value={mol.properties.hBondAcceptors} />
            <PropertyRow label="Rotatable Bonds" value={mol.properties.rotBonds} />
            <PropertyRow label="TPSA" value={mol.properties.tpsa?.toFixed(1)} unit=" Ų" />
            <PropertyRow label="Complexity" value={mol.properties.complexity?.toFixed(0)} />
            <PropertyRow label="Heavy Atoms" value={mol.properties.heavyAtomCount} />
            <PropertyRow label="Formal Charge" value={mol.properties.charge} />
            <PropertyRow label="Covalent Units" value={mol.properties.covalentUnitCount} />
            {mol.properties.dipole && <PropertyRow label="Dipole Moment" value={mol.properties.dipole.toFixed(2)} unit=" D" />}
          </div>
        )}
      </div>

      {/* Geometry */}
      <div>
        <SectionHeader id="geometry" label="Geometry & Structure" icon={<Zap className="w-3.5 h-3.5 text-purple-400" />} />
        {expandedSections.has('geometry') && (
          <div className="space-y-2">
            <div className="bg-white/3 rounded-xl border border-white/5 divide-y divide-white/5 overflow-hidden">
              <PropertyRow label="Geometry" value={mol.properties.geometry} />
              <PropertyRow label="VSEPR" value={mol.properties.vseprGeometry} />
              <PropertyRow label="Hybridization" value={mol.properties.hybridization} />
              <PropertyRow label="Stereocenters" value={mol.properties.atomStereoCount} />
              <PropertyRow label="Stereo Bonds" value={mol.properties.bondStereoCount} />
            </div>
            {mol.properties.bondAngles && mol.properties.bondAngles.length > 0 && (
              <div>
                <div className="text-xs text-gray-500 mb-1.5">Bond Angles:</div>
                <div className="space-y-1">
                  {mol.properties.bondAngles.map((ba, i) => (
                    <div key={i} className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-1.5">
                      <span className="text-xs font-mono text-violet-300">{ba.atom1}–{ba.central}–{ba.atom2}</span>
                      <span className="text-xs text-white font-bold">{ba.angle}°</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Functional Groups */}
      {mol.properties.functionalGroups && mol.properties.functionalGroups.length > 0 && (
        <div>
          <SectionHeader id="functional" label="Functional Groups" icon={<Droplets className="w-3.5 h-3.5 text-cyan-400" />} />
          {expandedSections.has('functional') && (
            <div className="flex flex-wrap gap-1.5">
              {mol.properties.functionalGroups.map(fg => (
                <span key={fg} className="px-2.5 py-1 bg-cyan-900/30 border border-cyan-500/30 text-cyan-300 text-xs rounded-full">
                  {fg}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Atom Composition */}
      <div>
        <SectionHeader id="composition" label="Atom Composition" icon={<AtomIcon className="w-3.5 h-3.5 text-orange-400" />} />
        {expandedSections.has('composition') && (
          <div className="space-y-1.5">
            {(() => {
              const counts: Record<string, number> = {};
              const colors: Record<string, string> = {};
              mol.atoms.forEach(a => {
                counts[a.symbol] = (counts[a.symbol] || 0) + 1;
                colors[a.symbol] = a.color;
              });
              const total = mol.atoms.length;
              return Object.entries(counts).sort(([, a], [, b]) => b - a).map(([sym, cnt]) => (
                <div key={sym} className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full border-2 flex-shrink-0" style={{ backgroundColor: colors[sym] + '33', borderColor: colors[sym] }} />
                  <span className="text-xs font-mono text-white w-6">{sym}</span>
                  <div className="flex-1 bg-white/10 rounded-full h-1.5">
                    <div
                      className="h-1.5 rounded-full transition-all"
                      style={{ width: `${(cnt / total) * 100}%`, backgroundColor: colors[sym] }}
                    />
                  </div>
                  <span className="text-xs text-gray-400 font-mono">{cnt} ({((cnt / total) * 100).toFixed(0)}%)</span>
                </div>
              ));
            })()}
          </div>
        )}
      </div>

      {/* Synonyms */}
      {mol.synonyms && mol.synonyms.length > 0 && (
        <div>
          <SectionHeader id="synonyms" label="Synonyms" icon={<Link className="w-3.5 h-3.5 text-gray-400" />} />
          {expandedSections.has('synonyms') && (
            <div className="flex flex-wrap gap-1.5">
              {mol.synonyms.slice(0, 8).map(syn => (
                <span key={syn} className="px-2 py-0.5 bg-white/5 border border-white/10 text-gray-300 text-xs rounded-full">{syn}</span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
