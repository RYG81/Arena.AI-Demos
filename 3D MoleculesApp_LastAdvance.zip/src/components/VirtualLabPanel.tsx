import { useState } from 'react';
import { Beaker, Zap, RefreshCw, Info, AlertTriangle, CheckCircle, ArrowRight, PlusCircle } from 'lucide-react';
import { useMolecularStore } from '../store/molecularStore';

interface Reaction {
  id: string;
  name: string;
  reactants: string[];
  products: string[];
  type: string;
  conditions: string;
  mechanism: string;
  energyChange: string;
  safetyNotes?: string;
  emoji: string;
}

const REACTIONS: Reaction[] = [
  {
    id: 'combustion-ch4',
    name: 'Methane Combustion',
    reactants: ['Methane (CH₄)', 'Oxygen (O₂)'],
    products: ['Carbon Dioxide (CO₂)', 'Water (H₂O)'],
    type: 'Combustion',
    conditions: 'Heat / Spark required',
    mechanism: 'CH₄ + 2O₂ → CO₂ + 2H₂O',
    energyChange: '-890 kJ/mol (exothermic)',
    safetyNotes: '⚠️ Flammable gas — handle with care',
    emoji: '🔥',
  },
  {
    id: 'acid-base',
    name: 'Acid-Base Neutralization',
    reactants: ['Hydrochloric Acid (HCl)', 'Sodium Hydroxide (NaOH)'],
    products: ['Sodium Chloride (NaCl)', 'Water (H₂O)'],
    type: 'Acid-Base',
    conditions: 'Aqueous solution, room temperature',
    mechanism: 'HCl + NaOH → NaCl + H₂O',
    energyChange: '-57 kJ/mol (exothermic)',
    safetyNotes: '⚠️ Corrosive reagents',
    emoji: '⚗️',
  },
  {
    id: 'photosynthesis',
    name: 'Photosynthesis',
    reactants: ['Carbon Dioxide (CO₂)', 'Water (H₂O)', 'Light Energy'],
    products: ['Glucose (C₆H₁₂O₆)', 'Oxygen (O₂)'],
    type: 'Biological',
    conditions: 'Sunlight, chlorophyll enzyme',
    mechanism: '6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂',
    energyChange: '+2803 kJ/mol (endothermic)',
    emoji: '🌿',
  },
  {
    id: 'fermentation',
    name: 'Alcoholic Fermentation',
    reactants: ['Glucose (C₆H₁₂O₆)'],
    products: ['Ethanol (C₂H₅OH)', 'Carbon Dioxide (CO₂)'],
    type: 'Biological',
    conditions: 'Yeast enzymes, anaerobic conditions',
    mechanism: 'C₆H₁₂O₆ → 2C₂H₅OH + 2CO₂',
    energyChange: '-218 kJ/mol',
    emoji: '🍺',
  },
  {
    id: 'esterification',
    name: 'Fischer Esterification',
    reactants: ['Acetic Acid (CH₃COOH)', 'Ethanol (C₂H₅OH)'],
    products: ['Ethyl Acetate (CH₃COOC₂H₅)', 'Water (H₂O)'],
    type: 'Organic',
    conditions: 'H₂SO₄ catalyst, heat',
    mechanism: 'CH₃COOH + C₂H₅OH ⇌ CH₃COOC₂H₅ + H₂O',
    energyChange: 'Reversible, ΔG ≈ -3 kJ/mol',
    emoji: '🧴',
  },
  {
    id: 'saponification',
    name: 'Saponification (Soap making)',
    reactants: ['Fat/Oil (Triglyceride)', 'Sodium Hydroxide (NaOH)'],
    products: ['Soap (Fatty acid salt)', 'Glycerol'],
    type: 'Organic',
    conditions: 'Base, heat',
    mechanism: 'Triglyceride + 3NaOH → 3RCOONa + Glycerol',
    energyChange: '-160 kJ/mol',
    emoji: '🧼',
  },
  {
    id: 'synthesis-aspirin',
    name: 'Aspirin Synthesis',
    reactants: ['Salicylic Acid (C₇H₆O₃)', 'Acetic Anhydride ((CH₃CO)₂O)'],
    products: ['Aspirin (C₉H₈O₄)', 'Acetic Acid (CH₃COOH)'],
    type: 'Pharmaceutical',
    conditions: 'H₃PO₄ catalyst, 50-60°C',
    mechanism: 'C₇H₆O₃ + (CH₃CO)₂O → C₉H₈O₄ + CH₃COOH',
    energyChange: '-60 kJ/mol',
    emoji: '💊',
  },
  {
    id: 'haber-process',
    name: 'Haber Process (Ammonia)',
    reactants: ['Nitrogen (N₂)', 'Hydrogen (H₂)'],
    products: ['Ammonia (NH₃)'],
    type: 'Industrial',
    conditions: '400-500°C, 200 atm, Fe catalyst',
    mechanism: 'N₂ + 3H₂ ⇌ 2NH₃',
    energyChange: '-92 kJ/mol per cycle',
    safetyNotes: '⚠️ High pressure process',
    emoji: '🏭',
  },
];

interface BubbleEffect {
  id: number;
  x: number;
  y: number;
  color: string;
}

export default function VirtualLabPanel() {
  const [selectedReaction, setSelectedReaction] = useState<Reaction | null>(null);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [bubbles, setBubbles] = useState<BubbleEffect[]>([]);
  const [filterType, setFilterType] = useState<string>('All');
  const { addXP } = useMolecularStore();

  const reactionTypes = ['All', ...Array.from(new Set(REACTIONS.map(r => r.type)))];
  const filtered = filterType === 'All' ? REACTIONS : REACTIONS.filter(r => r.type === filterType);

  function runReaction() {
    if (!selectedReaction || running) return;
    setRunning(true);
    setResult(null);

    // Create bubble effects
    const colors = ['#7C3AED', '#2563EB', '#059669', '#DC2626', '#D97706'];
    const newBubbles = Array.from({ length: 8 }).map((_, i) => ({
      id: i,
      x: 10 + Math.random() * 80,
      y: 20 + Math.random() * 60,
      color: colors[i % colors.length],
    }));
    setBubbles(newBubbles);

    setTimeout(() => {
      setRunning(false);
      setBubbles([]);
      setResult(`✅ Reaction Complete!\n\n${selectedReaction.mechanism}\n\nProducts: ${selectedReaction.products.join(' + ')}\n\nEnergy: ${selectedReaction.energyChange}`);
      addXP(75);
    }, 2500);
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-4 py-3 border-b border-white/10">
        <div className="flex items-center gap-2 mb-1">
          <Beaker className="w-4 h-4 text-green-400" />
          <h2 className="text-sm font-bold text-white">Virtual Lab</h2>
        </div>
        <p className="text-xs text-gray-400">Simulate chemical reactions safely in your browser</p>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin">
        <div className="p-4 space-y-4">
          {/* Filter */}
          <div className="flex gap-1.5 flex-wrap">
            {reactionTypes.map(type => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-2.5 py-1 text-xs rounded-full border transition-all ${
                  filterType === type
                    ? 'bg-green-600 border-green-400 text-white'
                    : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          {/* Reaction Cards */}
          <div className="space-y-2">
            {filtered.map(reaction => (
              <button
                key={reaction.id}
                onClick={() => { setSelectedReaction(reaction); setResult(null); }}
                className={`w-full text-left p-3 rounded-xl border transition-all ${
                  selectedReaction?.id === reaction.id
                    ? 'bg-green-900/30 border-green-500/40'
                    : 'bg-white/5 border-white/10 hover:bg-white/10'
                }`}
              >
                <div className="flex items-start gap-2">
                  <span className="text-lg">{reaction.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-white">{reaction.name}</div>
                    <div className="flex items-center gap-1 mt-1">
                      <span className="text-xs text-gray-400">{reaction.reactants.join(' + ')}</span>
                      <ArrowRight className="w-3 h-3 text-gray-500 flex-shrink-0" />
                      <span className="text-xs text-green-400">{reaction.products.join(' + ')}</span>
                    </div>
                    <div className="flex gap-2 mt-1">
                      <span className="text-xs bg-white/5 px-1.5 py-0.5 rounded text-gray-500">{reaction.type}</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* Selected Reaction Detail */}
          {selectedReaction && (
            <div className="space-y-3">
              <div className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 border border-green-500/30 rounded-xl p-4">
                <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                  <span>{selectedReaction.emoji}</span> {selectedReaction.name}
                </h3>

                {/* Reactants → Products visualization */}
                <div className="flex items-center gap-2 flex-wrap mb-3">
                  <div className="flex flex-wrap gap-1">
                    {selectedReaction.reactants.map(r => (
                      <span key={r} className="px-2 py-1 bg-blue-900/40 border border-blue-500/30 text-blue-300 text-xs rounded-lg">{r}</span>
                    ))}
                  </div>
                  <div className="flex items-center gap-1 text-gray-400">
                    <ArrowRight className="w-5 h-5" />
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {selectedReaction.products.map(p => (
                      <span key={p} className="px-2 py-1 bg-green-900/40 border border-green-500/30 text-green-300 text-xs rounded-lg">{p}</span>
                    ))}
                  </div>
                </div>

                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center gap-2">
                    <Info className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                    <span className="text-gray-300">{selectedReaction.conditions}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Zap className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                    <span className="text-gray-300 font-mono">{selectedReaction.energyChange}</span>
                  </div>
                  {selectedReaction.safetyNotes && (
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-3.5 h-3.5 text-red-400 flex-shrink-0" />
                      <span className="text-red-300">{selectedReaction.safetyNotes}</span>
                    </div>
                  )}
                </div>

                {/* Mechanism */}
                <div className="mt-3 p-2.5 bg-black/30 rounded-lg font-mono text-xs text-violet-300">
                  {selectedReaction.mechanism}
                </div>
              </div>

              {/* Reaction Flask Visual */}
              <div className="relative bg-black/30 border border-white/10 rounded-xl h-40 overflow-hidden flex items-center justify-center">
                {/* Flask SVG */}
                <svg viewBox="0 0 100 100" className="w-32 h-32 absolute opacity-20">
                  <path d="M35,10 L35,50 L10,90 L90,90 L65,50 L65,10 Z" fill="none" stroke="#7C3AED" strokeWidth="2"/>
                  <line x1="30" y1="10" x2="70" y2="10" stroke="#7C3AED" strokeWidth="2"/>
                </svg>

                {/* Bubbles */}
                {bubbles.map(bubble => (
                  <div
                    key={bubble.id}
                    className="absolute w-3 h-3 rounded-full animate-bounce opacity-80"
                    style={{
                      left: `${bubble.x}%`,
                      top: `${bubble.y}%`,
                      backgroundColor: bubble.color,
                      animationDelay: `${bubble.id * 100}ms`,
                      animationDuration: '0.6s',
                    }}
                  />
                ))}

                {!running && !result && (
                  <div className="text-center z-10">
                    <Beaker className="w-8 h-8 text-gray-500 mx-auto mb-2" />
                    <p className="text-xs text-gray-500">Ready to react</p>
                  </div>
                )}

                {running && (
                  <div className="text-center z-10">
                    <RefreshCw className="w-8 h-8 text-green-400 mx-auto mb-2 animate-spin" />
                    <p className="text-xs text-green-400 animate-pulse">Reaction in progress...</p>
                  </div>
                )}

                {result && !running && (
                  <div className="text-center z-10">
                    <CheckCircle className="w-8 h-8 text-green-400 mx-auto mb-2" />
                    <p className="text-xs text-green-300">Complete! +75 XP</p>
                  </div>
                )}
              </div>

              {/* Result */}
              {result && (
                <div className="bg-green-900/20 border border-green-500/30 rounded-xl p-3">
                  <pre className="text-xs text-green-300 whitespace-pre-wrap font-mono leading-relaxed">{result}</pre>
                </div>
              )}

              {/* Run Button */}
              <button
                onClick={runReaction}
                disabled={running}
                className="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 disabled:opacity-50 text-white rounded-xl font-medium text-sm transition-all flex items-center justify-center gap-2"
              >
                {running ? (
                  <><RefreshCw className="w-4 h-4 animate-spin" /> Simulating...</>
                ) : (
                  <><Zap className="w-4 h-4" /> Run Reaction</>
                )}
              </button>
            </div>
          )}

          {/* Tip */}
          <div className="bg-blue-900/20 border border-blue-500/20 rounded-xl p-3 flex gap-2">
            <PlusCircle className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-gray-400 leading-relaxed">
              Select a reaction to simulate it in the virtual flask. Each successful simulation awards +75 XP and helps you understand reaction mechanisms.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
