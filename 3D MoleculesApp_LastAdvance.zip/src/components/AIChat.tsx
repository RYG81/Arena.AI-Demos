import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Trash2, Settings2, Sparkles, Brain, Shield, Zap, Copy, Check } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { useMolecularStore } from '../store/molecularStore';
import { sendAIMessage } from '../services/aiService';
import type { ChatMessage, AIMode } from '../types/molecular';

const MODE_CONFIG: Record<AIMode, { label: string; icon: React.ReactNode; color: string; desc: string }> = {
  explainer: { label: 'Explainer', icon: <Sparkles className="w-3.5 h-3.5" />, color: 'text-violet-400', desc: 'Explains molecules clearly' },
  tutor: { label: 'Tutor', icon: <Brain className="w-3.5 h-3.5" />, color: 'text-blue-400', desc: 'Socratic teaching method' },
  validator: { label: 'Validator', icon: <Shield className="w-3.5 h-3.5" />, color: 'text-green-400', desc: 'Verifies chemical accuracy' },
  copilot: { label: 'Co-pilot', icon: <Zap className="w-3.5 h-3.5" />, color: 'text-yellow-400', desc: 'Research assistant' },
};

const QUICK_PROMPTS = [
  'What is this molecule used for?',
  'Explain its molecular structure',
  'What are its physical properties?',
  'How does it interact with water?',
  'What functional groups does it have?',
  'Compare to similar molecules',
  'Explain the VSEPR geometry',
  'What makes it biologically important?',
];

interface MessageBubbleProps {
  message: ChatMessage;
}

function MessageBubble({ message }: MessageBubbleProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (message.role === 'user') {
    return (
      <div className="flex justify-end mb-3">
        <div className="flex items-start gap-2 max-w-[85%]">
          <div className="bg-violet-600 text-white rounded-2xl rounded-tr-sm px-4 py-2.5 text-sm">
            {message.content}
          </div>
          <div className="flex-shrink-0 w-7 h-7 bg-violet-700 rounded-full flex items-center justify-center">
            <User className="w-4 h-4 text-white" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start mb-3">
      <div className="flex items-start gap-2 max-w-[95%]">
        <div className="flex-shrink-0 w-7 h-7 bg-gradient-to-br from-violet-600 to-blue-600 rounded-full flex items-center justify-center">
          <Bot className="w-4 h-4 text-white" />
        </div>
        <div className="group relative bg-white/5 border border-white/10 rounded-2xl rounded-tl-sm px-4 py-3 text-sm text-gray-200">
          <div className="prose prose-invert prose-sm max-w-none">
            <ReactMarkdown
              components={{
                h2: ({ children }) => <h2 className="text-violet-300 font-bold text-base mt-2 mb-1">{children}</h2>,
                h3: ({ children }) => <h3 className="text-blue-300 font-semibold mt-2 mb-1">{children}</h3>,
                code: ({ children }) => <code className="bg-white/10 px-1.5 py-0.5 rounded text-green-300 font-mono text-xs">{children}</code>,
                pre: ({ children }) => <pre className="bg-black/40 rounded-lg p-3 overflow-x-auto text-xs my-2">{children}</pre>,
                strong: ({ children }) => <strong className="text-white font-semibold">{children}</strong>,
                ul: ({ children }) => <ul className="list-disc list-inside space-y-0.5 my-1">{children}</ul>,
                ol: ({ children }) => <ol className="list-decimal list-inside space-y-0.5 my-1">{children}</ol>,
                blockquote: ({ children }) => (
                  <blockquote className="border-l-2 border-violet-500 pl-3 text-gray-400 italic my-2">{children}</blockquote>
                ),
                table: ({ children }) => (
                  <table className="w-full border-collapse text-xs my-2">{children}</table>
                ),
                th: ({ children }) => (
                  <th className="border border-white/20 bg-white/10 px-2 py-1 text-left font-medium">{children}</th>
                ),
                td: ({ children }) => (
                  <td className="border border-white/10 px-2 py-1">{children}</td>
                ),
              }}
            >
              {message.content}
            </ReactMarkdown>
          </div>
          <button
            onClick={handleCopy}
            className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1 hover:bg-white/10 rounded transition-all"
          >
            {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3 text-gray-400" />}
          </button>
          <div className="text-xs text-gray-600 mt-1">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>
      </div>
    </div>
  );
}

function ThinkingBubble() {
  return (
    <div className="flex justify-start mb-3">
      <div className="flex items-start gap-2">
        <div className="flex-shrink-0 w-7 h-7 bg-gradient-to-br from-violet-600 to-blue-600 rounded-full flex items-center justify-center animate-pulse">
          <Bot className="w-4 h-4 text-white" />
        </div>
        <div className="bg-white/5 border border-white/10 rounded-2xl rounded-tl-sm px-4 py-3">
          <div className="flex gap-1 items-center">
            <div className="w-2 h-2 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <div className="w-2 h-2 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <div className="w-2 h-2 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            <span className="ml-2 text-xs text-gray-500">Analyzing molecule...</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AIChat() {
  const [input, setInput] = useState('');
  const [showModeMenu, setShowModeMenu] = useState(false);
  const [showQuickPrompts, setShowQuickPrompts] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const {
    chatHistory,
    addChatMessage,
    clearChat,
    isChatLoading,
    setChatLoading,
    currentMolecule,
    aiConfig,
    aiMode,
    setAIMode,
  } = useMolecularStore();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory, isChatLoading]);

  async function handleSend(messageOverride?: string) {
    const msg = messageOverride || input.trim();
    if (!msg || isChatLoading) return;
    setInput('');
    setShowQuickPrompts(false);

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: msg,
      timestamp: Date.now(),
      mode: aiMode,
    };
    addChatMessage(userMsg);
    setChatLoading(true);

    try {
      const history = chatHistory.slice(-10).map(m => ({
        role: m.role as 'user' | 'assistant' | 'system',
        content: m.content,
      }));

      const response = await sendAIMessage(msg, aiConfig, aiMode, currentMolecule, history);

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: Date.now(),
        mode: aiMode,
      };
      addChatMessage(aiMsg);
    } catch (err) {
      const errMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `❌ **Error:** ${err instanceof Error ? err.message : 'Failed to get AI response'}. Please check your API key in Settings.`,
        timestamp: Date.now(),
      };
      addChatMessage(errMsg);
    } finally {
      setChatLoading(false);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  const currentMode = MODE_CONFIG[aiMode];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-gradient-to-br from-violet-600 to-blue-600 rounded-full flex items-center justify-center">
            <Bot className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="text-sm font-medium text-white">MolecularAI</span>
        </div>
        <div className="flex items-center gap-1">
          {/* Mode selector */}
          <div className="relative">
            <button
              onClick={() => setShowModeMenu(!showModeMenu)}
              className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs border border-white/10 bg-white/5 hover:bg-white/10 transition-colors ${currentMode.color}`}
            >
              {currentMode.icon}
              {currentMode.label}
            </button>
            {showModeMenu && (
              <div className="absolute right-0 top-full mt-1 bg-gray-900 border border-white/20 rounded-xl shadow-2xl z-50 overflow-hidden min-w-44">
                {(Object.entries(MODE_CONFIG) as [AIMode, typeof currentMode][]).map(([mode, cfg]) => (
                  <button
                    key={mode}
                    onClick={() => { setAIMode(mode); setShowModeMenu(false); }}
                    className={`w-full text-left px-3 py-2 hover:bg-white/10 transition-colors flex items-center gap-2 ${aiMode === mode ? 'bg-white/10' : ''}`}
                  >
                    <span className={cfg.color}>{cfg.icon}</span>
                    <div>
                      <div className={`text-xs font-medium ${cfg.color}`}>{cfg.label}</div>
                      <div className="text-xs text-gray-500">{cfg.desc}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
          <button onClick={clearChat} className="p-1 hover:bg-white/10 rounded text-gray-400 hover:text-red-400 transition-colors">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-1 scrollbar-thin">
        {chatHistory.length === 0 && (
          <div className="text-center py-6">
            <div className="w-12 h-12 bg-gradient-to-br from-violet-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-3">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <p className="text-sm font-medium text-white mb-1">MolecularAI Ready</p>
            <p className="text-xs text-gray-400 mb-3">
              {currentMolecule
                ? `Ask me anything about ${currentMolecule.name}`
                : 'Search for a molecule to begin analysis'}
            </p>
            {currentMolecule && (
              <button
                onClick={() => handleSend(`Give me a comprehensive overview of ${currentMolecule.name}`)}
                className="px-4 py-2 bg-violet-600/80 hover:bg-violet-600 text-white text-xs rounded-full transition-colors"
              >
                ✨ Auto-explain this molecule
              </button>
            )}
          </div>
        )}
        {chatHistory.map(msg => (
          <MessageBubble key={msg.id} message={msg} />
        ))}
        {isChatLoading && <ThinkingBubble />}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts */}
      {showQuickPrompts && (
        <div className="px-3 py-2 border-t border-white/10 bg-black/20">
          <div className="text-xs text-gray-500 mb-2">Quick prompts:</div>
          <div className="flex flex-wrap gap-1.5">
            {QUICK_PROMPTS.map(p => (
              <button
                key={p}
                onClick={() => handleSend(p)}
                className="px-2.5 py-1 text-xs bg-white/5 hover:bg-violet-600/40 border border-white/10 hover:border-violet-500 text-gray-300 hover:text-white rounded-full transition-all"
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="px-3 py-3 border-t border-white/10">
        <div className="flex gap-2">
          <button
            onClick={() => setShowQuickPrompts(!showQuickPrompts)}
            className={`flex-shrink-0 p-2 rounded-lg border transition-colors ${showQuickPrompts ? 'bg-violet-600 border-violet-400 text-white' : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'}`}
            title="Quick prompts"
          >
            <Settings2 className="w-4 h-4" />
          </button>
          <div className="flex-1 relative">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={currentMolecule ? `Ask about ${currentMolecule.name}...` : 'Search a molecule first...'}
              rows={1}
              className="w-full bg-white/5 border border-white/10 text-white placeholder-gray-500 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400 resize-none transition-colors"
              style={{ minHeight: '40px', maxHeight: '120px' }}
            />
          </div>
          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || isChatLoading}
            className="flex-shrink-0 p-2 bg-violet-600 hover:bg-violet-500 disabled:bg-violet-900 disabled:opacity-40 text-white rounded-xl transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <div className="text-xs text-gray-600 mt-1 text-center">
          Shift+Enter for new line • Enter to send
        </div>
      </div>
    </div>
  );
}
