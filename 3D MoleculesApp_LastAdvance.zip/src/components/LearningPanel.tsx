import { useState } from 'react';
import { BookOpen, Trophy, Star, ChevronRight, CheckCircle, Circle, Zap, Brain, Target, Award } from 'lucide-react';
import { useMolecularStore } from '../store/molecularStore';
import { generateQuizQuestions } from '../services/aiService';
import type { LessonModule } from '../types/molecular';

const DIFFICULTY_COLORS = {
  beginner: 'text-green-400 bg-green-900/30 border-green-500/30',
  intermediate: 'text-yellow-400 bg-yellow-900/30 border-yellow-500/30',
  advanced: 'text-red-400 bg-red-900/30 border-red-500/30',
};

function LevelBadge({ level, xp }: { level: number; xp: number }) {
  const nextLevelXP = level * 500;
  const progress = (xp % 500) / 500 * 100;

  return (
    <div className="bg-gradient-to-r from-violet-900/50 to-blue-900/50 border border-violet-500/30 rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center font-bold text-black text-sm shadow-lg">
            {level}
          </div>
          <div>
            <div className="text-sm font-bold text-white">Level {level}</div>
            <div className="text-xs text-gray-400">{xp} XP total</div>
          </div>
        </div>
        <Trophy className="w-6 h-6 text-yellow-400" />
      </div>
      <div className="space-y-1">
        <div className="flex justify-between text-xs text-gray-400">
          <span>Progress to Level {level + 1}</span>
          <span>{xp % 500}/{500} XP</span>
        </div>
        <div className="bg-white/10 rounded-full h-2">
          <div
            className="h-2 rounded-full bg-gradient-to-r from-violet-500 to-blue-500 transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
}

function AchievementBadge({ achievement }: { achievement: { id: string; name: string; description: string; icon: string; unlocked: boolean } }) {
  return (
    <div className={`p-2.5 rounded-xl border text-center transition-all ${
      achievement.unlocked
        ? 'bg-yellow-900/30 border-yellow-500/40'
        : 'bg-white/3 border-white/10 opacity-50 grayscale'
    }`}>
      <div className="text-xl mb-1">{achievement.icon}</div>
      <div className="text-xs font-medium text-white leading-tight">{achievement.name}</div>
      <div className="text-xs text-gray-500 mt-0.5 leading-tight">{achievement.description}</div>
    </div>
  );
}

interface QuizState {
  questions: Array<{ question: string; options: string[]; correct: string; explanation: string }>;
  currentQ: number;
  selected: string | null;
  score: number;
  finished: boolean;
}

function QuizMode({ onExit }: { onExit: () => void }) {
  const { currentMolecule, addXP } = useMolecularStore();
  const [quiz, setQuiz] = useState<QuizState | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  function startQuiz() {
    if (!currentMolecule) return;
    const questions = generateQuizQuestions(currentMolecule);
    setQuiz({ questions, currentQ: 0, selected: null, score: 0, finished: false });
    setShowExplanation(false);
  }

  function handleAnswer(option: string) {
    if (!quiz || quiz.selected) return;
    setQuiz(q => ({ ...q!, selected: option }));
    setShowExplanation(true);
    if (option === quiz.questions[quiz.currentQ].correct) {
      addXP(30);
    }
  }

  function nextQuestion() {
    if (!quiz) return;
    const isCorrect = quiz.selected === quiz.questions[quiz.currentQ].correct;
    const newScore = isCorrect ? quiz.score + 1 : quiz.score;
    if (quiz.currentQ + 1 >= quiz.questions.length) {
      setQuiz(q => ({ ...q!, score: newScore, finished: true }));
    } else {
      setQuiz(q => ({ ...q!, currentQ: q!.currentQ + 1, selected: null, score: newScore }));
      setShowExplanation(false);
    }
  }

  if (!currentMolecule) {
    return (
      <div className="text-center py-8">
        <Target className="w-10 h-10 text-gray-500 mx-auto mb-3" />
        <p className="text-sm text-gray-400">Load a molecule to start a quiz</p>
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="text-center py-8">
        <Brain className="w-10 h-10 text-violet-400 mx-auto mb-3" />
        <h3 className="text-sm font-bold text-white mb-1">Quiz: {currentMolecule.name}</h3>
        <p className="text-xs text-gray-400 mb-4">Test your knowledge about this molecule</p>
        <button onClick={startQuiz} className="px-6 py-2 bg-violet-600 hover:bg-violet-500 text-white rounded-xl text-sm font-medium transition-colors">
          Start Quiz
        </button>
      </div>
    );
  }

  if (quiz.finished) {
    const pct = Math.round((quiz.score / quiz.questions.length) * 100);
    return (
      <div className="text-center py-6">
        <div className="text-4xl mb-3">{pct >= 70 ? '🏆' : pct >= 50 ? '⭐' : '📚'}</div>
        <h3 className="text-lg font-bold text-white mb-1">Quiz Complete!</h3>
        <p className="text-2xl font-bold text-violet-400 mb-1">{quiz.score}/{quiz.questions.length}</p>
        <p className="text-sm text-gray-400 mb-4">{pct}% correct • {quiz.score * 30} XP earned</p>
        <div className="flex gap-2 justify-center">
          <button onClick={startQuiz} className="px-4 py-2 bg-violet-600 hover:bg-violet-500 text-white rounded-xl text-sm transition-colors">Retry</button>
          <button onClick={onExit} className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-sm transition-colors">Exit</button>
        </div>
      </div>
    );
  }

  const q = quiz.questions[quiz.currentQ];
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-400">Question {quiz.currentQ + 1}/{quiz.questions.length}</span>
        <span className="text-xs text-violet-400">Score: {quiz.score}</span>
      </div>
      <div className="bg-white/5 border border-white/10 rounded-xl p-4">
        <p className="text-sm text-white font-medium leading-relaxed">{q.question}</p>
      </div>
      <div className="space-y-2">
        {q.options.map((option) => {
          let style = 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10';
          if (quiz.selected) {
            if (option === q.correct) style = 'bg-green-900/50 border-green-500/50 text-green-300';
            else if (option === quiz.selected && option !== q.correct) style = 'bg-red-900/50 border-red-500/50 text-red-300';
          }
          return (
            <button
              key={option}
              onClick={() => handleAnswer(option)}
              disabled={!!quiz.selected}
              className={`w-full text-left px-4 py-3 rounded-xl border text-sm transition-all ${style}`}
            >
              {option}
            </button>
          );
        })}
      </div>
      {showExplanation && (
        <div className="bg-blue-900/30 border border-blue-500/30 rounded-xl p-3">
          <div className="text-xs font-medium text-blue-300 mb-1">💡 Explanation</div>
          <p className="text-xs text-gray-300 leading-relaxed">{q.explanation}</p>
        </div>
      )}
      {quiz.selected && (
        <button onClick={nextQuestion} className="w-full py-2 bg-violet-600 hover:bg-violet-500 text-white rounded-xl text-sm transition-colors">
          {quiz.currentQ + 1 >= quiz.questions.length ? 'See Results' : 'Next Question →'}
        </button>
      )}
    </div>
  );
}

export default function LearningPanel() {
  const { userProgress, lessonModules, setActiveTab } = useMolecularStore();
  const [activeView, setActiveView] = useState<'overview' | 'lessons' | 'quiz' | 'achievements'>('overview');
  const [expandedLesson, setExpandedLesson] = useState<string | null>(null);

  return (
    <div className="flex flex-col h-full">
      {/* Navigation */}
      <div className="flex gap-1 px-3 py-2 border-b border-white/10">
        {[
          { id: 'overview', label: 'Overview', icon: <Star className="w-3.5 h-3.5" /> },
          { id: 'lessons', label: 'Lessons', icon: <BookOpen className="w-3.5 h-3.5" /> },
          { id: 'quiz', label: 'Quiz', icon: <Target className="w-3.5 h-3.5" /> },
          { id: 'achievements', label: 'Awards', icon: <Award className="w-3.5 h-3.5" /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveView(tab.id as typeof activeView)}
            className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs transition-all flex-1 justify-center ${
              activeView === tab.id ? 'bg-violet-600 text-white' : 'text-gray-400 hover:text-white hover:bg-white/10'
            }`}
          >
            {tab.icon}
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-3 py-3 scrollbar-thin">
        {activeView === 'overview' && (
          <div className="space-y-4">
            <LevelBadge level={userProgress.level} xp={userProgress.xp} />

            {/* Stats */}
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: 'Molecules', value: userProgress.moleculesExplored.length, icon: '🔬', color: 'violet' },
                { label: 'Streak', value: `${userProgress.streak}d`, icon: '🔥', color: 'orange' },
                { label: 'Lessons', value: userProgress.completedLessons.length, icon: '📚', color: 'blue' },
                { label: 'Quizzes', value: userProgress.completedQuizzes.length, icon: '🎯', color: 'green' },
              ].map(stat => (
                <div key={stat.label} className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                  <div className="text-xl mb-1">{stat.icon}</div>
                  <div className="text-lg font-bold text-white">{stat.value}</div>
                  <div className="text-xs text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Recent Molecules */}
            {userProgress.moleculesExplored.length > 0 && (
              <div>
                <div className="text-xs text-gray-400 font-medium mb-2 flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5" /> Recently Explored
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {userProgress.moleculesExplored.slice(-6).reverse().map(m => (
                    <span key={m} className="px-2 py-0.5 bg-violet-900/30 border border-violet-500/30 text-violet-300 text-xs rounded-full">
                      {m}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Unlocked Achievements Preview */}
            <div>
              <div className="text-xs text-gray-400 font-medium mb-2">Achievements</div>
              <div className="grid grid-cols-3 gap-1.5">
                {userProgress.achievements.slice(0, 3).map(a => (
                  <AchievementBadge key={a.id} achievement={a} />
                ))}
              </div>
            </div>
          </div>
        )}

        {activeView === 'lessons' && (
          <div className="space-y-3">
            <p className="text-xs text-gray-400">Structured chemistry curriculum — click a lesson to explore</p>
            {lessonModules.map((module: LessonModule) => (
              <div key={module.id} className="bg-white/5 border border-white/10 rounded-xl overflow-hidden">
                <button
                  onClick={() => setExpandedLesson(expandedLesson === module.id ? null : module.id)}
                  className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-white/5 transition-colors"
                >
                  <div>
                    <div className="text-sm font-semibold text-white">{module.title}</div>
                    <div className="text-xs text-gray-400 mt-0.5">{module.description}</div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`px-2 py-0.5 text-xs rounded-full border ${DIFFICULTY_COLORS[module.difficulty]}`}>
                        {module.difficulty}
                      </span>
                      <span className="text-xs text-gray-500">{module.topics.length} topics</span>
                    </div>
                  </div>
                  <ChevronRight className={`w-4 h-4 text-gray-400 transition-transform ${expandedLesson === module.id ? 'rotate-90' : ''}`} />
                </button>

                {/* Progress bar */}
                <div className="px-4 pb-2">
                  <div className="bg-white/10 rounded-full h-1">
                    <div className="h-1 rounded-full bg-violet-500 transition-all" style={{ width: `${module.progress}%` }} />
                  </div>
                </div>

                {/* Topics */}
                {expandedLesson === module.id && (
                  <div className="border-t border-white/10 divide-y divide-white/5">
                    {module.topics.map(topic => (
                      <button
                        key={topic.id}
                        onClick={() => {
                          if (topic.molecule) {
                            // Navigate to viewer with this molecule
                            setActiveTab('viewer');
                          }
                        }}
                        className="w-full px-4 py-3 flex items-center gap-3 text-left hover:bg-white/5 transition-colors"
                      >
                        {topic.completed
                          ? <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                          : <Circle className="w-4 h-4 text-gray-500 flex-shrink-0" />
                        }
                        <div className="flex-1 min-w-0">
                          <div className="text-xs text-white font-medium">{topic.title}</div>
                          <div className="text-xs text-gray-500 truncate mt-0.5">{topic.content.slice(0, 50)}...</div>
                        </div>
                        {topic.molecule && (
                          <span className="text-xs text-violet-400 flex-shrink-0">🔬 {topic.molecule}</span>
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {activeView === 'quiz' && (
          <QuizMode onExit={() => setActiveView('overview')} />
        )}

        {activeView === 'achievements' && (
          <div className="space-y-3">
            <p className="text-xs text-gray-400">{userProgress.achievements.filter(a => a.unlocked).length}/{userProgress.achievements.length} unlocked</p>
            <div className="grid grid-cols-2 gap-2">
              {userProgress.achievements.map(a => (
                <AchievementBadge key={a.id} achievement={a} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
