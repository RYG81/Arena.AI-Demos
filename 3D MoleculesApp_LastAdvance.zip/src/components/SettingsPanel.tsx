import { useState } from 'react';
import { Eye, EyeOff, Key, Cpu, Sliders, Palette, Save, RotateCcw, Check } from 'lucide-react';
import { useMolecularStore } from '../store/molecularStore';
import type { AIProvider, RenderMode } from '../types/molecular';

const OPENAI_MODELS = ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-3.5-turbo'];
const DEEPSEEK_MODELS = ['deepseek-chat', 'deepseek-reasoner'];

export default function SettingsPanel() {
  const { aiConfig, setAIConfig, visualConfig, updateVisualConfig } = useMolecularStore();
  const [showKey, setShowKey] = useState<Record<string, boolean>>({});
  const [saved, setSaved] = useState(false);

  function handleSave() {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  const InputLabel = ({ label }: { label: string }) => (
    <label className="block text-xs text-gray-400 font-medium mb-1">{label}</label>
  );

  return (
    <div className="overflow-y-auto h-full px-4 py-4 space-y-6 scrollbar-thin">
      <div className="flex items-center justify-between">
        <h2 className="text-base font-bold text-white">Settings</h2>
        <button
          onClick={handleSave}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-violet-600 hover:bg-violet-500 text-white rounded-lg text-xs transition-colors"
        >
          {saved ? <><Check className="w-3.5 h-3.5" /> Saved!</> : <><Save className="w-3.5 h-3.5" /> Save</>}
        </button>
      </div>

      {/* ── AI Configuration ──────────────────────────── */}
      <section>
        <div className="flex items-center gap-2 mb-3 pb-2 border-b border-white/10">
          <Cpu className="w-4 h-4 text-violet-400" />
          <h3 className="text-sm font-semibold text-white">AI Configuration</h3>
        </div>

        {/* Provider */}
        <div className="mb-4">
          <InputLabel label="AI Provider" />
          <div className="grid grid-cols-3 gap-2">
            {(['openai', 'deepseek', 'local'] as AIProvider[]).map(provider => (
              <button
                key={provider}
                onClick={() => setAIConfig({ provider })}
                className={`py-2 text-xs rounded-lg border transition-all font-medium ${
                  aiConfig.provider === provider
                    ? 'bg-violet-600 border-violet-400 text-white'
                    : 'bg-white/5 border-white/15 text-gray-300 hover:bg-white/10'
                }`}
              >
                {provider === 'openai' ? '🤖 OpenAI' : provider === 'deepseek' ? '🧠 DeepSeek' : '💻 Local'}
              </button>
            ))}
          </div>
        </div>

        {/* OpenAI Key */}
        {aiConfig.provider === 'openai' && (
          <div className="mb-4">
            <InputLabel label="OpenAI API Key" />
            <div className="relative">
              <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
              <input
                type={showKey.openai ? 'text' : 'password'}
                value={aiConfig.openaiKey || ''}
                onChange={(e) => setAIConfig({ openaiKey: e.target.value })}
                placeholder="sk-..."
                className="w-full bg-white/5 border border-white/15 text-white rounded-lg pl-9 pr-10 py-2 text-xs font-mono focus:outline-none focus:border-violet-400 transition-colors"
              />
              <button
                onClick={() => setShowKey(p => ({ ...p, openai: !p.openai }))}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
              >
                {showKey.openai ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
            <div className="mt-1">
              <InputLabel label="Model" />
              <select
                value={aiConfig.model || 'gpt-4o-mini'}
                onChange={(e) => setAIConfig({ model: e.target.value })}
                className="w-full bg-white/5 border border-white/15 text-white rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-violet-400 transition-colors"
              >
                {OPENAI_MODELS.map(m => <option key={m} value={m} className="bg-gray-900">{m}</option>)}
              </select>
            </div>
          </div>
        )}

        {/* DeepSeek Key */}
        {aiConfig.provider === 'deepseek' && (
          <div className="mb-4">
            <InputLabel label="DeepSeek API Key" />
            <div className="relative">
              <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
              <input
                type={showKey.deepseek ? 'text' : 'password'}
                value={aiConfig.deepseekKey || ''}
                onChange={(e) => setAIConfig({ deepseekKey: e.target.value })}
                placeholder="sk-..."
                className="w-full bg-white/5 border border-white/15 text-white rounded-lg pl-9 pr-10 py-2 text-xs font-mono focus:outline-none focus:border-violet-400 transition-colors"
              />
              <button
                onClick={() => setShowKey(p => ({ ...p, deepseek: !p.deepseek }))}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
              >
                {showKey.deepseek ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
            <div className="mt-2">
              <InputLabel label="Model" />
              <select
                value={aiConfig.model || 'deepseek-chat'}
                onChange={(e) => setAIConfig({ model: e.target.value })}
                className="w-full bg-white/5 border border-white/15 text-white rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-violet-400 transition-colors"
              >
                {DEEPSEEK_MODELS.map(m => <option key={m} value={m} className="bg-gray-900">{m}</option>)}
              </select>
            </div>
          </div>
        )}

        {/* Local endpoint */}
        {aiConfig.provider === 'local' && (
          <div className="mb-4">
            <InputLabel label="Local Endpoint (Ollama)" />
            <input
              type="text"
              value={aiConfig.localEndpoint || 'http://localhost:11434/api/chat'}
              onChange={(e) => setAIConfig({ localEndpoint: e.target.value })}
              className="w-full bg-white/5 border border-white/15 text-white rounded-lg px-3 py-2 text-xs font-mono focus:outline-none focus:border-violet-400 transition-colors"
            />
            <div className="mt-2">
              <InputLabel label="Model Name" />
              <input
                type="text"
                value={aiConfig.model || 'llama3'}
                onChange={(e) => setAIConfig({ model: e.target.value })}
                placeholder="llama3, mistral, phi3..."
                className="w-full bg-white/5 border border-white/15 text-white rounded-lg px-3 py-2 text-xs font-mono focus:outline-none focus:border-violet-400 transition-colors"
              />
            </div>
          </div>
        )}

        {/* Temperature */}
        <div className="mb-3">
          <InputLabel label={`Temperature: ${aiConfig.temperature?.toFixed(1)}`} />
          <input
            type="range" min="0" max="1" step="0.1"
            value={aiConfig.temperature ?? 0.7}
            onChange={(e) => setAIConfig({ temperature: parseFloat(e.target.value) })}
            className="w-full accent-violet-500"
          />
          <div className="flex justify-between text-xs text-gray-600 mt-0.5">
            <span>Precise</span><span>Creative</span>
          </div>
        </div>

        {/* Max Tokens */}
        <div className="mb-3">
          <InputLabel label={`Max Tokens: ${aiConfig.maxTokens}`} />
          <input
            type="range" min="256" max="4096" step="128"
            value={aiConfig.maxTokens ?? 1024}
            onChange={(e) => setAIConfig({ maxTokens: parseInt(e.target.value) })}
            className="w-full accent-violet-500"
          />
          <div className="flex justify-between text-xs text-gray-600 mt-0.5">
            <span>256</span><span>4096</span>
          </div>
        </div>

        {/* Response Style */}
        <div>
          <InputLabel label="Response Style" />
          <div className="grid grid-cols-3 gap-2">
            {(['concise', 'detailed', 'educational'] as const).map(style => (
              <button
                key={style}
                onClick={() => setAIConfig({ responseStyle: style })}
                className={`py-1.5 text-xs rounded-lg border transition-all capitalize ${
                  aiConfig.responseStyle === style
                    ? 'bg-blue-600 border-blue-400 text-white'
                    : 'bg-white/5 border-white/15 text-gray-300 hover:bg-white/10'
                }`}
              >
                {style}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── Visual Configuration ──────────────────────── */}
      <section>
        <div className="flex items-center gap-2 mb-3 pb-2 border-b border-white/10">
          <Palette className="w-4 h-4 text-pink-400" />
          <h3 className="text-sm font-semibold text-white">Visual Settings</h3>
        </div>

        {/* Render Mode */}
        <div className="mb-4">
          <InputLabel label="Render Mode" />
          <div className="grid grid-cols-2 gap-2">
            {(['ball-stick', 'space-filling', 'wireframe', 'stick'] as RenderMode[]).map(mode => (
              <button
                key={mode}
                onClick={() => updateVisualConfig({ renderMode: mode })}
                className={`py-2 text-xs rounded-lg border transition-all ${
                  visualConfig.renderMode === mode
                    ? 'bg-pink-600 border-pink-400 text-white'
                    : 'bg-white/5 border-white/15 text-gray-300 hover:bg-white/10'
                }`}
              >
                {mode.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </button>
            ))}
          </div>
        </div>

        {/* Color Scheme */}
        <div className="mb-4">
          <InputLabel label="Color Scheme" />
          <div className="grid grid-cols-3 gap-2">
            {(['cpk', 'jmol', 'custom'] as const).map(scheme => (
              <button
                key={scheme}
                onClick={() => updateVisualConfig({ colorScheme: scheme })}
                className={`py-1.5 text-xs rounded-lg border transition-all uppercase ${
                  visualConfig.colorScheme === scheme
                    ? 'bg-orange-600 border-orange-400 text-white'
                    : 'bg-white/5 border-white/15 text-gray-300 hover:bg-white/10'
                }`}
              >
                {scheme}
              </button>
            ))}
          </div>
        </div>

        {/* Toggles */}
        <div className="space-y-2 mb-4">
          {[
            { key: 'showHydrogens', label: 'Show Hydrogens' },
            { key: 'showLabels', label: 'Show Atom Labels' },
            { key: 'showBondAngles', label: 'Show Bond Angles' },
            { key: 'showElectronDensity', label: 'Electron Density' },
            { key: 'autoRotate', label: 'Auto Rotate' },
            { key: 'showShadows', label: 'Cast Shadows' },
            { key: 'showOrbitals', label: 'Show Orbitals' },
          ].map(({ key, label }) => (
            <div key={key} className="flex items-center justify-between">
              <span className="text-xs text-gray-300">{label}</span>
              <button
                onClick={() => updateVisualConfig({ [key]: !visualConfig[key as keyof typeof visualConfig] })}
                className={`w-9 h-5 rounded-full transition-colors relative ${
                  visualConfig[key as keyof typeof visualConfig] ? 'bg-violet-600' : 'bg-white/20'
                }`}
              >
                <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full transition-transform shadow-sm ${
                  visualConfig[key as keyof typeof visualConfig] ? 'translate-x-4' : 'translate-x-0.5'
                }`} />
              </button>
            </div>
          ))}
        </div>

        {/* Sliders */}
        <div className="space-y-3">
          <div>
            <InputLabel label={`Atom Scale: ${visualConfig.atomScale.toFixed(1)}x`} />
            <input type="range" min="0.3" max="2.5" step="0.1"
              value={visualConfig.atomScale}
              onChange={(e) => updateVisualConfig({ atomScale: parseFloat(e.target.value) })}
              className="w-full accent-violet-500" />
          </div>
          <div>
            <InputLabel label={`Bond Thickness: ${visualConfig.bondThickness.toFixed(1)}x`} />
            <input type="range" min="0.2" max="3" step="0.1"
              value={visualConfig.bondThickness}
              onChange={(e) => updateVisualConfig({ bondThickness: parseFloat(e.target.value) })}
              className="w-full accent-violet-500" />
          </div>
          <div>
            <InputLabel label={`Light Intensity: ${visualConfig.lightIntensity.toFixed(1)}`} />
            <input type="range" min="0.1" max="3" step="0.1"
              value={visualConfig.lightIntensity}
              onChange={(e) => updateVisualConfig({ lightIntensity: parseFloat(e.target.value) })}
              className="w-full accent-violet-500" />
          </div>
          <div>
            <InputLabel label={`Rotate Speed: ${visualConfig.rotateSpeed.toFixed(1)}x`} />
            <input type="range" min="0" max="5" step="0.1"
              value={visualConfig.rotateSpeed}
              onChange={(e) => updateVisualConfig({ rotateSpeed: parseFloat(e.target.value) })}
              className="w-full accent-violet-500" />
          </div>
        </div>

        {/* Background Color */}
        <div className="mt-3">
          <InputLabel label="Background Color" />
          <div className="flex gap-2">
            <input
              type="color"
              value={visualConfig.backgroundColor}
              onChange={(e) => updateVisualConfig({ backgroundColor: e.target.value })}
              className="w-10 h-8 rounded border border-white/15 cursor-pointer bg-transparent"
            />
            <div className="flex-1 flex gap-1.5 flex-wrap">
              {['#0a0a1a', '#0d1117', '#1a0a2e', '#0a1a0a', '#1a1a1a', '#000000'].map(c => (
                <button
                  key={c}
                  onClick={() => updateVisualConfig({ backgroundColor: c })}
                  className="w-6 h-6 rounded border-2 transition-all"
                  style={{ backgroundColor: c, borderColor: visualConfig.backgroundColor === c ? '#7C3AED' : 'transparent' }}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Reset */}
      <button
        onClick={() => updateVisualConfig({
          renderMode: 'ball-stick', showHydrogens: true, showLabels: false,
          atomScale: 1, bondThickness: 1, lightIntensity: 1.2, autoRotate: true,
          backgroundColor: '#0a0a1a', colorScheme: 'jmol'
        })}
        className="w-full flex items-center justify-center gap-2 py-2 text-xs text-gray-400 hover:text-white border border-white/10 hover:border-white/20 rounded-lg transition-colors"
      >
        <RotateCcw className="w-3.5 h-3.5" /> Reset Visual Defaults
      </button>
    </div>
  );
}
