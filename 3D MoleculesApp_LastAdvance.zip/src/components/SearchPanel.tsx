import { useState, useRef, useEffect } from 'react';
import { Search, X, History, Star, Loader2, Beaker, ChevronDown } from 'lucide-react';
import { useMolecularStore } from '../store/molecularStore';
import { fetchMoleculeByName, fetchMoleculeBySMILES, generateLocalMolecule } from '../services/chemistryEngine';
import { PRESET_MOLECULES } from '../data/elements';

const QUICK_MOLECULES = [
  { name: 'Water', key: 'water', emoji: '💧' },
  { name: 'Caffeine', key: 'caffeine', emoji: '☕' },
  { name: 'Aspirin', key: 'aspirin', emoji: '💊' },
  { name: 'Benzene', key: 'benzene', emoji: '⬡' },
  { name: 'DNA Base', key: 'dna', emoji: '🧬' },
  { name: 'Glucose', key: 'glucose', emoji: '🍬' },
  { name: 'CO₂', key: 'co2', emoji: '🌿' },
  { name: 'Ethanol', key: 'ethanol', emoji: '🍾' },
  { name: 'Dopamine', key: 'dopamine', emoji: '🧠' },
  { name: 'Penicillin', key: 'penicillin', emoji: '💉' },
];

export default function SearchPanel() {
  const [query, setQuery] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [inputMode, setInputMode] = useState<'name' | 'smiles'>('name');
  const inputRef = useRef<HTMLInputElement>(null);

  const {
    setCurrentMolecule,
    setLoading,
    setError,
    isLoading,
    searchHistory,
    addSearchHistory,
    currentMolecule,
    getCachedMolecule,
  } = useMolecularStore();

  async function handleSearch(searchQuery: string = query) {
    if (!searchQuery.trim()) return;
    setShowDropdown(false);
    setLoading(true);
    setError(null);
    addSearchHistory(searchQuery.trim());

    try {
      // Check cache first
      const cached = getCachedMolecule(searchQuery.toLowerCase());
      if (cached) {
        setCurrentMolecule(cached);
        return;
      }

      // Check local presets
      const localMol = generateLocalMolecule(searchQuery.toLowerCase());
      if (localMol) {
        setCurrentMolecule(localMol);
        // Also try to enrich from PubChem in background
        enrichFromPubChem(searchQuery);
        return;
      }

      // Fetch from PubChem
      let mol;
      if (inputMode === 'smiles' || searchQuery.includes('=') || searchQuery.match(/^[A-Z][a-z]?(\[.*?\]|[BCNOPSFIbcnops]|Cl|Br|si|as|se|te)/)) {
        mol = await fetchMoleculeBySMILES(searchQuery);
      } else {
        mol = await fetchMoleculeByName(searchQuery);
      }

      setCurrentMolecule(mol);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to load molecule';
      setError(msg);
      setLoading(false);
    }
  }

  async function enrichFromPubChem(name: string) {
    try {
      const mol = await fetchMoleculeByName(name);
      setCurrentMolecule(mol);
    } catch { /* Silently fail — local data is sufficient */ }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter') handleSearch();
    if (e.key === 'Escape') setShowDropdown(false);
  }

  const filteredHistory = searchHistory.filter(h =>
    h.toLowerCase().includes(query.toLowerCase()) && h !== query
  ).slice(0, 5);

  return (
    <div className="relative">
      {/* Search Bar */}
      <div className="flex gap-2 items-center">
        {/* Mode Toggle */}
        <button
          onClick={() => setInputMode(m => m === 'name' ? 'smiles' : 'name')}
          className="flex-shrink-0 px-3 py-2.5 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-lg text-xs font-mono transition-colors"
          title={`Switch to ${inputMode === 'name' ? 'SMILES' : 'Name'} mode`}
        >
          {inputMode === 'name' ? 'NAME' : 'SMILES'}
          <ChevronDown className="inline ml-1 w-3 h-3" />
        </button>

        {/* Input */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => { setQuery(e.target.value); setShowDropdown(true); }}
            onFocus={() => setShowDropdown(true)}
            onBlur={() => setTimeout(() => setShowDropdown(false), 200)}
            onKeyDown={handleKeyDown}
            placeholder={inputMode === 'name' ? 'Search molecule (caffeine, aspirin...)' : 'Enter SMILES (CCO, c1ccccc1...)'}
            className="w-full bg-white/10 border border-white/20 text-white placeholder-gray-400 rounded-lg pl-10 pr-10 py-2.5 text-sm focus:outline-none focus:border-violet-400 focus:bg-white/15 transition-all"
          />
          {query && (
            <button
              onClick={() => { setQuery(''); inputRef.current?.focus(); }}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Search Button */}
        <button
          onClick={() => handleSearch()}
          disabled={isLoading || !query.trim()}
          className="flex-shrink-0 px-4 py-2.5 bg-violet-600 hover:bg-violet-500 disabled:bg-violet-800 disabled:opacity-50 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
        >
          {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Beaker className="w-4 h-4" />}
          <span className="hidden sm:inline">{isLoading ? 'Loading...' : 'Analyze'}</span>
        </button>
      </div>

      {/* Dropdown */}
      {showDropdown && (query || filteredHistory.length > 0) && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-gray-900/95 backdrop-blur-md border border-white/20 rounded-xl shadow-2xl z-50 overflow-hidden">
          {filteredHistory.length > 0 && (
            <>
              <div className="px-3 py-2 text-xs text-gray-500 font-medium flex items-center gap-1">
                <History className="w-3 h-3" /> Recent searches
              </div>
              {filteredHistory.map(h => (
                <button
                  key={h}
                  onMouseDown={() => { setQuery(h); handleSearch(h); }}
                  className="w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-white/10 flex items-center gap-2 transition-colors"
                >
                  <History className="w-3 h-3 text-gray-500" />
                  {h}
                </button>
              ))}
              <div className="border-t border-white/10" />
            </>
          )}
        </div>
      )}

      {/* Quick Access Molecules */}
      <div className="mt-3">
        <div className="flex items-center gap-1 mb-2">
          <Star className="w-3 h-3 text-yellow-400" />
          <span className="text-xs text-gray-400 font-medium">Quick Access</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {QUICK_MOLECULES.map(mol => (
            <button
              key={mol.key}
              onClick={() => { setQuery(mol.name); handleSearch(mol.name); }}
              disabled={isLoading}
              className={`px-2.5 py-1 text-xs rounded-full border transition-all ${
                currentMolecule?.name.toLowerCase() === mol.name.toLowerCase()
                  ? 'bg-violet-600 border-violet-400 text-white'
                  : 'bg-white/5 border-white/15 text-gray-300 hover:bg-white/15 hover:border-white/30'
              } disabled:opacity-50`}
            >
              {mol.emoji} {mol.name}
            </button>
          ))}
        </div>
      </div>

      {/* Preset molecules with descriptions */}
      <div className="mt-3 grid grid-cols-2 gap-1.5">
        {Object.entries(PRESET_MOLECULES).slice(0, 4).map(([key, mol]) => (
          <button
            key={key}
            onClick={() => { setQuery(mol.name); handleSearch(mol.name); }}
            disabled={isLoading}
            className="text-left p-2 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-violet-500/50 rounded-lg transition-all group"
          >
            <div className="text-xs font-medium text-white group-hover:text-violet-300">{mol.name}</div>
            <div className="text-xs text-gray-500">{mol.formula}</div>
          </button>
        ))}
      </div>
    </div>
  );
}
