import { useState } from 'react';
import { Users, Link, Copy, Check, Video, MessageSquare, Share2, Pencil, Eye, Crown, UserPlus, LogIn } from 'lucide-react';
import { useMolecularStore } from '../store/molecularStore';

const DEMO_SESSION = {
  id: 'mol-demo-session',
  participants: [
    { name: 'Dr. Smith', role: 'teacher' as const, color: '#7C3AED', online: true },
    { name: 'Alice', role: 'student' as const, color: '#2563EB', online: true },
    { name: 'Bob', role: 'student' as const, color: '#059669', online: false },
  ],
  activeMolecule: 'Caffeine',
};

export default function CollaborationPanel() {
  const [mode, setMode] = useState<'lobby' | 'host' | 'join' | 'session'>('lobby');
  const [sessionName, setSessionName] = useState('');
  const [joinCode, setJoinCode] = useState('');
  const [sessionId] = useState(`mol-${Math.random().toString(36).slice(2, 8).toUpperCase()}`);
  const [copied, setCopied] = useState(false);
  const [messages, setMessages] = useState([
    { id: 1, user: 'Dr. Smith', color: '#7C3AED', text: 'Welcome everyone! Today we study caffeine.', time: '2:15 PM' },
    { id: 2, user: 'Alice', color: '#2563EB', text: 'The ring structure is interesting!', time: '2:16 PM' },
  ]);
  const [chatInput, setChatInput] = useState('');
  const { currentMolecule, userName, setUserName } = useMolecularStore();

  function handleCopyLink() {
    navigator.clipboard.writeText(`molecularai.app/session/${sessionId}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function handleSendMessage() {
    if (!chatInput.trim()) return;
    setMessages(prev => [...prev, {
      id: Date.now(),
      user: userName,
      color: '#7C3AED',
      text: chatInput.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    }]);
    setChatInput('');
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-4 py-3 border-b border-white/10">
        <div className="flex items-center gap-2 mb-1">
          <Users className="w-4 h-4 text-blue-400" />
          <h2 className="text-sm font-bold text-white">Collaboration</h2>
        </div>
        <p className="text-xs text-gray-400">Real-time molecular workspace sharing</p>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin">
        <div className="p-4 space-y-4">
          {mode === 'lobby' && (
            <>
              {/* User name */}
              <div>
                <label className="text-xs text-gray-400 block mb-1">Your Display Name</label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="w-full bg-white/5 border border-white/15 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-400 transition-colors"
                  placeholder="Enter your name..."
                />
              </div>

              {/* Actions */}
              <div className="grid grid-cols-1 gap-3">
                <button
                  onClick={() => setMode('host')}
                  className="flex items-center gap-3 p-4 bg-gradient-to-r from-violet-900/40 to-blue-900/40 border border-violet-500/30 rounded-xl text-left hover:border-violet-400 transition-all group"
                >
                  <div className="w-10 h-10 bg-violet-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Crown className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white">Host Session</div>
                    <div className="text-xs text-gray-400">Create and lead a collaborative workspace</div>
                  </div>
                </button>

                <button
                  onClick={() => setMode('join')}
                  className="flex items-center gap-3 p-4 bg-gradient-to-r from-blue-900/40 to-cyan-900/40 border border-blue-500/30 rounded-xl text-left hover:border-blue-400 transition-all group"
                >
                  <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <LogIn className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white">Join Session</div>
                    <div className="text-xs text-gray-400">Enter a session code to join</div>
                  </div>
                </button>

                {/* Demo Session */}
                <button
                  onClick={() => setMode('session')}
                  className="flex items-center gap-3 p-4 bg-gradient-to-r from-green-900/40 to-emerald-900/40 border border-green-500/30 rounded-xl text-left hover:border-green-400 transition-all group"
                >
                  <div className="w-10 h-10 bg-green-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Eye className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white">Demo Session</div>
                    <div className="text-xs text-gray-400">Preview collaborative features</div>
                  </div>
                </button>
              </div>

              {/* Features list */}
              <div className="bg-white/3 border border-white/10 rounded-xl p-3">
                <div className="text-xs font-semibold text-gray-300 mb-2">📡 Collaboration Features</div>
                <div className="space-y-1.5">
                  {[
                    { icon: '🔬', text: 'Shared 3D molecular workspace' },
                    { icon: '✍️', text: 'Real-time annotations' },
                    { icon: '💬', text: 'In-session chat' },
                    { icon: '🎓', text: 'Teacher controls & task assignment' },
                    { icon: '🤖', text: 'AI classroom assistant' },
                    { icon: '📊', text: 'Session analytics' },
                  ].map(f => (
                    <div key={f.text} className="flex items-center gap-2 text-xs text-gray-400">
                      <span>{f.icon}</span><span>{f.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {mode === 'host' && (
            <div className="space-y-4">
              <button onClick={() => setMode('lobby')} className="text-xs text-gray-400 hover:text-white flex items-center gap-1">
                ← Back
              </button>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Session Name</label>
                <input
                  type="text"
                  value={sessionName}
                  onChange={(e) => setSessionName(e.target.value)}
                  placeholder="e.g., Chemistry 101 — Organic Week"
                  className="w-full bg-white/5 border border-white/15 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
                />
              </div>
              <div className="bg-violet-900/30 border border-violet-500/30 rounded-xl p-4">
                <div className="text-xs text-gray-400 mb-1">Your Session Code</div>
                <div className="text-2xl font-bold text-white font-mono tracking-widest">{sessionId}</div>
                <div className="text-xs text-gray-500 mt-1">Share this code with participants</div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleCopyLink}
                  className="flex-1 flex items-center justify-center gap-2 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-sm transition-colors"
                >
                  {copied ? <><Check className="w-4 h-4 text-green-400" /> Copied!</> : <><Copy className="w-4 h-4" /> Copy Link</>}
                </button>
                <button
                  onClick={() => setMode('session')}
                  className="flex-1 py-2 bg-violet-600 hover:bg-violet-500 text-white rounded-xl text-sm font-medium transition-colors"
                >
                  Start Session
                </button>
              </div>
            </div>
          )}

          {mode === 'join' && (
            <div className="space-y-4">
              <button onClick={() => setMode('lobby')} className="text-xs text-gray-400 hover:text-white">← Back</button>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Session Code</label>
                <input
                  type="text"
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                  placeholder="e.g., MOL-ABC123"
                  className="w-full bg-white/5 border border-white/15 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-400 font-mono tracking-widest text-center text-lg"
                />
              </div>
              <button
                onClick={() => setMode('session')}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-medium transition-colors"
              >
                Join Session
              </button>
            </div>
          )}

          {mode === 'session' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    <span className="text-sm font-bold text-white">Live Session</span>
                  </div>
                  <div className="text-xs text-gray-400 mt-0.5">Molecule: {currentMolecule?.name || DEMO_SESSION.activeMolecule}</div>
                </div>
                <button onClick={() => setMode('lobby')} className="px-2 py-1 text-xs text-red-400 hover:bg-red-900/30 border border-red-500/30 rounded-lg transition-colors">
                  Leave
                </button>
              </div>

              {/* Participants */}
              <div className="bg-white/5 border border-white/10 rounded-xl p-3">
                <div className="text-xs text-gray-400 font-medium mb-2 flex items-center gap-1">
                  <Users className="w-3.5 h-3.5" /> Participants ({DEMO_SESSION.participants.length})
                </div>
                <div className="space-y-2">
                  {DEMO_SESSION.participants.map(p => (
                    <div key={p.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div
                          className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white"
                          style={{ backgroundColor: p.color }}
                        >
                          {p.name[0]}
                        </div>
                        <div>
                          <div className="text-xs text-white font-medium">{p.name}</div>
                          <div className="text-xs text-gray-500 capitalize">{p.role}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {p.role === 'teacher' && <Crown className="w-3.5 h-3.5 text-yellow-400" />}
                        <div className={`w-2 h-2 rounded-full ${p.online ? 'bg-green-400' : 'bg-gray-600'}`} />
                      </div>
                    </div>
                  ))}
                  <button className="w-full flex items-center justify-center gap-1.5 py-1.5 border border-dashed border-white/20 rounded-lg text-xs text-gray-500 hover:text-gray-300 hover:border-white/40 transition-colors">
                    <UserPlus className="w-3.5 h-3.5" /> Invite participant
                  </button>
                </div>
              </div>

              {/* Toolbar */}
              <div className="flex gap-2">
                {[
                  { icon: <Pencil className="w-4 h-4" />, label: 'Annotate', color: 'violet' },
                  { icon: <Share2 className="w-4 h-4" />, label: 'Share View', color: 'blue' },
                  { icon: <Video className="w-4 h-4" />, label: 'Video', color: 'green' },
                ].map(tool => (
                  <button
                    key={tool.label}
                    className="flex-1 flex flex-col items-center gap-1 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-gray-400 hover:text-white transition-colors"
                  >
                    {tool.icon}
                    <span className="text-xs">{tool.label}</span>
                  </button>
                ))}
              </div>

              {/* Chat */}
              <div className="bg-black/20 border border-white/10 rounded-xl overflow-hidden">
                <div className="flex items-center gap-2 px-3 py-2 border-b border-white/10">
                  <MessageSquare className="w-3.5 h-3.5 text-gray-400" />
                  <span className="text-xs font-medium text-gray-300">Session Chat</span>
                </div>
                <div className="px-3 py-2 space-y-2 max-h-40 overflow-y-auto scrollbar-thin">
                  {messages.map(msg => (
                    <div key={msg.id} className="flex items-start gap-2">
                      <div
                        className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0 mt-0.5"
                        style={{ backgroundColor: msg.color }}
                      >
                        {msg.user[0]}
                      </div>
                      <div>
                        <span className="text-xs font-medium" style={{ color: msg.color }}>{msg.user}</span>
                        <span className="text-xs text-gray-600 ml-1">{msg.time}</span>
                        <p className="text-xs text-gray-300 leading-snug">{msg.text}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex gap-1.5 px-3 py-2 border-t border-white/10">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Say something..."
                    className="flex-1 bg-white/5 border border-white/10 text-white text-xs rounded-lg px-2 py-1.5 focus:outline-none focus:border-blue-400"
                  />
                  <button
                    onClick={handleSendMessage}
                    className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs transition-colors"
                  >
                    Send
                  </button>
                </div>
              </div>

              {/* Session link */}
              <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl px-3 py-2">
                <Link className="w-3.5 h-3.5 text-gray-500" />
                <span className="text-xs text-gray-500 flex-1 font-mono truncate">molecularai.app/session/{sessionId}</span>
                <button onClick={handleCopyLink} className="text-gray-400 hover:text-white transition-colors">
                  {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
