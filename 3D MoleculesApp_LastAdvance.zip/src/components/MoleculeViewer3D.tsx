import { useEffect, useRef, useCallback } from 'react';
import * as THREE from 'three';
import type { MolecularData, Atom, Bond, VisualConfig } from '../types/molecular';
import { useMolecularStore } from '../store/molecularStore';

// ── Minimal 3D renderer using raw Three.js ────────────────────────────────

class MolecularRenderer {
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private animationId: number = 0;
  private autoRotate: boolean = true;
  private rotateSpeed: number = 1;
  private moleculeGroup: THREE.Group;
  private atomMeshes: Map<number, THREE.Mesh> = new Map();
  private selectedId: number | null = null;
  private onSelectAtom: ((id: number | null) => void) | null = null;
  private isDisposed: boolean = false;
  private clock: THREE.Clock = new THREE.Clock();

  constructor(canvas: HTMLCanvasElement) {
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(60, canvas.clientWidth / canvas.clientHeight, 0.01, 1000);
    this.camera.position.set(0, 0, 8);

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(canvas.clientWidth, canvas.clientHeight);
    this.renderer.shadowMap.enabled = false;

    this.moleculeGroup = new THREE.Group();
    this.scene.add(this.moleculeGroup);

    this.setupLights();
    this.setupStars();
    this.setupOrbitControls(canvas);
    this.animate();
  }

  private setupLights() {
    this.scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    const dir = new THREE.DirectionalLight(0xffffff, 1.2);
    dir.position.set(10, 10, 5);
    this.scene.add(dir);
    const pt = new THREE.PointLight(0x4477FF, 0.5);
    pt.position.set(-8, -8, -5);
    this.scene.add(pt);
  }

  private setupStars() {
    const geo = new THREE.BufferGeometry();
    const verts: number[] = [];
    for (let i = 0; i < 2000; i++) {
      verts.push((Math.random() - 0.5) * 200, (Math.random() - 0.5) * 200, (Math.random() - 0.5) * 200);
    }
    geo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    const mat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.15, sizeAttenuation: true });
    this.scene.add(new THREE.Points(geo, mat));
  }

  // Simple orbit controls
  private isDragging = false;
  private prevMouse = { x: 0, y: 0 };
  private spherical = { theta: 0, phi: Math.PI / 2, radius: 8 };

  private setupOrbitControls(canvas: HTMLCanvasElement) {
    canvas.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.prevMouse = { x: e.clientX, y: e.clientY };
    });
    canvas.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      const dx = (e.clientX - this.prevMouse.x) * 0.01;
      const dy = (e.clientY - this.prevMouse.y) * 0.01;
      this.spherical.theta -= dx;
      this.spherical.phi = Math.max(0.1, Math.min(Math.PI - 0.1, this.spherical.phi + dy));
      this.prevMouse = { x: e.clientX, y: e.clientY };
      this.updateCamera();
    });
    canvas.addEventListener('mouseup', () => { this.isDragging = false; });
    canvas.addEventListener('mouseleave', () => { this.isDragging = false; });
    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.spherical.radius = Math.max(2, Math.min(50, this.spherical.radius + e.deltaY * 0.02));
      this.updateCamera();
    }, { passive: false });
    canvas.addEventListener('click', (e) => this.handleClick(e, canvas));

    // Touch
    let lastTouchDist = 0;
    canvas.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) {
        this.isDragging = true;
        this.prevMouse = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      } else if (e.touches.length === 2) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        lastTouchDist = Math.sqrt(dx * dx + dy * dy);
      }
    });
    canvas.addEventListener('touchmove', (e) => {
      e.preventDefault();
      if (e.touches.length === 1 && this.isDragging) {
        const dx = (e.touches[0].clientX - this.prevMouse.x) * 0.01;
        const dy = (e.touches[0].clientY - this.prevMouse.y) * 0.01;
        this.spherical.theta -= dx;
        this.spherical.phi = Math.max(0.1, Math.min(Math.PI - 0.1, this.spherical.phi + dy));
        this.prevMouse = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        this.updateCamera();
      } else if (e.touches.length === 2) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const delta = (lastTouchDist - dist) * 0.05;
        this.spherical.radius = Math.max(2, Math.min(50, this.spherical.radius + delta));
        lastTouchDist = dist;
        this.updateCamera();
      }
    }, { passive: false });
    canvas.addEventListener('touchend', () => { this.isDragging = false; });
  }

  private updateCamera() {
    const { theta, phi, radius } = this.spherical;
    this.camera.position.set(
      radius * Math.sin(phi) * Math.sin(theta),
      radius * Math.cos(phi),
      radius * Math.sin(phi) * Math.cos(theta)
    );
    this.camera.lookAt(0, 0, 0);
  }

  private handleClick(e: MouseEvent, canvas: HTMLCanvasElement) {
    const rect = canvas.getBoundingClientRect();
    const mouse = new THREE.Vector2(
      ((e.clientX - rect.left) / rect.width) * 2 - 1,
      -((e.clientY - rect.top) / rect.height) * 2 + 1
    );
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, this.camera);
    const meshes = Array.from(this.atomMeshes.values());
    const hits = raycaster.intersectObjects(meshes);
    if (hits.length > 0) {
      const mesh = hits[0].object as THREE.Mesh;
      const id = mesh.userData.atomId as number;
      this.selectAtom(id);
      this.onSelectAtom?.(id);
    } else {
      this.selectAtom(null);
      this.onSelectAtom?.(null);
    }
  }

  selectAtom(id: number | null) {
    if (this.selectedId !== null) {
      const prev = this.atomMeshes.get(this.selectedId);
      if (prev) (prev.material as THREE.MeshPhysicalMaterial).emissiveIntensity = 0;
    }
    this.selectedId = id;
    if (id !== null) {
      const mesh = this.atomMeshes.get(id);
      if (mesh) {
        const mat = mesh.material as THREE.MeshPhysicalMaterial;
        mat.emissive.set('#FFD700');
        mat.emissiveIntensity = 0.5;
      }
    }
  }

  setOnSelectAtom(fn: (id: number | null) => void) {
    this.onSelectAtom = fn;
  }

  renderMolecule(molecule: MolecularData | null, config: VisualConfig) {
    // Clear previous
    while (this.moleculeGroup.children.length > 0) {
      const child = this.moleculeGroup.children[0];
      this.moleculeGroup.remove(child);
      if ((child as THREE.Mesh).geometry) (child as THREE.Mesh).geometry.dispose();
    }
    this.atomMeshes.clear();
    this.selectedId = null;

    if (!molecule) return;

    const atomScale = config.atomScale;
    const renderMode = config.renderMode;

    // Compute center
    const cx = molecule.atoms.reduce((s, a) => s + a.x, 0) / molecule.atoms.length;
    const cy = molecule.atoms.reduce((s, a) => s + a.y, 0) / molecule.atoms.length;
    const cz = molecule.atoms.reduce((s, a) => s + a.z, 0) / molecule.atoms.length;

    // Compute extent for camera
    let maxDist = 0;
    molecule.atoms.forEach(a => {
      const d = Math.sqrt((a.x - cx) ** 2 + (a.y - cy) ** 2 + (a.z - cz) ** 2);
      if (d > maxDist) maxDist = d;
    });

    const visAtoms = config.showHydrogens ? molecule.atoms : molecule.atoms.filter(a => a.symbol !== 'H');
    const visIds = new Set(visAtoms.map(a => a.id));
    const atomMap = new Map<number, Atom>(molecule.atoms.map(a => [a.id, a]));

    // Atom scale per mode
    const baseScale = renderMode === 'space-filling' ? 2.8 : renderMode === 'stick' ? 0.12 : renderMode === 'wireframe' ? 0.12 : 1.0;

    // Render atoms
    visAtoms.forEach(atom => {
      const r = atom.radius * baseScale * atomScale;
      const geo = new THREE.SphereGeometry(r, 24, 24);
      const color = config.customAtomColors[atom.symbol] || atom.color;
      const mat = new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(color),
        roughness: 0.25,
        metalness: 0.1,
        clearcoat: 0.9,
        clearcoatRoughness: 0.1,
        emissive: new THREE.Color('#000000'),
        emissiveIntensity: 0,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(atom.x - cx, atom.y - cy, atom.z - cz);
      mesh.userData.atomId = atom.id;
      this.atomMeshes.set(atom.id, mesh);
      this.moleculeGroup.add(mesh);

      // Label
      if (config.showLabels && renderMode !== 'space-filling') {
        // Canvas sprite label
        const canvas2 = document.createElement('canvas');
        canvas2.width = 64; canvas2.height = 32;
        const ctx = canvas2.getContext('2d')!;
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.roundRect(0, 0, 64, 32, 8);
        ctx.fill();
        ctx.fillStyle = color;
        ctx.font = 'bold 18px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(atom.symbol, 32, 16);
        const tex = new THREE.CanvasTexture(canvas2);
        const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
        sprite.position.set(atom.x - cx, atom.y - cy + r + 0.3, atom.z - cz);
        sprite.scale.set(0.6, 0.3, 1);
        this.moleculeGroup.add(sprite);
      }
    });

    // Render bonds
    if (renderMode !== 'space-filling') {
      const t = config.bondThickness * (renderMode === 'stick' ? 0.14 : 0.065);
      molecule.bonds.forEach(bond => {
        if (!visIds.has(bond.atom1) || !visIds.has(bond.atom2)) return;
        const a1 = atomMap.get(bond.atom1);
        const a2 = atomMap.get(bond.atom2);
        if (!a1 || !a2) return;

        const start = new THREE.Vector3(a1.x - cx, a1.y - cy, a1.z - cz);
        const end = new THREE.Vector3(a2.x - cx, a2.y - cy, a2.z - cz);
        const dir = end.clone().sub(start);
        const len = dir.length();
        const mid = start.clone().add(end).multiplyScalar(0.5);
        const quat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());

        const bondColor = bond.type === 'aromatic' ? '#7BC8F6'
          : bond.type === 'double' ? '#B8D4FF'
          : bond.type === 'triple' ? '#C4B8FF'
          : '#CCCCCC';

        const offsets = bond.order === 2 ? [-0.09, 0.09] : bond.order === 3 ? [-0.13, 0, 0.13] : [0];
        offsets.forEach(offset => {
          const geo = new THREE.CylinderGeometry(t, t, len, 8);
          const mat = new THREE.MeshPhysicalMaterial({ color: new THREE.Color(bondColor), roughness: 0.35, metalness: 0.1 });
          const mesh = new THREE.Mesh(geo, mat);
          mesh.position.copy(mid).add(new THREE.Vector3(offset, 0, 0));
          mesh.quaternion.copy(quat);
          this.moleculeGroup.add(mesh);
        });
      });
    }

    // Reposition camera
    const dist = Math.max(5, maxDist * 2.8 + 3);
    this.spherical.radius = dist;
    this.spherical.theta = 0;
    this.spherical.phi = Math.PI / 2;
    this.updateCamera();
  }

  updateConfig(config: VisualConfig) {
    this.autoRotate = config.autoRotate;
    this.rotateSpeed = config.rotateSpeed;
    (this.renderer as THREE.WebGLRenderer).setClearColor(new THREE.Color(config.backgroundColor), 1);
  }

  resize(width: number, height: number) {
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private animate() {
    if (this.isDisposed) return;
    this.animationId = requestAnimationFrame(() => this.animate());
    const dt = this.clock.getDelta();
    if (this.autoRotate && !this.isDragging) {
      this.moleculeGroup.rotation.y += dt * 0.3 * this.rotateSpeed;
    }
    this.renderer.render(this.scene, this.camera);
  }

  dispose() {
    this.isDisposed = true;
    cancelAnimationFrame(this.animationId);
    this.renderer.dispose();
    this.atomMeshes.clear();
  }
}

export default function MoleculeViewer3D({ className = '' }: { className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<MolecularRenderer | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const { currentMolecule, isLoading, visualConfig, selectedAtomId, setSelectedAtom, setHoveredAtom } = useMolecularStore();

  // Initialize renderer
  useEffect(() => {
    if (!canvasRef.current) return;
    const r = new MolecularRenderer(canvasRef.current);
    rendererRef.current = r;
    r.setOnSelectAtom((id) => {
      setSelectedAtom(id);
      setHoveredAtom(null);
    });
    r.updateConfig(visualConfig);

    // Resize observer
    const obs = new ResizeObserver(entries => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        r.resize(width, height);
      }
    });
    if (containerRef.current) obs.observe(containerRef.current);

    return () => {
      obs.disconnect();
      r.dispose();
      rendererRef.current = null;
    };
  }, []); // eslint-disable-line

  // Update molecule
  useEffect(() => {
    rendererRef.current?.renderMolecule(currentMolecule, visualConfig);
  }, [currentMolecule, visualConfig]);

  // Update config
  useEffect(() => {
    rendererRef.current?.updateConfig(visualConfig);
  }, [visualConfig]);

  // Sync selected atom
  useEffect(() => {
    rendererRef.current?.selectAtom(selectedAtomId);
  }, [selectedAtomId]);

  return (
    <div ref={containerRef} className={`relative w-full h-full ${className}`}>
      <canvas ref={canvasRef} className="w-full h-full" style={{ display: 'block' }} />

      {/* Overlay: molecule info */}
      {currentMolecule && !isLoading && (
        <div className="absolute top-3 left-3 pointer-events-none">
          <div className="bg-black/55 backdrop-blur-sm text-white px-3 py-2 rounded-xl border border-white/10">
            <div className="font-bold text-base leading-tight">{currentMolecule.name}</div>
            <div className="text-gray-300 text-xs mt-0.5">{currentMolecule.formula} • {currentMolecule.atoms.length} atoms • {currentMolecule.bonds.length} bonds</div>
          </div>
        </div>
      )}

      {/* Loading overlay */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/30">
          <div className="text-center">
            <div className="w-12 h-12 border-2 border-violet-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <div className="text-sm text-gray-300">Loading molecule...</div>
          </div>
        </div>
      )}

      {/* Empty state */}
      {!currentMolecule && !isLoading && (
        <div className="absolute inset-0 flex items-end justify-center pb-10 pointer-events-none">
          <div className="bg-black/70 backdrop-blur-md border border-white/10 rounded-2xl p-6 text-center max-w-sm mx-4">
            <div className="text-4xl mb-3">🧬</div>
            <h2 className="text-lg font-bold text-white mb-2">MolecularAI</h2>
            <p className="text-sm text-gray-400 leading-relaxed mb-4">Search any molecule above to begin 3D visualization and AI analysis</p>
            <div className="flex flex-wrap justify-center gap-2">
              {['💧 Water', '☕ Caffeine', '💊 Aspirin', '⬡ Benzene'].map(m => (
                <span key={m} className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs text-gray-300">{m}</span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Render mode badge */}
      <div className="absolute bottom-3 right-3 pointer-events-none">
        <div className="bg-black/40 text-white/50 px-2 py-1 rounded-lg text-xs border border-white/5">
          {visualConfig.renderMode.replace('-', ' ')} • {visualConfig.colorScheme.toUpperCase()}
          {visualConfig.autoRotate ? ' • ↻' : ''}
        </div>
      </div>
    </div>
  );
}
