export interface Atom {
  id: number;
  element: string;
  symbol: string;
  x: number;
  y: number;
  z: number;
  charge?: number;
  hybridization?: string;
  color: string;
  radius: number;
  mass: number;
  electronegativity?: number;
  selected?: boolean;
}

export interface Bond {
  id: number;
  atom1: number;
  atom2: number;
  order: 1 | 2 | 3 | 1.5;
  type: 'single' | 'double' | 'triple' | 'aromatic';
  length?: number;
  angle?: number;
}

export interface MolecularData {
  name: string;
  formula: string;
  smiles: string;
  inchi?: string;
  inchikey?: string;
  iupacName?: string;
  synonyms?: string[];
  atoms: Atom[];
  bonds: Bond[];
  properties: MolecularProperties;
  cid?: number;
  source?: string;
  timestamp?: number;
}

export interface MolecularProperties {
  molecularWeight: number;
  logP?: number;
  hBondDonors?: number;
  hBondAcceptors?: number;
  rotBonds?: number;
  polarSurfaceArea?: number;
  complexity?: number;
  charge?: number;
  xlogp?: number;
  exactMass?: number;
  monoisotopicMass?: number;
  heavyAtomCount?: number;
  atomStereoCount?: number;
  bondStereoCount?: number;
  covalentUnitCount?: number;
  tpsa?: number;
  geometry?: string;
  hybridization?: string;
  dipole?: number;
  boilingPoint?: number;
  meltingPoint?: number;
  density?: number;
  solubility?: string;
  functionalGroups?: string[];
  vseprGeometry?: string;
  electronDomains?: number;
  bondAngles?: BondAngle[];
  isAromatic?: boolean;
  isChiral?: boolean;
}

export interface BondAngle {
  atom1: string;
  central: string;
  atom2: string;
  angle: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  molecule?: string;
  mode?: AIMode;
}

export type AIMode = 'explainer' | 'tutor' | 'validator' | 'copilot';
export type AIProvider = 'openai' | 'deepseek' | 'local';
export type RenderMode = 'ball-stick' | 'space-filling' | 'wireframe' | 'stick';
export type AppTab = 'viewer' | 'builder' | 'learn' | 'lab' | 'collaborate' | 'settings';

export interface AIConfig {
  provider: AIProvider;
  openaiKey?: string;
  deepseekKey?: string;
  localEndpoint?: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
  responseStyle?: 'concise' | 'detailed' | 'educational';
}

export interface VisualConfig {
  renderMode: RenderMode;
  showHydrogens: boolean;
  showLabels: boolean;
  showBondAngles: boolean;
  showElectronDensity: boolean;
  showOrbitals: boolean;
  atomScale: number;
  bondThickness: number;
  backgroundColor: string;
  lightIntensity: number;
  showShadows: boolean;
  rotateSpeed: number;
  autoRotate: boolean;
  colorScheme: 'cpk' | 'jmol' | 'custom';
  customAtomColors: Record<string, string>;
}

export interface LessonModule {
  id: string;
  title: string;
  description: string;
  topics: Topic[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  completed: boolean;
  progress: number;
}

export interface Topic {
  id: string;
  title: string;
  content: string;
  molecule?: string;
  quiz?: QuizQuestion[];
  completed: boolean;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  type: 'multiple-choice' | 'text' | 'structure';
}

export interface UserProgress {
  xp: number;
  level: number;
  completedLessons: string[];
  completedQuizzes: string[];
  score: number;
  streak: number;
  moleculesExplored: string[];
  achievements: Achievement[];
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: number;
}

export interface ReactionResult {
  reactants: string[];
  products: string[];
  mechanism: string;
  conditions?: string;
  energyChange?: string;
  explanation: string;
}

export interface CollaborationSession {
  id: string;
  name: string;
  hostId: string;
  participants: Participant[];
  currentMolecule?: string;
  messages: ChatMessage[];
  isActive: boolean;
}

export interface Participant {
  id: string;
  name: string;
  role: 'teacher' | 'student' | 'observer';
  color: string;
  cursor?: { x: number; y: number };
}

export interface MoleculeHistoryEntry {
  id: string;
  molecule: MolecularData;
  timestamp: number;
  action: string;
}

export interface PluginDefinition {
  id: string;
  name: string;
  version: string;
  description: string;
  type: 'renderer' | 'ai' | 'data' | 'analysis';
  enabled: boolean;
  config?: Record<string, unknown>;
}
