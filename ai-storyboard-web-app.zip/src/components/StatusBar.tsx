import React from 'react';
import { Cpu, Zap, CheckCircle, Circle, Activity } from 'lucide-react';
import { useStoryboardStore } from '../store/storyboardStore';
import { useReactFlow } from '@xyflow/react';

export const StatusBar: React.FC = () => {
  const { nodes, edges, jobQueue, selectedNodeId } = useStoryboardStore();
  const reactFlow = useReactFlow();

  const [zoom, setZoom] = React.useState(1);

  React.useEffect(() => {
    const updateZoom = () => {
      try {
        const vp = reactFlow.getViewport();
        setZoom(vp.zoom);
      } catch { /* ignore */ }
    };
    const interval = setInterval(updateZoom, 500);
    return () => clearInterval(interval);
  }, [reactFlow]);

  const completedNodes = nodes.filter((n) => n.data?.status === 'complete').length;
  const generatingNodes = nodes.filter((n) => n.data?.status === 'generating').length;
  const activeJobs = jobQueue.filter((j) => j.status === 'generating' || j.status === 'queued').length;
  const selectedNode = nodes.find((n) => n.id === selectedNodeId);

  return (
    <div className="absolute bottom-0 left-0 right-0 z-40 flex items-center justify-between px-4 py-1.5 bg-slate-900/95 backdrop-blur border-t border-slate-700/80 text-[10px] text-slate-500">
      {/* Left */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5">
          <Circle size={6} className="text-emerald-400" fill="currentColor" />
          <span>Connected</span>
        </div>
        <span>{nodes.length} nodes · {edges.length} connections</span>
        <div className="flex items-center gap-1">
          <CheckCircle size={8} className="text-emerald-400" />
          <span className="text-emerald-400">{completedNodes} complete</span>
        </div>
        {generatingNodes > 0 && (
          <div className="flex items-center gap-1 animate-pulse">
            <Activity size={8} className="text-violet-400" />
            <span className="text-violet-400">{generatingNodes} generating</span>
          </div>
        )}
      </div>

      {/* Center */}
      {selectedNode && (
        <div className="flex items-center gap-2">
          <span className="text-slate-600">Selected:</span>
          <span className="text-slate-300 font-medium">{selectedNode.data?.label}</span>
          <span className="text-slate-600">·</span>
          <span className="capitalize text-slate-400">{selectedNode.data?.nodeType?.replace(/([A-Z])/g, ' $1').trim()}</span>
        </div>
      )}

      {/* Right */}
      <div className="flex items-center gap-4">
        {activeJobs > 0 && (
          <div className="flex items-center gap-1 text-violet-400">
            <Zap size={8} />
            <span>{activeJobs} job{activeJobs !== 1 ? 's' : ''} running</span>
          </div>
        )}
        <div className="flex items-center gap-1">
          <Cpu size={8} />
          <span>Flux · Standard</span>
        </div>
        <span>Zoom: {Math.round(zoom * 100)}%</span>
        <span>FrameForge v1.0</span>
      </div>
    </div>
  );
};
