import React, { useState } from 'react';
import {
  FileText, Wand2, Image, Film, Lock, Download, MessageSquare,
  Undo2, Redo2, Grid3X3, Map, ZoomIn, ZoomOut, Save,
  GitBranch, Users, Zap, Bell,
  Settings, Plus, ChevronDown, Cpu, Layers as LayersIcon,
  Video, Edit
} from 'lucide-react';
import { useStoryboardStore } from '../store/storyboardStore';
import type { NodeType, PanelType } from '../types';
import { useReactFlow } from '@xyflow/react';

interface NodeTypeOption {
  type: NodeType;
  label: string;
  icon: React.ElementType;
  color: string;
  description: string;
}

const NODE_TYPES: NodeTypeOption[] = [
  { type: 'scriptBeat', label: 'Script Beat', icon: FileText, color: 'text-slate-300', description: 'Story beat or scene description' },
  { type: 'promptBuilder', label: 'Prompt Builder', icon: Wand2, color: 'text-indigo-400', description: 'Structured prompt composition' },
  { type: 'imageGeneration', label: 'Image Gen', icon: Image, color: 'text-violet-400', description: 'AI image generation' },
  { type: 'imageEdit', label: 'Image Edit', icon: Edit, color: 'text-purple-400', description: 'Edit and inpaint images' },
  { type: 'videoGeneration', label: 'Video Gen', icon: Video, color: 'text-pink-400', description: 'Animate with motion prompts' },
  { type: 'referenceLock', label: 'Ref Lock', icon: Lock, color: 'text-amber-400', description: 'Lock style/character refs' },
  { type: 'exportNode', label: 'Export', icon: Download, color: 'text-emerald-400', description: 'Export to PDF/JSON/MP4' },
  { type: 'comment', label: 'Note', icon: MessageSquare, color: 'text-yellow-400', description: 'Director notes and comments' },
];

const PANEL_BUTTONS: { panel: PanelType; icon: React.ElementType; label: string; color: string }[] = [
  { panel: 'promptInspector', icon: Wand2, label: 'Prompt', color: 'text-violet-400' },
  { panel: 'versionHistory', icon: GitBranch, label: 'History', color: 'text-indigo-400' },
  { panel: 'timeline', icon: Film, label: 'Timeline', color: 'text-pink-400' },
  { panel: 'referenceManager', icon: Lock, label: 'References', color: 'text-amber-400' },
  { panel: 'jobQueue', icon: Zap, label: 'Queue', color: 'text-yellow-400' },
  { panel: 'collaboration', icon: Users, label: 'Team', color: 'text-blue-400' },
];

export const Toolbar: React.FC = () => {
  const {
    undo, redo, undoHistory, redoHistory,
    toggleGrid, toggleMinimap, showGrid, showMinimap,
    openPanels, togglePanel,
    addNode,
    notifications,
    jobQueue,
    saveVersion,
    project,
    lastSaved,
    isSaving,
  } = useStoryboardStore();

  const reactFlow = useReactFlow();
  const [showNodeMenu, setShowNodeMenu] = useState(false);
  const [showNotifDropdown, setShowNotifDropdown] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;
  const activeJobs = jobQueue.filter((j) => j.status === 'generating' || j.status === 'queued').length;

  const handleAddNode = (type: NodeType) => {
    const center = reactFlow.screenToFlowPosition({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
    addNode(type, { x: center.x - 140, y: center.y - 100 });
    setShowNodeMenu(false);
  };

  const formatSaveTime = () => {
    const diff = Date.now() - lastSaved;
    if (isSaving) return 'Saving...';
    if (diff < 60000) return 'Saved just now';
    if (diff < 3600000) return `Saved ${Math.floor(diff / 60000)}m ago`;
    return `Saved ${Math.floor(diff / 3600000)}h ago`;
  };

  return (
    <div className="absolute top-0 left-0 right-0 z-50 flex items-center justify-between px-4 py-2 bg-slate-900/95 backdrop-blur border-b border-slate-700/80 shadow-xl">
      {/* Left: Brand & Project */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center">
            <LayersIcon size={14} className="text-white" />
          </div>
          <div>
            <h1 className="text-xs font-bold text-white leading-none">FrameForge</h1>
            <p className="text-[9px] text-slate-500 leading-none mt-0.5">AI Studio</p>
          </div>
        </div>

        <div className="w-px h-6 bg-slate-700" />

        <div className="flex items-center gap-2">
          <div>
            <p className="text-xs font-medium text-white truncate max-w-[140px]">{project.name}</p>
            <p className="text-[9px] text-slate-500">{formatSaveTime()}</p>
          </div>
          <button
            onClick={() => saveVersion(`Auto ${new Date().toLocaleTimeString()}`)}
            className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            title="Save version"
          >
            <Save size={13} />
          </button>
        </div>
      </div>

      {/* Center: Add node + Edit tools */}
      <div className="flex items-center gap-1">
        {/* Add Node Menu */}
        <div className="relative">
          <button
            onClick={() => setShowNodeMenu(!showNodeMenu)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white text-xs font-medium transition-all shadow-lg"
          >
            <Plus size={13} />
            Add Node
            <ChevronDown size={10} />
          </button>
          {showNodeMenu && (
            <div className="absolute top-full left-0 mt-2 w-64 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl overflow-hidden z-50">
              <div className="px-3 py-2 border-b border-slate-700">
                <p className="text-[10px] text-slate-400 uppercase tracking-wider font-medium">Node Types</p>
              </div>
              <div className="py-1">
                {NODE_TYPES.map((nt) => (
                  <button
                    key={nt.type}
                    onClick={() => handleAddNode(nt.type)}
                    className="w-full flex items-center gap-3 px-3 py-2 hover:bg-slate-700 transition-colors text-left"
                  >
                    <nt.icon size={14} className={nt.color} />
                    <div>
                      <p className="text-xs text-white font-medium">{nt.label}</p>
                      <p className="text-[10px] text-slate-400">{nt.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="w-px h-6 bg-slate-700 mx-1" />

        {/* Undo/Redo */}
        <button
          onClick={undo}
          disabled={undoHistory.length === 0}
          className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
          title="Undo (Ctrl+Z)"
        >
          <Undo2 size={14} />
        </button>
        <button
          onClick={redo}
          disabled={redoHistory.length === 0}
          className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
          title="Redo (Ctrl+Y)"
        >
          <Redo2 size={14} />
        </button>

        <div className="w-px h-6 bg-slate-700 mx-1" />

        {/* Canvas controls */}
        <button
          onClick={toggleGrid}
          className={`p-1.5 rounded-lg transition-colors ${showGrid ? 'bg-slate-700 text-white' : 'hover:bg-slate-700 text-slate-500 hover:text-white'}`}
          title="Toggle grid"
        >
          <Grid3X3 size={14} />
        </button>
        <button
          onClick={toggleMinimap}
          className={`p-1.5 rounded-lg transition-colors ${showMinimap ? 'bg-slate-700 text-white' : 'hover:bg-slate-700 text-slate-500 hover:text-white'}`}
          title="Toggle minimap"
        >
          <Map size={14} />
        </button>
        <button
          onClick={() => reactFlow.zoomIn()}
          className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          title="Zoom in"
        >
          <ZoomIn size={14} />
        </button>
        <button
          onClick={() => reactFlow.zoomOut()}
          className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          title="Zoom out"
        >
          <ZoomOut size={14} />
        </button>
        <button
          onClick={() => reactFlow.fitView({ padding: 0.1 })}
          className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          title="Fit view"
        >
          <Cpu size={14} />
        </button>
      </div>

      {/* Right: Panels & Notifications */}
      <div className="flex items-center gap-1">
        {/* Panel toggles */}
        {PANEL_BUTTONS.map(({ panel, icon: Icon, label, color }) => (
          <button
            key={panel}
            onClick={() => togglePanel(panel)}
            className={`flex items-center gap-1 px-2 py-1.5 rounded-lg text-[10px] font-medium transition-colors ${
              openPanels.includes(panel)
                ? 'bg-slate-700 text-white'
                : 'hover:bg-slate-800 text-slate-500 hover:text-slate-300'
            }`}
            title={label}
          >
            <Icon size={12} className={openPanels.includes(panel) ? color : ''} />
            <span className="hidden lg:inline">{label}</span>
          </button>
        ))}

        <div className="w-px h-6 bg-slate-700 mx-1" />

        {/* Active jobs indicator */}
        {activeJobs > 0 && (
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-violet-900/50 border border-violet-700/50">
            <Zap size={11} className="text-violet-400 animate-pulse" />
            <span className="text-[10px] text-violet-300 font-medium">{activeJobs} running</span>
          </div>
        )}

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setShowNotifDropdown(!showNotifDropdown)}
            className="relative p-1.5 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <Bell size={14} />
            {unreadCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-red-500 text-white text-[8px] font-bold flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>
          {showNotifDropdown && (
            <div className="absolute top-full right-0 mt-2 w-80 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl overflow-hidden z-50">
              <div className="flex items-center justify-between px-3 py-2 border-b border-slate-700">
                <p className="text-xs font-medium text-white">Notifications</p>
                <button onClick={() => setShowNotifDropdown(false)} className="text-[10px] text-slate-400 hover:text-white">Close</button>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.slice(0, 10).map((n) => (
                  <div key={n.id} className={`px-3 py-2.5 border-b border-slate-700/50 ${!n.read ? 'bg-slate-700/30' : ''}`}>
                    <div className="flex items-start gap-2">
                      <div className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                        n.type === 'success' ? 'bg-emerald-400' :
                        n.type === 'error' ? 'bg-red-400' :
                        n.type === 'warning' ? 'bg-amber-400' :
                        'bg-blue-400'
                      }`} />
                      <div>
                        <p className="text-xs font-medium text-white">{n.title}</p>
                        <p className="text-[10px] text-slate-400 mt-0.5">{n.message}</p>
                        <p className="text-[9px] text-slate-600 mt-0.5">{new Date(n.timestamp).toLocaleTimeString()}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <button className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
          <Settings size={14} />
        </button>

        {/* Collaborator avatars */}
        <div className="flex -space-x-1.5 ml-1">
          {[
            { name: 'AC', color: '#6366f1', online: true },
            { name: 'MP', color: '#10b981', online: true },
          ].map((c, i) => (
            <div
              key={i}
              className="w-7 h-7 rounded-full border-2 border-slate-900 flex items-center justify-center text-[10px] font-bold text-white relative"
              style={{ backgroundColor: c.color }}
              title={c.name}
            >
              {c.name}
              {c.online && (
                <div className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 border border-slate-900" />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Click outside to close menus */}
      {(showNodeMenu || showNotifDropdown) && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => { setShowNodeMenu(false); setShowNotifDropdown(false); }}
        />
      )}
    </div>
  );
};
