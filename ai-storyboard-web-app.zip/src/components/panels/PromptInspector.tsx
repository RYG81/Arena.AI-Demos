import React, { useState } from 'react';
import { X, Wand2, Plus, Minus, ChevronDown, ChevronRight, Zap, BookOpen, Save, RotateCcw } from 'lucide-react';
import { useStoryboardStore } from '../../store/storyboardStore';
import type { PromptStructure } from '../../types';

const ASPECT_RATIOS = ['16:9', '4:3', '1:1', '9:16', '2.35:1'] as const;
const CAMERA_PRESETS = ['wide shot', 'medium shot', 'close-up', 'extreme close-up', 'overhead', 'low angle', 'dutch angle', 'over the shoulder'];
const LIGHTING_PRESETS = ['natural light', 'golden hour', 'blue hour', 'dramatic side light', 'soft box', 'neon', 'candlelight', 'studio', 'harsh sunlight'];
const STYLE_PRESETS = ['cinematic', 'photorealistic', 'anime', 'oil painting', 'watercolor', 'noir', 'cyberpunk', 'fantasy', 'documentary'];

const WeightSlider = ({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) => (
  <div className="flex items-center gap-2">
    <span className="text-xs text-slate-400 w-16 shrink-0 capitalize">{label}</span>
    <input
      type="range"
      min="0"
      max="2"
      step="0.1"
      value={value}
      onChange={(e) => onChange(parseFloat(e.target.value))}
      className="flex-1 h-1 accent-violet-500"
    />
    <span className="text-xs text-slate-400 w-8 text-right">{value.toFixed(1)}</span>
  </div>
);

export const PromptInspector: React.FC = () => {
  const { selectedNodeId, nodes, updateNodeData, closePanel, promptTemplates, startGeneration } = useStoryboardStore();
  const [showNegative, setShowNegative] = useState(true);
  const [showWeights, setShowWeights] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [activeField, setActiveField] = useState<string | null>(null);

  const selectedNode = nodes.find((n) => n.id === selectedNodeId);
  const data = selectedNode?.data;
  const prompt: PromptStructure = data?.prompt || {
    subject: '', action: '', environment: '', camera: 'medium shot',
    lighting: 'natural light', style: 'cinematic', aspectRatio: '16:9',
    negativePrompt: 'blurry, low quality', useNegative: true, weights: {}, styleTokens: [],
  };

  const updatePrompt = (field: keyof PromptStructure, value: unknown) => {
    if (!selectedNodeId) return;
    updateNodeData(selectedNodeId, {
      prompt: { ...prompt, [field]: value },
    });
  };

  const updateWeight = (key: string, value: number) => {
    if (!selectedNodeId) return;
    updateNodeData(selectedNodeId, {
      prompt: { ...prompt, weights: { ...prompt.weights, [key]: value } },
    });
  };

  const buildFullPrompt = () => {
    const parts = [prompt.subject, prompt.action, prompt.environment, prompt.camera, prompt.lighting, prompt.style].filter(Boolean);
    return parts.join(', ');
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 text-white">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <Wand2 size={16} className="text-violet-400" />
          <span className="text-sm font-semibold">Prompt Inspector</span>
        </div>
        <button onClick={() => closePanel('promptInspector')} className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
          <X size={14} />
        </button>
      </div>

      {!selectedNode ? (
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
          <Wand2 size={32} className="text-slate-600 mb-3" />
          <p className="text-slate-500 text-sm">Select a node to inspect its prompt</p>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto">
          {/* Node info */}
          <div className="px-4 py-3 bg-slate-800/50 border-b border-slate-700">
            <p className="text-sm font-medium text-white truncate">{data?.label}</p>
            <p className="text-xs text-slate-400 capitalize">{data?.nodeType?.replace(/([A-Z])/g, ' $1').trim()}</p>
          </div>

          {/* Full prompt preview */}
          <div className="mx-4 mt-3 p-3 bg-slate-800 rounded-lg border border-slate-700">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-medium">Full Prompt</span>
              <button className="text-[10px] text-violet-400 hover:text-violet-300">Copy</button>
            </div>
            <p className="text-xs text-slate-300 font-mono leading-relaxed">
              {buildFullPrompt() || <span className="text-slate-600 italic">Build your prompt below...</span>}
            </p>
          </div>

          {/* Structured fields */}
          <div className="px-4 py-3 space-y-3">
            {(['subject', 'action', 'environment'] as const).map((field) => (
              <div key={field}>
                <label className="block text-[10px] text-slate-400 uppercase tracking-wider font-medium mb-1 capitalize">{field}</label>
                <textarea
                  value={prompt[field] as string}
                  onChange={(e) => updatePrompt(field, e.target.value)}
                  onFocus={() => setActiveField(field)}
                  onBlur={() => setActiveField(null)}
                  placeholder={`Describe the ${field}...`}
                  rows={2}
                  className={`w-full bg-slate-800 border rounded-lg px-3 py-2 text-xs text-slate-200 placeholder-slate-600 resize-none focus:outline-none transition-colors ${activeField === field ? 'border-violet-500' : 'border-slate-700'}`}
                />
              </div>
            ))}

            {/* Camera */}
            <div>
              <label className="block text-[10px] text-slate-400 uppercase tracking-wider font-medium mb-1">Camera</label>
              <div className="flex gap-2">
                <select
                  value={prompt.camera}
                  onChange={(e) => updatePrompt('camera', e.target.value)}
                  className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-violet-500"
                >
                  {CAMERA_PRESETS.map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
            </div>

            {/* Lighting */}
            <div>
              <label className="block text-[10px] text-slate-400 uppercase tracking-wider font-medium mb-1">Lighting</label>
              <div className="flex flex-wrap gap-1">
                {LIGHTING_PRESETS.map((l) => (
                  <button
                    key={l}
                    onClick={() => updatePrompt('lighting', l)}
                    className={`text-[10px] px-2 py-1 rounded-full border transition-colors ${prompt.lighting === l ? 'bg-violet-600 border-violet-500 text-white' : 'border-slate-700 text-slate-400 hover:border-slate-500'}`}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>

            {/* Style */}
            <div>
              <label className="block text-[10px] text-slate-400 uppercase tracking-wider font-medium mb-1">Style</label>
              <div className="flex flex-wrap gap-1">
                {STYLE_PRESETS.map((s) => (
                  <button
                    key={s}
                    onClick={() => updatePrompt('style', s)}
                    className={`text-[10px] px-2 py-1 rounded-full border transition-colors ${prompt.style === s ? 'bg-indigo-600 border-indigo-500 text-white' : 'border-slate-700 text-slate-400 hover:border-slate-500'}`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Aspect ratio */}
            <div>
              <label className="block text-[10px] text-slate-400 uppercase tracking-wider font-medium mb-1">Aspect Ratio</label>
              <div className="flex gap-1">
                {ASPECT_RATIOS.map((ar) => (
                  <button
                    key={ar}
                    onClick={() => updatePrompt('aspectRatio', ar)}
                    className={`flex-1 text-[10px] py-1.5 rounded-lg border transition-colors ${prompt.aspectRatio === ar ? 'bg-violet-600 border-violet-500 text-white' : 'border-slate-700 text-slate-400 hover:border-slate-500'}`}
                  >
                    {ar}
                  </button>
                ))}
              </div>
            </div>

            {/* Weights */}
            <div>
              <button
                onClick={() => setShowWeights(!showWeights)}
                className="flex items-center gap-2 text-[10px] text-slate-400 uppercase tracking-wider font-medium w-full"
              >
                {showWeights ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                Weight Sliders
              </button>
              {showWeights && (
                <div className="mt-2 space-y-2 bg-slate-800 rounded-lg p-3">
                  {Object.entries(prompt.weights).map(([key, val]) => (
                    <WeightSlider key={key} label={key} value={val} onChange={(v) => updateWeight(key, v)} />
                  ))}
                  <button
                    onClick={() => updateWeight(`token${Date.now()}`, 1.0)}
                    className="flex items-center gap-1 text-[10px] text-violet-400 hover:text-violet-300"
                  >
                    <Plus size={10} /> Add weight token
                  </button>
                </div>
              )}
            </div>

            {/* Negative prompt */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] text-slate-400 uppercase tracking-wider font-medium">Negative Prompt</label>
                <button
                  onClick={() => setShowNegative(!showNegative)}
                  className={`text-[10px] px-2 py-0.5 rounded-full border transition-colors ${showNegative ? 'bg-red-900/50 border-red-700 text-red-400' : 'border-slate-700 text-slate-500'}`}
                >
                  {showNegative ? <Minus size={10} /> : <Plus size={10} />}
                </button>
              </div>
              {showNegative && (
                <textarea
                  value={prompt.negativePrompt}
                  onChange={(e) => updatePrompt('negativePrompt', e.target.value)}
                  placeholder="What to exclude..."
                  rows={2}
                  className="w-full bg-red-950/30 border border-red-900/50 rounded-lg px-3 py-2 text-xs text-red-200 placeholder-slate-600 resize-none focus:outline-none focus:border-red-700"
                />
              )}
            </div>
          </div>

          {/* Templates */}
          <div className="border-t border-slate-700 mx-4 pt-3 pb-3">
            <button
              onClick={() => setShowTemplates(!showTemplates)}
              className="flex items-center gap-2 text-[10px] text-slate-400 uppercase tracking-wider font-medium w-full"
            >
              {showTemplates ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
              <BookOpen size={11} />
              Templates
            </button>
            {showTemplates && (
              <div className="mt-2 space-y-1">
                {promptTemplates.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => {
                      if (!selectedNodeId) return;
                      updateNodeData(selectedNodeId, {
                        prompt: { ...prompt, ...t.prompt },
                      });
                    }}
                    className="w-full text-left p-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors"
                  >
                    <p className="text-xs text-white font-medium">{t.name}</p>
                    <p className="text-[10px] text-slate-400">{t.description}</p>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Actions */}
          {data?.nodeType && ['imageGeneration', 'imageEdit', 'videoGeneration'].includes(data.nodeType) && (
            <div className="px-4 pb-4 flex gap-2">
              <button
                onClick={() => selectedNodeId && startGeneration(selectedNodeId)}
                disabled={data?.status === 'generating' || data?.status === 'queued'}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-medium transition-all"
              >
                <Zap size={14} />
                {data?.status === 'generating' ? 'Generating...' : data?.status === 'queued' ? 'Queued...' : 'Generate'}
              </button>
              <button
                className="p-2.5 rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                title="Reset prompt"
              >
                <RotateCcw size={14} />
              </button>
              <button
                className="p-2.5 rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                title="Save as template"
              >
                <Save size={14} />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
