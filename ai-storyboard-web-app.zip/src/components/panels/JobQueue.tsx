import React from 'react';
import { X, Loader2, CheckCircle, Clock, AlertCircle, XCircle, Zap, Cpu } from 'lucide-react';
import { useStoryboardStore } from '../../store/storyboardStore';
import type { JobQueueItem } from '../../types';

const JobCard: React.FC<{ job: JobQueueItem }> = ({ job }) => {
  const { cancelJob, nodes } = useStoryboardStore();
  const node = nodes.find((n) => n.id === job.nodeId);
  const elapsed = job.startedAt ? Math.round((Date.now() - job.startedAt) / 1000) : 0;

  const statusIcon = {
    queued: <Clock size={12} className="text-amber-400" />,
    generating: <Loader2 size={12} className="text-violet-400 animate-spin" />,
    complete: <CheckCircle size={12} className="text-emerald-400" />,
    error: <AlertCircle size={12} className="text-red-400" />,
    idle: <Clock size={12} className="text-slate-500" />,
  }[job.status];

  return (
    <div className={`p-3 rounded-lg border transition-all ${
      job.status === 'generating' ? 'border-violet-700/50 bg-violet-950/30' :
      job.status === 'complete' ? 'border-emerald-800/50 bg-emerald-950/20' :
      job.status === 'error' ? 'border-red-800/50 bg-red-950/20' :
      'border-slate-700 bg-slate-800/50'
    }`}>
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="flex items-center gap-2 min-w-0">
          {statusIcon}
          <span className="text-xs font-medium text-white truncate">{node?.data?.label || job.nodeId}</span>
        </div>
        {(job.status === 'queued' || job.status === 'generating') && (
          <button
            onClick={() => cancelJob(job.id)}
            className="shrink-0 p-0.5 rounded hover:bg-white/10 text-slate-500 hover:text-red-400 transition-colors"
          >
            <XCircle size={12} />
          </button>
        )}
      </div>

      <div className="flex items-center gap-2 text-[10px] text-slate-500 mb-2">
        <Cpu size={9} />
        <span className="uppercase">{job.model}</span>
        <span>•</span>
        <span className="capitalize">{job.type}</span>
        {elapsed > 0 && <><span>•</span><span>{elapsed}s</span></>}
      </div>

      <p className="text-[10px] text-slate-400 font-mono line-clamp-1 mb-2">{job.prompt}</p>

      {(job.status === 'generating' || job.status === 'queued') && (
        <div className="w-full h-1 bg-slate-700 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-violet-500 to-pink-500 rounded-full transition-all duration-300"
            style={{ width: `${job.progress}%` }}
          />
        </div>
      )}

      {job.status === 'complete' && (
        <div className="flex items-center gap-1 text-[10px] text-emerald-400">
          <CheckCircle size={9} />
          Generated in {job.completedAt && job.startedAt ? `${((job.completedAt - job.startedAt) / 1000).toFixed(1)}s` : '—'}
        </div>
      )}

      {job.error && (
        <p className="text-[10px] text-red-400 mt-1">{job.error}</p>
      )}
    </div>
  );
};

export const JobQueue: React.FC = () => {
  const { jobQueue, closePanel } = useStoryboardStore();
  const active = jobQueue.filter((j) => j.status === 'generating' || j.status === 'queued');
  const completed = jobQueue.filter((j) => j.status === 'complete' || j.status === 'error');

  return (
    <div className="flex flex-col h-full bg-slate-900 text-white">
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <Zap size={16} className="text-amber-400" />
          <span className="text-sm font-semibold">Job Queue</span>
          {active.length > 0 && (
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-violet-600 text-white font-medium">
              {active.length} active
            </span>
          )}
        </div>
        <button onClick={() => closePanel('jobQueue')} className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
          <X size={14} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {jobQueue.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Zap size={32} className="text-slate-600 mb-3" />
            <p className="text-slate-500 text-sm">No jobs in queue</p>
            <p className="text-slate-600 text-xs mt-1">Start a generation to see it here</p>
          </div>
        ) : (
          <>
            {active.length > 0 && (
              <div>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider font-medium mb-2">Active</p>
                <div className="space-y-2">
                  {active.map((job) => <JobCard key={job.id} job={job} />)}
                </div>
              </div>
            )}
            {completed.length > 0 && (
              <div>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider font-medium mb-2">Completed</p>
                <div className="space-y-2">
                  {completed.slice(0, 10).map((job) => <JobCard key={job.id} job={job} />)}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Stats footer */}
      <div className="border-t border-slate-700 px-4 py-3 grid grid-cols-3 gap-3">
        {[
          { label: 'Active', value: active.length, color: 'text-violet-400' },
          { label: 'Complete', value: completed.filter((j) => j.status === 'complete').length, color: 'text-emerald-400' },
          { label: 'Failed', value: completed.filter((j) => j.status === 'error').length, color: 'text-red-400' },
        ].map((s) => (
          <div key={s.label} className="text-center">
            <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
            <p className="text-[10px] text-slate-500">{s.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
