import React, { useState } from 'react';
import { X, GitBranch, Clock, User, ChevronRight, RotateCcw, Save, Eye } from 'lucide-react';
import { useStoryboardStore } from '../../store/storyboardStore';

export const VersionHistory: React.FC = () => {
  const { project, closePanel, saveVersion } = useStoryboardStore();
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [versionLabel, setVersionLabel] = useState('');
  const [selectedVersions, setSelectedVersions] = useState<string[]>([]);

  const formatTime = (ts: number) => {
    const diff = Date.now() - ts;
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return new Date(ts).toLocaleDateString();
  };

  const handleSave = () => {
    if (!versionLabel.trim()) return;
    saveVersion(versionLabel.trim());
    setVersionLabel('');
    setShowSaveDialog(false);
  };

  const toggleVersionSelect = (id: string) => {
    setSelectedVersions((prev) =>
      prev.includes(id) ? prev.filter((v) => v !== id) : prev.length < 2 ? [...prev, id] : [prev[1], id]
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 text-white">
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <GitBranch size={16} className="text-indigo-400" />
          <span className="text-sm font-semibold">Version History</span>
        </div>
        <button onClick={() => closePanel('versionHistory')} className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
          <X size={14} />
        </button>
      </div>

      {/* Actions */}
      <div className="px-4 py-3 border-b border-slate-700 flex gap-2">
        <button
          onClick={() => setShowSaveDialog(true)}
          className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium transition-colors"
        >
          <Save size={12} /> Save Version
        </button>
        {selectedVersions.length === 2 && (
          <button className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-300 text-xs transition-colors">
            <Eye size={12} /> Compare
          </button>
        )}
      </div>

      {/* Save dialog */}
      {showSaveDialog && (
        <div className="mx-4 my-3 p-3 bg-slate-800 rounded-lg border border-slate-600">
          <p className="text-xs text-slate-300 mb-2 font-medium">Version label</p>
          <input
            type="text"
            value={versionLabel}
            onChange={(e) => setVersionLabel(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSave()}
            placeholder="e.g., Act 1 Complete"
            className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 mb-2"
            autoFocus
          />
          <div className="flex gap-2">
            <button onClick={handleSave} className="flex-1 py-1.5 rounded bg-indigo-600 hover:bg-indigo-500 text-xs text-white transition-colors">Save</button>
            <button onClick={() => setShowSaveDialog(false)} className="flex-1 py-1.5 rounded border border-slate-700 text-xs text-slate-400 hover:text-white transition-colors">Cancel</button>
          </div>
        </div>
      )}

      {/* Tip */}
      <div className="px-4 py-2">
        <p className="text-[10px] text-slate-500">Click versions to select up to 2 for side-by-side comparison</p>
      </div>

      {/* Version list */}
      <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2">
        {[...project.versions].reverse().map((version, i) => {
          const isSelected = selectedVersions.includes(version.id);
          const isCurrent = i === 0;
          return (
            <div
              key={version.id}
              onClick={() => toggleVersionSelect(version.id)}
              className={`p-3 rounded-lg border cursor-pointer transition-all ${
                isSelected
                  ? 'border-indigo-500 bg-indigo-900/30'
                  : isCurrent
                  ? 'border-slate-600 bg-slate-800'
                  : 'border-slate-700 bg-slate-800/50 hover:border-slate-600'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    {isCurrent && (
                      <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-indigo-600 text-white font-medium">CURRENT</span>
                    )}
                    <p className="text-sm font-medium text-white truncate">{version.label}</p>
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-slate-500">
                    <span className="flex items-center gap-1"><User size={9} />{version.author}</span>
                    <span className="flex items-center gap-1"><Clock size={9} />{formatTime(version.timestamp)}</span>
                  </div>
                  <div className="mt-1.5 space-y-0.5">
                    {version.changes.slice(0, 2).map((c, ci) => (
                      <div key={ci} className="flex items-center gap-1 text-[10px] text-slate-400">
                        <ChevronRight size={8} className="shrink-0" />
                        {c}
                      </div>
                    ))}
                    {version.changes.length > 2 && (
                      <p className="text-[10px] text-slate-500 pl-3">+{version.changes.length - 2} more</p>
                    )}
                  </div>
                </div>
                <div className="flex flex-col gap-1 shrink-0">
                  <button
                    onClick={(e) => { e.stopPropagation(); }}
                    className="p-1.5 rounded hover:bg-white/10 text-slate-500 hover:text-white transition-colors"
                    title="Restore this version"
                  >
                    <RotateCcw size={11} />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Diff viewer placeholder */}
      {selectedVersions.length === 2 && (
        <div className="border-t border-slate-700 p-4">
          <p className="text-xs font-medium text-slate-300 mb-3">Comparing versions</p>
          <div className="grid grid-cols-2 gap-2">
            {selectedVersions.map((vid) => {
              const v = project.versions.find((vv) => vv.id === vid);
              return (
                <div key={vid} className="p-2 bg-slate-800 rounded text-[10px] text-slate-400">
                  <p className="font-medium text-slate-300 mb-1">{v?.label}</p>
                  <p>{new Date(v?.timestamp || 0).toLocaleDateString()}</p>
                  <p className="text-slate-500">{v?.author}</p>
                </div>
              );
            })}
          </div>
          <div className="mt-2 p-2 bg-slate-800 rounded">
            <p className="text-[10px] text-slate-500 text-center">Full diff viewer available in production build</p>
          </div>
        </div>
      )}
    </div>
  );
};
