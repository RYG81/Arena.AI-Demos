import React from 'react';
import { X, Users, Crown, Edit3, MessageCircle, Eye, Circle, Clock, Send, Activity } from 'lucide-react';
import { useStoryboardStore } from '../../store/storyboardStore';
import type { UserRole } from '../../types';

const ROLE_ICONS: Record<UserRole, React.ElementType> = {
  owner: Crown,
  editor: Edit3,
  commenter: MessageCircle,
  viewer: Eye,
};

const ROLE_COLORS: Record<UserRole, string> = {
  owner: 'text-amber-400',
  editor: 'text-violet-400',
  commenter: 'text-blue-400',
  viewer: 'text-slate-400',
};

const activityLog = [
  { id: 1, user: 'Alex Chen', action: 'generated "Hero Wide Shot"', time: '2m ago', color: '#6366f1' },
  { id: 2, user: 'Maya Patel', action: 'updated prompt on "Close-up Face"', time: '8m ago', color: '#10b981' },
  { id: 3, user: 'Alex Chen', action: 'added Reference Lock node', time: '15m ago', color: '#6366f1' },
  { id: 4, user: 'Jordan Kim', action: 'commented on "Director Notes"', time: '1h ago', color: '#f59e0b' },
  { id: 5, user: 'Maya Patel', action: 'forked node "Hero Wide Shot"', time: '2h ago', color: '#10b981' },
];

export const Collaboration: React.FC = () => {
  const { collaborators, closePanel, project } = useStoryboardStore();
  const [message, setMessage] = React.useState('');

  const formatLastSeen = (ts: number) => {
    const diff = Date.now() - ts;
    if (diff < 60000) return 'Active now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    return `${Math.floor(diff / 3600000)}h ago`;
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 text-white">
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <Users size={16} className="text-blue-400" />
          <span className="text-sm font-semibold">Collaboration</span>
          <span className="flex items-center gap-1 text-[10px] text-emerald-400">
            <Circle size={6} fill="currentColor" />
            {collaborators.filter((c) => c.isOnline).length} online
          </span>
        </div>
        <button onClick={() => closePanel('collaboration')} className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
          <X size={14} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Project info */}
        <div className="px-4 py-3 border-b border-slate-700 bg-slate-800/50">
          <p className="text-xs font-medium text-white">{project.name}</p>
          <div className="flex items-center gap-2 mt-1">
            <span className={`text-[10px] px-2 py-0.5 rounded-full border ${project.isPublic ? 'border-emerald-700 text-emerald-400' : 'border-slate-600 text-slate-400'}`}>
              {project.isPublic ? 'Public' : 'Private'}
            </span>
            <button className="text-[10px] text-blue-400 hover:text-blue-300 transition-colors">Share link ↗</button>
          </div>
        </div>

        {/* Team members */}
        <div className="px-4 py-3 border-b border-slate-700">
          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-medium mb-3">Team ({collaborators.length})</p>
          <div className="space-y-2">
            {collaborators.map((collab) => {
              const RoleIcon = ROLE_ICONS[collab.role];
              const roleColor = ROLE_COLORS[collab.role];
              return (
                <div key={collab.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-800 transition-colors">
                  <div className="relative">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white"
                      style={{ backgroundColor: collab.color }}
                    >
                      {collab.avatar}
                    </div>
                    <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-slate-900 ${collab.isOnline ? 'bg-emerald-400' : 'bg-slate-600'}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-xs font-medium text-white truncate">{collab.name}</p>
                      <RoleIcon size={10} className={roleColor} />
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-slate-500">
                      <Clock size={8} />
                      <span>{formatLastSeen(collab.lastSeen)}</span>
                    </div>
                  </div>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full capitalize ${roleColor} bg-white/5`}>
                    {collab.role}
                  </span>
                </div>
              );
            })}
          </div>
          <button className="w-full mt-2 py-2 rounded-lg border border-dashed border-slate-700 text-[10px] text-slate-500 hover:border-slate-500 hover:text-slate-300 transition-colors">
            + Invite collaborator
          </button>
        </div>

        {/* Activity log */}
        <div className="px-4 py-3">
          <div className="flex items-center gap-2 mb-3">
            <Activity size={12} className="text-slate-400" />
            <p className="text-[10px] text-slate-400 uppercase tracking-wider font-medium">Activity Log</p>
          </div>
          <div className="space-y-2">
            {activityLog.map((item) => (
              <div key={item.id} className="flex items-start gap-2.5">
                <div
                  className="w-5 h-5 rounded-full flex items-center justify-center text-[8px] font-bold text-white shrink-0 mt-0.5"
                  style={{ backgroundColor: item.color }}
                >
                  {item.user[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] text-slate-300 leading-relaxed">
                    <span className="font-medium text-white">{item.user}</span> {item.action}
                  </p>
                  <p className="text-[9px] text-slate-600">{item.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick message */}
      <div className="border-t border-slate-700 p-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Send a message..."
            className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500"
          />
          <button
            onClick={() => setMessage('')}
            className="p-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white transition-colors"
          >
            <Send size={13} />
          </button>
        </div>
      </div>
    </div>
  );
};
