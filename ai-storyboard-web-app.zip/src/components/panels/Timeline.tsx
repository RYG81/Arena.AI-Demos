import React, { useState } from 'react';
import { X, Film, Play, Pause, SkipBack, SkipForward, Plus } from 'lucide-react';
import { useStoryboardStore } from '../../store/storyboardStore';
import type { TimelinePanel } from '../../types';

const TRANSITIONS = ['cut', 'fade', 'dissolve', 'wipe'] as const;
const TRANSITION_COLORS: Record<string, string> = {
  cut: 'bg-slate-600',
  fade: 'bg-indigo-600',
  dissolve: 'bg-violet-600',
  wipe: 'bg-pink-600',
};

const totalDuration = (panels: TimelinePanel[]) =>
  panels.reduce((acc, p) => Math.max(acc, p.startTime + p.duration), 0);

export const Timeline: React.FC = () => {
  const { timelinePanels, nodes, closePanel } = useStoryboardStore();
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [zoom, setZoom] = useState(80);
  const total = totalDuration(timelinePanels);

  const getNode = (nodeId: string) => nodes.find((n) => n.id === nodeId);

  React.useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setCurrentTime((prev) => {
        if (prev >= total) { setIsPlaying(false); return 0; }
        return prev + 0.1;
      });
    }, 100);
    return () => clearInterval(interval);
  }, [isPlaying, total]);

  const pixelsPerSecond = zoom;

  return (
    <div className="flex flex-col h-full bg-slate-900 text-white">
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <Film size={16} className="text-pink-400" />
          <span className="text-sm font-semibold">Timeline</span>
          <span className="text-[10px] text-slate-500">{total.toFixed(1)}s total</span>
        </div>
        <button onClick={() => closePanel('timeline')} className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
          <X size={14} />
        </button>
      </div>

      {/* Transport controls */}
      <div className="px-4 py-3 border-b border-slate-700 flex items-center gap-3">
        <button onClick={() => setCurrentTime(0)} className="p-1.5 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
          <SkipBack size={14} />
        </button>
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="p-2 rounded-lg bg-pink-600 hover:bg-pink-500 text-white transition-colors"
        >
          {isPlaying ? <Pause size={14} /> : <Play size={14} />}
        </button>
        <button onClick={() => setCurrentTime(total)} className="p-1.5 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
          <SkipForward size={14} />
        </button>
        <span className="text-xs font-mono text-slate-400 ml-2">
          {currentTime.toFixed(1)}s / {total.toFixed(1)}s
        </span>
        <div className="ml-auto flex items-center gap-2">
          <span className="text-[10px] text-slate-500">Zoom</span>
          <input
            type="range"
            min={40}
            max={160}
            value={zoom}
            onChange={(e) => setZoom(Number(e.target.value))}
            className="w-20 h-1 accent-pink-500"
          />
        </div>
      </div>

      {/* Timeline tracks */}
      <div className="flex-1 overflow-auto">
        {/* Timecode ruler */}
        <div className="sticky top-0 z-10 bg-slate-800 border-b border-slate-700 h-7 flex items-end" style={{ minWidth: total * pixelsPerSecond + 40 }}>
          <div className="w-32 shrink-0" />
          <div className="flex-1 relative overflow-hidden h-full">
            {Array.from({ length: Math.ceil(total) + 1 }).map((_, i) => (
              <div
                key={i}
                className="absolute bottom-0 flex flex-col items-center"
                style={{ left: i * pixelsPerSecond }}
              >
                <span className="text-[9px] text-slate-500 mb-0.5">{i}s</span>
                <div className="w-px h-2 bg-slate-600" />
              </div>
            ))}
            {/* Playhead */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-pink-500 z-10 pointer-events-none"
              style={{ left: currentTime * pixelsPerSecond }}
            />
          </div>
        </div>

        {/* Panel tracks */}
        <div style={{ minWidth: total * pixelsPerSecond + 40 }}>
          {timelinePanels.map((panel, i) => {
            const node = getNode(panel.nodeId);
            const asset = node?.data?.currentAsset;
            return (
              <div key={panel.nodeId} className="flex items-center h-16 border-b border-slate-800 group">
                {/* Track label */}
                <div className="w-32 shrink-0 px-3 flex items-center gap-2">
                  <div className="w-1.5 h-8 rounded-full" style={{ background: `hsl(${i * 60 + 200}, 70%, 50%)` }} />
                  <div className="min-w-0">
                    <p className="text-[10px] text-white font-medium truncate">{panel.label}</p>
                    <p className="text-[9px] text-slate-500">{panel.duration}s</p>
                  </div>
                </div>

                {/* Track lane */}
                <div className="flex-1 relative h-full">
                  {/* Clip block */}
                  <div
                    className="absolute top-2 bottom-2 rounded-lg overflow-hidden border border-white/10 cursor-move hover:border-white/30 transition-all group/clip"
                    style={{
                      left: panel.startTime * pixelsPerSecond,
                      width: panel.duration * pixelsPerSecond - 2,
                      background: `hsla(${i * 60 + 200}, 50%, 15%, 0.8)`,
                    }}
                  >
                    {asset && (
                      <img
                        src={asset.thumbnailUrl}
                        alt=""
                        className="absolute inset-0 w-full h-full object-cover opacity-40"
                      />
                    )}
                    <div className="relative z-10 flex items-center h-full px-2 gap-2">
                      <div
                        className={`w-1.5 h-5 rounded-full shrink-0 ${TRANSITION_COLORS[panel.transition] || 'bg-slate-600'}`}
                        title={`Transition: ${panel.transition}`}
                      />
                      <span className="text-[10px] text-white font-medium truncate">{panel.label}</span>
                    </div>
                  </div>

                  {/* Playhead overlay */}
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-pink-500/60 z-10 pointer-events-none"
                    style={{ left: currentTime * pixelsPerSecond }}
                  />
                </div>
              </div>
            );
          })}

          {/* Add track button */}
          <div className="flex items-center h-10 border-b border-slate-800 px-3">
            <button className="flex items-center gap-1 text-[10px] text-slate-500 hover:text-slate-300 transition-colors">
              <Plus size={11} /> Add clip
            </button>
          </div>
        </div>
      </div>

      {/* Panel controls */}
      <div className="border-t border-slate-700 px-4 py-3">
        <p className="text-[10px] text-slate-400 uppercase tracking-wider font-medium mb-2">Transition Settings</p>
        <div className="flex gap-1">
          {TRANSITIONS.map((t) => (
            <button
              key={t}
              className={`flex-1 text-[10px] py-1.5 rounded-lg border capitalize transition-colors border-slate-700 text-slate-400 hover:border-slate-500 hover:text-white`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
