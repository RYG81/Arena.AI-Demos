import React, { useState } from 'react';
import { X, Lock, Upload, Search, Image, Trash2, Pin, Layers } from 'lucide-react';
import { useStoryboardStore } from '../../store/storyboardStore';
import type { ReferenceImage } from '../../types';

const REF_TYPES = ['all', 'character', 'style', 'location', 'prop', 'reference'] as const;
const SCOPES = ['all', 'project', 'node'] as const;

const RefCard: React.FC<{ ref: ReferenceImage; onDelete: (id: string) => void }> = ({ ref, onDelete }) => {
  const typeColors: Record<string, string> = {
    character: 'text-violet-400 border-violet-700/50',
    style: 'text-indigo-400 border-indigo-700/50',
    location: 'text-emerald-400 border-emerald-700/50',
    prop: 'text-amber-400 border-amber-700/50',
    reference: 'text-slate-400 border-slate-600',
  };
  const color = typeColors[ref.type] || typeColors.reference;

  return (
    <div className={`group relative rounded-lg overflow-hidden border bg-slate-800 hover:border-white/20 transition-all ${color}`}>
      <div className="relative aspect-square">
        <img src={ref.thumbnailUrl} alt={ref.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all" />
        <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
          <button
            onClick={() => onDelete(ref.id)}
            className="p-1 rounded bg-black/60 hover:bg-red-600 text-white transition-colors"
          >
            <Trash2 size={10} />
          </button>
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
          <p className="text-[9px] text-white truncate">{ref.name}</p>
        </div>
        {ref.scope === 'project' && (
          <div className="absolute top-1 left-1">
            <Pin size={9} className="text-amber-400" />
          </div>
        )}
      </div>
      <div className="px-2 py-1.5">
        <p className="text-[10px] text-white font-medium truncate">{ref.name}</p>
        <div className="flex items-center justify-between mt-0.5">
          <span className={`text-[9px] capitalize ${color.split(' ')[0]}`}>{ref.type}</span>
          <span className="text-[9px] text-slate-500">{ref.scope}</span>
        </div>
        {ref.tags.length > 0 && (
          <div className="flex flex-wrap gap-0.5 mt-1">
            {ref.tags.slice(0, 2).map((tag) => (
              <span key={tag} className="text-[8px] px-1 py-0.5 rounded bg-white/5 text-slate-400">{tag}</span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export const ReferenceManager: React.FC = () => {
  const { referenceImages, removeReferenceImage, addReferenceImage, closePanel } = useStoryboardStore();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [scopeFilter, setScopeFilter] = useState<string>('all');
  const [isDragging, setIsDragging] = useState(false);

  const filtered = referenceImages.filter((ref) => {
    const matchSearch = ref.name.toLowerCase().includes(search.toLowerCase()) ||
      ref.tags.some((t) => t.toLowerCase().includes(search.toLowerCase()));
    const matchType = typeFilter === 'all' || ref.type === typeFilter;
    const matchScope = scopeFilter === 'all' || ref.scope === scopeFilter;
    return matchSearch && matchType && matchScope;
  });

  const handleFakeUpload = () => {
    const idx = Math.floor(Math.random() * 99) + 1;
    addReferenceImage({
      url: `https://picsum.photos/seed/upload${idx}/200/200`,
      thumbnailUrl: `https://picsum.photos/seed/upload${idx}/100/100`,
      name: `Reference ${idx}`,
      tags: ['uploaded'],
      scope: 'project',
      type: 'reference',
    });
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 text-white">
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <Lock size={16} className="text-amber-400" />
          <span className="text-sm font-semibold">Reference Manager</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-700 text-slate-300">{referenceImages.length}</span>
        </div>
        <button onClick={() => closePanel('referenceManager')} className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
          <X size={14} />
        </button>
      </div>

      {/* Upload zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => { e.preventDefault(); setIsDragging(false); handleFakeUpload(); }}
        onClick={handleFakeUpload}
        className={`mx-4 mt-3 p-4 border-2 border-dashed rounded-xl cursor-pointer transition-all text-center ${
          isDragging ? 'border-amber-500 bg-amber-900/20' : 'border-slate-700 hover:border-slate-500'
        }`}
      >
        <Upload size={18} className="mx-auto mb-1 text-slate-500" />
        <p className="text-xs text-slate-400">Drop images or click to upload</p>
        <p className="text-[10px] text-slate-600 mt-0.5">PNG, JPG, WebP supported</p>
      </div>

      {/* Search & filters */}
      <div className="px-4 pt-3 space-y-2">
        <div className="relative">
          <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search references..."
            className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-8 pr-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-amber-500"
          />
        </div>
        <div className="flex gap-1 overflow-x-auto pb-1">
          {REF_TYPES.map((t) => (
            <button
              key={t}
              onClick={() => setTypeFilter(t)}
              className={`shrink-0 text-[10px] px-2 py-1 rounded-full border transition-colors capitalize ${
                typeFilter === t ? 'bg-amber-600 border-amber-500 text-white' : 'border-slate-700 text-slate-400 hover:border-slate-500'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
        <div className="flex gap-1">
          {SCOPES.map((s) => (
            <button
              key={s}
              onClick={() => setScopeFilter(s)}
              className={`text-[10px] px-2 py-1 rounded-full border transition-colors capitalize flex items-center gap-1 ${
                scopeFilter === s ? 'bg-slate-600 border-slate-500 text-white' : 'border-slate-700 text-slate-400 hover:border-slate-500'
              }`}
            >
              {s === 'project' && <Layers size={8} />}
              {s === 'node' && <Pin size={8} />}
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-y-auto p-4">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Image size={28} className="text-slate-600 mb-2" />
            <p className="text-slate-500 text-sm">No references found</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {filtered.map((ref) => (
              <RefCard key={ref.id} ref={ref} onDelete={removeReferenceImage} />
            ))}
          </div>
        )}
      </div>

      {/* Style lock info */}
      <div className="border-t border-slate-700 px-4 py-3">
        <div className="flex items-start gap-2 p-2 bg-amber-900/20 rounded-lg border border-amber-800/30">
          <Lock size={12} className="text-amber-400 mt-0.5 shrink-0" />
          <div>
            <p className="text-[10px] text-amber-300 font-medium">Style Lock Active</p>
            <p className="text-[9px] text-amber-400/70">Drift detection enabled for 3 project references</p>
          </div>
        </div>
      </div>
    </div>
  );
};
