import React, { memo, useCallback } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import {
  FileText, Wand2, Image, Film, Lock, Download, MessageSquare,
  Play, Loader2, AlertCircle, CheckCircle, Clock, Zap,
  ChevronDown, ChevronUp, Copy, GitBranch, Trash2, Eye,
  Layers, Video
} from 'lucide-react';
import type { StoryboardNodeData, NodeType } from '../../types';
import { useStoryboardStore } from '../../store/storyboardStore';

const NODE_COLORS: Record<NodeType, { bg: string; border: string; icon: string; badge: string }> = {
  scriptBeat:     { bg: 'bg-slate-800', border: 'border-slate-600', icon: 'text-slate-300', badge: 'bg-slate-600' },
  promptBuilder:  { bg: 'bg-indigo-950', border: 'border-indigo-600', icon: 'text-indigo-300', badge: 'bg-indigo-700' },
  imageGeneration:{ bg: 'bg-violet-950', border: 'border-violet-600', icon: 'text-violet-300', badge: 'bg-violet-700' },
  imageEdit:      { bg: 'bg-purple-950', border: 'border-purple-600', icon: 'text-purple-300', badge: 'bg-purple-700' },
  videoGeneration:{ bg: 'bg-pink-950', border: 'border-pink-600', icon: 'text-pink-300', badge: 'bg-pink-700' },
  referenceLock:  { bg: 'bg-amber-950', border: 'border-amber-600', icon: 'text-amber-300', badge: 'bg-amber-700' },
  exportNode:     { bg: 'bg-emerald-950', border: 'border-emerald-600', icon: 'text-emerald-300', badge: 'bg-emerald-700' },
  comment:        { bg: 'bg-yellow-950', border: 'border-yellow-600', icon: 'text-yellow-300', badge: 'bg-yellow-700' },
};

const NODE_ICONS: Record<NodeType, React.ElementType> = {
  scriptBeat: FileText,
  promptBuilder: Wand2,
  imageGeneration: Image,
  imageEdit: Layers,
  videoGeneration: Video,
  referenceLock: Lock,
  exportNode: Download,
  comment: MessageSquare,
};

const NODE_LABELS: Record<NodeType, string> = {
  scriptBeat: 'Script Beat',
  promptBuilder: 'Prompt Builder',
  imageGeneration: 'Image Gen',
  imageEdit: 'Image Edit',
  videoGeneration: 'Video Gen',
  referenceLock: 'Ref Lock',
  exportNode: 'Export',
  comment: 'Note',
};

const StatusBadge = ({ status, progress }: { status: string; progress?: number }) => {
  if (status === 'complete') return (
    <span className="flex items-center gap-1 text-emerald-400 text-xs">
      <CheckCircle size={10} /> Done
    </span>
  );
  if (status === 'generating') return (
    <span className="flex items-center gap-1 text-violet-400 text-xs">
      <Loader2 size={10} className="animate-spin" />
      {progress !== undefined ? `${Math.round(progress)}%` : 'Gen...'}
    </span>
  );
  if (status === 'queued') return (
    <span className="flex items-center gap-1 text-amber-400 text-xs">
      <Clock size={10} /> Queued
    </span>
  );
  if (status === 'error') return (
    <span className="flex items-center gap-1 text-red-400 text-xs">
      <AlertCircle size={10} /> Error
    </span>
  );
  return (
    <span className="flex items-center gap-1 text-slate-500 text-xs">
      <Clock size={10} /> Idle
    </span>
  );
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const StoryboardNodeComponent = memo(({ id, data: rawData, selected }: NodeProps & { data?: any }) => {
  const data = rawData as StoryboardNodeData;
  const {
    setSelectedNodeId,
    updateNodeData,
    deleteNode,
    duplicateNode,
    forkNode,
    startGeneration,
    setLightboxAsset,
    jobQueue,
  } = useStoryboardStore();

  const colors = NODE_COLORS[data.nodeType] || NODE_COLORS.comment;
  const Icon = NODE_ICONS[data.nodeType] || MessageSquare;
  const typeLabel = NODE_LABELS[data.nodeType] || 'Node';

  const activeJob = jobQueue.find((j) => j.nodeId === id && (j.status === 'generating' || j.status === 'queued'));
  const progress = activeJob?.progress;

  const handleSelect = useCallback(() => {
    setSelectedNodeId(id);
  }, [id, setSelectedNodeId]);

  const handleGenerate = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    startGeneration(id);
  }, [id, startGeneration]);

  const handleToggleCollapse = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    updateNodeData(id, { isCollapsed: !data.isCollapsed });
  }, [id, data.isCollapsed, updateNodeData]);

  const handleViewAsset = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (data.currentAsset) setLightboxAsset(data.currentAsset);
  }, [data.currentAsset, setLightboxAsset]);

  const isGeneratable = ['imageGeneration', 'imageEdit', 'videoGeneration'].includes(data.nodeType);
  const hasHandles = !['comment'].includes(data.nodeType);

  return (
    <div
      onClick={handleSelect}
      className={`
        relative min-w-[220px] max-w-[280px] rounded-xl border-2 overflow-hidden
        ${colors.bg} ${selected ? 'border-white shadow-[0_0_20px_rgba(255,255,255,0.15)]' : colors.border}
        cursor-pointer transition-all duration-150 group
        ${data.isLocked ? 'opacity-80' : ''}
      `}
    >
      {/* Input handle */}
      {hasHandles && (
        <Handle
          type="target"
          position={Position.Left}
          className="!w-3 !h-3 !bg-slate-400 !border-2 !border-slate-600 hover:!bg-white transition-colors"
        />
      )}

      {/* Header */}
      <div className={`flex items-center justify-between px-3 py-2 ${colors.badge} bg-opacity-60`}>
        <div className="flex items-center gap-2 min-w-0">
          <Icon size={13} className={colors.icon} />
          <span className={`text-[10px] font-semibold uppercase tracking-wider ${colors.icon} opacity-80`}>
            {typeLabel}
          </span>
          {data.isLocked && <Lock size={9} className="text-amber-400" />}
        </div>
        <div className="flex items-center gap-1">
          <StatusBadge status={data.status} progress={progress} />
          <button
            onClick={handleToggleCollapse}
            className="p-0.5 rounded hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            {data.isCollapsed ? <ChevronDown size={12} /> : <ChevronUp size={12} />}
          </button>
        </div>
      </div>

      {/* Node body */}
      {!data.isCollapsed && (
        <>
          {/* Label */}
          <div className="px-3 pt-2 pb-1">
            <p className="text-white text-sm font-medium leading-tight truncate">{data.label}</p>
            {data.tags.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-1">
                {data.tags.slice(0, 2).map((tag) => (
                  <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded-full bg-white/10 text-slate-300">{tag}</span>
                ))}
              </div>
            )}
          </div>

          {/* Preview area */}
          {(data.nodeType === 'imageGeneration' || data.nodeType === 'imageEdit' || data.nodeType === 'videoGeneration') && (
            <div className="mx-3 mb-2 relative">
              {data.status === 'generating' && (
                <div className="h-28 bg-slate-900 rounded-lg flex flex-col items-center justify-center gap-2 border border-white/5">
                  <div className="w-full px-4">
                    <div className="h-1 bg-slate-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-violet-500 to-pink-500 rounded-full transition-all duration-300"
                        style={{ width: `${progress || 0}%` }}
                      />
                    </div>
                  </div>
                  <Loader2 size={20} className="animate-spin text-violet-400" />
                  <span className="text-xs text-slate-400">{Math.round(progress || 0)}% generating...</span>
                </div>
              )}
              {data.status === 'queued' && (
                <div className="h-28 bg-slate-900 rounded-lg flex flex-col items-center justify-center gap-2 border border-white/5">
                  <Clock size={20} className="text-amber-400" />
                  <span className="text-xs text-slate-400">In queue...</span>
                </div>
              )}
              {data.status === 'complete' && data.currentAsset && (
                <div className="relative rounded-lg overflow-hidden cursor-pointer group/img" onClick={handleViewAsset}>
                  <img
                    src={data.currentAsset.thumbnailUrl}
                    alt={data.label}
                    className="w-full h-28 object-cover"
                  />
                  {data.nodeType === 'videoGeneration' && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-8 h-8 rounded-full bg-black/60 flex items-center justify-center">
                        <Play size={14} className="text-white ml-0.5" />
                      </div>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/0 group-hover/img:bg-black/30 transition-all flex items-center justify-center opacity-0 group-hover/img:opacity-100">
                    <Eye size={16} className="text-white" />
                  </div>
                  {/* Drift indicator */}
                  {data.driftScore !== undefined && (
                    <div className={`absolute bottom-1 right-1 text-[9px] px-1.5 py-0.5 rounded-full font-medium ${data.driftScore > 0.2 ? 'bg-red-500/80 text-white' : 'bg-emerald-500/80 text-white'}`}>
                      {data.driftScore > 0.2 ? `⚠ ${Math.round(data.driftScore * 100)}% drift` : `✓ ${Math.round((1 - data.driftScore) * 100)}% match`}
                    </div>
                  )}
                </div>
              )}
              {(data.status === 'idle' || data.status === 'error') && (
                <div className="h-28 bg-slate-900 rounded-lg flex flex-col items-center justify-center gap-2 border border-dashed border-white/10">
                  {data.status === 'error'
                    ? <AlertCircle size={20} className="text-red-400" />
                    : <Image size={20} className="text-slate-600" />}
                  <span className="text-xs text-slate-500">
                    {data.status === 'error' ? 'Generation failed' : 'No output yet'}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Script beat text */}
          {(data.nodeType === 'scriptBeat' || data.nodeType === 'comment') && data.beatText && (
            <div className="mx-3 mb-2 p-2 bg-black/20 rounded-lg">
              <p className="text-xs text-slate-300 leading-relaxed line-clamp-3">{data.beatText}</p>
            </div>
          )}

          {/* Reference lock */}
          {data.nodeType === 'referenceLock' && (
            <div className="mx-3 mb-2 grid grid-cols-3 gap-1">
              {[1, 2, 3].map((i) => (
                <div key={i} className="aspect-square bg-slate-900 rounded border border-white/5 flex items-center justify-center">
                  {i <= 2 ? (
                    <img src={`https://picsum.photos/seed/ref${i}/60/60`} alt="" className="w-full h-full object-cover rounded" />
                  ) : (
                    <span className="text-slate-600 text-xs">+</span>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Prompt preview */}
          {data.nodeType === 'promptBuilder' && (
            <div className="mx-3 mb-2 p-2 bg-black/20 rounded-lg">
              <p className="text-[10px] text-indigo-300 font-mono leading-relaxed line-clamp-2">
                {[data.prompt.subject, data.prompt.action, data.prompt.environment, data.prompt.style].filter(Boolean).join(', ') || 'No prompt configured'}
              </p>
            </div>
          )}

          {/* Export node */}
          {data.nodeType === 'exportNode' && (
            <div className="mx-3 mb-2 p-2 bg-black/20 rounded-lg flex items-center gap-2">
              <Download size={14} className="text-emerald-400" />
              <span className="text-xs text-slate-300 uppercase font-medium">{data.exportFormat || 'PDF'}</span>
              <span className="text-[10px] text-slate-500 ml-auto">{data.exportSettings?.gridColumns}col grid</span>
            </div>
          )}

          {/* Duration badge */}
          {data.duration !== undefined && (
            <div className="mx-3 mb-2 flex items-center gap-2">
              <Film size={10} className="text-slate-500" />
              <span className="text-[10px] text-slate-500">{data.duration}s</span>
              {data.motionStrength !== undefined && (
                <>
                  <Zap size={10} className="text-pink-400" />
                  <span className="text-[10px] text-pink-400">{Math.round(data.motionStrength * 100)}% motion</span>
                </>
              )}
            </div>
          )}

          {/* Action bar */}
          <div className="px-3 pb-2 flex items-center gap-1 border-t border-white/5 pt-2 opacity-0 group-hover:opacity-100 transition-opacity">
            {isGeneratable && (data.status === 'idle' || data.status === 'error' || data.status === 'complete') && (
              <button
                onClick={handleGenerate}
                className="flex items-center gap-1 px-2 py-1 rounded text-[10px] bg-violet-600 hover:bg-violet-500 text-white transition-colors"
              >
                <Zap size={9} /> Generate
              </button>
            )}
            <button
              onClick={(e) => { e.stopPropagation(); duplicateNode(id); }}
              className="p-1 rounded hover:bg-white/10 text-slate-500 hover:text-white transition-colors"
              title="Duplicate"
            >
              <Copy size={11} />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); forkNode(id); }}
              className="p-1 rounded hover:bg-white/10 text-slate-500 hover:text-purple-300 transition-colors"
              title="Fork branch"
            >
              <GitBranch size={11} />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); deleteNode(id); }}
              className="p-1 rounded hover:bg-white/10 text-slate-500 hover:text-red-400 transition-colors ml-auto"
              title="Delete"
            >
              <Trash2 size={11} />
            </button>
          </div>
        </>
      )}

      {/* Output handle */}
      {hasHandles && (
        <Handle
          type="source"
          position={Position.Right}
          className="!w-3 !h-3 !bg-slate-400 !border-2 !border-slate-600 hover:!bg-white transition-colors"
        />
      )}

      {/* Comments indicator */}
      {data.comments && data.comments.length > 0 && (
        <div className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-blue-500 border-2 border-slate-900 flex items-center justify-center">
          <span className="text-[9px] text-white font-bold">{data.comments.length}</span>
        </div>
      )}

      {/* Frame index badge */}
      {data.frameIndex !== undefined && (
        <div className="absolute -top-2 -left-2 w-5 h-5 rounded-full bg-slate-600 border-2 border-slate-900 flex items-center justify-center">
          <span className="text-[9px] text-white font-bold">{data.frameIndex + 1}</span>
        </div>
      )}
    </div>
  );
});

StoryboardNodeComponent.displayName = 'StoryboardNode';
export default StoryboardNodeComponent;
