import React, { useEffect } from 'react';
import { X, Download, Share2, RotateCcw, ZoomIn, ZoomOut, Info } from 'lucide-react';
import { useStoryboardStore } from '../store/storyboardStore';

export const Lightbox: React.FC = () => {
  const { lightboxAsset, setLightboxAsset } = useStoryboardStore();

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setLightboxAsset(null);
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [setLightboxAsset]);

  if (!lightboxAsset) return null;

  const { metadata } = lightboxAsset;

  return (
    <div
      className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-sm flex items-center justify-center"
      onClick={() => setLightboxAsset(null)}
    >
      <div
        className="relative max-w-5xl max-h-[90vh] w-full mx-4 flex gap-4"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Main image */}
        <div className="flex-1 flex items-center justify-center rounded-2xl overflow-hidden bg-slate-900 border border-slate-700">
          <img
            src={lightboxAsset.url}
            alt="Generated asset"
            className="max-w-full max-h-[80vh] object-contain"
          />
        </div>

        {/* Info panel */}
        <div className="w-72 bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden flex flex-col">
          <div className="px-4 py-3 border-b border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Info size={14} className="text-slate-400" />
              <span className="text-sm font-medium text-white">Generation Info</span>
            </div>
            <button
              onClick={() => setLightboxAsset(null)}
              className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X size={14} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* Model info */}
            <div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider font-medium mb-2">Model</p>
              <div className="p-2 bg-slate-800 rounded-lg">
                <p className="text-xs text-white font-mono uppercase">{metadata.model}</p>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  {metadata.cached ? '⚡ Cached output' : 'Fresh generation'}
                </p>
              </div>
            </div>

            {/* Seed */}
            <div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider font-medium mb-2">Seed</p>
              <div className="flex items-center gap-2 p-2 bg-slate-800 rounded-lg">
                <span className="text-xs text-white font-mono">{metadata.seed}</span>
                <button className="ml-auto p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors" title="Lock seed">
                  <RotateCcw size={10} />
                </button>
              </div>
            </div>

            {/* Dimensions */}
            <div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider font-medium mb-2">Dimensions</p>
              <p className="text-xs text-white font-mono">{lightboxAsset.width} × {lightboxAsset.height}</p>
            </div>

            {/* Stats */}
            <div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider font-medium mb-2">Stats</p>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Latency</span>
                  <span className="text-white font-mono">{(metadata.latencyMs / 1000).toFixed(1)}s</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Cost</span>
                  <span className="text-white font-mono">{metadata.costCredits} credits</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Prompt v</span>
                  <span className="text-white font-mono">{metadata.promptVersion}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Hash</span>
                  <span className="text-white font-mono">{lightboxAsset.promptHash}</span>
                </div>
              </div>
            </div>

            {/* Timestamp */}
            <div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider font-medium mb-1">Generated</p>
              <p className="text-xs text-slate-400">{new Date(metadata.timestamp).toLocaleString()}</p>
            </div>
          </div>

          {/* Actions */}
          <div className="border-t border-slate-700 p-4 flex gap-2">
            <button className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors">
              <Download size={12} /> Download
            </button>
            <button className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors">
              <Share2 size={12} /> Share
            </button>
          </div>
        </div>
      </div>

      {/* Zoom controls */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-slate-900/90 border border-slate-700 rounded-full px-4 py-2">
        <button className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
          <ZoomOut size={13} />
        </button>
        <span className="text-xs text-slate-400 w-10 text-center">100%</span>
        <button className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
          <ZoomIn size={13} />
        </button>
      </div>
    </div>
  );
};
