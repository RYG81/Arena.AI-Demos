import React from 'react';
import { useStoryboardStore } from '../store/storyboardStore';
import { PromptInspector } from './panels/PromptInspector';
import { VersionHistory } from './panels/VersionHistory';
import { JobQueue } from './panels/JobQueue';
import { ReferenceManager } from './panels/ReferenceManager';
import { Timeline } from './panels/Timeline';
import { Collaboration } from './panels/Collaboration';

const PANEL_ORDER = ['promptInspector', 'versionHistory', 'timeline', 'referenceManager', 'jobQueue', 'collaboration'] as const;

const PANEL_COMPONENTS: Record<string, React.FC> = {
  promptInspector: PromptInspector,
  versionHistory: VersionHistory,
  jobQueue: JobQueue,
  referenceManager: ReferenceManager,
  timeline: Timeline,
  collaboration: Collaboration,
};

export const RightSidebar: React.FC = () => {
  const { openPanels } = useStoryboardStore();

  const visiblePanels = PANEL_ORDER.filter((p) => openPanels.includes(p));

  if (visiblePanels.length === 0) return null;

  // Show only the first open panel (to avoid overflow), or stack them
  const activePanel = visiblePanels[0];
  const PanelComponent = PANEL_COMPONENTS[activePanel];

  return (
    <div className="absolute right-0 top-[53px] bottom-0 z-40 w-80 flex flex-col shadow-2xl">
      {/* Panel tabs when multiple are open */}
      {visiblePanels.length > 1 && (
        <div className="flex overflow-x-auto bg-slate-900 border-b border-slate-700 shrink-0">
      {visiblePanels.map((panel) => (
        <div key={panel} />
      ))}
        </div>
      )}
      {PanelComponent && (
        <div className="flex-1 overflow-hidden">
          <PanelComponent />
        </div>
      )}
    </div>
  );
};

// Multi-panel sidebar that stacks panels vertically
export const MultiPanelSidebar: React.FC = () => {
  const { openPanels } = useStoryboardStore();
  const visiblePanels = PANEL_ORDER.filter((p) => openPanels.includes(p));

  if (visiblePanels.length === 0) return null;

  return (
    <div className="absolute right-0 top-[53px] bottom-0 z-40 w-[320px] flex flex-col bg-slate-900 border-l border-slate-700 shadow-2xl overflow-hidden">
      {visiblePanels.map((panel, i) => {
        const Component = PANEL_COMPONENTS[panel];
        if (!Component) return null;
        const height = `${100 / visiblePanels.length}%`;
        return (
          <div
            key={panel}
            className={`flex flex-col overflow-hidden ${i > 0 ? 'border-t border-slate-700' : ''}`}
            style={{ height }}
          >
            <Component />
          </div>
        );
      })}
    </div>
  );
};
