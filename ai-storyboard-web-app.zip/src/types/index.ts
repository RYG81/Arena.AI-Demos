export type NodeType =
  | 'scriptBeat'
  | 'promptBuilder'
  | 'imageGeneration'
  | 'imageEdit'
  | 'videoGeneration'
  | 'referenceLock'
  | 'exportNode'
  | 'comment';

export type GenerationStatus = 'idle' | 'queued' | 'generating' | 'complete' | 'error';
export type ModelType = 'flux' | 'klein-9b' | 'qwen-image' | 'stable-diffusion';
export type QualityTier = 'draft' | 'standard' | 'high';
export type UserRole = 'owner' | 'editor' | 'commenter' | 'viewer';

export interface PromptStructure {
  subject: string;
  action: string;
  environment: string;
  camera: string;
  lighting: string;
  style: string;
  aspectRatio: '16:9' | '4:3' | '1:1' | '9:16' | '2.35:1';
  negativePrompt: string;
  useNegative: boolean;
  weights: Record<string, number>;
  styleTokens: string[];
}

export interface GenerationMetadata {
  model: ModelType;
  seed: number;
  promptVersion: string;
  latencyMs: number;
  costCredits: number;
  timestamp: number;
  cached: boolean;
}

export interface GeneratedAsset {
  id: string;
  nodeId: string;
  url: string;
  thumbnailUrl: string;
  type: 'image' | 'video';
  width: number;
  height: number;
  metadata: GenerationMetadata;
  promptHash: string;
  versionIndex: number;
}

export interface NodeVersion {
  id: string;
  timestamp: number;
  prompt: PromptStructure;
  seed: number;
  outputAsset?: GeneratedAsset;
  label: string;
  notes: string;
}

export interface Comment {
  id: string;
  nodeId: string;
  author: string;
  avatar: string;
  text: string;
  timestamp: number;
  resolved: boolean;
  replies: Comment[];
}

export interface StoryboardNodeData {
  nodeType: NodeType;
  label: string;
  prompt: PromptStructure;
  status: GenerationStatus;
  currentAsset?: GeneratedAsset;
  versions: NodeVersion[];
  currentVersionIndex: number;
  referenceImages: string[];
  beatText?: string;
  scriptText?: string;
  duration?: number;
  motionStrength?: number;
  cameraPath?: CameraPath;
  isLocked: boolean;
  isCollapsed: boolean;
  driftScore?: number;
  comments: Comment[];
  tags: string[];
  qualityTier: QualityTier;
  model: ModelType;
  frameIndex?: number;
  notes: string;
  exportFormat?: 'pdf' | 'json' | 'mp4';
  exportSettings?: ExportSettings;
}

export interface CameraPath {
  pan: number;
  tilt: number;
  dolly: number;
  zoom: number;
  focusRack: boolean;
}

export interface ExportSettings {
  format: 'pdf' | 'json' | 'mp4';
  gridColumns: number;
  includeNotes: boolean;
  includeTimecodes: boolean;
  includeThumbnails: boolean;
  fps?: number;
  resolution?: '720p' | '1080p' | '4k';
}

export interface TimelinePanel {
  nodeId: string;
  startTime: number;
  duration: number;
  transition: 'cut' | 'fade' | 'dissolve' | 'wipe';
  label: string;
}

export interface ProjectVersion {
  id: string;
  timestamp: number;
  label: string;
  snapshot: string;
  author: string;
  changes: string[];
}

export interface Collaborator {
  id: string;
  name: string;
  avatar: string;
  role: UserRole;
  color: string;
  cursorPosition?: { x: number; y: number };
  activeNodeId?: string;
  isOnline: boolean;
  lastSeen: number;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  createdAt: number;
  updatedAt: number;
  author: string;
  collaborators: Collaborator[];
  tags: string[];
  isPublic: boolean;
  versions: ProjectVersion[];
  currentVersionIndex: number;
  settings: ProjectSettings;
}

export interface ProjectSettings {
  defaultModel: ModelType;
  defaultQuality: QualityTier;
  defaultAspectRatio: '16:9' | '4:3' | '1:1' | '9:16' | '2.35:1';
  autoSave: boolean;
  autoSaveInterval: number;
  gridSnapping: boolean;
  gridSize: number;
  showMinimap: boolean;
  collaborationEnabled: boolean;
}

export interface JobQueueItem {
  id: string;
  nodeId: string;
  type: 'image' | 'video';
  status: GenerationStatus;
  progress: number;
  model: ModelType;
  prompt: string;
  seed: number;
  startedAt?: number;
  completedAt?: number;
  error?: string;
  retryCount: number;
}

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info' | 'generation';
  title: string;
  message: string;
  timestamp: number;
  read: boolean;
  nodeId?: string;
  actionLabel?: string;
  action?: () => void;
}

export interface ReferenceImage {
  id: string;
  url: string;
  thumbnailUrl: string;
  name: string;
  tags: string[];
  scope: 'project' | 'node';
  nodeId?: string;
  type: 'character' | 'style' | 'location' | 'prop' | 'reference';
  embedding?: number[];
  uploadedAt: number;
}

export interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  prompt: Partial<PromptStructure>;
  tags: string[];
  isPublic: boolean;
  author: string;
  usageCount: number;
  createdAt: number;
}

export type PanelType =
  | 'promptInspector'
  | 'versionHistory'
  | 'timeline'
  | 'referenceManager'
  | 'jobQueue'
  | 'collaboration'
  | 'notifications'
  | 'nodeLibrary'
  | 'export'
  | 'settings';
