import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import {
  addEdge,
  applyNodeChanges,
  applyEdgeChanges,
  type Node,
  type Edge,
  type NodeChange,
  type EdgeChange,
  type Connection,
} from '@xyflow/react';
import { v4 as uuidv4 } from 'uuid';
import type {
  StoryboardNodeData,
  NodeType,
  PanelType,
  Project,
  JobQueueItem,
  Notification,
  ReferenceImage,
  PromptTemplate,
  TimelinePanel,
  ProjectVersion,
  GeneratedAsset,
  GenerationMetadata,
  Collaborator,
  PromptStructure,
} from '../types';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type StoryboardNode = Node<any>;
export type StoryboardEdge = Edge;

const PLACEHOLDER_IMAGES = [
  'https://picsum.photos/seed/node1/400/300',
  'https://picsum.photos/seed/node2/400/300',
  'https://picsum.photos/seed/node3/400/300',
  'https://picsum.photos/seed/node4/400/300',
  'https://picsum.photos/seed/node5/400/300',
  'https://picsum.photos/seed/node6/400/300',
];

const defaultPrompt = (): PromptStructure => ({
  subject: '',
  action: '',
  environment: '',
  camera: 'medium shot',
  lighting: 'natural light',
  style: 'cinematic',
  aspectRatio: '16:9',
  negativePrompt: 'blurry, low quality, distorted',
  useNegative: true,
  weights: { subject: 1.0, style: 0.8, lighting: 0.7 },
  styleTokens: [],
});

const createNodeData = (type: NodeType, label: string, index: number): StoryboardNodeData => ({
  nodeType: type,
  label,
  prompt: defaultPrompt(),
  status: index < 3 ? 'complete' : index < 5 ? 'generating' : 'idle',
  currentAsset: index < 3 ? {
    id: uuidv4(),
    nodeId: '',
    url: PLACEHOLDER_IMAGES[index % PLACEHOLDER_IMAGES.length],
    thumbnailUrl: PLACEHOLDER_IMAGES[index % PLACEHOLDER_IMAGES.length],
    type: 'image',
    width: 400,
    height: 300,
    metadata: {
      model: 'flux',
      seed: Math.floor(Math.random() * 999999),
      promptVersion: 'v1',
      latencyMs: 1200 + Math.random() * 3000,
      costCredits: 0.5,
      timestamp: Date.now() - Math.random() * 86400000,
      cached: false,
    } as GenerationMetadata,
    promptHash: uuidv4().slice(0, 8),
    versionIndex: 0,
  } : undefined,
  versions: [],
  currentVersionIndex: 0,
  referenceImages: [],
  isLocked: false,
  isCollapsed: false,
  driftScore: index < 3 ? Math.random() : undefined,
  comments: [],
  tags: [],
  qualityTier: 'standard',
  model: 'flux',
  notes: '',
  beatText: type === 'scriptBeat' ? `Beat ${index + 1}: Character enters the scene` : undefined,
  duration: 3,
  frameIndex: index,
});

const initialNodes: StoryboardNode[] = [
  {
    id: 'node-1',
    type: 'storyboardNode',
    position: { x: 80, y: 120 },
    data: { ...createNodeData('scriptBeat', 'Opening Beat', 0), beatText: 'EXT. CITY ROOFTOP - DAWN\nHero stands overlooking the awakening city, cape billowing in the wind.' },
  },
  {
    id: 'node-2',
    type: 'storyboardNode',
    position: { x: 420, y: 60 },
    data: { ...createNodeData('promptBuilder', 'Scene Setup', 1), label: 'Scene Setup' },
  },
  {
    id: 'node-3',
    type: 'storyboardNode',
    position: { x: 760, y: 120 },
    data: { ...createNodeData('imageGeneration', 'Hero Wide Shot', 2), label: 'Hero Wide Shot', prompt: { ...defaultPrompt(), subject: 'Superhero in costume', action: 'standing on rooftop', environment: 'city skyline at dawn', camera: 'wide shot, low angle', lighting: 'golden hour backlit' } },
  },
  {
    id: 'node-4',
    type: 'storyboardNode',
    position: { x: 1100, y: 60 },
    data: { ...createNodeData('imageGeneration', 'Close-up Face', 3), label: 'Close-up Face', prompt: { ...defaultPrompt(), subject: 'Hero face', action: 'looking determined', camera: 'extreme close-up', lighting: 'dramatic side light' } },
  },
  {
    id: 'node-5',
    type: 'storyboardNode',
    position: { x: 1100, y: 280 },
    data: { ...createNodeData('videoGeneration', 'Cape Billowing', 4), label: 'Cape Billowing', motionStrength: 0.7 },
  },
  {
    id: 'node-6',
    type: 'storyboardNode',
    position: { x: 760, y: 360 },
    data: { ...createNodeData('referenceLock', 'Character Lock', 5), label: 'Character Ref Lock' },
  },
  {
    id: 'node-7',
    type: 'storyboardNode',
    position: { x: 420, y: 320 },
    data: { ...createNodeData('comment', 'Director Notes', 6), label: 'Director Notes', beatText: '⚡ Make sure the lighting matches the mood of the opening act. Hero should feel imposing but vulnerable.' },
  },
  {
    id: 'node-8',
    type: 'storyboardNode',
    position: { x: 1440, y: 160 },
    data: { ...createNodeData('exportNode', 'PDF Export', 7), label: 'PDF Export', exportFormat: 'pdf', exportSettings: { format: 'pdf', gridColumns: 3, includeNotes: true, includeTimecodes: true, includeThumbnails: true } },
  },
];

const initialEdges: StoryboardEdge[] = [
  { id: 'e1-2', source: 'node-1', target: 'node-2', type: 'smoothstep', animated: false },
  { id: 'e2-3', source: 'node-2', target: 'node-3', type: 'smoothstep', animated: false },
  { id: 'e3-4', source: 'node-3', target: 'node-4', type: 'smoothstep', animated: true },
  { id: 'e3-5', source: 'node-3', target: 'node-5', type: 'smoothstep', animated: true },
  { id: 'e6-3', source: 'node-6', target: 'node-3', type: 'smoothstep', animated: false },
  { id: 'e4-8', source: 'node-4', target: 'node-8', type: 'smoothstep', animated: false },
  { id: 'e5-8', source: 'node-5', target: 'node-8', type: 'smoothstep', animated: false },
];

const initialTimelinePanels: TimelinePanel[] = [
  { nodeId: 'node-1', startTime: 0, duration: 3, transition: 'cut', label: 'Opening Beat' },
  { nodeId: 'node-3', startTime: 3, duration: 4, transition: 'fade', label: 'Hero Wide Shot' },
  { nodeId: 'node-4', startTime: 7, duration: 2.5, transition: 'cut', label: 'Close-up Face' },
  { nodeId: 'node-5', startTime: 9.5, duration: 3, transition: 'dissolve', label: 'Cape Billowing' },
];

const initialCollaborators: Collaborator[] = [
  { id: 'user-1', name: 'Alex Chen', avatar: 'AC', role: 'owner', color: '#6366f1', isOnline: true, lastSeen: Date.now() },
  { id: 'user-2', name: 'Maya Patel', avatar: 'MP', role: 'editor', color: '#10b981', isOnline: true, lastSeen: Date.now() - 30000 },
  { id: 'user-3', name: 'Jordan Kim', avatar: 'JK', role: 'commenter', color: '#f59e0b', isOnline: false, lastSeen: Date.now() - 3600000 },
];

const initialTemplates: PromptTemplate[] = [
  { id: 't1', name: 'Cinematic Hero Shot', description: 'Epic wide shot for action sequences', prompt: { camera: 'wide shot, low angle', lighting: 'dramatic golden hour', style: 'cinematic, epic' }, tags: ['action', 'hero'], isPublic: true, author: 'Alex Chen', usageCount: 234, createdAt: Date.now() - 86400000 * 30 },
  { id: 't2', name: 'Intimate Close-Up', description: 'Emotional character moment', prompt: { camera: 'extreme close-up', lighting: 'soft natural light', style: 'intimate, emotional' }, tags: ['drama', 'character'], isPublic: true, author: 'Maya Patel', usageCount: 189, createdAt: Date.now() - 86400000 * 20 },
  { id: 't3', name: 'Noir Atmosphere', description: 'Dark, high-contrast noir aesthetic', prompt: { lighting: 'high contrast, shadows, venetian blind shadows', style: 'film noir, black and white, moody' }, tags: ['noir', 'dark'], isPublic: true, author: 'Jordan Kim', usageCount: 97, createdAt: Date.now() - 86400000 * 10 },
];

const initialRefImages: ReferenceImage[] = [
  { id: 'ref-1', url: 'https://picsum.photos/seed/ref1/200/200', thumbnailUrl: 'https://picsum.photos/seed/ref1/100/100', name: 'Hero Character Ref', tags: ['character', 'hero', 'costume'], scope: 'project', type: 'character', uploadedAt: Date.now() - 86400000 },
  { id: 'ref-2', url: 'https://picsum.photos/seed/ref2/200/200', thumbnailUrl: 'https://picsum.photos/seed/ref2/100/100', name: 'City Skyline', tags: ['location', 'city', 'urban'], scope: 'project', type: 'location', uploadedAt: Date.now() - 72000000 },
  { id: 'ref-3', url: 'https://picsum.photos/seed/ref3/200/200', thumbnailUrl: 'https://picsum.photos/seed/ref3/100/100', name: 'Cinematic Style Guide', tags: ['style', 'mood', 'aesthetic'], scope: 'project', type: 'style', uploadedAt: Date.now() - 36000000 },
];

interface StoryboardState {
  // Flow
  nodes: StoryboardNode[];
  edges: StoryboardEdge[];
  onNodesChange: (changes: NodeChange[]) => void;
  onEdgesChange: (changes: EdgeChange[]) => void;
  onConnect: (connection: Connection) => void;

  // Selected
  selectedNodeId: string | null;
  setSelectedNodeId: (id: string | null) => void;

  // Panels
  openPanels: PanelType[];
  togglePanel: (panel: PanelType) => void;
  closePanel: (panel: PanelType) => void;

  // Lightbox
  lightboxAsset: GeneratedAsset | null;
  setLightboxAsset: (asset: GeneratedAsset | null) => void;

  // Project
  project: Project;
  updateProject: (updates: Partial<Project>) => void;

  // Nodes
  addNode: (type: NodeType, position: { x: number; y: number }) => void;
  updateNodeData: (nodeId: string, updates: Partial<StoryboardNodeData>) => void;
  deleteNode: (nodeId: string) => void;
  duplicateNode: (nodeId: string) => void;
  forkNode: (nodeId: string) => void;

  // Generation
  jobQueue: JobQueueItem[];
  startGeneration: (nodeId: string) => void;
  cancelJob: (jobId: string) => void;

  // Notifications
  notifications: Notification[];
  addNotification: (n: Omit<Notification, 'id' | 'timestamp' | 'read'>) => void;
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;

  // References
  referenceImages: ReferenceImage[];
  addReferenceImage: (ref: Omit<ReferenceImage, 'id' | 'uploadedAt'>) => void;
  removeReferenceImage: (id: string) => void;

  // Templates
  promptTemplates: PromptTemplate[];
  saveTemplate: (template: Omit<PromptTemplate, 'id' | 'createdAt' | 'usageCount'>) => void;

  // Timeline
  timelinePanels: TimelinePanel[];
  updateTimelinePanel: (nodeId: string, updates: Partial<TimelinePanel>) => void;
  reorderTimeline: (panels: TimelinePanel[]) => void;

  // Collaborators
  collaborators: Collaborator[];

  // Version history
  saveVersion: (label: string) => void;

  // UI state
  activeTab: string;
  setActiveTab: (tab: string) => void;
  showGrid: boolean;
  toggleGrid: () => void;
  showMinimap: boolean;
  toggleMinimap: () => void;
  isSaving: boolean;
  lastSaved: number;

  // Undo/redo
  undoHistory: string[];
  redoHistory: string[];
  undo: () => void;
  redo: () => void;
  pushUndoSnapshot: () => void;
}

let generationTimers: Record<string, ReturnType<typeof setInterval>> = {};

export const useStoryboardStore = create<StoryboardState>()(
  subscribeWithSelector((set, get) => ({
    nodes: initialNodes,
    edges: initialEdges,
    selectedNodeId: null,
    openPanels: ['promptInspector'],
    lightboxAsset: null,
    jobQueue: [],
    notifications: [
      { id: 'n1', type: 'success', title: 'Generation Complete', message: 'Hero Wide Shot rendered in 2.3s', timestamp: Date.now() - 60000, read: false, nodeId: 'node-3' },
      { id: 'n2', type: 'info', title: 'Maya Patel joined', message: 'Maya is now viewing the project', timestamp: Date.now() - 120000, read: true },
      { id: 'n3', type: 'warning', title: 'Drift Detected', message: 'Close-up Face drifted 18% from character ref', timestamp: Date.now() - 300000, read: false, nodeId: 'node-4' },
    ],
    referenceImages: initialRefImages,
    promptTemplates: initialTemplates,
    timelinePanels: initialTimelinePanels,
    collaborators: initialCollaborators,
    activeTab: 'canvas',
    showGrid: true,
    showMinimap: true,
    isSaving: false,
    lastSaved: Date.now() - 120000,
    undoHistory: [],
    redoHistory: [],

    project: {
      id: 'proj-1',
      name: 'The Last Horizon',
      description: 'A cinematic sci-fi storyboard for the opening sequence of an action film.',
      createdAt: Date.now() - 86400000 * 7,
      updatedAt: Date.now() - 3600000,
      author: 'Alex Chen',
      collaborators: initialCollaborators,
      tags: ['sci-fi', 'action', 'cinematic'],
      isPublic: false,
      versions: [
        { id: 'v1', timestamp: Date.now() - 86400000 * 7, label: 'Initial Draft', snapshot: '{}', author: 'Alex Chen', changes: ['Created project', 'Added 4 nodes'] },
        { id: 'v2', timestamp: Date.now() - 86400000 * 3, label: 'Act 1 Complete', snapshot: '{}', author: 'Alex Chen', changes: ['Added character refs', 'Generated 3 panels', 'Added video node'] },
        { id: 'v3', timestamp: Date.now() - 86400000, label: 'Director Review', snapshot: '{}', author: 'Maya Patel', changes: ['Adjusted lighting prompts', 'Added director notes', 'Updated timeline'] },
      ],
      currentVersionIndex: 2,
      settings: {
        defaultModel: 'flux',
        defaultQuality: 'standard',
        defaultAspectRatio: '16:9',
        autoSave: true,
        autoSaveInterval: 30000,
        gridSnapping: true,
        gridSize: 20,
        showMinimap: true,
        collaborationEnabled: true,
      },
    },

    onNodesChange: (changes) =>
      set((state) => ({ nodes: applyNodeChanges(changes, state.nodes) as StoryboardNode[] })),

    onEdgesChange: (changes) =>
      set((state) => ({ edges: applyEdgeChanges(changes, state.edges) })),

    onConnect: (connection) =>
      set((state) => ({ edges: addEdge({ ...connection, type: 'smoothstep' }, state.edges) })),

    setSelectedNodeId: (id) => set({ selectedNodeId: id }),

    togglePanel: (panel) =>
      set((state) => ({
        openPanels: state.openPanels.includes(panel)
          ? state.openPanels.filter((p) => p !== panel)
          : [...state.openPanels, panel],
      })),

    closePanel: (panel) =>
      set((state) => ({ openPanels: state.openPanels.filter((p) => p !== panel) })),

    setLightboxAsset: (asset) => set({ lightboxAsset: asset }),

    updateProject: (updates) =>
      set((state) => ({ project: { ...state.project, ...updates } })),

    addNode: (type, position) => {
      const id = `node-${uuidv4().slice(0, 8)}`;
      const labels: Record<NodeType, string> = {
        scriptBeat: 'New Beat',
        promptBuilder: 'New Prompt',
        imageGeneration: 'New Image',
        imageEdit: 'Image Edit',
        videoGeneration: 'New Video',
        referenceLock: 'Reference Lock',
        exportNode: 'Export',
        comment: 'Note',
      };
      const newNode: StoryboardNode = {
        id,
        type: 'storyboardNode',
        position,
        data: createNodeData(type, labels[type], get().nodes.length),
      };
      set((state) => ({
        nodes: [...state.nodes, newNode],
        selectedNodeId: id,
      }));
      get().pushUndoSnapshot();
    },

    updateNodeData: (nodeId, updates) => {
      set((state) => ({
        nodes: state.nodes.map((n) =>
          n.id === nodeId ? { ...n, data: { ...n.data, ...updates } } : n
        ),
      }));
    },

    deleteNode: (nodeId) => {
      get().pushUndoSnapshot();
      set((state) => ({
        nodes: state.nodes.filter((n) => n.id !== nodeId),
        edges: state.edges.filter((e) => e.source !== nodeId && e.target !== nodeId),
        selectedNodeId: state.selectedNodeId === nodeId ? null : state.selectedNodeId,
      }));
    },

    duplicateNode: (nodeId) => {
      const node = get().nodes.find((n) => n.id === nodeId);
      if (!node) return;
      const newId = `node-${uuidv4().slice(0, 8)}`;
      const newNode: StoryboardNode = {
        ...node,
        id: newId,
        position: { x: node.position.x + 40, y: node.position.y + 40 },
        data: { ...node.data, label: `${node.data.label} (Copy)` },
      };
      set((state) => ({ nodes: [...state.nodes, newNode], selectedNodeId: newId }));
    },

    forkNode: (nodeId) => {
      const node = get().nodes.find((n) => n.id === nodeId);
      if (!node) return;
      const newId = `node-${uuidv4().slice(0, 8)}`;
      const newNode: StoryboardNode = {
        ...node,
        id: newId,
        position: { x: node.position.x, y: node.position.y + 200 },
        data: { ...node.data, label: `${node.data.label} [Fork]`, status: 'idle', currentAsset: undefined },
      };
      const newEdge: StoryboardEdge = {
        id: `e-fork-${nodeId}-${newId}`,
        source: nodeId,
        target: newId,
        type: 'smoothstep',
        style: { stroke: '#a855f7', strokeDasharray: '5,5' },
      };
      set((state) => ({
        nodes: [...state.nodes, newNode],
        edges: [...state.edges, newEdge],
        selectedNodeId: newId,
      }));
      get().addNotification({ type: 'info', title: 'Node Forked', message: `Created alternate branch from "${node.data.label}"` });
    },

    startGeneration: (nodeId) => {
      const jobId = uuidv4();
      const node = get().nodes.find((n) => n.id === nodeId);
      if (!node) return;

      const job: JobQueueItem = {
        id: jobId,
        nodeId,
        type: node.data.nodeType === 'videoGeneration' ? 'video' : 'image',
        status: 'queued',
        progress: 0,
        model: node.data.model,
        prompt: node.data.prompt.subject || 'cinematic scene',
        seed: Math.floor(Math.random() * 999999),
        retryCount: 0,
        startedAt: Date.now(),
      };

      set((state) => ({
        jobQueue: [...state.jobQueue, job],
        nodes: state.nodes.map((n) =>
          n.id === nodeId ? { ...n, data: { ...n.data, status: 'queued' } } : n
        ),
      }));

      // Simulate generation progress
      let progress = 0;
      generationTimers[jobId] = setInterval(() => {
        progress += Math.random() * 15 + 5;
        if (progress >= 100) {
          progress = 100;
          clearInterval(generationTimers[jobId]);
          delete generationTimers[jobId];

          const imgIndex = Math.floor(Math.random() * PLACEHOLDER_IMAGES.length);
          const asset: GeneratedAsset = {
            id: uuidv4(),
            nodeId,
            url: PLACEHOLDER_IMAGES[imgIndex],
            thumbnailUrl: PLACEHOLDER_IMAGES[imgIndex],
            type: node.data.nodeType === 'videoGeneration' ? 'video' : 'image',
            width: 400,
            height: 300,
            metadata: {
              model: node.data.model,
              seed: job.seed,
              promptVersion: 'v1',
              latencyMs: Date.now() - (job.startedAt || Date.now()),
              costCredits: 0.5,
              timestamp: Date.now(),
              cached: false,
            },
            promptHash: uuidv4().slice(0, 8),
            versionIndex: 0,
          };

          set((state) => ({
            jobQueue: state.jobQueue.map((j) =>
              j.id === jobId ? { ...j, status: 'complete', progress: 100, completedAt: Date.now() } : j
            ),
            nodes: state.nodes.map((n) =>
              n.id === nodeId
                ? { ...n, data: { ...n.data, status: 'complete', currentAsset: asset, driftScore: Math.random() * 0.3 } }
                : n
            ),
          }));

          get().addNotification({
            type: 'success',
            title: 'Generation Complete',
            message: `"${node.data.label}" rendered successfully`,
            nodeId,
          });
        } else {
          set((state) => ({
            jobQueue: state.jobQueue.map((j) =>
              j.id === jobId ? { ...j, status: 'generating', progress } : j
            ),
            nodes: state.nodes.map((n) =>
              n.id === nodeId ? { ...n, data: { ...n.data, status: 'generating' } } : n
            ),
          }));
        }
      }, 300);
    },

    cancelJob: (jobId) => {
      if (generationTimers[jobId]) {
        clearInterval(generationTimers[jobId]);
        delete generationTimers[jobId];
      }
      set((state) => {
        const job = state.jobQueue.find((j) => j.id === jobId);
        return {
          jobQueue: state.jobQueue.filter((j) => j.id !== jobId),
          nodes: state.nodes.map((n) =>
            n.id === job?.nodeId ? { ...n, data: { ...n.data, status: 'idle' } } : n
          ),
        };
      });
    },

    addNotification: (n) => {
      const notification: Notification = {
        ...n,
        id: uuidv4(),
        timestamp: Date.now(),
        read: false,
      };
      set((state) => ({
        notifications: [notification, ...state.notifications].slice(0, 50),
      }));
    },

    markNotificationRead: (id) =>
      set((state) => ({
        notifications: state.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)),
      })),

    clearNotifications: () =>
      set((state) => ({ notifications: state.notifications.map((n) => ({ ...n, read: true })) })),

    addReferenceImage: (ref) => {
      const newRef: ReferenceImage = { ...ref, id: uuidv4(), uploadedAt: Date.now() };
      set((state) => ({ referenceImages: [...state.referenceImages, newRef] }));
    },

    removeReferenceImage: (id) =>
      set((state) => ({ referenceImages: state.referenceImages.filter((r) => r.id !== id) })),

    saveTemplate: (template) => {
      const newTemplate: PromptTemplate = { ...template, id: uuidv4(), createdAt: Date.now(), usageCount: 0 };
      set((state) => ({ promptTemplates: [...state.promptTemplates, newTemplate] }));
    },

    updateTimelinePanel: (nodeId, updates) =>
      set((state) => ({
        timelinePanels: state.timelinePanels.map((p) =>
          p.nodeId === nodeId ? { ...p, ...updates } : p
        ),
      })),

    reorderTimeline: (panels) => set({ timelinePanels: panels }),

    saveVersion: (label) => {
      const version: ProjectVersion = {
        id: uuidv4(),
        timestamp: Date.now(),
        label,
        snapshot: JSON.stringify({ nodes: get().nodes, edges: get().edges }),
        author: 'Alex Chen',
        changes: ['Manual save'],
      };
      set((state) => ({
        project: {
          ...state.project,
          versions: [...state.project.versions, version],
          currentVersionIndex: state.project.versions.length,
        },
        isSaving: false,
        lastSaved: Date.now(),
      }));
      get().addNotification({ type: 'success', title: 'Version Saved', message: `"${label}" saved to history` });
    },

    setActiveTab: (tab) => set({ activeTab: tab }),
    toggleGrid: () => set((state) => ({ showGrid: !state.showGrid })),
    toggleMinimap: () => set((state) => ({ showMinimap: !state.showMinimap })),

    pushUndoSnapshot: () => {
      const snapshot = JSON.stringify({ nodes: get().nodes, edges: get().edges });
      set((state) => ({
        undoHistory: [...state.undoHistory.slice(-29), snapshot],
        redoHistory: [],
      }));
    },

    undo: () => {
      const { undoHistory, nodes, edges } = get();
      if (undoHistory.length === 0) return;
      const currentSnapshot = JSON.stringify({ nodes, edges });
      const prevSnapshot = undoHistory[undoHistory.length - 1];
      const parsed = JSON.parse(prevSnapshot);
      set((state) => ({
        nodes: parsed.nodes,
        edges: parsed.edges,
        undoHistory: state.undoHistory.slice(0, -1),
        redoHistory: [currentSnapshot, ...state.redoHistory.slice(0, 29)],
      }));
    },

    redo: () => {
      const { redoHistory, nodes, edges } = get();
      if (redoHistory.length === 0) return;
      const currentSnapshot = JSON.stringify({ nodes, edges });
      const nextSnapshot = redoHistory[0];
      const parsed = JSON.parse(nextSnapshot);
      set((state) => ({
        nodes: parsed.nodes,
        edges: parsed.edges,
        redoHistory: state.redoHistory.slice(1),
        undoHistory: [...state.undoHistory.slice(-29), currentSnapshot],
      }));
    },
  }))
);
