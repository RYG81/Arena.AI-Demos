import { useCallback, useEffect } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  BackgroundVariant,
  type NodeTypes,
  type OnSelectionChangeParams,
  SelectionMode,
  Panel,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import StoryboardNodeComponent from './components/nodes/StoryboardNode';
import { Toolbar } from './components/Toolbar';
import { MultiPanelSidebar } from './components/RightSidebar';
import { Lightbox } from './components/Lightbox';
import { StatusBar } from './components/StatusBar';
import { useStoryboardStore } from './store/storyboardStore';

const nodeTypes: NodeTypes = {
  storyboardNode: StoryboardNodeComponent,
};

// Inner canvas that uses ReactFlow context
function InnerCanvas() {
  const {
    nodes,
    edges,
    onNodesChange,
    onEdgesChange,
    onConnect,
    setSelectedNodeId,
    showGrid,
    showMinimap,
    openPanels,
    undo,
    redo,
    pushUndoSnapshot,
  } = useStoryboardStore();

  const hasOpenPanels = openPanels.length > 0;

  const onSelectionChange = useCallback(
    ({ nodes: selectedNodes }: OnSelectionChangeParams) => {
      setSelectedNodeId(selectedNodes.length > 0 ? selectedNodes[selectedNodes.length - 1].id : null);
    },
    [setSelectedNodeId]
  );

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement;
      const isInput = el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable;
      if (isInput) return;
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        undo();
      } else if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) {
        e.preventDefault();
        redo();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [undo, redo]);

  return (
    <ReactFlow
      nodes={nodes}
      edges={edges}
      onNodesChange={onNodesChange}
      onEdgesChange={onEdgesChange}
      onConnect={onConnect}
      onSelectionChange={onSelectionChange}
      nodeTypes={nodeTypes}
      onNodeDragStop={() => pushUndoSnapshot()}
      fitView
      fitViewOptions={{ padding: 0.15 }}
      minZoom={0.08}
      maxZoom={3}
      snapToGrid
      snapGrid={[20, 20]}
      selectionMode={SelectionMode.Partial}
      zoomOnScroll
      defaultEdgeOptions={{
        type: 'smoothstep',
        style: { stroke: '#334155', strokeWidth: 2 },
        animated: false,
      }}
      style={{ background: '#0f172a' }}
      proOptions={{ hideAttribution: true }}
    >
      {showGrid && (
        <Background
          variant={BackgroundVariant.Dots}
          gap={20}
          size={1}
          color="#1e293b"
        />
      )}

      <Controls
        className="!bg-slate-800 !border-slate-700 !rounded-xl !shadow-xl"
        style={{ bottom: '40px', left: '16px' }}
        showFitView
        showZoom
        showInteractive
      />

      {showMinimap && (
        <MiniMap
          style={{
            background: '#1e293b',
            border: '1px solid #334155',
            borderRadius: '12px',
            right: hasOpenPanels ? '336px' : '16px',
            bottom: '40px',
          }}
          nodeColor={(node) => {
            const colors: Record<string, string> = {
              scriptBeat: '#64748b',
              promptBuilder: '#6366f1',
              imageGeneration: '#8b5cf6',
              imageEdit: '#a855f7',
              videoGeneration: '#ec4899',
              referenceLock: '#f59e0b',
              exportNode: '#10b981',
              comment: '#eab308',
            };
            return colors[node.data?.nodeType as string] || '#64748b';
          }}
          maskColor="rgba(15,23,42,0.6)"
        />
      )}

      {/* Toolbar inside ReactFlow context to access useReactFlow */}
      <Panel position="top-left" style={{ margin: 0, padding: 0, top: 0, left: 0, right: 0, width: '100vw' }}>
        <Toolbar />
      </Panel>

      {/* Status bar */}
      <Panel position="bottom-left" style={{ margin: 0, padding: 0, bottom: 0, left: 0, right: 0, width: '100vw' }}>
        <StatusBar />
      </Panel>

      {nodes.length === 0 && (
        <Panel position="top-center" style={{ top: '80px' }}>
          <div className="bg-slate-800/90 border border-slate-700 rounded-xl px-6 py-4 text-center">
            <p className="text-slate-300 text-sm font-medium">Canvas is empty</p>
            <p className="text-slate-500 text-xs mt-1">Click "Add Node" in the toolbar to get started</p>
          </div>
        </Panel>
      )}
    </ReactFlow>
  );
}

export default function App() {
  return (
    <div className="w-screen h-screen bg-slate-950 overflow-hidden">
      {/* Main canvas fills entire screen */}
      <div className="w-full h-full">
        <InnerCanvas />
      </div>

      {/* Right sidebar overlays on the right */}
      <MultiPanelSidebar />

      {/* Lightbox overlay */}
      <Lightbox />
    </div>
  );
}
