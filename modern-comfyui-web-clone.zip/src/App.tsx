import { useWorkflowStore } from './store/workflowStore';
import { Topbar } from './components/Topbar';
import { NodeSidebar } from './components/NodeSidebar';
import { FlowCanvas } from './components/FlowCanvas';
import { NodeInspector } from './components/NodeInspector';

export default function App() {
  const { selectedNodeId } = useWorkflowStore();

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#0a0a0f]">
      {/* Top bar */}
      <Topbar />

      {/* Main area */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Node sidebar */}
        <NodeSidebar onDragStart={() => {}} />

        {/* Canvas */}
        <div className="flex-1 relative overflow-hidden">
          <FlowCanvas />
        </div>

        {/* Node inspector panel (right side) */}
        {selectedNodeId && <NodeInspector />}
      </div>
    </div>
  );
}
