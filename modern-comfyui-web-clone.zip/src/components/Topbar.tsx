import React, { useRef } from 'react';
import { useWorkflowStore } from '../store/workflowStore';
import {
  Play, Square, Download, Upload, Trash2, RotateCcw, Cpu, Zap, Clock
} from 'lucide-react';

export function Topbar() {
  const {
    executionStatus,
    executionProgress,
    queueCount,
    runWorkflow,
    loadDefaultWorkflow,
    clearWorkflow,
    exportWorkflow,
    importWorkflow,
    nodes,
    edges,
  } = useWorkflowStore();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const isRunning = executionStatus === 'running';
  const isDone = executionStatus === 'done';

  const handleExport = () => {
    const json = exportWorkflow();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'comfyflow_workflow.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      if (ev.target?.result) {
        importWorkflow(ev.target.result as string);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="h-12 bg-slate-950/98 border-b border-white/8 flex items-center px-4 gap-3 z-30 backdrop-blur-xl flex-shrink-0">
      {/* Logo */}
      <div className="flex items-center gap-2 mr-2">
        <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-violet-900/50">
          <Zap size={14} className="text-white" />
        </div>
        <div className="leading-none">
          <div className="text-sm font-bold text-white tracking-tight">ComfyFlow</div>
          <div className="text-[9px] text-slate-600 tracking-widest uppercase">AI Node Editor</div>
        </div>
      </div>

      <div className="h-5 w-px bg-white/10 mx-1" />

      {/* Run button */}
      <button
        onClick={runWorkflow}
        disabled={isRunning || nodes.length === 0}
        className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed"
        style={{
          background: isRunning
            ? 'linear-gradient(135deg, #dc2626, #b91c1c)'
            : isDone
            ? 'linear-gradient(135deg, #059669, #047857)'
            : 'linear-gradient(135deg, #7c3aed, #6d28d9)',
          boxShadow: isRunning
            ? '0 0 12px rgba(220,38,38,0.4)'
            : isDone
            ? '0 0 12px rgba(5,150,105,0.4)'
            : '0 0 12px rgba(124,58,237,0.4)',
          color: 'white',
        }}
      >
        {isRunning ? (
          <>
            <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            Running...
          </>
        ) : isDone ? (
          <>✅ Done</>
        ) : (
          <>
            <Play size={12} fill="white" />
            Queue Prompt
          </>
        )}
      </button>

      {/* Progress bar */}
      {isRunning && (
        <div className="flex items-center gap-2">
          <div className="w-24 h-1.5 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{
                width: `${executionProgress}%`,
                background: 'linear-gradient(90deg, #7c3aed, #dc2626)',
              }}
            />
          </div>
          <span className="text-[10px] text-slate-500 tabular-nums">{Math.round(executionProgress)}%</span>
        </div>
      )}

      {/* Queue counter */}
      {queueCount > 0 && (
        <div className="flex items-center gap-1.5 text-[10px] text-slate-500">
          <Clock size={10} />
          <span>Ran {queueCount}×</span>
        </div>
      )}

      <div className="flex-1" />

      {/* Stats */}
      <div className="flex items-center gap-3 text-[10px] text-slate-600 mr-2">
        <div className="flex items-center gap-1">
          <Cpu size={10} />
          <span>{nodes.length} nodes</span>
        </div>
        <div className="flex items-center gap-1">
          <Square size={10} />
          <span>{edges.length} edges</span>
        </div>
      </div>

      <div className="h-5 w-px bg-white/10 mx-1" />

      {/* Actions */}
      <div className="flex items-center gap-1">
        <button
          onClick={loadDefaultWorkflow}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] text-slate-400 hover:text-white hover:bg-white/5 border border-transparent hover:border-white/10 transition-all"
          title="Load default workflow"
        >
          <RotateCcw size={12} />
          Default
        </button>
        <button
          onClick={handleExport}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] text-slate-400 hover:text-white hover:bg-white/5 border border-transparent hover:border-white/10 transition-all"
          title="Export workflow as JSON"
        >
          <Download size={12} />
          Export
        </button>
        <label className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] text-slate-400 hover:text-white hover:bg-white/5 border border-transparent hover:border-white/10 transition-all cursor-pointer">
          <Upload size={12} />
          Import
          <input ref={fileInputRef} type="file" accept=".json" onChange={handleImport} className="hidden" />
        </label>
        <button
          onClick={clearWorkflow}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] text-red-500 hover:text-red-400 hover:bg-red-500/5 border border-transparent hover:border-red-500/20 transition-all"
          title="Clear workflow"
        >
          <Trash2 size={12} />
          Clear
        </button>
      </div>
    </div>
  );
}
