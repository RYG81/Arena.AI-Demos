import React from 'react';
import { useWorkflowStore } from '../store/workflowStore';
import { X, Trash2, Copy, ChevronRight } from 'lucide-react';
import { NODE_REGISTRY } from '../nodes/nodeConfig';

export function NodeInspector() {
  const {
    nodes,
    selectedNodeId,
    selectNode,
    deleteNode,
    duplicateNode,
    updateNodeData,
  } = useWorkflowStore();

  if (!selectedNodeId) return null;

  const node = nodes.find(n => n.id === selectedNodeId);
  if (!node) return null;

  const nodeDef = NODE_REGISTRY.find(n => n.type === node.type);

  return (
    <div className="absolute top-12 right-0 bottom-0 w-72 bg-slate-950/98 border-l border-white/8 flex flex-col z-20 backdrop-blur-xl">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/8">
        <div className="flex items-center gap-2">
          <span className="text-lg">{nodeDef?.icon ?? '🔷'}</span>
          <div>
            <div className="text-sm font-semibold text-white leading-tight">{node.data.label as string}</div>
            <div className="text-[9px] text-slate-600 font-mono">{node.type} · {node.id}</div>
          </div>
        </div>
        <button onClick={() => selectNode(null)} className="text-slate-500 hover:text-white transition-colors">
          <X size={14} />
        </button>
      </div>

      {/* Node description */}
      {nodeDef && (
        <div className="px-4 py-2 border-b border-white/5">
          <p className="text-[10px] text-slate-500 leading-relaxed">{nodeDef.description}</p>
        </div>
      )}

      {/* Properties */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
        <div>
          <h3 className="text-[10px] uppercase tracking-widest text-slate-600 mb-2">Properties</h3>
          <div className="space-y-2">
            {Object.entries(node.data).map(([key, value]) => {
              if (key === 'label') return null;

              return (
                <div key={key} className="space-y-1">
                  <label className="text-[10px] text-slate-500 uppercase tracking-wider">
                    {key.replace(/_/g, ' ')}
                  </label>
                  {typeof value === 'boolean' ? (
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={value}
                        onChange={e => updateNodeData(selectedNodeId, { [key]: e.target.checked })}
                        className="rounded"
                      />
                      <span className="text-xs text-slate-400">{value ? 'Enabled' : 'Disabled'}</span>
                    </div>
                  ) : typeof value === 'number' ? (
                    <input
                      type="number"
                      value={value}
                      onChange={e => updateNodeData(selectedNodeId, { [key]: parseFloat(e.target.value) })}
                      className="w-full bg-black/40 border border-white/10 rounded-md text-xs text-slate-200 px-2 py-1.5 focus:outline-none focus:border-white/30 font-mono"
                    />
                  ) : (
                    <input
                      type="text"
                      value={value as string}
                      onChange={e => updateNodeData(selectedNodeId, { [key]: e.target.value })}
                      className="w-full bg-black/40 border border-white/10 rounded-md text-xs text-slate-200 px-2 py-1.5 focus:outline-none focus:border-white/30"
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Position */}
        <div>
          <h3 className="text-[10px] uppercase tracking-widest text-slate-600 mb-2">Position</h3>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label className="text-[10px] text-slate-500">X</label>
              <div className="bg-black/40 border border-white/10 rounded-md text-xs text-slate-400 px-2 py-1.5 font-mono">
                {Math.round(node.position.x)}
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] text-slate-500">Y</label>
              <div className="bg-black/40 border border-white/10 rounded-md text-xs text-slate-400 px-2 py-1.5 font-mono">
                {Math.round(node.position.y)}
              </div>
            </div>
          </div>
        </div>

        {/* Connections info */}
        <div>
          <h3 className="text-[10px] uppercase tracking-widest text-slate-600 mb-2">Info</h3>
          <div className="space-y-1">
            {[
              { label: 'Node ID', value: node.id },
              { label: 'Type', value: node.type ?? 'unknown' },
              { label: 'Category', value: nodeDef?.category ?? '—' },
            ].map(row => (
              <div key={row.label} className="flex items-center justify-between py-1 border-b border-white/5">
                <span className="text-[10px] text-slate-600">{row.label}</span>
                <span className="text-[10px] text-slate-400 font-mono truncate max-w-[140px]">{row.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="border-t border-white/8 px-4 py-3 flex items-center gap-2">
        <button
          onClick={() => duplicateNode(selectedNodeId)}
          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all"
        >
          <Copy size={12} />
          Duplicate
        </button>
        <button
          onClick={() => deleteNode(selectedNodeId)}
          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs text-red-500 hover:text-red-400 bg-red-500/5 hover:bg-red-500/10 border border-red-500/20 transition-all"
        >
          <Trash2 size={12} />
          Delete
        </button>
      </div>
    </div>
  );
}
