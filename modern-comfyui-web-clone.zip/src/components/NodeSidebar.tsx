import { useState, useMemo } from 'react';
import { useWorkflowStore } from '../store/workflowStore';
import { NODE_REGISTRY, NODE_CATEGORIES, NodeCategory } from '../nodes/nodeConfig';
import { Search, ChevronDown, ChevronRight, X } from 'lucide-react';

interface NodeSidebarProps {
  onDragStart: (type: string) => void;
}

export function NodeSidebar({ onDragStart }: NodeSidebarProps) {
  const { nodeSearchQuery, setNodeSearchQuery, sidebarOpen, setSidebarOpen } = useWorkflowStore();
  const [collapsedCategories, setCollapsedCategories] = useState<Set<string>>(new Set());

  const filtered = useMemo(() => {
    const q = nodeSearchQuery.toLowerCase();
    if (!q) return NODE_REGISTRY;
    return NODE_REGISTRY.filter(n =>
      n.label.toLowerCase().includes(q) ||
      n.description.toLowerCase().includes(q) ||
      n.category.toLowerCase().includes(q)
    );
  }, [nodeSearchQuery]);

  const byCategory = useMemo(() => {
    const map: Partial<Record<NodeCategory, typeof NODE_REGISTRY>> = {};
    for (const cat of NODE_CATEGORIES) {
      const items = filtered.filter(n => n.category === cat);
      if (items.length) map[cat] = items;
    }
    return map;
  }, [filtered]);

  const toggleCategory = (cat: string) => {
    setCollapsedCategories(prev => {
      const next = new Set(prev);
      next.has(cat) ? next.delete(cat) : next.add(cat);
      return next;
    });
  };

  if (!sidebarOpen) {
    return (
      <button
        onClick={() => setSidebarOpen(true)}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-30 bg-slate-900/90 border border-white/10 rounded-r-xl p-2 text-slate-400 hover:text-white transition-colors"
      >
        <ChevronRight size={16} />
      </button>
    );
  }

  return (
    <div className="w-64 h-full bg-slate-950/95 border-r border-white/8 flex flex-col z-20 backdrop-blur-xl">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/8">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-violet-600 flex items-center justify-center text-xs">⚡</div>
          <span className="text-sm font-semibold text-white">Node Library</span>
        </div>
        <button
          onClick={() => setSidebarOpen(false)}
          className="text-slate-500 hover:text-white transition-colors"
        >
          <X size={14} />
        </button>
      </div>

      {/* Search */}
      <div className="px-3 py-2 border-b border-white/8">
        <div className="relative">
          <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={nodeSearchQuery}
            onChange={e => setNodeSearchQuery(e.target.value)}
            placeholder="Search nodes..."
            className="w-full bg-white/5 border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-violet-500/50"
          />
          {nodeSearchQuery && (
            <button onClick={() => setNodeSearchQuery('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white">
              <X size={10} />
            </button>
          )}
        </div>
      </div>

      {/* Node list */}
      <div className="flex-1 overflow-y-auto py-2 space-y-1">
        {Object.entries(byCategory).map(([cat, nodes]) => (
          <div key={cat}>
            {/* Category header */}
            <button
              onClick={() => toggleCategory(cat)}
              className="w-full flex items-center justify-between px-4 py-1.5 text-[10px] uppercase tracking-widest text-slate-500 hover:text-slate-300 transition-colors"
            >
              <span>{cat}</span>
              <div className="flex items-center gap-1">
                <span className="text-[9px] bg-white/5 rounded px-1">{nodes!.length}</span>
                {collapsedCategories.has(cat) ? <ChevronRight size={10} /> : <ChevronDown size={10} />}
              </div>
            </button>

            {/* Node items */}
            {!collapsedCategories.has(cat) && (
              <div className="space-y-0.5 px-2">
                {nodes!.map(node => (
                  <div
                    key={node.type}
                    draggable
                    onDragStart={e => {
                      e.dataTransfer.setData('nodeType', node.type);
                      onDragStart(node.type);
                    }}
                    className="group flex items-center gap-2.5 px-2.5 py-2 rounded-lg cursor-grab active:cursor-grabbing hover:bg-white/5 border border-transparent hover:border-white/8 transition-all"
                  >
                    <span className="text-base leading-none">{node.icon}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-[11px] font-medium text-slate-300 group-hover:text-white transition-colors truncate">
                        {node.label}
                      </div>
                      <div className="text-[9px] text-slate-600 truncate leading-tight mt-0.5">
                        {node.description}
                      </div>
                    </div>
                    <div
                      className="w-2 h-2 rounded-full flex-shrink-0 opacity-60 group-hover:opacity-100 transition-opacity"
                      style={{ background: node.color }}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}

        {Object.keys(byCategory).length === 0 && (
          <div className="px-4 py-8 text-center text-slate-600 text-xs">
            No nodes found for "{nodeSearchQuery}"
          </div>
        )}
      </div>

      {/* Footer hint */}
      <div className="px-4 py-2 border-t border-white/5 text-[9px] text-slate-700 text-center">
        Drag nodes onto the canvas · Right-click for menu
      </div>
    </div>
  );
}
