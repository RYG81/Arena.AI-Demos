import React, { useEffect, useRef } from 'react';
import { useWorkflowStore } from '../store/workflowStore';
import { NODE_REGISTRY, NodeCategory, NODE_CATEGORIES } from '../nodes/nodeConfig';
import { Copy, Trash2, Plus, ZoomIn, ZoomOut, Layers } from 'lucide-react';

interface ContextMenuProps {
  x: number;
  y: number;
  nodeId: string | null;
  canvasPos: { x: number; y: number };
  onClose: () => void;
  onAddNode: (type: string, pos: { x: number; y: number }) => void;
}

export function ContextMenu({ x, y, nodeId, canvasPos, onClose, onAddNode }: ContextMenuProps) {
  const { deleteNode, duplicateNode, selectNode } = useWorkflowStore();
  const ref = useRef<HTMLDivElement>(null);
  const [showAddSubmenu, setShowAddSubmenu] = React.useState(false);
  const [activeCategory, setActiveCategory] = React.useState<string | null>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        onClose();
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [onClose]);

  // Adjust position to stay within viewport
  const menuStyle: React.CSSProperties = {
    position: 'fixed',
    left: Math.min(x, window.innerWidth - 240),
    top: Math.min(y, window.innerHeight - 300),
    zIndex: 1000,
  };

  return (
    <div ref={ref} style={menuStyle} className="w-52">
      <div className="bg-slate-900/98 border border-white/12 rounded-xl shadow-2xl shadow-black/60 overflow-hidden backdrop-blur-xl">
        {nodeId ? (
          // Node context menu
          <>
            <div className="px-3 py-1.5 border-b border-white/8">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider">Node Actions</span>
            </div>
            <div className="py-1">
              <MenuItem icon={<Copy size={12} />} label="Duplicate" onClick={() => { duplicateNode(nodeId); onClose(); }} />
              <MenuItem icon={<Trash2 size={12} />} label="Delete" onClick={() => { deleteNode(nodeId); onClose(); }} danger />
            </div>
          </>
        ) : (
          // Canvas context menu
          <>
            <div className="px-3 py-1.5 border-b border-white/8">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider">Canvas</span>
            </div>
            <div className="py-1">
              <div
                className="relative group"
                onMouseEnter={() => setShowAddSubmenu(true)}
                onMouseLeave={() => { setShowAddSubmenu(false); setActiveCategory(null); }}
              >
                <MenuItem icon={<Plus size={12} />} label="Add Node" hasSubmenu />

                {/* Submenu */}
                {showAddSubmenu && (
                  <div
                    className="absolute left-full top-0 w-48 bg-slate-900/98 border border-white/12 rounded-xl shadow-2xl shadow-black/60 overflow-hidden backdrop-blur-xl"
                    style={{ marginLeft: 4 }}
                  >
                    {NODE_CATEGORIES.map(cat => {
                      const catNodes = NODE_REGISTRY.filter(n => n.category === cat);
                      if (!catNodes.length) return null;
                      return (
                        <div
                          key={cat}
                          className="relative"
                          onMouseEnter={() => setActiveCategory(cat)}
                          onMouseLeave={() => setActiveCategory(null)}
                        >
                          <MenuItem
                            label={cat}
                            hasSubmenu
                          />
                          {activeCategory === cat && (
                            <div
                              className="absolute left-full top-0 w-56 bg-slate-900/98 border border-white/12 rounded-xl shadow-2xl shadow-black/60 overflow-hidden backdrop-blur-xl"
                              style={{ marginLeft: 4 }}
                            >
                              <div className="px-3 py-1.5 border-b border-white/8">
                                <span className="text-[10px] text-slate-500">{cat}</span>
                              </div>
                              <div className="py-1">
                                {catNodes.map(node => (
                                  <button
                                    key={node.type}
                                    onClick={() => { onAddNode(node.type, canvasPos); onClose(); }}
                                    className="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-white/8 transition-colors text-left"
                                  >
                                    <span>{node.icon}</span>
                                    <div>
                                      <div className="text-[11px] font-medium">{node.label}</div>
                                    </div>
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function MenuItem({
  icon,
  label,
  onClick,
  danger,
  hasSubmenu,
}: {
  icon?: React.ReactNode;
  label: string;
  onClick?: () => void;
  danger?: boolean;
  hasSubmenu?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-2 px-3 py-1.5 text-xs transition-colors text-left
        ${danger
          ? 'text-red-400 hover:text-red-300 hover:bg-red-500/10'
          : 'text-slate-300 hover:text-white hover:bg-white/8'
        }`}
    >
      {icon && <span className="text-slate-500">{icon}</span>}
      <span className="flex-1">{label}</span>
      {hasSubmenu && <span className="text-slate-600">›</span>}
    </button>
  );
}
