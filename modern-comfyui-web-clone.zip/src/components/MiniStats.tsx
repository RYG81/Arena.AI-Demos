import { useWorkflowStore } from '../store/workflowStore';

export function MiniStats() {
  const { executionStatus, executingNodeId, nodes, executionProgress } = useWorkflowStore();

  const executingNode = nodes.find(n => n.id === executingNodeId);
  const isRunning = executionStatus === 'running';

  return (
    <div className="absolute top-3 right-3 z-20 flex flex-col items-end gap-2">
      {/* Execution status badge */}
      {isRunning && executingNode && (
        <div className="flex items-center gap-2 bg-slate-900/95 border border-white/10 rounded-lg px-3 py-2 backdrop-blur-xl shadow-xl">
          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <div>
            <div className="text-[10px] text-slate-400">Processing</div>
            <div className="text-xs font-semibold text-white">{executingNode.data.label as string}</div>
          </div>
          <div className="ml-2 text-[11px] font-mono text-violet-400 tabular-nums">
            {Math.round(executionProgress)}%
          </div>
        </div>
      )}

      {executionStatus === 'done' && (
        <div className="flex items-center gap-2 bg-emerald-900/50 border border-emerald-500/30 rounded-lg px-3 py-2 backdrop-blur-xl shadow-xl">
          <div className="text-emerald-400 text-sm">✅</div>
          <div className="text-xs font-semibold text-emerald-300">Generation Complete</div>
        </div>
      )}
    </div>
  );
}
