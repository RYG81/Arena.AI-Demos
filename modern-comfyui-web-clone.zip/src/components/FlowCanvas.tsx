import React, { useCallback, useRef, useState } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  BackgroundVariant,
  ConnectionMode,
  Panel,
  useReactFlow,
  ReactFlowProvider,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import { useWorkflowStore } from '../store/workflowStore';
import { NODE_TYPES } from '../nodes/AllNodes';
import { ContextMenu } from './ContextMenu';
import { ExecutionLog } from './ExecutionLog';
import { MiniStats } from './MiniStats';


function FlowCanvasInner() {
  const {
    nodes,
    edges,
    onNodesChange,
    onEdgesChange,
    onConnect,
    addNode,
    selectNode,
  } = useWorkflowStore();

  const { screenToFlowPosition } = useReactFlow();
  const [contextMenu, setContextMenu] = useState<{
    x: number;
    y: number;
    nodeId: string | null;
    canvasPos: { x: number; y: number };
  } | null>(null);

  const reactFlowWrapper = useRef<HTMLDivElement>(null);

  const onNodeContextMenu = useCallback((e: React.MouseEvent, node: any) => {
    e.preventDefault();
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      nodeId: node.id,
      canvasPos: { x: node.position.x, y: node.position.y },
    });
  }, []);

  const onPaneContextMenu = useCallback((e: MouseEvent | React.MouseEvent) => {
    e.preventDefault();
    const pos = screenToFlowPosition({ x: e.clientX, y: e.clientY });
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      nodeId: null,
      canvasPos: pos,
    });
  }, [screenToFlowPosition]);

  const onPaneClick = useCallback(() => {
    selectNode(null);
    setContextMenu(null);
  }, [selectNode]);

  const onNodeClick = useCallback((_: React.MouseEvent, node: any) => {
    selectNode(node.id);
    setContextMenu(null);
  }, [selectNode]);

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  }, []);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const type = e.dataTransfer.getData('nodeType');
    if (!type) return;

    const pos = screenToFlowPosition({ x: e.clientX, y: e.clientY });
    addNode(type, pos);
  }, [screenToFlowPosition, addNode]);

  const handleAddNodeFromMenu = useCallback((type: string, pos: { x: number; y: number }) => {
    addNode(type, pos);
  }, [addNode]);

  return (
    <div ref={reactFlowWrapper} className="w-full h-full relative">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        nodeTypes={NODE_TYPES}
        connectionMode={ConnectionMode.Loose}
        onNodeContextMenu={onNodeContextMenu}
        onPaneContextMenu={onPaneContextMenu}
        onPaneClick={onPaneClick}
        onNodeClick={onNodeClick}
        onDrop={onDrop}
        onDragOver={onDragOver}
        fitView
        fitViewOptions={{ padding: 0.12, maxZoom: 1.0 }}
        minZoom={0.1}
        maxZoom={3}
        deleteKeyCode="Delete"
        multiSelectionKeyCode="Shift"
        style={{ background: 'transparent' }}
        proOptions={{ hideAttribution: true }}
        defaultEdgeOptions={{
          type: 'smoothstep',
          style: { strokeWidth: 2, stroke: '#64748b' },
        }}
      >
        {/* Dark grid background */}
        <Background
          variant={BackgroundVariant.Dots}
          gap={20}
          size={1}
          color="rgba(255,255,255,0.06)"
          style={{ background: '#0a0a0f' }}
        />

        {/* Controls */}
        <Controls
          style={{
            background: 'rgba(10,10,20,0.9)',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: 12,
            bottom: 16,
            left: 16,
          }}
          showInteractive={false}
        />

        {/* MiniMap */}
        <MiniMap
          style={{
            background: 'rgba(10,10,20,0.9)',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: 12,
          }}
          maskColor="rgba(0,0,0,0.6)"
          nodeColor={(n) => {
            const colorMap: Record<string, string> = {
              checkpointLoader: '#7c3aed',
              clipTextEncode: '#d97706',
              kSampler: '#dc2626',
              kSamplerAdvanced: '#b91c1c',
              emptyLatentImage: '#ea580c',
              vaeDecoder: '#0891b2',
              vaeEncoder: '#0e7490',
              vaeLoader: '#059669',
              saveImage: '#1d4ed8',
              loadImage: '#7c3aed',
              imagePreview: '#0284c7',
              loraLoader: '#7c3aed',
              controlnetApply: '#0369a1',
              upscaleImage: '#059669',
              note: '#64748b',
              primitiveInt: '#475569',
              primitiveFloat: '#475569',
              primitiveString: '#475569',
            };
            return colorMap[n.type ?? ''] ?? '#64748b';
          }}
        />

        {/* Keyboard shortcut hints panel */}
        <Panel position="bottom-left" style={{ left: 180, bottom: 16 }}>
          <div className="flex items-center gap-3 text-[9px] text-slate-700">
            <span><kbd className="bg-white/5 border border-white/10 rounded px-1">Del</kbd> delete</span>
            <span><kbd className="bg-white/5 border border-white/10 rounded px-1">Shift</kbd> multi-select</span>
            <span><kbd className="bg-white/5 border border-white/10 rounded px-1">Scroll</kbd> zoom</span>
            <span><kbd className="bg-white/5 border border-white/10 rounded px-1">Right-click</kbd> context menu</span>
          </div>
        </Panel>
      </ReactFlow>

      {/* Overlays */}
      <MiniStats />
      <ExecutionLog />

      {/* Context menu */}
      {contextMenu && (
        <ContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          nodeId={contextMenu.nodeId}
          canvasPos={contextMenu.canvasPos}
          onClose={() => setContextMenu(null)}
          onAddNode={handleAddNodeFromMenu}
        />
      )}
    </div>
  );
}

export function FlowCanvas() {
  return (
    <ReactFlowProvider>
      <FlowCanvasInner />
    </ReactFlowProvider>
  );
}
