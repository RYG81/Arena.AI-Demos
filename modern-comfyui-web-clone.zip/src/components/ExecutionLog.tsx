import React, { useEffect, useRef, useState } from 'react';
import { useWorkflowStore } from '../store/workflowStore';
import { Terminal, X, ChevronDown, ChevronUp, Trash2 } from 'lucide-react';

export function ExecutionLog() {
  const { executionLog, executionStatus, clearLog } = useWorkflowStore();
  const logRef = useRef<HTMLDivElement>(null);
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    if (logRef.current && !collapsed) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [executionLog, collapsed]);

  const isRunning = executionStatus === 'running';

  const getLineColor = (line: string) => {
    if (line.startsWith('✅') || line.includes('✓')) return 'text-emerald-400';
    if (line.startsWith('▶')) return 'text-violet-400';
    if (line.startsWith('⚡')) return 'text-yellow-400';
    if (line.startsWith('[KSampler]')) return 'text-red-400';
    if (line.startsWith('[CheckpointLoader]')) return 'text-violet-400';
    if (line.startsWith('[VAEDecoder]')) return 'text-cyan-400';
    if (line.startsWith('[CLIPTextEncode]')) return 'text-amber-400';
    if (line.startsWith('[EmptyLatentImage]')) return 'text-orange-400';
    if (line.startsWith('[SaveImage]')) return 'text-blue-400';
    if (line.startsWith('[LoRALoader]')) return 'text-purple-400';
    if (line === '') return 'text-transparent';
    return 'text-slate-400';
  };

  return (
    <div
      className="absolute bottom-0 right-0 z-20 flex flex-col"
      style={{
        width: '380px',
        maxHeight: collapsed ? '40px' : '260px',
        transition: 'max-height 0.2s ease',
      }}
    >
      {/* Header bar */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-950/98 border border-white/8 rounded-t-xl border-b-0 backdrop-blur-xl">
        <div className="flex items-center gap-2">
          <Terminal size={12} className="text-slate-500" />
          <span className="text-[11px] font-semibold text-slate-300">Execution Log</span>
          {isRunning && (
            <div className="flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
              <span className="text-[9px] text-red-400 uppercase tracking-wider">Running</span>
            </div>
          )}
          {executionStatus === 'done' && (
            <span className="text-[9px] text-emerald-400 uppercase tracking-wider">Complete</span>
          )}
        </div>
        <div className="flex items-center gap-1">
          {executionLog.length > 0 && (
            <button
              onClick={clearLog}
              className="p-1 text-slate-600 hover:text-slate-400 transition-colors"
              title="Clear log"
            >
              <Trash2 size={10} />
            </button>
          )}
          <button
            onClick={() => setCollapsed(v => !v)}
            className="p-1 text-slate-600 hover:text-slate-400 transition-colors"
          >
            {collapsed ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
          </button>
        </div>
      </div>

      {/* Log body */}
      {!collapsed && (
        <div
          ref={logRef}
          className="flex-1 overflow-y-auto bg-black/80 border border-white/8 border-t-0 rounded-b-xl backdrop-blur-xl p-3"
          style={{ fontFamily: "'JetBrains Mono', 'Fira Code', 'Courier New', monospace" }}
        >
          {executionLog.length === 0 ? (
            <div className="text-center py-6 text-slate-700 text-[10px]">
              Press <span className="text-violet-500">Queue Prompt</span> to run the workflow
            </div>
          ) : (
            <div className="space-y-0.5">
              {executionLog.map((line, i) => (
                <div key={i} className={`text-[10px] leading-relaxed ${getLineColor(line)}`}>
                  {line === '' ? '\u00A0' : line}
                </div>
              ))}
              {isRunning && (
                <div className="flex items-center gap-1 mt-1">
                  <div className="w-1 h-3 bg-slate-400 animate-pulse" />
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
