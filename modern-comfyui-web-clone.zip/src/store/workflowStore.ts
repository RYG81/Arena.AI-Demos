import { create } from 'zustand';
import { immer } from 'zustand/middleware/immer';
import {
  Node,
  Edge,
  NodeChange,
  EdgeChange,
  Connection,
  applyNodeChanges,
  applyEdgeChanges,
  addEdge,
} from '@xyflow/react';
import { nanoid } from 'nanoid';

export type ExecutionStatus = 'idle' | 'queued' | 'running' | 'done' | 'error';

export interface NodeData {
  label: string;
  [key: string]: unknown;
}

export interface WorkflowState {
  nodes: Node[];
  edges: Edge[];
  executionStatus: ExecutionStatus;
  executingNodeId: string | null;
  executionProgress: number;
  executionLog: string[];
  selectedNodeId: string | null;
  queueCount: number;
  sidebarOpen: boolean;
  nodeSearchQuery: string;

  // Actions
  onNodesChange: (changes: NodeChange[]) => void;
  onEdgesChange: (changes: EdgeChange[]) => void;
  onConnect: (connection: Connection) => void;
  addNode: (type: string, position: { x: number; y: number }) => void;
  updateNodeData: (nodeId: string, data: Partial<NodeData>) => void;
  deleteNode: (nodeId: string) => void;
  duplicateNode: (nodeId: string) => void;
  selectNode: (nodeId: string | null) => void;
  runWorkflow: () => void;
  clearLog: () => void;
  setSidebarOpen: (open: boolean) => void;
  setNodeSearchQuery: (q: string) => void;
  loadDefaultWorkflow: () => void;
  clearWorkflow: () => void;
  exportWorkflow: () => string;
  importWorkflow: (json: string) => void;
}

// Default workflow: the canonical SD pipeline
const DEFAULT_NODES: Node[] = [
  {
    id: 'ckpt-1',
    type: 'checkpointLoader',
    position: { x: 60, y: 220 },
    data: {
      label: 'Load Checkpoint',
      ckpt_name: 'v1-5-pruned-emaonly.safetensors',
    },
  },
  {
    id: 'clip-pos-1',
    type: 'clipTextEncode',
    position: { x: 420, y: 80 },
    data: {
      label: 'CLIP Text Encode (Positive)',
      text: 'a beautiful landscape, cinematic lighting, 8k, detailed',
      polarity: 'positive',
    },
  },
  {
    id: 'clip-neg-1',
    type: 'clipTextEncode',
    position: { x: 420, y: 320 },
    data: {
      label: 'CLIP Text Encode (Negative)',
      text: 'ugly, blurry, low quality, watermark, deformed',
      polarity: 'negative',
    },
  },
  {
    id: 'latent-1',
    type: 'emptyLatentImage',
    position: { x: 420, y: 540 },
    data: {
      label: 'Empty Latent Image',
      width: 512,
      height: 512,
      batch_size: 1,
    },
  },
  {
    id: 'ksampler-1',
    type: 'kSampler',
    position: { x: 800, y: 220 },
    data: {
      label: 'KSampler',
      seed: 42,
      steps: 20,
      cfg: 7.5,
      sampler_name: 'euler',
      scheduler: 'karras',
      denoise: 1.0,
    },
  },
  {
    id: 'vae-decode-1',
    type: 'vaeDecoder',
    position: { x: 1180, y: 280 },
    data: {
      label: 'VAE Decode',
    },
  },
  {
    id: 'save-1',
    type: 'saveImage',
    position: { x: 1500, y: 260 },
    data: {
      label: 'Save Image',
      filename_prefix: 'ComfyFlow',
    },
  },
];

const DEFAULT_EDGES: Edge[] = [
  { id: 'e1', source: 'ckpt-1', sourceHandle: 'model', target: 'ksampler-1', targetHandle: 'model', type: 'smoothstep', animated: false, style: { stroke: '#a78bfa', strokeWidth: 2 } },
  { id: 'e2', source: 'ckpt-1', sourceHandle: 'clip', target: 'clip-pos-1', targetHandle: 'clip', type: 'smoothstep', animated: false, style: { stroke: '#fbbf24', strokeWidth: 2 } },
  { id: 'e3', source: 'ckpt-1', sourceHandle: 'clip', target: 'clip-neg-1', targetHandle: 'clip', type: 'smoothstep', animated: false, style: { stroke: '#fbbf24', strokeWidth: 2 } },
  { id: 'e4', source: 'ckpt-1', sourceHandle: 'vae', target: 'vae-decode-1', targetHandle: 'vae', type: 'smoothstep', animated: false, style: { stroke: '#34d399', strokeWidth: 2 } },
  { id: 'e5', source: 'clip-pos-1', sourceHandle: 'conditioning', target: 'ksampler-1', targetHandle: 'positive', type: 'smoothstep', animated: false, style: { stroke: '#f87171', strokeWidth: 2 } },
  { id: 'e6', source: 'clip-neg-1', sourceHandle: 'conditioning', target: 'ksampler-1', targetHandle: 'negative', type: 'smoothstep', animated: false, style: { stroke: '#94a3b8', strokeWidth: 2 } },
  { id: 'e7', source: 'latent-1', sourceHandle: 'latent', target: 'ksampler-1', targetHandle: 'latent_image', type: 'smoothstep', animated: false, style: { stroke: '#fb923c', strokeWidth: 2 } },
  { id: 'e8', source: 'ksampler-1', sourceHandle: 'latent', target: 'vae-decode-1', targetHandle: 'samples', type: 'smoothstep', animated: false, style: { stroke: '#fb923c', strokeWidth: 2 } },
  { id: 'e9', source: 'vae-decode-1', sourceHandle: 'image', target: 'save-1', targetHandle: 'images', type: 'smoothstep', animated: false, style: { stroke: '#60a5fa', strokeWidth: 2 } },
];

const NODE_DEFAULTS: Record<string, Partial<NodeData>> = {
  checkpointLoader: { label: 'Load Checkpoint', ckpt_name: 'v1-5-pruned-emaonly.safetensors' },
  clipTextEncode: { label: 'CLIP Text Encode', text: '', polarity: 'positive' },
  kSampler: { label: 'KSampler', seed: Math.floor(Math.random() * 99999), steps: 20, cfg: 7.5, sampler_name: 'euler', scheduler: 'karras', denoise: 1.0 },
  emptyLatentImage: { label: 'Empty Latent Image', width: 512, height: 512, batch_size: 1 },
  vaeDecoder: { label: 'VAE Decode' },
  vaeEncoder: { label: 'VAE Encode' },
  saveImage: { label: 'Save Image', filename_prefix: 'ComfyFlow' },
  loadImage: { label: 'Load Image' },
  imagePreview: { label: 'Preview Image' },
  loraLoader: { label: 'Load LoRA', lora_name: 'example.safetensors', strength_model: 1.0, strength_clip: 1.0 },
  controlnetApply: { label: 'Apply ControlNet', strength: 1.0 },
  upscaleImage: { label: 'Upscale Image', upscale_method: 'nearest-exact', scale_by: 2.0 },
  note: { label: 'Note', content: 'Add your notes here...' },
  primitiveInt: { label: 'Integer', value: 512 },
  primitiveFloat: { label: 'Float', value: 1.0 },
  primitiveString: { label: 'String', value: '' },
};

// Simulate async node execution
async function simulateExecution(
  _nodeId: string,
  nodeType: string,
  onLog: (msg: string) => void,
  onProgress: (p: number) => void
): Promise<void> {
  const msgs: Record<string, string[]> = {
    checkpointLoader: [
      `[CheckpointLoader] Loading model weights...`,
      `[CheckpointLoader] Parsing UNet architecture`,
      `[CheckpointLoader] Loading CLIP encoder`,
      `[CheckpointLoader] Loading VAE decoder`,
      `[CheckpointLoader] ✓ Model loaded successfully`,
    ],
    clipTextEncode: [
      `[CLIPTextEncode] Tokenizing prompt...`,
      `[CLIPTextEncode] Running CLIP encoder`,
      `[CLIPTextEncode] ✓ Conditioning vectors ready (77 tokens)`,
    ],
    emptyLatentImage: [
      `[EmptyLatentImage] Allocating latent tensor`,
      `[EmptyLatentImage] ✓ Latent shape: [1, 4, 64, 64]`,
    ],
    kSampler: [
      `[KSampler] Initializing sampler: Euler/Karras`,
      `[KSampler] Starting denoising loop (20 steps)...`,
      `[KSampler] Step  1/20 — σ=14.61 loss=0.842`,
      `[KSampler] Step  4/20 — σ= 7.34 loss=0.631`,
      `[KSampler] Step  8/20 — σ= 3.12 loss=0.412`,
      `[KSampler] Step 12/20 — σ= 1.24 loss=0.271`,
      `[KSampler] Step 16/20 — σ= 0.41 loss=0.134`,
      `[KSampler] Step 20/20 — σ= 0.02 loss=0.009`,
      `[KSampler] ✓ Denoising complete`,
    ],
    vaeDecoder: [
      `[VAEDecoder] Decoding latents to pixel space`,
      `[VAEDecoder] ✓ Image decoded: 512×512px`,
    ],
    saveImage: [
      `[SaveImage] Saving to: ComfyFlow_00001.png`,
      `[SaveImage] ✓ Saved successfully`,
    ],
    loraLoader: [
      `[LoRALoader] Loading LoRA weights`,
      `[LoRALoader] Patching UNet attention layers`,
      `[LoRALoader] ✓ LoRA applied (strength=1.0)`,
    ],
  };

  const lines = msgs[nodeType] ?? [`[${nodeType}] Processing...`, `[${nodeType}] ✓ Done`];
  const delay = nodeType === 'kSampler' ? 280 : 120;

  for (let i = 0; i < lines.length; i++) {
    await new Promise(r => setTimeout(r, delay));
    onLog(lines[i]);
    onProgress(((i + 1) / lines.length) * 100);
  }
}

// Topological sort for execution order
function topologicalSort(nodes: Node[], edges: Edge[]): Node[] {
  const adj: Record<string, string[]> = {};
  const inDegree: Record<string, number> = {};

  nodes.forEach(n => {
    adj[n.id] = [];
    inDegree[n.id] = 0;
  });

  edges.forEach(e => {
    if (adj[e.source]) adj[e.source].push(e.target);
    if (e.target in inDegree) inDegree[e.target]++;
  });

  const queue = nodes.filter(n => inDegree[n.id] === 0).map(n => n.id);
  const sorted: string[] = [];

  while (queue.length) {
    const cur = queue.shift()!;
    sorted.push(cur);
    (adj[cur] || []).forEach(next => {
      inDegree[next]--;
      if (inDegree[next] === 0) queue.push(next);
    });
  }

  return sorted.map(id => nodes.find(n => n.id === id)!).filter(Boolean);
}

export const useWorkflowStore = create<WorkflowState>()(
  immer((set, get) => ({
    nodes: DEFAULT_NODES,
    edges: DEFAULT_EDGES,
    executionStatus: 'idle',
    executingNodeId: null,
    executionProgress: 0,
    executionLog: [],
    selectedNodeId: null,
    queueCount: 0,
    sidebarOpen: true,
    nodeSearchQuery: '',

    onNodesChange: (changes) => {
      set(state => {
        state.nodes = applyNodeChanges(changes, state.nodes) as Node[];
      });
    },

    onEdgesChange: (changes) => {
      set(state => {
        state.edges = applyEdgeChanges(changes, state.edges) as Edge[];
      });
    },

    onConnect: (connection) => {
      set(state => {
        // Color edges based on handle type
        const colorMap: Record<string, string> = {
          model: '#a78bfa',
          clip: '#fbbf24',
          vae: '#34d399',
          conditioning: '#f87171',
          negative: '#94a3b8',
          latent: '#fb923c',
          image: '#60a5fa',
          samples: '#fb923c',
          latent_image: '#fb923c',
          positive: '#f87171',
          mask: '#e879f9',
          control_net: '#38bdf8',
          lora: '#c084fc',
        };
        const handle = connection.sourceHandle ?? connection.targetHandle ?? '';
        const color = colorMap[handle] ?? '#64748b';

        const newEdge: Edge = {
          ...connection,
          id: `e-${nanoid(6)}`,
          type: 'smoothstep',
          animated: false,
          style: { stroke: color, strokeWidth: 2 },
          source: connection.source!,
          target: connection.target!,
        };
        state.edges = addEdge(newEdge, state.edges) as Edge[];
      });
    },

    addNode: (type, position) => {
      const id = `${type}-${nanoid(6)}`;
      const defaults = NODE_DEFAULTS[type] ?? { label: type };
      set(state => {
        state.nodes.push({
          id,
          type,
          position,
          data: { ...defaults },
        });
        state.selectedNodeId = id;
      });
    },

    updateNodeData: (nodeId, data) => {
      set(state => {
        const node = state.nodes.find(n => n.id === nodeId);
        if (node) {
          Object.assign(node.data, data);
        }
      });
    },

    deleteNode: (nodeId) => {
      set(state => {
        state.nodes = state.nodes.filter(n => n.id !== nodeId);
        state.edges = state.edges.filter(e => e.source !== nodeId && e.target !== nodeId);
        if (state.selectedNodeId === nodeId) state.selectedNodeId = null;
      });
    },

    duplicateNode: (sourceNodeId) => {
      const node = get().nodes.find(n => n.id === sourceNodeId);
      if (!node) return;
      const newId = `${node.type}-${nanoid(6)}`;
      set(state => {
        state.nodes.push({
          ...node,
          id: newId,
          position: { x: node.position.x + 40, y: node.position.y + 40 },
          data: { ...node.data },
          selected: false,
        });
        state.selectedNodeId = newId;
      });
    },

    selectNode: (nodeId) => {
      set(state => { state.selectedNodeId = nodeId; });
    },

    runWorkflow: async () => {
      const { nodes, edges } = get();
      const sorted = topologicalSort(nodes, edges);

      set(state => {
        state.executionStatus = 'running';
        state.executionLog = ['⚡ Workflow queued — starting execution...', ''];
        state.executionProgress = 0;
        state.queueCount += 1;
      });

      let nodeIndex = 0;
      for (const node of sorted) {
        set(state => {
          state.executingNodeId = node.id;
          state.executionLog.push(`▶ Executing: ${node.data.label as string}`);
        });

        // Highlight running edges
        set(state => {
          state.edges = state.edges.map(e =>
            e.source === node.id || e.target === node.id
              ? { ...e, animated: true }
              : e
          );
        });

        await simulateExecution(
          node.id,
          node.type ?? 'default',
          (msg) => set(state => { state.executionLog.push(msg); }),
          (p) => set(state => { state.executionProgress = p; })
        );

        // Stop animating
        set(state => {
          state.edges = state.edges.map(e =>
            e.source === node.id || e.target === node.id
              ? { ...e, animated: false }
              : e
          );
          state.executionLog.push('');
        });

        nodeIndex++;
      }

      set(state => {
        state.executionStatus = 'done';
        state.executingNodeId = null;
        state.executionProgress = 100;
        state.executionLog.push('✅ Workflow complete!');
      });

      setTimeout(() => {
        set(state => {
          if (state.executionStatus === 'done') state.executionStatus = 'idle';
        });
      }, 3000);
    },

    clearLog: () => {
      set(state => { state.executionLog = []; });
    },

    setSidebarOpen: (open) => {
      set(state => { state.sidebarOpen = open; });
    },

    setNodeSearchQuery: (q) => {
      set(state => { state.nodeSearchQuery = q; });
    },

    loadDefaultWorkflow: () => {
      set(state => {
        state.nodes = DEFAULT_NODES;
        state.edges = DEFAULT_EDGES;
        state.selectedNodeId = null;
        state.executionStatus = 'idle';
        state.executionLog = [];
        state.executingNodeId = null;
      });
    },

    clearWorkflow: () => {
      set(state => {
        state.nodes = [];
        state.edges = [];
        state.selectedNodeId = null;
        state.executionStatus = 'idle';
        state.executionLog = [];
      });
    },

    exportWorkflow: () => {
      const { nodes, edges } = get();
      return JSON.stringify({ nodes, edges, version: '1.0' }, null, 2);
    },

    importWorkflow: (json) => {
      try {
        const data = JSON.parse(json);
        set(state => {
          state.nodes = data.nodes ?? [];
          state.edges = data.edges ?? [];
          state.selectedNodeId = null;
        });
      } catch {
        console.error('Failed to import workflow');
      }
    },
  }))
);
