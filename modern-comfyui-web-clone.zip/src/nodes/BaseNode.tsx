import React from 'react';
import { Handle, Position, NodeProps } from '@xyflow/react';
import { useWorkflowStore } from '../store/workflowStore';
import { PORT_COLORS } from './nodeConfig';

export interface PortDef {
  id: string;
  label: string;
  type: keyof typeof PORT_COLORS;
}

interface BaseNodeProps extends NodeProps {
  title: string;
  color: string;
  icon: string;
  inputs?: PortDef[];
  outputs?: PortDef[];
  children?: React.ReactNode;
  minWidth?: number;
}

function getPortColor(type: string): string {
  return PORT_COLORS[type.toUpperCase()] ?? '#64748b';
}

export function BaseNode({
  id,
  title,
  color,
  icon,
  inputs = [],
  outputs = [],
  children,
  selected,
  minWidth = 280,
}: BaseNodeProps) {
  const { executingNodeId } = useWorkflowStore();
  const isRunning = executingNodeId === id;

  return (
    <div
      className="relative rounded-xl overflow-visible"
      style={{
        minWidth,
        background: 'rgba(15, 15, 20, 0.95)',
        border: isRunning
          ? `2px solid ${color}`
          : selected
          ? `2px solid rgba(255,255,255,0.4)`
          : '2px solid rgba(255,255,255,0.08)',
        boxShadow: isRunning
          ? `0 0 0 3px ${color}44, 0 8px 32px rgba(0,0,0,0.6)`
          : selected
          ? '0 0 0 2px rgba(255,255,255,0.15), 0 8px 32px rgba(0,0,0,0.5)'
          : '0 4px 24px rgba(0,0,0,0.5)',
        transition: 'all 0.15s ease',
      }}
    >
      {/* Running pulse ring */}
      {isRunning && (
        <div
          className="absolute inset-0 rounded-xl animate-ping"
          style={{
            background: 'transparent',
            border: `2px solid ${color}`,
            opacity: 0.3,
          }}
        />
      )}

      {/* Header */}
      <div
        className="flex items-center gap-2 px-3 py-2 rounded-t-xl"
        style={{
          background: `linear-gradient(135deg, ${color}33 0%, ${color}11 100%)`,
          borderBottom: `1px solid ${color}33`,
        }}
      >
        <span className="text-base leading-none">{icon}</span>
        <span
          className="text-xs font-semibold tracking-wide truncate"
          style={{ color: color === '#475569' ? '#94a3b8' : color, textShadow: `0 0 8px ${color}66` }}
        >
          {title}
        </span>
        {isRunning && (
          <div className="ml-auto flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: color, animationDelay: '0ms' }} />
            <div className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: color, animationDelay: '150ms' }} />
            <div className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: color, animationDelay: '300ms' }} />
          </div>
        )}
      </div>

      {/* Port handles */}
      <div className="relative flex">
        {/* Inputs */}
        {inputs.length > 0 && (
          <div className="flex flex-col gap-0">
                {inputs.map((port) => {
                  const portColor = getPortColor(port.type);
              return (
                <div key={port.id} className="relative flex items-center h-8">
                  <Handle
                    type="target"
                    position={Position.Left}
                    id={port.id}
                    style={{
                      left: -8,
                      background: portColor,
                      border: `2px solid rgba(0,0,0,0.5)`,
                      width: 14,
                      height: 14,
                      borderRadius: '50%',
                      zIndex: 10,
                    }}
                  />
                  <span className="ml-4 text-[10px] text-slate-400 font-medium pl-1 select-none">
                    {port.label}
                    <span className="ml-1 opacity-40 text-[9px]">[{port.type}]</span>
                  </span>
                </div>
              );
            })}
          </div>
        )}

        {/* Spacer / content */}
        <div className="flex-1 min-w-0" />

        {/* Outputs */}
        {outputs.length > 0 && (
          <div className="flex flex-col gap-0">
            {outputs.map((port) => {
              const portColor = getPortColor(port.type);
              return (
                <div key={port.id} className="relative flex items-center justify-end h-8">
                  <span className="mr-4 text-[10px] text-slate-400 font-medium pr-1 select-none text-right">
                    <span className="mr-1 opacity-40 text-[9px]">[{port.type}]</span>
                    {port.label}
                  </span>
                  <Handle
                    type="source"
                    position={Position.Right}
                    id={port.id}
                    style={{
                      right: -8,
                      background: portColor,
                      border: `2px solid rgba(0,0,0,0.5)`,
                      width: 14,
                      height: 14,
                      borderRadius: '50%',
                      zIndex: 10,
                    }}
                  />
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Body content */}
      {children && (
        <div className="px-3 pb-3 pt-1 border-t border-white/5 space-y-2">
          {children}
        </div>
      )}
    </div>
  );
}

// Shared widget components
export function NodeSelect({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
}) {
  return (
    <div className="space-y-1">
      <label className="text-[10px] text-slate-500 uppercase tracking-wider">{label}</label>
      <select
        value={value}
        onChange={e => onChange(e.target.value)}
        className="w-full bg-black/40 border border-white/10 rounded-md text-xs text-slate-200 px-2 py-1.5 focus:outline-none focus:border-white/30 cursor-pointer"
        onClick={e => e.stopPropagation()}
      >
        {options.map(o => (
          <option key={o} value={o} className="bg-slate-900">{o}</option>
        ))}
      </select>
    </div>
  );
}

export function NodeSlider({
  label,
  value,
  min,
  max,
  step,
  onChange,
  color = '#a78bfa',
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  color?: string;
}) {
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <label className="text-[10px] text-slate-500 uppercase tracking-wider">{label}</label>
        <span className="text-[11px] text-slate-300 font-mono tabular-nums">{value}</span>
      </div>
      <div className="relative">
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={e => onChange(parseFloat(e.target.value))}
          onClick={e => e.stopPropagation()}
          className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
          style={{
            background: `linear-gradient(to right, ${color} 0%, ${color} ${((value - min) / (max - min)) * 100}%, rgba(255,255,255,0.1) ${((value - min) / (max - min)) * 100}%, rgba(255,255,255,0.1) 100%)`,
          }}
        />
      </div>
    </div>
  );
}

export function NodeTextArea({
  label,
  value,
  onChange,
  rows = 3,
  placeholder = '',
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  rows?: number;
  placeholder?: string;
}) {
  return (
    <div className="space-y-1">
      <label className="text-[10px] text-slate-500 uppercase tracking-wider">{label}</label>
      <textarea
        value={value}
        onChange={e => onChange(e.target.value)}
        rows={rows}
        placeholder={placeholder}
        className="w-full bg-black/40 border border-white/10 rounded-md text-xs text-slate-200 px-2 py-1.5 focus:outline-none focus:border-white/30 resize-none placeholder:text-slate-600"
        onClick={e => e.stopPropagation()}
      />
    </div>
  );
}

export function NodeInput({
  label,
  value,
  onChange,
  type = 'text',
  placeholder = '',
}: {
  label: string;
  value: string | number;
  onChange: (v: string) => void;
  type?: string;
  placeholder?: string;
}) {
  return (
    <div className="space-y-1">
      <label className="text-[10px] text-slate-500 uppercase tracking-wider">{label}</label>
      <input
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-black/40 border border-white/10 rounded-md text-xs text-slate-200 px-2 py-1.5 focus:outline-none focus:border-white/30 placeholder:text-slate-600"
        onClick={e => e.stopPropagation()}
      />
    </div>
  );
}
