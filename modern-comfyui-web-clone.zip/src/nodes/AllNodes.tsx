
import { NodeProps } from '@xyflow/react';
import { useWorkflowStore } from '../store/workflowStore';
import {
  BaseNode,
  NodeSelect,
  NodeSlider,
  NodeTextArea,
  NodeInput,
} from './BaseNode';
import {
  CHECKPOINT_MODELS,
  LORA_MODELS,
  VAE_MODELS,
  SAMPLERS,
  SCHEDULERS,
  UPSCALE_METHODS,
  CONTROLNET_MODELS,
} from './nodeConfig';

// ─── Checkpoint Loader ───────────────────────────────────────────────────────
export function CheckpointLoaderNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);

  return (
    <BaseNode
      {...props}
      title="Load Checkpoint"
      color="#7c3aed"
      icon="🏛️"
      selected={selected}
      outputs={[
        { id: 'model', label: 'MODEL', type: 'MODEL' },
        { id: 'clip', label: 'CLIP', type: 'CLIP' },
        { id: 'vae', label: 'VAE', type: 'VAE' },
      ]}
      minWidth={300}
    >
      <NodeSelect
        label="Checkpoint"
        value={data.ckpt_name as string}
        options={CHECKPOINT_MODELS}
        onChange={v => updateNodeData(id, { ckpt_name: v })}
      />
      <div className="mt-2 grid grid-cols-3 gap-1 text-center">
        {['UNet', 'CLIP', 'VAE'].map(tag => (
          <div key={tag} className="bg-white/5 rounded text-[9px] text-slate-500 py-0.5">{tag}</div>
        ))}
      </div>
    </BaseNode>
  );
}

// ─── CLIP Text Encode ────────────────────────────────────────────────────────
export function ClipTextEncodeNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);
  const polarity = (data.polarity as string) ?? 'positive';
  const isPositive = polarity === 'positive';

  return (
    <BaseNode
      {...props}
      title={isPositive ? 'CLIP Text Encode (Positive)' : 'CLIP Text Encode (Negative)'}
      color={isPositive ? '#16a34a' : '#dc2626'}
      icon={isPositive ? '✅' : '❌'}
      selected={selected}
      inputs={[{ id: 'clip', label: 'CLIP', type: 'CLIP' }]}
      outputs={[{ id: 'conditioning', label: 'CONDITIONING', type: 'CONDITIONING' }]}
      minWidth={320}
    >
      <NodeTextArea
        label="Prompt"
        value={data.text as string}
        onChange={v => updateNodeData(id, { text: v })}
        rows={4}
        placeholder={isPositive ? 'Describe what you want...' : 'Describe what to avoid...'}
      />
    </BaseNode>
  );
}

// ─── KSampler ────────────────────────────────────────────────────────────────
export function KSamplerNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);

  return (
    <BaseNode
      {...props}
      title="KSampler"
      color="#dc2626"
      icon="⚡"
      selected={selected}
      inputs={[
        { id: 'model', label: 'MODEL', type: 'MODEL' },
        { id: 'positive', label: 'POSITIVE', type: 'CONDITIONING' },
        { id: 'negative', label: 'NEGATIVE', type: 'CONDITIONING' },
        { id: 'latent_image', label: 'LATENT', type: 'LATENT' },
      ]}
      outputs={[{ id: 'latent', label: 'LATENT', type: 'LATENT' }]}
      minWidth={310}
    >
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <NodeInput
            label="Seed"
            value={data.seed as number}
            onChange={v => updateNodeData(id, { seed: parseInt(v) || 0 })}
            type="number"
          />
          <button
            onClick={e => { e.stopPropagation(); updateNodeData(id, { seed: Math.floor(Math.random() * 9999999) }); }}
            className="mt-4 text-[10px] bg-white/5 hover:bg-white/10 border border-white/10 rounded px-2 py-1.5 text-slate-400 hover:text-white transition-colors whitespace-nowrap"
          >
            🎲 Rand
          </button>
        </div>
        <NodeSlider
          label="Steps"
          value={data.steps as number}
          min={1} max={150} step={1}
          onChange={v => updateNodeData(id, { steps: v })}
          color="#dc2626"
        />
        <NodeSlider
          label="CFG Scale"
          value={data.cfg as number}
          min={1} max={30} step={0.1}
          onChange={v => updateNodeData(id, { cfg: v })}
          color="#f97316"
        />
        <NodeSlider
          label="Denoise"
          value={data.denoise as number}
          min={0} max={1} step={0.01}
          onChange={v => updateNodeData(id, { denoise: v })}
          color="#fb923c"
        />
        <div className="grid grid-cols-2 gap-2">
          <NodeSelect
            label="Sampler"
            value={data.sampler_name as string}
            options={SAMPLERS}
            onChange={v => updateNodeData(id, { sampler_name: v })}
          />
          <NodeSelect
            label="Scheduler"
            value={data.scheduler as string}
            options={SCHEDULERS}
            onChange={v => updateNodeData(id, { scheduler: v })}
          />
        </div>
      </div>
    </BaseNode>
  );
}

// ─── KSampler Advanced ───────────────────────────────────────────────────────
export function KSamplerAdvancedNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);

  return (
    <BaseNode
      {...props}
      title="KSampler Advanced"
      color="#b91c1c"
      icon="⚙️"
      selected={selected}
      inputs={[
        { id: 'model', label: 'MODEL', type: 'MODEL' },
        { id: 'positive', label: 'POSITIVE', type: 'CONDITIONING' },
        { id: 'negative', label: 'NEGATIVE', type: 'CONDITIONING' },
        { id: 'latent_image', label: 'LATENT', type: 'LATENT' },
      ]}
      outputs={[
        { id: 'latent', label: 'LATENT', type: 'LATENT' },
      ]}
      minWidth={310}
    >
      <div className="space-y-2">
        <NodeInput label="Seed" value={(data.seed as number) ?? 42} onChange={v => updateNodeData(id, { seed: parseInt(v) || 0 })} type="number" />
        <NodeSlider label="Steps" value={(data.steps as number) ?? 20} min={1} max={150} step={1} onChange={v => updateNodeData(id, { steps: v })} color="#b91c1c" />
        <NodeSlider label="CFG Scale" value={(data.cfg as number) ?? 7.5} min={1} max={30} step={0.1} onChange={v => updateNodeData(id, { cfg: v })} color="#f97316" />
        <div className="grid grid-cols-2 gap-2">
          <NodeInput label="Start Step" value={(data.start_at_step as number) ?? 0} onChange={v => updateNodeData(id, { start_at_step: parseInt(v) })} type="number" />
          <NodeInput label="End Step" value={(data.end_at_step as number) ?? 20} onChange={v => updateNodeData(id, { end_at_step: parseInt(v) })} type="number" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <NodeSelect label="Sampler" value={(data.sampler_name as string) ?? 'euler'} options={SAMPLERS} onChange={v => updateNodeData(id, { sampler_name: v })} />
          <NodeSelect label="Scheduler" value={(data.scheduler as string) ?? 'karras'} options={SCHEDULERS} onChange={v => updateNodeData(id, { scheduler: v })} />
        </div>
        <div className="flex items-center gap-2">
          <input type="checkbox" id={`return-with-leftover-${id}`} checked={(data.return_with_leftover_noise as boolean) ?? false}
            onChange={e => { e.stopPropagation(); updateNodeData(id, { return_with_leftover_noise: e.target.checked }); }}
            className="rounded" />
          <label htmlFor={`return-with-leftover-${id}`} className="text-[10px] text-slate-400 select-none">Return with leftover noise</label>
        </div>
      </div>
    </BaseNode>
  );
}

// ─── Empty Latent Image ──────────────────────────────────────────────────────
export function EmptyLatentImageNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);

  const PRESETS = ['512×512', '768×512', '512×768', '1024×1024', '1280×720', '720×1280'];
  const PRESET_VALUES: Record<string, [number, number]> = {
    '512×512': [512, 512], '768×512': [768, 512], '512×768': [512, 768],
    '1024×1024': [1024, 1024], '1280×720': [1280, 720], '720×1280': [720, 1280],
  };

  return (
    <BaseNode
      {...props}
      title="Empty Latent Image"
      color="#ea580c"
      icon="🌫️"
      selected={selected}
      outputs={[{ id: 'latent', label: 'LATENT', type: 'LATENT' }]}
      minWidth={280}
    >
      <div className="space-y-2">
        <div className="grid grid-cols-3 gap-1">
          {PRESETS.map(p => (
            <button
              key={p}
              onClick={e => {
                e.stopPropagation();
                const [w, h] = PRESET_VALUES[p];
                updateNodeData(id, { width: w, height: h });
              }}
              className="text-[9px] bg-white/5 hover:bg-white/10 border border-white/10 rounded py-0.5 text-slate-400 hover:text-white transition-colors"
            >{p}</button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-2">
          <NodeSlider label="Width" value={data.width as number} min={64} max={2048} step={64} onChange={v => updateNodeData(id, { width: v })} color="#ea580c" />
          <NodeSlider label="Height" value={data.height as number} min={64} max={2048} step={64} onChange={v => updateNodeData(id, { height: v })} color="#fb923c" />
        </div>
        <NodeSlider label="Batch Size" value={(data.batch_size as number) ?? 1} min={1} max={16} step={1} onChange={v => updateNodeData(id, { batch_size: v })} color="#f97316" />
      </div>
    </BaseNode>
  );
}

// ─── VAE Decoder ─────────────────────────────────────────────────────────────
export function VAEDecoderNode(props: NodeProps) {
  const { selected } = props;
  return (
    <BaseNode
      {...props}
      title="VAE Decode"
      color="#0891b2"
      icon="🖼️"
      selected={selected}
      inputs={[
        { id: 'samples', label: 'LATENT', type: 'LATENT' },
        { id: 'vae', label: 'VAE', type: 'VAE' },
      ]}
      outputs={[{ id: 'image', label: 'IMAGE', type: 'IMAGE' }]}
      minWidth={250}
    >
      <div className="text-[10px] text-slate-600 text-center py-1">
        Converts latent tensors → pixel images
      </div>
    </BaseNode>
  );
}

// ─── VAE Encoder ─────────────────────────────────────────────────────────────
export function VAEEncoderNode(props: NodeProps) {
  const { selected } = props;
  return (
    <BaseNode
      {...props}
      title="VAE Encode"
      color="#0e7490"
      icon="📦"
      selected={selected}
      inputs={[
        { id: 'pixels', label: 'IMAGE', type: 'IMAGE' },
        { id: 'vae', label: 'VAE', type: 'VAE' },
      ]}
      outputs={[{ id: 'latent', label: 'LATENT', type: 'LATENT' }]}
      minWidth={250}
    >
      <div className="text-[10px] text-slate-600 text-center py-1">
        Encodes pixel image → latent space
      </div>
    </BaseNode>
  );
}

// ─── VAE Loader ──────────────────────────────────────────────────────────────
export function VAELoaderNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);
  return (
    <BaseNode
      {...props}
      title="Load VAE"
      color="#059669"
      icon="🔷"
      selected={selected}
      outputs={[{ id: 'vae', label: 'VAE', type: 'VAE' }]}
      minWidth={280}
    >
      <NodeSelect
        label="VAE Model"
        value={(data.vae_name as string) ?? VAE_MODELS[0]}
        options={VAE_MODELS}
        onChange={v => updateNodeData(id, { vae_name: v })}
      />
    </BaseNode>
  );
}

// ─── Save Image ──────────────────────────────────────────────────────────────
export function SaveImageNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);
  return (
    <BaseNode
      {...props}
      title="Save Image"
      color="#1d4ed8"
      icon="💾"
      selected={selected}
      inputs={[{ id: 'images', label: 'IMAGE', type: 'IMAGE' }]}
      minWidth={260}
    >
      <NodeInput
        label="Filename Prefix"
        value={data.filename_prefix as string}
        onChange={v => updateNodeData(id, { filename_prefix: v })}
        placeholder="ComfyFlow"
      />
      <div className="text-[10px] text-slate-600 text-center mt-1">
        Saves to output/{data.filename_prefix as string}_00001.png
      </div>
    </BaseNode>
  );
}

// ─── Load Image ──────────────────────────────────────────────────────────────
export function LoadImageNode(props: NodeProps) {
  const { selected } = props;
  return (
    <BaseNode
      {...props}
      title="Load Image"
      color="#7c3aed"
      icon="🖼️"
      selected={selected}
      outputs={[
        { id: 'image', label: 'IMAGE', type: 'IMAGE' },
        { id: 'mask', label: 'MASK', type: 'MASK' },
      ]}
      minWidth={260}
    >
      <div
        className="border-2 border-dashed border-white/10 rounded-lg p-4 text-center cursor-pointer hover:border-white/20 transition-colors"
        onClick={e => e.stopPropagation()}
      >
        <div className="text-xl mb-1">📁</div>
        <div className="text-[10px] text-slate-500">Click to load image</div>
        <div className="text-[9px] text-slate-600 mt-0.5">PNG, JPG, WEBP</div>
      </div>
    </BaseNode>
  );
}

// ─── Preview Image ───────────────────────────────────────────────────────────
export function ImagePreviewNode(props: NodeProps) {
  const { selected } = props;
  return (
    <BaseNode
      {...props}
      title="Preview Image"
      color="#0284c7"
      icon="👁️"
      selected={selected}
      inputs={[{ id: 'images', label: 'IMAGE', type: 'IMAGE' }]}
      minWidth={260}
    >
      <div className="bg-black/40 rounded-lg aspect-square flex items-center justify-center border border-white/5">
        <div className="text-center">
          <div className="text-3xl opacity-20">🖼️</div>
          <div className="text-[9px] text-slate-700 mt-1">Preview will appear here</div>
        </div>
      </div>
    </BaseNode>
  );
}

// ─── LoRA Loader ─────────────────────────────────────────────────────────────
export function LoRALoaderNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);
  return (
    <BaseNode
      {...props}
      title="Load LoRA"
      color="#7c3aed"
      icon="🔌"
      selected={selected}
      inputs={[
        { id: 'model', label: 'MODEL', type: 'MODEL' },
        { id: 'clip', label: 'CLIP', type: 'CLIP' },
      ]}
      outputs={[
        { id: 'model', label: 'MODEL', type: 'MODEL' },
        { id: 'clip', label: 'CLIP', type: 'CLIP' },
      ]}
      minWidth={300}
    >
      <NodeSelect
        label="LoRA"
        value={(data.lora_name as string) ?? LORA_MODELS[0]}
        options={LORA_MODELS}
        onChange={v => updateNodeData(id, { lora_name: v })}
      />
      <NodeSlider
        label="Model Strength"
        value={(data.strength_model as number) ?? 1.0}
        min={-2} max={2} step={0.01}
        onChange={v => updateNodeData(id, { strength_model: v })}
        color="#7c3aed"
      />
      <NodeSlider
        label="CLIP Strength"
        value={(data.strength_clip as number) ?? 1.0}
        min={-2} max={2} step={0.01}
        onChange={v => updateNodeData(id, { strength_clip: v })}
        color="#a78bfa"
      />
    </BaseNode>
  );
}

// ─── ControlNet Apply ────────────────────────────────────────────────────────
export function ControlNetApplyNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);
  return (
    <BaseNode
      {...props}
      title="Apply ControlNet"
      color="#0369a1"
      icon="🕹️"
      selected={selected}
      inputs={[
        { id: 'conditioning', label: 'CONDITIONING', type: 'CONDITIONING' },
        { id: 'control_net', label: 'CONTROL_NET', type: 'CONTROL_NET' },
        { id: 'image', label: 'IMAGE', type: 'IMAGE' },
      ]}
      outputs={[{ id: 'conditioning', label: 'CONDITIONING', type: 'CONDITIONING' }]}
      minWidth={290}
    >
      <NodeSelect
        label="ControlNet Model"
        value={(data.controlnet_name as string) ?? CONTROLNET_MODELS[0]}
        options={CONTROLNET_MODELS}
        onChange={v => updateNodeData(id, { controlnet_name: v })}
      />
      <NodeSlider
        label="Strength"
        value={(data.strength as number) ?? 1.0}
        min={0} max={2} step={0.01}
        onChange={v => updateNodeData(id, { strength: v })}
        color="#0369a1"
      />
      <div className="grid grid-cols-2 gap-2">
        <NodeInput label="Start %" value={(data.start_percent as number) ?? 0} onChange={v => updateNodeData(id, { start_percent: parseFloat(v) })} type="number" />
        <NodeInput label="End %" value={(data.end_percent as number) ?? 1} onChange={v => updateNodeData(id, { end_percent: parseFloat(v) })} type="number" />
      </div>
    </BaseNode>
  );
}

// ─── Upscale Image ───────────────────────────────────────────────────────────
export function UpscaleImageNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);
  return (
    <BaseNode
      {...props}
      title="Upscale Image"
      color="#059669"
      icon="🔍"
      selected={selected}
      inputs={[{ id: 'image', label: 'IMAGE', type: 'IMAGE' }]}
      outputs={[{ id: 'image', label: 'IMAGE', type: 'IMAGE' }]}
      minWidth={280}
    >
      <NodeSelect
        label="Method"
        value={(data.upscale_method as string) ?? 'lanczos'}
        options={UPSCALE_METHODS}
        onChange={v => updateNodeData(id, { upscale_method: v })}
      />
      <NodeSlider
        label="Scale Factor"
        value={(data.scale_by as number) ?? 2.0}
        min={0.5} max={8} step={0.1}
        onChange={v => updateNodeData(id, { scale_by: v })}
        color="#059669"
      />
    </BaseNode>
  );
}

// ─── Note ────────────────────────────────────────────────────────────────────
export function NoteNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);
  return (
    <BaseNode
      {...props}
      title="Note"
      color="#64748b"
      icon="📝"
      selected={selected}
      minWidth={240}
    >
      <textarea
        value={data.content as string}
        onChange={e => { e.stopPropagation(); updateNodeData(id, { content: e.target.value }); }}
        rows={4}
        className="w-full bg-yellow-500/5 border border-yellow-500/20 rounded text-xs text-yellow-200/80 px-2 py-1.5 focus:outline-none resize-none placeholder:text-slate-600"
        onClick={e => e.stopPropagation()}
        placeholder="Add notes..."
        style={{ fontFamily: "'Segoe UI', sans-serif" }}
      />
    </BaseNode>
  );
}

// ─── Primitive Nodes ─────────────────────────────────────────────────────────
export function PrimitiveIntNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);
  return (
    <BaseNode {...props} title="Integer" color="#475569" icon="🔢" selected={selected} outputs={[{ id: 'value', label: 'INT', type: 'INT' }]} minWidth={200}>
      <NodeInput label="Value" value={data.value as number} onChange={v => updateNodeData(id, { value: parseInt(v) })} type="number" />
    </BaseNode>
  );
}

export function PrimitiveFloatNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);
  return (
    <BaseNode {...props} title="Float" color="#475569" icon="🔣" selected={selected} outputs={[{ id: 'value', label: 'FLOAT', type: 'FLOAT' }]} minWidth={200}>
      <NodeInput label="Value" value={data.value as number} onChange={v => updateNodeData(id, { value: parseFloat(v) })} type="number" />
    </BaseNode>
  );
}

export function PrimitiveStringNode(props: NodeProps) {
  const { id, data, selected } = props;
  const updateNodeData = useWorkflowStore(s => s.updateNodeData);
  return (
    <BaseNode {...props} title="String" color="#475569" icon="🔤" selected={selected} outputs={[{ id: 'value', label: 'STRING', type: 'STRING' }]} minWidth={220}>
      <NodeInput label="Value" value={data.value as string} onChange={v => updateNodeData(id, { value: v })} />
    </BaseNode>
  );
}

// ─── Node type map ───────────────────────────────────────────────────────────
export const NODE_TYPES = {
  checkpointLoader: CheckpointLoaderNode,
  clipTextEncode: ClipTextEncodeNode,
  kSampler: KSamplerNode,
  kSamplerAdvanced: KSamplerAdvancedNode,
  emptyLatentImage: EmptyLatentImageNode,
  vaeDecoder: VAEDecoderNode,
  vaeEncoder: VAEEncoderNode,
  vaeLoader: VAELoaderNode,
  saveImage: SaveImageNode,
  loadImage: LoadImageNode,
  imagePreview: ImagePreviewNode,
  loraLoader: LoRALoaderNode,
  controlnetApply: ControlNetApplyNode,
  upscaleImage: UpscaleImageNode,
  note: NoteNode,
  primitiveInt: PrimitiveIntNode,
  primitiveFloat: PrimitiveFloatNode,
  primitiveString: PrimitiveStringNode,
};
