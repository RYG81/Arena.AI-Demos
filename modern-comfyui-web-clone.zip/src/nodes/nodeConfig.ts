// Node registry: defines all available node categories and metadata
export interface NodeDef {
  type: string;
  label: string;
  category: string;
  description: string;
  color: string;
  icon: string;
}

export const NODE_CATEGORIES = [
  'Loaders',
  'Conditioning',
  'Latent',
  'Sampling',
  'Image',
  'LoRA',
  'Upscaling',
  'Primitives',
  'Utils',
] as const;

export type NodeCategory = typeof NODE_CATEGORIES[number];

export const NODE_REGISTRY: NodeDef[] = [
  // Loaders
  { type: 'checkpointLoader', label: 'Load Checkpoint', category: 'Loaders', description: 'Loads a diffusion model checkpoint (UNet, CLIP, VAE)', color: '#7c3aed', icon: '🏛️' },
  { type: 'loraLoader', label: 'Load LoRA', category: 'Loaders', description: 'Load and apply a LoRA weight to a model', color: '#7c3aed', icon: '🔌' },
  { type: 'vaeLoader', label: 'Load VAE', category: 'Loaders', description: 'Load a separate VAE encoder/decoder', color: '#7c3aed', icon: '🔷' },
  { type: 'loadImage', label: 'Load Image', category: 'Loaders', description: 'Load an image from disk', color: '#7c3aed', icon: '🖼️' },

  // Conditioning
  { type: 'clipTextEncode', label: 'CLIP Text Encode', category: 'Conditioning', description: 'Encode text prompt into CLIP conditioning embeddings', color: '#d97706', icon: '✍️' },
  { type: 'controlnetApply', label: 'Apply ControlNet', category: 'Conditioning', description: 'Apply ControlNet conditioning to a model', color: '#d97706', icon: '🕹️' },

  // Latent
  { type: 'emptyLatentImage', label: 'Empty Latent', category: 'Latent', description: 'Create an empty latent tensor (noise) for generation', color: '#ea580c', icon: '🌫️' },
  { type: 'vaeEncoder', label: 'VAE Encode', category: 'Latent', description: 'Encode a pixel image into latent space', color: '#ea580c', icon: '📦' },

  // Sampling
  { type: 'kSampler', label: 'KSampler', category: 'Sampling', description: 'Core diffusion sampler — denoises latent using a chosen algorithm', color: '#dc2626', icon: '⚡' },
  { type: 'kSamplerAdvanced', label: 'KSampler Advanced', category: 'Sampling', description: 'Advanced KSampler with start/end step control', color: '#dc2626', icon: '⚙️' },

  // Image
  { type: 'vaeDecoder', label: 'VAE Decode', category: 'Image', description: 'Decode latent tensor to pixel image', color: '#0891b2', icon: '🖼️' },
  { type: 'saveImage', label: 'Save Image', category: 'Image', description: 'Save generated image to disk', color: '#0891b2', icon: '💾' },
  { type: 'imagePreview', label: 'Preview Image', category: 'Image', description: 'Preview image in the UI without saving', color: '#0891b2', icon: '👁️' },

  // Upscaling
  { type: 'upscaleImage', label: 'Upscale Image', category: 'Upscaling', description: 'Upscale image using a selected algorithm', color: '#059669', icon: '🔍' },

  // Primitives
  { type: 'primitiveInt', label: 'Integer', category: 'Primitives', description: 'Integer primitive value', color: '#475569', icon: '🔢' },
  { type: 'primitiveFloat', label: 'Float', category: 'Primitives', description: 'Float primitive value', color: '#475569', icon: '🔣' },
  { type: 'primitiveString', label: 'String', category: 'Primitives', description: 'String primitive value', color: '#475569', icon: '🔤' },

  // Utils
  { type: 'note', label: 'Note', category: 'Utils', description: 'Add a sticky note to your workflow', color: '#64748b', icon: '📝' },
];

// Port (handle) type colors
export const PORT_COLORS: Record<string, string> = {
  MODEL: '#a78bfa',
  CLIP: '#fbbf24',
  VAE: '#34d399',
  CONDITIONING: '#f87171',
  LATENT: '#fb923c',
  IMAGE: '#60a5fa',
  MASK: '#e879f9',
  CONTROL_NET: '#38bdf8',
  LORA: '#c084fc',
  INT: '#94a3b8',
  FLOAT: '#94a3b8',
  STRING: '#94a3b8',
};

// Available models (simulated)
export const CHECKPOINT_MODELS = [
  'v1-5-pruned-emaonly.safetensors',
  'dreamshaper_8.safetensors',
  'realisticVisionV60B1.safetensors',
  'sdxl_base_1.0.safetensors',
  'sd_xl_refiner_1.0.safetensors',
  'juggernautXL_v8.safetensors',
  'flux1-dev-fp8.safetensors',
];

export const LORA_MODELS = [
  'lcm-lora-sdv1-5.safetensors',
  'add_detail.safetensors',
  'more_details.safetensors',
  'epiNoiseoffset_v2.safetensors',
];

export const VAE_MODELS = [
  'vae-ft-mse-840000-ema-pruned.safetensors',
  'sdxl_vae.safetensors',
  'blessed2.vae.pt',
];

export const SAMPLERS = [
  'euler', 'euler_ancestral', 'heun', 'heunpp2', 'dpm_2',
  'dpm_2_ancestral', 'lms', 'dpm_fast', 'dpm_adaptive',
  'dpmpp_2s_ancestral', 'dpmpp_sde', 'dpmpp_sde_gpu',
  'dpmpp_2m', 'dpmpp_2m_sde', 'dpmpp_2m_sde_gpu',
  'dpmpp_3m_sde', 'dpmpp_3m_sde_gpu', 'ddpm', 'lcm', 'ddim', 'uni_pc',
];

export const SCHEDULERS = [
  'normal', 'karras', 'exponential', 'sgm_uniform', 'simple', 'ddim_uniform',
];

export const UPSCALE_METHODS = [
  'nearest-exact', 'bilinear', 'area', 'bicubic', 'lanczos',
];

export const CONTROLNET_MODELS = [
  'control_v11p_sd15_canny.pth',
  'control_v11p_sd15_openpose.pth',
  'control_v11f1p_sd15_depth.pth',
  'control_v11p_sd15_scribble.pth',
];
