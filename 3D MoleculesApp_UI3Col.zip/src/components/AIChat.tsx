import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, Key, GraduationCap, AlertCircle, RefreshCw, Sparkles } from 'lucide-react';
import type { ChatMessage, MoleculeData, ExplanationLevel } from '../types/molecule';
import { sendChatMessage, generateMoleculeExplanation } from '../utils/openai';

interface AIChatProps {
  molecule: MoleculeData | null;
  apiKey: string;
  onApiKeyChange: (key: string) => void;
}

const SUGGESTED_QUESTIONS = [
  'What is the geometry of this molecule?',
  'Why is this molecule polar or nonpolar?',
  'Explain the hybridization of the central atom.',
  'What are the bond angles and why?',
  'How does this molecule interact with water?',
  'What makes this molecule biologically active?',
];

export default function AIChat({ molecule, apiKey, onApiKeyChange }: AIChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [level, setLevel] = useState<ExplanationLevel>('intermediate');
  const [showApiKey, setShowApiKey] = useState(false);
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isGeneratingIntro, setIsGeneratingIntro] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (msg?: string) => {
    const text = (msg || input).trim();
    if (!text || isLoading) return;
    if (!apiKey) { setShowApiKey(true); return; }

    const userMsg: ChatMessage = { role: 'user', content: text, timestamp: new Date() };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);
    setError(null);

    try {
      const response = await sendChatMessage(
        apiKey,
        newMessages.filter(m => m.role !== 'system'),
        molecule,
        level
      );
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      }]);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateIntro = async () => {
    if (!molecule || !apiKey) { if (!apiKey) setShowApiKey(true); return; }
    setIsGeneratingIntro(true);
    setError(null);
    try {
      const intro = await generateMoleculeExplanation(apiKey, molecule, level);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: intro,
        timestamp: new Date(),
      }]);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setIsGeneratingIntro(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSaveKey = () => {
    if (apiKeyInput.trim()) {
      onApiKeyChange(apiKeyInput.trim());
      setApiKeyInput('');
      setShowApiKey(false);
    }
  };

  const levelColors: Record<ExplanationLevel, string> = {
    beginner: 'bg-green-600',
    intermediate: 'bg-yellow-600',
    advanced: 'bg-purple-600',
  };

  return (
    <div className="flex flex-col bg-slate-800 border border-slate-700 rounded-xl overflow-hidden h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-b border-slate-700 flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center">
            <Bot size={15} className="text-white" />
          </div>
          <span className="font-semibold text-white text-sm">MoleculeAI Tutor</span>
          <span className="text-xs text-slate-500">gpt-4o-mini</span>
        </div>
        <div className="flex items-center gap-2">
          {/* Level selector */}
          <div className="flex items-center gap-1 bg-slate-900 rounded-lg p-0.5">
            <GraduationCap size={13} className="text-slate-400 ml-1.5" />
            {(['beginner', 'intermediate', 'advanced'] as ExplanationLevel[]).map(l => (
              <button
                key={l}
                onClick={() => setLevel(l)}
                className={`px-2 py-1 rounded text-xs font-medium capitalize transition-all ${
                  level === l ? `${levelColors[l]} text-white` : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {l === 'beginner' ? '🟢' : l === 'intermediate' ? '🟡' : '🟣'} {l.slice(0, 3)}
              </button>
            ))}
          </div>
          <button
            onClick={() => setShowApiKey(!showApiKey)}
            className={`p-1.5 rounded-lg transition-all ${
              apiKey ? 'bg-green-700/40 text-green-400' : 'bg-red-800/40 text-red-400 animate-pulse'
            }`}
            title={apiKey ? 'API Key Set' : 'Set OpenAI API Key'}
          >
            <Key size={13} />
          </button>
        </div>
      </div>

      {/* API Key Input */}
      {showApiKey && (
        <div className="px-4 py-3 bg-slate-900/60 border-b border-slate-700 flex-shrink-0">
          <p className="text-xs text-slate-400 mb-2">
            🔑 Enter your <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline">OpenAI API key</a> to enable AI explanations:
          </p>
          <div className="flex gap-2">
            <input
              type="password"
              value={apiKeyInput}
              onChange={e => setApiKeyInput(e.target.value)}
              placeholder="sk-proj-..."
              className="flex-1 px-3 py-1.5 bg-slate-800 border border-slate-600 rounded-lg text-white text-xs placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              onKeyDown={e => e.key === 'Enter' && handleSaveKey()}
            />
            <button
              onClick={handleSaveKey}
              disabled={!apiKeyInput.trim()}
              className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-700 text-white text-xs rounded-lg font-medium transition-all"
            >
              Save
            </button>
          </div>
          {apiKey && (
            <p className="text-xs text-green-400 mt-1.5 flex items-center gap-1">
              ✓ API key active ({apiKey.slice(0, 8)}...)
            </p>
          )}
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center py-8 space-y-4">
            <div className="w-12 h-12 bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/30 rounded-xl flex items-center justify-center">
              <Bot size={24} className="text-cyan-400" />
            </div>
            <div>
              <p className="text-slate-300 text-sm font-medium">AI Chemistry Tutor</p>
              <p className="text-slate-500 text-xs mt-1">
                {molecule
                  ? `Ask me anything about ${molecule.name}!`
                  : 'Load a molecule first to get started'}
              </p>
            </div>
            {molecule && apiKey && (
              <button
                onClick={handleGenerateIntro}
                disabled={isGeneratingIntro}
                className="flex items-center gap-2 px-4 py-2 bg-cyan-600/20 border border-cyan-500/40 hover:bg-cyan-600/30 text-cyan-300 rounded-lg text-sm transition-all"
              >
                {isGeneratingIntro ? (
                  <Loader2 size={14} className="animate-spin" />
                ) : (
                  <Sparkles size={14} />
                )}
                Generate AI Introduction
              </button>
            )}
            {!apiKey && (
              <button
                onClick={() => setShowApiKey(true)}
                className="flex items-center gap-2 px-4 py-2 bg-red-800/30 border border-red-700/50 hover:bg-red-800/50 text-red-300 rounded-lg text-xs transition-all"
              >
                <Key size={12} />
                Set API Key to Enable AI
              </button>
            )}
          </div>
        )}

        {messages.map((msg, i) => (
          <div key={i} className={`flex gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {msg.role === 'assistant' && (
              <div className="w-6 h-6 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                <Bot size={13} className="text-white" />
              </div>
            )}
            <div
              className={`max-w-[85%] rounded-xl px-3 py-2.5 text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-cyan-700/60 text-white rounded-br-sm'
                  : 'bg-slate-700/80 text-slate-100 rounded-bl-sm border border-slate-600/50'
              }`}
            >
              <div className="whitespace-pre-wrap">{msg.content}</div>
              {msg.timestamp && (
                <div className={`text-xs mt-1 ${msg.role === 'user' ? 'text-cyan-200/60 text-right' : 'text-slate-500'}`}>
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              )}
            </div>
            {msg.role === 'user' && (
              <div className="w-6 h-6 bg-slate-600 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                <User size={13} className="text-slate-300" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex gap-2.5 justify-start">
            <div className="w-6 h-6 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <Bot size={13} className="text-white" />
            </div>
            <div className="bg-slate-700/80 rounded-xl rounded-bl-sm border border-slate-600/50 px-3 py-2.5">
              <div className="flex gap-1 items-center">
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="flex items-start gap-2 bg-red-900/30 border border-red-700/50 rounded-lg p-2.5 text-xs text-red-300">
            <AlertCircle size={13} className="flex-shrink-0 mt-0.5" />
            <div>
              <strong>Error:</strong> {error}
              {error.includes('API key') && (
                <button onClick={() => setShowApiKey(true)} className="ml-2 text-red-200 underline">Set API Key</button>
              )}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Questions */}
      {molecule && messages.length > 0 && !isLoading && (
        <div className="px-3 py-2 border-t border-slate-700 flex-shrink-0">
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {SUGGESTED_QUESTIONS.slice(0, 4).map(q => (
              <button
                key={q}
                onClick={() => handleSend(q)}
                disabled={isLoading || !apiKey}
                className="flex-shrink-0 px-2.5 py-1 bg-slate-700 hover:bg-slate-600 border border-slate-600 text-xs text-slate-300 rounded-full transition-all disabled:opacity-50 whitespace-nowrap"
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="px-3 py-3 border-t border-slate-700 flex-shrink-0">
        <div className="flex gap-2 items-end">
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={
              !apiKey ? 'Set your OpenAI API key first...' :
              !molecule ? 'Load a molecule to ask questions...' :
              `Ask about ${molecule.name}... (Enter to send)`
            }
            disabled={!apiKey || isLoading}
            rows={1}
            className="flex-1 px-3 py-2 bg-slate-900 border border-slate-600 rounded-xl text-white text-sm placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/20 resize-none transition-all disabled:opacity-50 min-h-[40px] max-h-[120px]"
            style={{ height: 'auto' }}
            onInput={e => {
              const t = e.target as HTMLTextAreaElement;
              t.style.height = 'auto';
              t.style.height = Math.min(t.scrollHeight, 120) + 'px';
            }}
          />
          <div className="flex flex-col gap-1">
            <button
              onClick={() => handleSend()}
              disabled={!input.trim() || !apiKey || isLoading}
              className="p-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-700 disabled:text-slate-500 text-white rounded-xl transition-all"
            >
              {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
            </button>
            {messages.length > 0 && (
              <button
                onClick={() => setMessages([])}
                className="p-2 bg-slate-700 hover:bg-slate-600 text-slate-400 rounded-xl transition-all"
                title="Clear chat"
              >
                <RefreshCw size={14} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
