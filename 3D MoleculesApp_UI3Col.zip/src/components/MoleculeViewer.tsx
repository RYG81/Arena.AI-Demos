import { useEffect, useRef, useState, useCallback } from 'react';
import { RotateCcw, ZoomIn, ZoomOut, Box, Circle, Maximize2 } from 'lucide-react';
import type { ViewMode } from '../types/molecule';
import WelcomeBanner from './WelcomeBanner';

declare global {
  interface Window {
    $3Dmol: any;
  }
}

interface MoleculeViewerProps {
  sdf: string | null;
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  onExampleSearch?: (name: string) => void;
}

const STYLE_MAP: Record<ViewMode, any> = {
  stick: { stick: { radius: 0.15, colorscheme: 'Jmol' }, sphere: { radius: 0.3, colorscheme: 'Jmol' } },
  sphere: { sphere: { colorscheme: 'Jmol', scale: 1.0 } },
  line: { line: { colorscheme: 'Jmol' } },
  cartoon: { stick: { radius: 0.12, colorscheme: 'Jmol' }, sphere: { radius: 0.5, colorscheme: 'Jmol' } },
};

export default function MoleculeViewer({ sdf, viewMode, onViewModeChange, onExampleSearch }: MoleculeViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const script3dmolRef = useRef<HTMLScriptElement | null>(null);

  const initViewer = useCallback(() => {
    if (!containerRef.current || !window.$3Dmol) return;
    if (viewerRef.current) {
      try { viewerRef.current.clear(); } catch {}
    }
    viewerRef.current = window.$3Dmol.createViewer(containerRef.current, {
      backgroundColor: '#0f172a',
      antialias: true,
    });
  }, []);

  const loadMolecule = useCallback(() => {
    if (!viewerRef.current || !sdf) return;
    setIsLoading(true);
    setError(null);
    try {
      viewerRef.current.removeAllModels();
      viewerRef.current.addModel(sdf, 'sdf');
      viewerRef.current.setStyle({}, STYLE_MAP[viewMode]);
      viewerRef.current.addSurface(window.$3Dmol.SurfaceType.VDW, {
        opacity: 0.05,
        color: 'white',
      });
      viewerRef.current.zoomTo();
      viewerRef.current.render();
    } catch (e: any) {
      setError('Failed to render molecule: ' + e.message);
    } finally {
      setIsLoading(false);
    }
  }, [sdf, viewMode]);

  useEffect(() => {
    const load3Dmol = () => {
      if (window.$3Dmol) {
        initViewer();
        return;
      }
      const script = document.createElement('script');
      script.src = 'https://3dmol.org/build/3Dmol-min.js';
      script.async = true;
      script.onload = () => initViewer();
      script.onerror = () => setError('Failed to load 3Dmol.js');
      document.head.appendChild(script);
      script3dmolRef.current = script;
    };
    load3Dmol();
    return () => {
      if (viewerRef.current) {
        try { viewerRef.current.clear(); } catch {}
      }
    };
  }, [initViewer]);

  useEffect(() => {
    if (!viewerRef.current && window.$3Dmol) initViewer();
    if (sdf && viewerRef.current) loadMolecule();
  }, [sdf, loadMolecule, initViewer]);

  useEffect(() => {
    if (viewerRef.current && sdf) {
      try {
        viewerRef.current.setStyle({}, STYLE_MAP[viewMode]);
        viewerRef.current.render();
      } catch {}
    }
  }, [viewMode, sdf]);

  const handleReset = () => {
    if (viewerRef.current) {
      viewerRef.current.zoomTo();
      viewerRef.current.render();
    }
  };

  const handleZoom = (factor: number) => {
    if (viewerRef.current) {
      viewerRef.current.zoom(factor);
      viewerRef.current.render();
    }
  };

  const viewModes: { mode: ViewMode; label: string; icon: React.ReactNode }[] = [
    { mode: 'stick', label: 'Ball & Stick', icon: <Box size={14} /> },
    { mode: 'sphere', label: 'Space Fill', icon: <Circle size={14} /> },
    { mode: 'line', label: 'Wireframe', icon: <span className="text-xs font-mono">⌗</span> },
    { mode: 'cartoon', label: 'Thick Stick', icon: <span className="text-xs">◎</span> },
  ];

  return (
    <div className={`flex flex-col bg-slate-900 rounded-xl overflow-hidden border border-slate-700 ${isFullscreen ? 'fixed inset-4 z-50' : 'h-full'}`}>
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-800 border-b border-slate-700">
        <div className="flex gap-1">
          {viewModes.map(({ mode, label, icon }) => (
            <button
              key={mode}
              onClick={() => onViewModeChange(mode)}
              className={`flex items-center gap-1 px-2 py-1 rounded text-xs font-medium transition-all ${
                viewMode === mode
                  ? 'bg-cyan-500 text-white'
                  : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
              }`}
              title={label}
            >
              {icon}
              <span className="hidden sm:inline">{label}</span>
            </button>
          ))}
        </div>
        <div className="flex gap-1">
          <button onClick={() => handleZoom(1.2)} className="p-1.5 rounded bg-slate-700 hover:bg-slate-600 text-slate-300" title="Zoom In">
            <ZoomIn size={14} />
          </button>
          <button onClick={() => handleZoom(0.8)} className="p-1.5 rounded bg-slate-700 hover:bg-slate-600 text-slate-300" title="Zoom Out">
            <ZoomOut size={14} />
          </button>
          <button onClick={handleReset} className="p-1.5 rounded bg-slate-700 hover:bg-slate-600 text-slate-300" title="Reset View">
            <RotateCcw size={14} />
          </button>
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 rounded bg-slate-700 hover:bg-slate-600 text-slate-300"
            title="Toggle Fullscreen"
          >
            <Maximize2 size={14} />
          </button>
        </div>
      </div>

      {/* Viewer */}
      <div className="relative flex-1 min-h-0">
        <div
          ref={containerRef}
          className="w-full h-full"
          style={{ minHeight: '300px' }}
        />
        {!sdf && !isLoading && (
          <WelcomeBanner onExampleClick={onExampleSearch || (() => {})} />
        )}
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-900/80">
            <div className="flex flex-col items-center gap-3">
              <div className="w-10 h-10 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin" />
              <span className="text-cyan-400 text-sm">Rendering molecule...</span>
            </div>
          </div>
        )}
        {error && (
          <div className="absolute bottom-4 left-4 right-4 bg-red-900/80 text-red-200 text-xs px-3 py-2 rounded-lg border border-red-700">
            ⚠️ {error}
          </div>
        )}
      </div>

      {/* CPK Legend */}
      <div className="px-3 py-2 bg-slate-800 border-t border-slate-700">
        <div className="flex flex-wrap gap-x-3 gap-y-1">
          {[
            { el: 'C', color: '#6b7280', label: 'Carbon' },
            { el: 'H', color: '#e5e7eb', label: 'Hydrogen' },
            { el: 'O', color: '#ef4444', label: 'Oxygen' },
            { el: 'N', color: '#3b82f6', label: 'Nitrogen' },
            { el: 'S', color: '#eab308', label: 'Sulfur' },
            { el: 'P', color: '#f97316', label: 'Phosphorus' },
          ].map(({ el, color, label }) => (
            <div key={el} className="flex items-center gap-1">
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
              <span className="text-xs text-slate-400">{el} ({label})</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
