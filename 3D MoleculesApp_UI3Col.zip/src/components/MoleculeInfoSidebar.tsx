import { Atom, Link2, Zap, Scale, Activity, BookOpen, ExternalLink } from 'lucide-react';
import type { MoleculeData } from '../types/molecule';

interface MoleculeInfoSidebarProps {
  molecule: MoleculeData | null;
}

function InfoRow({ label, value, color }: { label: string; value: string | number | undefined; color?: string }) {
  if (value === undefined || value === null || value === '') return null;
  return (
    <div className="flex justify-between items-start gap-2 py-1.5 border-b border-slate-700/50">
      <span className="text-slate-400 text-xs flex-shrink-0">{label}</span>
      <span className={`text-right text-xs font-medium break-all ${color || 'text-slate-200'}`}>{value}</span>
    </div>
  );
}

function Section({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <div className="flex items-center gap-2 mb-2">
        <span className="text-cyan-400">{icon}</span>
        <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">{title}</h3>
      </div>
      {children}
    </div>
  );
}

export default function MoleculeInfoSidebar({ molecule }: MoleculeInfoSidebarProps) {
  if (!molecule) {
    return (
      <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 h-full flex flex-col items-center justify-center text-center">
        <div className="text-4xl mb-3">🔬</div>
        <p className="text-slate-400 text-sm font-medium">No molecule loaded</p>
        <p className="text-slate-600 text-xs mt-1">Search for a molecule to see its properties</p>
      </div>
    );
  }

  const { properties, geometry, hybridization, polarity, bondAngles, atoms, cid } = molecule;

  const atomColors: Record<string, string> = {
    C: '#6b7280', H: '#e5e7eb', O: '#ef4444', N: '#3b82f6',
    S: '#eab308', P: '#f97316', F: '#a3e635', Cl: '#4ade80',
    Br: '#b45309', I: '#a855f7',
  };

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden flex flex-col h-full">
      {/* Header */}
      <div className="bg-gradient-to-r from-cyan-900/60 to-blue-900/60 border-b border-slate-700 p-4">
        <h2 className="font-bold text-white text-base leading-tight">{molecule.name}</h2>
        <div className="text-2xl font-mono font-bold text-cyan-300 mt-1">{properties.molecularFormula}</div>
        <div className="flex items-center gap-2 mt-2">
          <span className="text-xs text-slate-400">PubChem CID:</span>
          <a
            href={`https://pubchem.ncbi.nlm.nih.gov/compound/${cid}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
          >
            {cid} <ExternalLink size={10} />
          </a>
        </div>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 scrollbar-thin">
        {/* Atom Composition */}
        <Section title="Atoms" icon={<Atom size={14} />}>
          <div className="flex flex-wrap gap-1.5 mt-1">
            {atoms.map(atom => (
              <div
                key={atom.element}
                className="flex items-center gap-1.5 px-2 py-1 bg-slate-700/80 rounded-lg border border-slate-600"
              >
                <div
                  className="w-3 h-3 rounded-full flex-shrink-0"
                  style={{ backgroundColor: atomColors[atom.element] || '#ec4899' }}
                />
                <span className="text-white text-xs font-bold">{atom.element}</span>
                <span className="text-slate-400 text-xs">×{atom.count}</span>
              </div>
            ))}
          </div>
        </Section>

        {/* Geometry */}
        <Section title="3D Geometry" icon={<BookOpen size={14} />}>
          <InfoRow label="VSEPR Geometry" value={geometry} color="text-cyan-300" />
          <InfoRow label="Bond Angles" value={bondAngles} color="text-yellow-300" />
          <InfoRow label="Hybridization" value={hybridization} color="text-purple-300" />
          <InfoRow label="Polarity" value={polarity} color={polarity === 'Polar' || polarity.includes('Polar') ? 'text-blue-300' : 'text-orange-300'} />
        </Section>

        {/* Physical Properties */}
        <Section title="Physical Properties" icon={<Scale size={14} />}>
          <InfoRow label="Mol. Weight" value={`${properties.molecularWeight} g/mol`} />
          <InfoRow label="Exact Mass" value={properties.exactMass ? `${properties.exactMass} Da` : undefined} />
          <InfoRow label="XLogP" value={properties.xlogp} />
          <InfoRow label="TPSA" value={properties.tpsa ? `${properties.tpsa} Å²` : undefined} />
          <InfoRow label="Complexity" value={properties.complexity} />
        </Section>

        {/* Bonding Properties */}
        <Section title="Bonding" icon={<Link2 size={14} />}>
          <InfoRow label="H-Bond Donors" value={properties.hBondDonorCount} />
          <InfoRow label="H-Bond Acceptors" value={properties.hBondAcceptorCount} />
          <InfoRow label="Rotatable Bonds" value={properties.rotatableBondCount} />
          <InfoRow label="Heavy Atoms" value={properties.heavyAtomCount} />
          <InfoRow label="Formal Charge" value={properties.charge} />
        </Section>

        {/* Identifiers */}
        <Section title="Identifiers" icon={<Activity size={14} />}>
          <div className="space-y-1.5">
            <div>
              <div className="text-xs text-slate-400 mb-0.5">IUPAC Name</div>
              <div className="text-xs text-slate-200 bg-slate-900/50 rounded p-1.5 break-all font-mono leading-relaxed">
                {properties.iupacName || 'N/A'}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400 mb-0.5">Canonical SMILES</div>
              <div className="text-xs text-green-300 bg-slate-900/50 rounded p-1.5 break-all font-mono leading-relaxed">
                {properties.canonicalSMILES}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400 mb-0.5">InChIKey</div>
              <div className="text-xs text-slate-300 bg-slate-900/50 rounded p-1.5 break-all font-mono">
                {properties.inchiKey}
              </div>
            </div>
          </div>
        </Section>

        {/* Drug-likeness */}
        {(properties.hBondDonorCount !== undefined && properties.hBondAcceptorCount !== undefined) && (
          <Section title="Lipinski's Rule of 5" icon={<Zap size={14} />}>
            <div className="grid grid-cols-2 gap-1.5 mt-1">
              {[
                { label: 'MW ≤ 500', pass: properties.molecularWeight <= 500 },
                { label: 'XLogP ≤ 5', pass: (properties.xlogp || 0) <= 5 },
                { label: 'HBD ≤ 5', pass: (properties.hBondDonorCount || 0) <= 5 },
                { label: 'HBA ≤ 10', pass: (properties.hBondAcceptorCount || 0) <= 10 },
              ].map(rule => (
                <div
                  key={rule.label}
                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-xs border ${
                    rule.pass
                      ? 'bg-green-900/30 border-green-700/50 text-green-300'
                      : 'bg-red-900/30 border-red-700/50 text-red-300'
                  }`}
                >
                  <span>{rule.pass ? '✓' : '✗'}</span>
                  {rule.label}
                </div>
              ))}
            </div>
          </Section>
        )}
      </div>
    </div>
  );
}
