import { useState } from 'react';
import { Search, FlaskConical, FileText, Loader2, Sparkles } from 'lucide-react';

type SearchMode = 'name' | 'smiles';

interface SearchPanelProps {
  onSearch: (query: string, mode: SearchMode) => void;
  isLoading: boolean;
}

const EXAMPLE_MOLECULES = [
  { name: 'Water', query: 'water', mode: 'name' as SearchMode },
  { name: 'Caffeine', query: 'caffeine', mode: 'name' as SearchMode },
  { name: 'Aspirin', query: 'aspirin', mode: 'name' as SearchMode },
  { name: 'Ethanol', query: 'ethanol', mode: 'name' as SearchMode },
  { name: 'Glucose', query: 'glucose', mode: 'name' as SearchMode },
  { name: 'Benzene', query: 'benzene', mode: 'name' as SearchMode },
  { name: 'Methane', query: 'methane', mode: 'name' as SearchMode },
  { name: 'CO₂', query: 'carbon dioxide', mode: 'name' as SearchMode },
  { name: 'Penicillin', query: 'penicillin', mode: 'name' as SearchMode },
  { name: 'Dopamine', query: 'dopamine', mode: 'name' as SearchMode },
  { name: 'Ibuprofen', query: 'ibuprofen', mode: 'name' as SearchMode },
  { name: 'Adenine', query: 'adenine', mode: 'name' as SearchMode },
];

const SMILES_EXAMPLES = [
  { name: 'Acetic Acid', smiles: 'CC(O)=O' },
  { name: 'Paracetamol', smiles: 'CC(=O)Nc1ccc(O)cc1' },
  { name: 'Nicotine', smiles: 'CN1CCCC1c2cccnc2' },
];

export default function SearchPanel({ onSearch, isLoading }: SearchPanelProps) {
  const [mode, setMode] = useState<SearchMode>('name');
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || isLoading) return;
    onSearch(query.trim(), mode);
  };

  const handleExample = (q: string, m: SearchMode) => {
    setQuery(q);
    setMode(m);
    onSearch(q, m);
  };

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 space-y-4">
      {/* Mode Toggle */}
      <div className="flex bg-slate-900 rounded-lg p-1 gap-1">
        <button
          onClick={() => setMode('name')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-md text-sm font-medium transition-all ${
            mode === 'name' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Search size={14} />
          Molecule Name
        </button>
        <button
          onClick={() => setMode('smiles')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-md text-sm font-medium transition-all ${
            mode === 'smiles' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileText size={14} />
          SMILES String
        </button>
      </div>

      {/* Search Form */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <div className="flex-1 relative">
          <FlaskConical size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder={mode === 'name' ? 'e.g. caffeine, aspirin, water...' : 'e.g. CC(O)=O, c1ccccc1...'}
            className="w-full pl-9 pr-4 py-2.5 bg-slate-900 border border-slate-600 rounded-lg text-white text-sm placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/30 transition-all"
            disabled={isLoading}
          />
        </div>
        <button
          type="submit"
          disabled={isLoading || !query.trim()}
          className="px-4 py-2.5 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-700 disabled:text-slate-500 text-white rounded-lg font-medium text-sm transition-all flex items-center gap-2"
        >
          {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />}
          {isLoading ? 'Loading...' : 'Search'}
        </button>
      </form>

      {/* Quick Examples */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Sparkles size={13} className="text-cyan-400" />
          <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Quick Examples</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {(mode === 'name' ? EXAMPLE_MOLECULES : SMILES_EXAMPLES.map(e => ({
            name: e.name,
            query: e.smiles,
            mode: 'smiles' as SearchMode,
          }))).map(ex => (
            <button
              key={ex.name}
              onClick={() => handleExample(ex.query, ex.mode)}
              disabled={isLoading}
              className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 border border-slate-600 hover:border-cyan-500/50 text-slate-300 hover:text-cyan-300 text-xs rounded-full transition-all disabled:opacity-50"
            >
              {ex.name}
            </button>
          ))}
        </div>
      </div>

      {/* Info */}
      <div className="text-xs text-slate-500 flex items-start gap-2 bg-slate-900/50 rounded-lg p-2.5">
        <span className="text-cyan-400 mt-0.5">ℹ</span>
        <span>
          Molecular data is sourced from <strong className="text-slate-400">PubChem</strong> — 
          SMILES, geometry, hybridization & properties are computed, not guessed.
        </span>
      </div>
    </div>
  );
}
