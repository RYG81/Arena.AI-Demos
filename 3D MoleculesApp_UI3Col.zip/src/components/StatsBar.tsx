import type { MoleculeData } from '../types/molecule';

interface StatsBarProps {
  molecule: MoleculeData | null;
  isLoading: boolean;
}

export default function StatsBar({ molecule, isLoading }: StatsBarProps) {
  if (isLoading) {
    return (
      <div className="bg-slate-800/60 border border-slate-700 rounded-xl px-4 py-3 flex items-center gap-6">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
          <span className="text-slate-400 text-sm animate-pulse">Fetching molecular data from PubChem...</span>
        </div>
      </div>
    );
  }

  if (!molecule) return null;

  const { properties, geometry, polarity } = molecule;

  const stats = [
    { label: 'Formula', value: properties.molecularFormula, mono: true },
    { label: 'Weight', value: `${properties.molecularWeight} g/mol` },
    { label: 'Geometry', value: geometry },
    { label: 'Polarity', value: polarity },
    { label: 'H-Bond Donors', value: properties.hBondDonorCount?.toString() ?? '—' },
    { label: 'H-Bond Acceptors', value: properties.hBondAcceptorCount?.toString() ?? '—' },
    { label: 'XLogP', value: properties.xlogp?.toString() ?? '—' },
  ];

  return (
    <div className="bg-slate-800/60 border border-slate-700 rounded-xl px-4 py-2.5 overflow-x-auto">
      <div className="flex gap-6 min-w-max">
        {stats.map(s => (
          <div key={s.label} className="flex flex-col">
            <span className="text-xs text-slate-500">{s.label}</span>
            <span className={`text-sm font-semibold text-white ${s.mono ? 'font-mono' : ''}`}>{s.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
