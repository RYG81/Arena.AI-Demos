import { FlaskConical, Atom, Bot, Layers } from 'lucide-react';

interface WelcomeBannerProps {
  onExampleClick: (name: string) => void;
}

const FEATURED = [
  { name: 'Water', formula: 'H₂O', emoji: '💧' },
  { name: 'Caffeine', formula: 'C₈H₁₀N₄O₂', emoji: '☕' },
  { name: 'Aspirin', formula: 'C₉H₈O₄', emoji: '💊' },
  { name: 'Glucose', formula: 'C₆H₁₂O₆', emoji: '🍬' },
  { name: 'DNA base - Adenine', formula: 'C₅H₅N₅', emoji: '🧬' },
  { name: 'Ethanol', formula: 'C₂H₅OH', emoji: '🍷' },
];

export default function WelcomeBanner({ onExampleClick }: WelcomeBannerProps) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center p-6 pointer-events-none">
      <div className="text-center max-w-md pointer-events-auto">
        {/* Animated molecule icon */}
        <div className="relative w-20 h-20 mx-auto mb-6">
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-2xl opacity-20 animate-ping" />
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-2xl flex items-center justify-center">
            <FlaskConical size={36} className="text-white" />
          </div>
        </div>

        <h2 className="text-2xl font-bold text-white mb-2">3D Molecular Explorer</h2>
        <p className="text-slate-400 text-sm mb-6 leading-relaxed">
          Search any molecule to visualize its 3D structure, explore chemical properties,
          and get AI-powered explanations.
        </p>

        {/* Feature badges */}
        <div className="flex flex-wrap justify-center gap-2 mb-6">
          {[
            { icon: <Layers size={13} />, text: 'Interactive 3D' },
            { icon: <Atom size={13} />, text: 'PubChem Data' },
            { icon: <Bot size={13} />, text: 'AI Tutor' },
          ].map(f => (
            <div
              key={f.text}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/80 border border-slate-700 rounded-full text-xs text-slate-300"
            >
              <span className="text-cyan-400">{f.icon}</span>
              {f.text}
            </div>
          ))}
        </div>

        {/* Featured molecules */}
        <div>
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Featured Molecules</p>
          <div className="grid grid-cols-3 gap-2">
            {FEATURED.map(m => (
              <button
                key={m.name}
                onClick={() => onExampleClick(m.name.split(' - ')[0])}
                className="flex flex-col items-center gap-1 p-2.5 bg-slate-800/60 hover:bg-slate-700/80 border border-slate-700 hover:border-cyan-500/50 rounded-xl transition-all text-center"
              >
                <span className="text-xl">{m.emoji}</span>
                <span className="text-white text-xs font-medium leading-tight">{m.name.split(' - ')[0]}</span>
                <span className="text-slate-500 text-xs font-mono">{m.formula}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
