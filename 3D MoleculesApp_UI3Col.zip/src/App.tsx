import { useState, useCallback } from 'react';
import { FlaskConical, AlertCircle, X, ChevronRight, Info, Layers } from 'lucide-react';
import SearchPanel from './components/SearchPanel';
import MoleculeViewer from './components/MoleculeViewer';
import MoleculeInfoSidebar from './components/MoleculeInfoSidebar';
import AIChat from './components/AIChat';
import StatsBar from './components/StatsBar';
import type { MoleculeData, ViewMode } from './types/molecule';
import { fetchMoleculeByName, fetchMoleculeBySmiles } from './utils/pubchem';

type SearchMode = 'name' | 'smiles';
type ActiveTab = 'viewer' | 'info' | 'chat';

export default function App() {
  const [molecule, setMolecule] = useState<MoleculeData | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('stick');
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [apiKey, setApiKey] = useState('');
  const [activeTab, setActiveTab] = useState<ActiveTab>('viewer');
  const [mobileTab, setMobileTab] = useState<'search' | 'viewer' | 'info' | 'chat'>('search');

  const handleSearch = useCallback(async (query: string, mode: SearchMode) => {
    setIsSearching(true);
    setSearchError(null);
    try {
      let data: MoleculeData;
      if (mode === 'name') {
        data = await fetchMoleculeByName(query);
      } else {
        data = await fetchMoleculeBySmiles(query);
      }
      setMolecule(data);
      setActiveTab('viewer');
      setMobileTab('viewer');
    } catch (e: any) {
      setSearchError(e.message || 'Failed to fetch molecule.');
    } finally {
      setIsSearching(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-700 px-4 py-3 flex-shrink-0">
        <div className="max-w-[1600px] mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <FlaskConical size={20} className="text-white" />
            </div>
            <div>
              <h1 className="font-bold text-white text-lg leading-none">MoleculeAI</h1>
              <p className="text-xs text-slate-400">3D Molecular Explorer · AI Chemistry Tutor</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {molecule && (
              <div className="hidden sm:flex items-center gap-2 bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5">
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
                <span className="text-slate-300 text-sm font-medium">{molecule.properties.molecularFormula}</span>
                <ChevronRight size={14} className="text-slate-500" />
                <span className="text-slate-400 text-xs truncate max-w-[120px]">{molecule.name}</span>
              </div>
            )}
            <a
              href="https://pubchem.ncbi.nlm.nih.gov"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-1 text-xs text-slate-500 hover:text-slate-300 transition-colors"
            >
              <Info size={13} />
              Powered by PubChem
            </a>
          </div>
        </div>
      </header>

      {/* Error Banner */}
      {searchError && (
        <div className="bg-red-900/40 border-b border-red-700/50 px-4 py-2 flex items-center gap-2">
          <AlertCircle size={16} className="text-red-400 flex-shrink-0" />
          <span className="text-red-200 text-sm flex-1">{searchError}</span>
          <button onClick={() => setSearchError(null)} className="text-red-400 hover:text-red-200">
            <X size={16} />
          </button>
        </div>
      )}

      {/* Desktop Layout */}
      <div className="hidden lg:flex flex-1 overflow-hidden max-w-[1600px] mx-auto w-full p-4 gap-4">
        {/* Left Column: Search + Info */}
        <div className="w-80 flex-shrink-0 flex flex-col gap-4 overflow-y-auto">
          <SearchPanel onSearch={handleSearch} isLoading={isSearching} />
          <div className="flex-1 min-h-0" style={{ minHeight: '400px' }}>
            <MoleculeInfoSidebar molecule={molecule} />
          </div>
        </div>

        {/* Center Column: 3D Viewer + Stats */}
        <div className="flex-1 flex flex-col min-w-0 gap-3 min-h-0">
          {(molecule || isSearching) && (
            <div className="flex-shrink-0">
              <StatsBar molecule={molecule} isLoading={isSearching} />
            </div>
          )}
          <div className="flex-1 min-h-0">
            <MoleculeViewer
              sdf={molecule?.sdf3d || null}
              viewMode={viewMode}
              onViewModeChange={setViewMode}
              onExampleSearch={(name) => handleSearch(name, 'name')}
            />
          </div>
        </div>

        {/* Right Column: AI Chat */}
        <div className="w-80 xl:w-96 flex-shrink-0">
          <AIChat
            molecule={molecule}
            apiKey={apiKey}
            onApiKeyChange={setApiKey}
          />
        </div>
      </div>

      {/* Tablet Layout */}
      <div className="hidden md:flex lg:hidden flex-1 overflow-hidden flex-col p-4 gap-4">
        <SearchPanel onSearch={handleSearch} isLoading={isSearching} />
        <div className="flex gap-4 flex-1 min-h-0">
          {/* Tabs for viewer/info/chat */}
          <div className="flex flex-col flex-1 min-h-0 gap-2">
            <div className="flex bg-slate-800 rounded-xl border border-slate-700 p-1 gap-1">
              {(['viewer', 'info', 'chat'] as ActiveTab[]).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium capitalize transition-all flex items-center justify-center gap-1.5 ${
                    activeTab === tab ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab === 'viewer' ? <Layers size={14} /> : tab === 'info' ? <Info size={14} /> : <FlaskConical size={14} />}
                  {tab === 'viewer' ? '3D View' : tab === 'info' ? 'Properties' : 'AI Chat'}
                </button>
              ))}
            </div>
            <div className="flex-1 min-h-0 overflow-hidden">
              {activeTab === 'viewer' && (
                <MoleculeViewer sdf={molecule?.sdf3d || null} viewMode={viewMode} onViewModeChange={setViewMode} onExampleSearch={(name) => handleSearch(name, 'name')} />
              )}
              {activeTab === 'info' && (
                <div className="h-full overflow-y-auto">
                  <MoleculeInfoSidebar molecule={molecule} />
                </div>
              )}
              {activeTab === 'chat' && (
                <AIChat molecule={molecule} apiKey={apiKey} onApiKeyChange={setApiKey} />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Layout */}
      <div className="flex md:hidden flex-1 flex-col overflow-hidden">
        {/* Mobile Tab Bar */}
        <div className="flex bg-slate-900 border-b border-slate-700 px-2 py-2 gap-1 flex-shrink-0">
          {[
            { key: 'search', label: 'Search', icon: '🔍' },
            { key: 'viewer', label: '3D', icon: '⚛️' },
            { key: 'info', label: 'Info', icon: '📊' },
            { key: 'chat', label: 'AI', icon: '🤖' },
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setMobileTab(tab.key as any)}
              className={`flex-1 flex flex-col items-center py-1.5 rounded-lg text-xs font-medium transition-all ${
                mobileTab === tab.key
                  ? 'bg-cyan-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="text-base leading-none mb-0.5">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Mobile Content */}
        <div className="flex-1 overflow-hidden p-3">
          {mobileTab === 'search' && (
            <SearchPanel onSearch={handleSearch} isLoading={isSearching} />
          )}
          {mobileTab === 'viewer' && (
            <div className="h-full">
              <MoleculeViewer sdf={molecule?.sdf3d || null} viewMode={viewMode} onViewModeChange={setViewMode} onExampleSearch={(name) => { handleSearch(name, 'name'); }} />
            </div>
          )}
          {mobileTab === 'info' && (
            <div className="h-full overflow-y-auto">
              <MoleculeInfoSidebar molecule={molecule} />
            </div>
          )}
          {mobileTab === 'chat' && (
            <div className="h-full">
              <AIChat molecule={molecule} apiKey={apiKey} onApiKeyChange={setApiKey} />
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <footer className="hidden lg:block bg-slate-900 border-t border-slate-700 px-4 py-2 flex-shrink-0">
        <div className="max-w-[1600px] mx-auto flex items-center justify-between text-xs text-slate-600">
          <span>MoleculeAI — 3D Molecular Explorer | Data sourced from PubChem (NCBI) | AI by OpenAI</span>
          <span>⚠ Chemistry data is fetched from PubChem, not AI-generated. AI explanations are based strictly on provided data.</span>
        </div>
      </footer>
    </div>
  );
}
