import type { ChatMessage, MoleculeData, ExplanationLevel } from '../types/molecule';

function buildSystemPrompt(molecule: MoleculeData | null, level: ExplanationLevel): string {
  const levelDesc = {
    beginner: 'Explain in simple terms, avoiding jargon. Use analogies and everyday language.',
    intermediate: 'Use standard chemistry terminology. Assume the user knows high school chemistry.',
    advanced: 'Use advanced chemistry concepts, VSEPR theory, MO theory, and precise scientific language.',
  }[level];

  if (!molecule) {
    return `You are MoleculeAI, an expert chemistry tutor and molecular structure guide.
${levelDesc}
No molecule is currently loaded. Help the user search for a molecule or explain general chemistry concepts.
IMPORTANT: Do NOT invent molecular structures or properties. Always direct users to load a molecule first for specifics.`;
  }

  const { properties, geometry, hybridization, polarity, bondAngles, atoms } = molecule;
  const atomList = atoms.map(a => `${a.element}(${a.count})`).join(', ');

  return `You are MoleculeAI, an expert chemistry tutor and molecular structure guide.
${levelDesc}

## CURRENT MOLECULE DATA (Source of Truth — PubChem CID: ${molecule.cid})
- Name: ${molecule.name}
- IUPAC Name: ${properties.iupacName}
- Molecular Formula: ${properties.molecularFormula}
- Molecular Weight: ${properties.molecularWeight} g/mol
- Canonical SMILES: ${properties.canonicalSMILES}
- InChIKey: ${properties.inchiKey}
- Atoms present: ${atomList}
- 3D Geometry (VSEPR): ${geometry}
- Hybridization: ${hybridization}
- Bond Angles: ${bondAngles}
- Polarity: ${polarity}
${properties.xlogp !== undefined ? `- XLogP (lipophilicity): ${properties.xlogp}` : ''}
${properties.tpsa !== undefined ? `- Topological Polar Surface Area: ${properties.tpsa} Å²` : ''}
${properties.hBondDonorCount !== undefined ? `- H-Bond Donors: ${properties.hBondDonorCount}` : ''}
${properties.hBondAcceptorCount !== undefined ? `- H-Bond Acceptors: ${properties.hBondAcceptorCount}` : ''}
${properties.complexity !== undefined ? `- Structural Complexity: ${properties.complexity}` : ''}
${properties.charge !== undefined ? `- Formal Charge: ${properties.charge}` : ''}

## CRITICAL RULES:
1. ONLY use the above data when discussing this molecule's properties.
2. Do NOT hallucinate or invent any chemical values not present above.
3. If asked about a property not in the data, say "This data is not available in the current dataset."
4. You may explain general chemistry principles (VSEPR, hybridization, etc.) using the actual data above as examples.
5. Keep explanations consistent with the data above at all times.
6. When discussing bond angles or geometry, use VSEPR theory and the provided values.`;
}

export async function sendChatMessage(
  apiKey: string,
  messages: ChatMessage[],
  molecule: MoleculeData | null,
  level: ExplanationLevel
): Promise<string> {
  const systemPrompt = buildSystemPrompt(molecule, level);

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        ...messages.map(m => ({ role: m.role, content: m.content })),
      ],
      temperature: 0.3,
      max_tokens: 800,
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err?.error?.message || `OpenAI API error: ${response.status}`);
  }

  const data = await response.json();
  return data.choices?.[0]?.message?.content || 'No response from AI.';
}

export async function generateMoleculeExplanation(
  apiKey: string,
  molecule: MoleculeData,
  level: ExplanationLevel
): Promise<string> {
  const systemPrompt = buildSystemPrompt(molecule, level);

  const userMessage = `Please provide a comprehensive introduction to ${molecule.name} (${molecule.properties.molecularFormula}). 
Cover:
1. What this molecule is and its importance
2. Its 3D geometry and why it has this shape (VSEPR)
3. Bond types and hybridization
4. Whether it's polar or nonpolar and why
5. Key chemical properties visible in the data

Use ONLY the provided molecular data above.`;

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage },
      ],
      temperature: 0.3,
      max_tokens: 600,
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err?.error?.message || 'OpenAI error');
  }

  const data = await response.json();
  return data.choices?.[0]?.message?.content || '';
}
