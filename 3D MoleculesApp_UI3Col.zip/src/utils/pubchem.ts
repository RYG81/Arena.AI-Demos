import type { MolecularProperties, MoleculeData, AtomInfo } from '../types/molecule';

const BASE = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug';

// Element colors (CPK coloring scheme)
const ELEMENT_COLORS: Record<string, string> = {
  H: '#FFFFFF', C: '#404040', N: '#3050F8', O: '#FF0D0D',
  F: '#90E050', Cl: '#1FF01F', Br: '#A62929', I: '#940094',
  S: '#FFFF30', P: '#FF8000', Na: '#AB5CF2', K: '#8F40D4',
  Ca: '#3DFF00', Mg: '#8AFF00', Fe: '#E06633', Cu: '#C88033',
  Zn: '#7D80B0', Si: '#F0C8A0', B: '#FFB5B5', Al: '#BFA6A6',
  default: '#FF69B4',
};

export function getElementColor(element: string): string {
  return ELEMENT_COLORS[element] || ELEMENT_COLORS.default;
}

// Determine geometry based on heavy atom count and formula
function inferGeometry(formula: string, heavyAtomCount: number): string {
  if (heavyAtomCount <= 1) return 'Monoatomic';
  if (heavyAtomCount === 2) return 'Linear';

  // Simple heuristics based on common molecules
  const formulaUpper = formula.toUpperCase();
  if (formulaUpper === 'H2O') return 'Bent (104.5°)';
  if (formulaUpper === 'NH3') return 'Trigonal Pyramidal';
  if (formulaUpper === 'CH4') return 'Tetrahedral';
  if (formulaUpper === 'CO2') return 'Linear';
  if (formulaUpper === 'SO2') return 'Bent';
  if (formulaUpper === 'SO3') return 'Trigonal Planar';
  if (formulaUpper === 'BF3') return 'Trigonal Planar';
  if (formulaUpper === 'PCL5') return 'Trigonal Bipyramidal';
  if (formulaUpper === 'SF6') return 'Octahedral';

  if (heavyAtomCount <= 3) return 'Bent / Angular';
  if (heavyAtomCount <= 4) return 'Tetrahedral / Trigonal Planar';
  if (heavyAtomCount <= 6) return 'Trigonal Bipyramidal / Octahedral';
  return 'Complex Polyhedral';
}

function inferHybridization(formula: string, heavyAtomCount: number): string {
  const f = formula.toUpperCase();
  if (f === 'CH4' || f === 'NH3' || f === 'H2O' || f === 'CCL4') return 'sp³';
  if (f === 'CO2' || f === 'C2H2') return 'sp';
  if (f === 'C6H6' || f === 'SO3' || f === 'BF3') return 'sp²';
  if (heavyAtomCount <= 2) return 'sp';
  if (heavyAtomCount <= 4) return 'sp³';
  return 'sp³ / sp² (mixed)';
}

function inferPolarity(xlogp: number | undefined, formula: string): string {
  const f = formula.toUpperCase();
  if (f === 'CO2' || f === 'CH4' || f === 'CCL4' || f === 'BF3' || f === 'SF6') return 'Nonpolar';
  if (f === 'H2O' || f === 'NH3' || f === 'HCL' || f === 'SO2') return 'Polar';
  if (xlogp !== undefined) {
    return xlogp > 0 ? 'Nonpolar / Lipophilic' : 'Polar / Hydrophilic';
  }
  return 'Polar';
}

function inferBondAngles(formula: string): string {
  const f = formula.toUpperCase();
  if (f === 'H2O') return '104.5°';
  if (f === 'NH3') return '107.3°';
  if (f === 'CH4') return '109.5°';
  if (f === 'CO2' || f === 'C2H2') return '180°';
  if (f === 'BF3' || f === 'SO3') return '120°';
  if (f === 'SF6') return '90°, 180°';
  if (f === 'C6H6') return '120°';
  return '≈109.5° (sp³) / 120° (sp²)';
}

function parseAtomsFromFormula(formula: string): AtomInfo[] {
  const regex = /([A-Z][a-z]?)(\d*)/g;
  const atoms: AtomInfo[] = [];
  let match;
  while ((match = regex.exec(formula)) !== null) {
    if (match[1]) {
      atoms.push({
        element: match[1],
        count: match[2] ? parseInt(match[2]) : 1,
        color: getElementColor(match[1]),
      });
    }
  }
  return atoms;
}

export async function searchMoleculeByName(name: string): Promise<number> {
  const url = `${BASE}/compound/name/${encodeURIComponent(name)}/cids/JSON`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Molecule "${name}" not found in PubChem.`);
  const data = await res.json();
  if (!data.IdentifierList?.CID?.[0]) throw new Error(`No CID found for "${name}".`);
  return data.IdentifierList.CID[0];
}

export async function searchMoleculeBySmiles(smiles: string): Promise<number> {
  const url = `${BASE}/compound/smiles/cids/JSON`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `smiles=${encodeURIComponent(smiles)}`,
  });
  if (!res.ok) throw new Error(`SMILES "${smiles}" not found in PubChem.`);
  const data = await res.json();
  if (!data.IdentifierList?.CID?.[0]) throw new Error(`No CID found for SMILES.`);
  return data.IdentifierList.CID[0];
}

export async function fetchMolecularProperties(cid: number): Promise<MolecularProperties> {
  const props = [
    'MolecularFormula', 'MolecularWeight', 'IUPACName',
    'CanonicalSMILES', 'IsomericSMILES', 'InChIKey',
    'XLogP', 'ExactMass', 'TPSA', 'Complexity',
    'HBondDonorCount', 'HBondAcceptorCount', 'RotatableBondCount',
    'HeavyAtomCount', 'Charge'
  ].join(',');

  const url = `${BASE}/compound/cid/${cid}/property/${props}/JSON`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch properties for CID ${cid}.`);
  const data = await res.json();
  const p = data.PropertyTable?.Properties?.[0];
  if (!p) throw new Error('No properties returned from PubChem.');

  return {
    cid,
    molecularFormula: p.MolecularFormula || '',
    molecularWeight: p.MolecularWeight || 0,
    iupacName: p.IUPACName || '',
    canonicalSMILES: p.CanonicalSMILES || '',
    isomericSMILES: p.IsomericSMILES || '',
    inchiKey: p.InChIKey || '',
    xlogp: p.XLogP,
    exactMass: p.ExactMass,
    tpsa: p.TPSA,
    complexity: p.Complexity,
    hBondDonorCount: p.HBondDonorCount,
    hBondAcceptorCount: p.HBondAcceptorCount,
    rotatableBondCount: p.RotatableBondCount,
    heavyAtomCount: p.HeavyAtomCount,
    charge: p.Charge,
  };
}

export async function fetchSDF3D(cid: number): Promise<string> {
  const url = `${BASE}/compound/cid/${cid}/record/SDF?record_type=3d`;
  const res = await fetch(url);
  if (!res.ok) {
    // fallback to 2D SDF if 3D not available
    const url2d = `${BASE}/compound/cid/${cid}/record/SDF`;
    const res2d = await fetch(url2d);
    if (!res2d.ok) throw new Error(`Could not retrieve SDF for CID ${cid}.`);
    return await res2d.text();
  }
  return await res.text();
}

export async function fetchMoleculeByName(name: string): Promise<MoleculeData> {
  const cid = await searchMoleculeByName(name);
  return fetchMoleculeData(cid, name);
}

export async function fetchMoleculeBySmiles(smiles: string): Promise<MoleculeData> {
  const cid = await searchMoleculeBySmiles(smiles);
  return fetchMoleculeData(cid, smiles);
}

export async function fetchMoleculeData(cid: number, inputName: string): Promise<MoleculeData> {
  const [properties, sdf3d] = await Promise.all([
    fetchMolecularProperties(cid),
    fetchSDF3D(cid),
  ]);

  const formula = properties.molecularFormula;
  const heavyAtomCount = properties.heavyAtomCount || 0;
  const atoms = parseAtomsFromFormula(formula);
  const geometry = inferGeometry(formula, heavyAtomCount);
  const hybridization = inferHybridization(formula, heavyAtomCount);
  const polarity = inferPolarity(properties.xlogp, formula);
  const bondAngles = inferBondAngles(formula);

  return {
    name: properties.iupacName || inputName,
    cid,
    properties,
    sdf3d,
    atoms,
    geometry,
    hybridization,
    polarity,
    bondAngles,
  };
}
