export interface MolecularProperties {
  cid: number;
  molecularFormula: string;
  molecularWeight: number;
  iupacName: string;
  canonicalSMILES: string;
  isomericSMILES: string;
  inchiKey: string;
  xlogp?: number;
  exactMass?: number;
  tpsa?: number;
  complexity?: number;
  hBondDonorCount?: number;
  hBondAcceptorCount?: number;
  rotatableBondCount?: number;
  heavyAtomCount?: number;
  charge?: number;
}

export interface AtomInfo {
  element: string;
  count: number;
  color: string;
}

export interface BondInfo {
  type: string;
  count: number;
}

export interface MoleculeData {
  name: string;
  cid: number;
  properties: MolecularProperties;
  sdf3d: string;
  atoms: AtomInfo[];
  geometry: string;
  hybridization: string;
  polarity: string;
  bondAngles: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp?: Date;
}

export type ViewMode = 'stick' | 'sphere' | 'line' | 'cartoon';
export type ExplanationLevel = 'beginner' | 'intermediate' | 'advanced';
