import { MoleculeData } from '../data/molecules';
import { PubChemProperties } from './pubchem';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

// Intelligent local AI explainer — uses structured molecule data, never hallucinates
export function generateMoleculeExplanation(molecule: MoleculeData): string {
  const polarText = molecule.polarity === 'Polar'
    ? `Due to its ${molecule.geometry} geometry and electronegativity differences, **${molecule.name}** is a polar molecule. This means it has a net dipole moment.`
    : `Despite having polar bonds, the ${molecule.geometry} symmetry of **${molecule.name}** causes the bond dipoles to cancel, making it a nonpolar molecule.`;

  return `## ${molecule.name} (${molecule.formula})

**Molecular Overview**
${molecule.description}

**Geometry & Hybridization**
- Shape: **${molecule.geometry}**
- Hybridization: **${molecule.hybridization}**
- Bond angles: **${molecule.bondAngles}**
- Atom count: **${molecule.atoms.length}** atoms, **${molecule.bonds.length}** bonds

**Polarity**
${polarText}

**Physical Properties**
- Molar mass: **${molecule.molarMass} g/mol**
- H-bond donors: **${molecule.hBondDonors}**
- H-bond acceptors: **${molecule.hBondAcceptors}**
- LogP: **${molecule.logP}** (${molecule.logP < 0 ? 'hydrophilic' : 'lipophilic'})

**Fun Fact** 💡
${molecule.funFact}`;
}

export function answerMoleculeQuestion(question: string, molecule: MoleculeData | null, pubchemData?: PubChemProperties | null): string {
  const q = question.toLowerCase();

  if (!molecule) {
    return "Please select a molecule first, then I can answer your questions about it with accurate data!";
  }

  // Geometry questions
  if (q.includes('geometry') || q.includes('shape') || q.includes('structure')) {
    return `**${molecule.name}** has a **${molecule.geometry}** geometry.

This is determined by VSEPR theory:
- Number of atoms: ${molecule.atoms.length}
- Bond angles: ${molecule.bondAngles}
- Hybridization: ${molecule.hybridization}

${molecule.geometry === 'Bent' ? `The bent shape arises from lone pairs on the central atom, which repel bonding pairs more strongly than other bonds.` :
  molecule.geometry === 'Linear' ? `The linear shape means all atoms are arranged in a straight line at 180°.` :
  molecule.geometry === 'Tetrahedral' ? `The tetrahedral geometry places all four substituents at equal 109.5° angles — the maximum distance apart.` :
  molecule.geometry === 'Trigonal Pyramidal' ? `The trigonal pyramidal shape results from a lone pair pushing the three bonded atoms downward.` :
  molecule.geometry.includes('Planar') ? `The planar structure is stabilized by sp² hybridization and delocalized π electrons.` :
  `This geometry is determined by the number of bonding and lone pairs around the central atom.`}`;
  }

  // Polarity questions
  if (q.includes('polar') || q.includes('dipole') || q.includes('charge')) {
    if (molecule.polarity === 'Polar') {
      return `**${molecule.name}** is a **polar molecule** (μ ≠ 0).

**Why it's polar:**
- Geometry: ${molecule.geometry}
- The asymmetric arrangement of atoms creates unequal charge distribution
- Electronegativity differences create bond dipoles that don't cancel

**Consequences:**
- Dissolves in polar solvents (like water)
- Has higher boiling point than similar nonpolar molecules
- H-bond donors: ${molecule.hBondDonors}, H-bond acceptors: ${molecule.hBondAcceptors}`;
    } else {
      return `**${molecule.name}** is a **nonpolar molecule** (μ = 0).

**Why it's nonpolar:**
- Geometry: ${molecule.geometry}
- Even if individual bonds are polar, the ${molecule.geometry} symmetry causes all dipoles to cancel
- Net dipole moment = 0

**Consequences:**
- Dissolves in nonpolar solvents
- LogP = ${molecule.logP} (${molecule.logP > 0 ? 'prefers nonpolar environments' : 'somewhat hydrophilic'})`;
    }
  }

  // Hybridization questions
  if (q.includes('hybrid') || q.includes('orbital') || q.includes('electron')) {
    return `**${molecule.name}** uses **${molecule.hybridization}** hybridization.

${molecule.hybridization === 'sp³' ? `**sp³ hybridization** mixes 1 s-orbital with 3 p-orbitals to form 4 equivalent hybrid orbitals arranged tetrahedrally (109.5°). This allows for 4 sigma bonds.` :
  molecule.hybridization === 'sp²' ? `**sp² hybridization** mixes 1 s-orbital with 2 p-orbitals to form 3 equivalent hybrid orbitals arranged in a plane (120°), leaving 1 unhybridized p-orbital for π bonding.` :
  molecule.hybridization === 'sp' ? `**sp hybridization** mixes 1 s-orbital with 1 p-orbital to form 2 equivalent hybrid orbitals in a line (180°), leaving 2 unhybridized p-orbitals for π bonding.` :
  `This hybridization determines the geometry and bonding of ${molecule.name}.`}

Bond angles: **${molecule.bondAngles}**`;
  }

  // Bonding questions
  if (q.includes('bond') || q.includes('single') || q.includes('double') || q.includes('triple')) {
    const singleBonds = molecule.bonds.filter(b => b.order === 1).length;
    const doubleBonds = molecule.bonds.filter(b => b.order === 2).length;
    const tripleBonds = molecule.bonds.filter(b => b.order === 3).length;
    return `**${molecule.name}** contains:
- **${singleBonds}** single bond(s) (σ bonds)
- **${doubleBonds}** double bond(s) (1σ + 1π each)
- **${tripleBonds}** triple bond(s) (1σ + 2π each)

Total: **${molecule.bonds.length}** bonds between **${molecule.atoms.length}** atoms.

${doubleBonds > 0 || tripleBonds > 0 ? `The presence of multiple bonds with ${molecule.hybridization} hybridization contributes to the **${molecule.geometry}** geometry.` : ''}`;
  }

  // Molar mass / weight
  if (q.includes('mass') || q.includes('weight') || q.includes('molar') || q.includes('heavy')) {
    return `**${molecule.name}** has a molar mass of **${molecule.molarMass} g/mol**.

Formula: **${molecule.formula}**
Atom composition:
${countAtomTypes(molecule).map(([sym, count]) => `- ${sym}: ${count} atom(s)`).join('\n')}

${pubchemData ? `\nFrom PubChem:
- Heavy atom count: ${pubchemData.HeavyAtomCount || 'N/A'}
- Complexity: ${pubchemData.Complexity?.toFixed(1) || 'N/A'}` : ''}`;
  }

  // Solubility / LogP
  if (q.includes('solub') || q.includes('water') || q.includes('hydro') || q.includes('logp')) {
    return `**${molecule.name}** has a LogP of **${molecule.logP}**.

${molecule.logP < -1 ? `LogP < -1 → **Highly hydrophilic** (very water soluble)\n${molecule.name} loves water and will readily dissolve in aqueous environments.` :
  molecule.logP < 0 ? `LogP < 0 → **Hydrophilic** (water soluble)\nPrefers polar/aqueous environments.` :
  molecule.logP < 2 ? `0 < LogP < 2 → **Slightly lipophilic**\nSoluble in both water and some organic solvents.` :
  `LogP > 2 → **Lipophilic**\nPrefers nonpolar organic solvents over water.`}

Hydrogen bonding capacity:
- Donors: **${molecule.hBondDonors}** (can donate H-bonds)
- Acceptors: **${molecule.hBondAcceptors}** (can accept H-bonds)`;
  }

  // Fun fact
  if (q.includes('fact') || q.includes('interesting') || q.includes('cool') || q.includes('fun')) {
    return `**Fun fact about ${molecule.name}:** 💡\n\n${molecule.funFact}`;
  }

  // Compare
  if (q.includes('compar') || q.includes('vs') || q.includes('versus') || q.includes('differ')) {
    return `To compare molecules, click the **Compare** tab at the top! You can compare two molecules side-by-side with a detailed property analysis.`;
  }

  // Default: comprehensive summary
  return `**${molecule.name}** — Quick Summary

📐 **Geometry:** ${molecule.geometry}
⚡ **Polarity:** ${molecule.polarity}
🔬 **Hybridization:** ${molecule.hybridization}
📏 **Bond angles:** ${molecule.bondAngles}
⚖️ **Molar mass:** ${molecule.molarMass} g/mol
🧪 **Category:** ${molecule.category}

${molecule.description}

Ask me about: geometry, polarity, hybridization, bonding, solubility, or fun facts!`;
}

function countAtomTypes(molecule: MoleculeData): [string, number][] {
  const counts: Record<string, number> = {};
  for (const atom of molecule.atoms) {
    counts[atom.symbol] = (counts[atom.symbol] || 0) + 1;
  }
  return Object.entries(counts).sort((a, b) => b[1] - a[1]);
}

export function generatePubChemExplanation(props: PubChemProperties, sdfParsed: boolean): string {
  const logPDesc = props.XLogP !== undefined
    ? props.XLogP < 0 ? 'hydrophilic (water-loving)' : props.XLogP < 2 ? 'slightly lipophilic' : 'lipophilic (fat-loving)'
    : 'unknown';

  return `## ${props.IUPACName || 'Unknown'} (CID: ${props.CID})

**Fetched live from PubChem** ✅

**Chemical Formula:** ${props.MolecularFormula}
**Molar Mass:** ${props.MolecularWeight} g/mol
**SMILES:** \`${props.CanonicalSMILES}\`

**Drug-likeness Properties:**
- LogP: **${props.XLogP ?? 'N/A'}** (${logPDesc})
- H-bond donors: **${props.HBondDonorCount ?? 'N/A'}**
- H-bond acceptors: **${props.HBondAcceptorCount ?? 'N/A'}**
- Rotatable bonds: **${props.RotatableBondCount ?? 'N/A'}**
- Polar surface area: **${props.TPSA ?? 'N/A'} Ų**

**Structure:**
- Heavy atoms: **${props.HeavyAtomCount ?? 'N/A'}**
- Complexity: **${props.Complexity?.toFixed(0) ?? 'N/A'}**
- Formal charge: **${props.Charge ?? 0}**

${sdfParsed ? '✅ 3D structure loaded from PubChem conformer data' : '⚠️ 3D structure unavailable — using 2D projection'}`;
}
