const PUBCHEM_BASE = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug';

export interface PubChemProperties {
  CID: number;
  MolecularFormula: string;
  MolecularWeight: number;
  CanonicalSMILES: string;
  IUPACName: string;
  XLogP?: number;
  HBondDonorCount?: number;
  HBondAcceptorCount?: number;
  RotatableBondCount?: number;
  TPSA?: number;
  HeavyAtomCount?: number;
  Charge?: number;
  Complexity?: number;
}

export interface PubChemResult {
  properties: PubChemProperties;
  sdf3d: string | null;
}

export async function searchMoleculeByName(name: string): Promise<PubChemResult | null> {
  try {
    const encodedName = encodeURIComponent(name);
    const propsUrl = `${PUBCHEM_BASE}/compound/name/${encodedName}/property/MolecularFormula,MolecularWeight,CanonicalSMILES,IUPACName,XLogP,HBondDonorCount,HBondAcceptorCount,RotatableBondCount,TPSA,HeavyAtomCount,Charge,Complexity/JSON`;
    
    const propsRes = await fetch(propsUrl);
    if (!propsRes.ok) return null;
    
    const propsData = await propsRes.json();
    const props: PubChemProperties = propsData.PropertyTable?.Properties?.[0];
    if (!props) return null;

    // Fetch 3D SDF
    let sdf3d: string | null = null;
    try {
      const sdfUrl = `${PUBCHEM_BASE}/compound/cid/${props.CID}/record/SDF?record_type=3d`;
      const sdfRes = await fetch(sdfUrl);
      if (sdfRes.ok) {
        sdf3d = await sdfRes.text();
      }
    } catch {
      // 3D not available
    }

    return { properties: props, sdf3d };
  } catch {
    return null;
  }
}

export async function searchMoleculeBySMILES(smiles: string): Promise<PubChemResult | null> {
  try {
    const encodedSmiles = encodeURIComponent(smiles);
    const propsUrl = `${PUBCHEM_BASE}/compound/smiles/${encodedSmiles}/property/MolecularFormula,MolecularWeight,CanonicalSMILES,IUPACName,XLogP,HBondDonorCount,HBondAcceptorCount,RotatableBondCount,TPSA,HeavyAtomCount,Charge,Complexity/JSON`;
    
    const propsRes = await fetch(propsUrl);
    if (!propsRes.ok) return null;
    
    const propsData = await propsRes.json();
    const props: PubChemProperties = propsData.PropertyTable?.Properties?.[0];
    if (!props) return null;

    let sdf3d: string | null = null;
    try {
      const sdfUrl = `${PUBCHEM_BASE}/compound/cid/${props.CID}/record/SDF?record_type=3d`;
      const sdfRes = await fetch(sdfUrl);
      if (sdfRes.ok) {
        sdf3d = await sdfRes.text();
      }
    } catch {
      // ignore
    }

    return { properties: props, sdf3d };
  } catch {
    return null;
  }
}

export function parseSDFToAtomsBonds(sdf: string): { atoms: { symbol: string; x: number; y: number; z: number }[]; bonds: { from: number; to: number; order: number }[] } | null {
  try {
    const lines = sdf.split('\n');
    // Find the counts line (line index 3 in the V2000 format)
    let countsLine = '';
    let startIdx = 0;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].includes('V2000') || lines[i].includes('V3000')) {
        countsLine = lines[i];
        startIdx = i + 1;
        break;
      }
      if (i === 3) {
        countsLine = lines[i];
        startIdx = i + 1;
        break;
      }
    }

    const numAtoms = parseInt(countsLine.substring(0, 3).trim(), 10);
    const numBonds = parseInt(countsLine.substring(3, 6).trim(), 10);

    if (isNaN(numAtoms) || isNaN(numBonds)) return null;

    const atoms: { symbol: string; x: number; y: number; z: number }[] = [];
    const bonds: { from: number; to: number; order: number }[] = [];

    for (let i = 0; i < numAtoms; i++) {
      const line = lines[startIdx + i];
      if (!line) continue;
      const x = parseFloat(line.substring(0, 10).trim());
      const y = parseFloat(line.substring(10, 20).trim());
      const z = parseFloat(line.substring(20, 30).trim());
      const symbol = line.substring(31, 34).trim();
      atoms.push({ symbol, x, y, z });
    }

    for (let i = 0; i < numBonds; i++) {
      const line = lines[startIdx + numAtoms + i];
      if (!line) continue;
      const from = parseInt(line.substring(0, 3).trim(), 10) - 1;
      const to = parseInt(line.substring(3, 6).trim(), 10) - 1;
      const order = parseInt(line.substring(6, 9).trim(), 10);
      bonds.push({ from, to, order });
    }

    return { atoms, bonds };
  } catch {
    return null;
  }
}
