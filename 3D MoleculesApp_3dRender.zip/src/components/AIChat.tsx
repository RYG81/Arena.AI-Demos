import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles } from 'lucide-react';
import { ChatMessage, answerMoleculeQuestion } from '../utils/aiExplainer';
import { MoleculeData } from '../data/molecules';
import { PubChemProperties } from '../utils/pubchem';

interface Props {
  molecule: MoleculeData | null;
  pubchemData?: PubChemProperties | null;
  initialMessage?: string;
}

const QUICK_QUESTIONS = [
  "What is the geometry?",
  "Why is it polar/nonpolar?",
  "Explain hybridization",
  "What bonds does it have?",
  "How does it dissolve?",
  "Tell me a fun fact!",
];

function formatMessage(content: string) {
  const parts = content.split(/(\*\*[^*]+\*\*|`[^`]+`|\n)/g);
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={i} className="text-cyan-300 font-semibold">{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith('`') && part.endsWith('`')) {
      return <code key={i} className="bg-slate-700 text-green-300 px-1 rounded text-xs font-mono">{part.slice(1, -1)}</code>;
    }
    if (part === '\n') return <br key={i} />;
    if (part.startsWith('## ')) return <h3 key={i} className="text-lg font-bold text-white mt-1 mb-1">{part.slice(3)}</h3>;
    if (part.startsWith('- ')) return <div key={i} className="flex gap-2 ml-2"><span className="text-cyan-400 mt-1">•</span><span>{part.slice(2)}</span></div>;
    if (part.startsWith('📐') || part.startsWith('⚡') || part.startsWith('🔬') || part.startsWith('📏') || part.startsWith('⚖️') || part.startsWith('🧪') || part.startsWith('💡') || part.startsWith('✅') || part.startsWith('⚠️')) {
      return <div key={i} className="text-sm">{part}</div>;
    }
    return <span key={i}>{part}</span>;
  });
}

export default function AIChat({ molecule, pubchemData, initialMessage }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '0',
      role: 'assistant',
      content: initialMessage || "Hello! I'm your **AI Chemistry Tutor**. Select a molecule and ask me anything — geometry, polarity, hybridization, bonding, solubility, or any chemistry concept! I only use verified structural data, never guesses. 🔬",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (molecule && messages.length === 1) {
      // Auto-greet with molecule
      setTimeout(() => {
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: `I can see you've loaded **${molecule.name}** (${molecule.formula}). It's a ${molecule.difficulty.toLowerCase()}-level molecule with **${molecule.geometry}** geometry. Ask me anything about it!`,
          timestamp: new Date(),
        }]);
      }, 500);
    }
  }, [molecule]);

  const sendMessage = async (text?: string) => {
    const msg = (text || input).trim();
    if (!msg) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: msg,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    // Simulate AI thinking delay
    await new Promise(r => setTimeout(r, 600 + Math.random() * 400));

    const response = answerMoleculeQuestion(msg, molecule, pubchemData);
    const aiMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: response,
      timestamp: new Date(),
    };

    setIsTyping(false);
    setMessages(prev => [...prev, aiMsg]);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/80 rounded-xl border border-slate-700/50 overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-2 px-4 py-3 bg-gradient-to-r from-violet-900/60 to-cyan-900/60 border-b border-slate-700/50">
        <div className="relative">
          <Bot size={20} className="text-cyan-400" />
          <span className="absolute -top-1 -right-1 w-2 h-2 bg-green-400 rounded-full animate-pulse" />
        </div>
        <div>
          <div className="text-sm font-semibold text-white">AI Chemistry Tutor</div>
          <div className="text-xs text-slate-400">Powered by verified molecular data</div>
        </div>
        <Sparkles size={14} className="text-yellow-400 ml-auto" />
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 scrollbar-thin">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
            <div className={`flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center ${
              msg.role === 'user' ? 'bg-violet-600' : 'bg-cyan-800'
            }`}>
              {msg.role === 'user' ? <User size={14} className="text-white" /> : <Bot size={14} className="text-cyan-300" />}
            </div>
            <div className={`max-w-[85%] rounded-xl px-3 py-2 text-sm leading-relaxed ${
              msg.role === 'user'
                ? 'bg-violet-600 text-white rounded-tr-none'
                : 'bg-slate-800 text-slate-200 rounded-tl-none border border-slate-700/50'
            }`}>
              {formatMessage(msg.content)}
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-2">
            <div className="w-7 h-7 rounded-full bg-cyan-800 flex items-center justify-center flex-shrink-0">
              <Bot size={14} className="text-cyan-300" />
            </div>
            <div className="bg-slate-800 border border-slate-700/50 rounded-xl rounded-tl-none px-4 py-3">
              <div className="flex gap-1 items-center">
                <span className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Quick Questions */}
      {molecule && (
        <div className="px-3 py-2 border-t border-slate-700/50">
          <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none">
            {QUICK_QUESTIONS.map((q) => (
              <button
                key={q}
                onClick={() => sendMessage(q)}
                className="flex-shrink-0 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-600/50 px-2 py-1 rounded-full transition-all hover:border-cyan-500/50"
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="p-3 border-t border-slate-700/50">
        <div className="flex gap-2">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={molecule ? `Ask about ${molecule.name}...` : "Select a molecule first..."}
            className="flex-1 bg-slate-800 border border-slate-600/50 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-cyan-500/70 placeholder-slate-500 transition-colors"
          />
          <button
            onClick={() => sendMessage()}
            disabled={!input.trim() || isTyping}
            className="bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-700 disabled:text-slate-500 text-white p-2 rounded-lg transition-all disabled:cursor-not-allowed flex items-center justify-center"
          >
            <Send size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
