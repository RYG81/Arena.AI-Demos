import { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { AtomData, BondData, CPK_COLORS, ATOM_RADII } from '../data/molecules';

interface Props {
  atoms: AtomData[];
  bonds: BondData[];
  renderMode: 'ball-stick' | 'space-filling' | 'wireframe';
  selectedAtom: number | null;
  onAtomClick: (index: number) => void;
  animated: boolean;
}

function getAtomColor(symbol: string): string {
  return CPK_COLORS[symbol] || CPK_COLORS.default;
}

function getAtomRadius(symbol: string, mode: string): number {
  const base = ATOM_RADII[symbol] || ATOM_RADII.default;
  if (mode === 'space-filling') return base * 1.8;
  if (mode === 'wireframe') return base * 0.3;
  return base * 0.6;
}

export default function MoleculeViewer3D({ atoms, bonds, renderMode, selectedAtom, onAtomClick, animated }: Props) {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const frameRef = useRef<number>(0);
  const isDragging = useRef(false);
  const lastMouse = useRef({ x: 0, y: 0 });
  const rotation = useRef({ x: 0.3, y: 0.3 });
  const atomMeshes = useRef<THREE.Mesh[]>([]);
  const groupRef = useRef<THREE.Group | null>(null);
  const [hoveredAtom] = useState<number | null>(null);
  const raycaster = useRef(new THREE.Raycaster());
  const mouse = useRef(new THREE.Vector2());

  const buildScene = useCallback(() => {
    const scene = sceneRef.current!;
    const group = new THREE.Group();
    groupRef.current = group;
    atomMeshes.current = [];

    // Clear existing
    while (scene.children.length > 0) scene.remove(scene.children[0]);

    // Lighting
    const ambient = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambient);
    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(5, 10, 5);
    scene.add(dirLight);
    const pointLight = new THREE.PointLight(0x6699ff, 0.8, 50);
    pointLight.position.set(-5, 5, 5);
    scene.add(pointLight);
    const rimLight = new THREE.DirectionalLight(0xff9933, 0.4);
    rimLight.position.set(-5, -5, -5);
    scene.add(rimLight);

    // Center atoms
    if (atoms.length === 0) { scene.add(group); return; }
    const cx = atoms.reduce((s, a) => s + a.x, 0) / atoms.length;
    const cy = atoms.reduce((s, a) => s + a.y, 0) / atoms.length;
    const cz = atoms.reduce((s, a) => s + a.z, 0) / atoms.length;

    // Bonds
    if (renderMode !== 'space-filling') {
      bonds.forEach((bond) => {
        const a1 = atoms[bond.from];
        const a2 = atoms[bond.to];
        if (!a1 || !a2) return;

        const v1 = new THREE.Vector3(a1.x - cx, a1.y - cy, a1.z - cz);
        const v2 = new THREE.Vector3(a2.x - cx, a2.y - cy, a2.z - cz);

        const bondCount = bond.order;
        const offsets = bondCount === 1 ? [0] : bondCount === 2 ? [-0.07, 0.07] : [-0.12, 0, 0.12];

        offsets.forEach((offset, i) => {
          const dir = new THREE.Vector3().subVectors(v2, v1);
          const length = dir.length();
          dir.normalize();

          const perp = new THREE.Vector3(dir.y, -dir.x, 0).normalize().multiplyScalar(offset);

          const mid = new THREE.Vector3().addVectors(v1, v2).multiplyScalar(0.5);
          mid.add(perp);

          const bondGeo = new THREE.CylinderGeometry(
            renderMode === 'wireframe' ? 0.04 : 0.07,
            renderMode === 'wireframe' ? 0.04 : 0.07,
            length,
            12
          );
          const bondColor = i === 0 ? 0x888888 : i === 1 ? 0xaaaaaa : 0xbbbbbb;
          const bondMat = new THREE.MeshPhongMaterial({
            color: bondColor,
            shininess: 60,
            transparent: renderMode === 'wireframe',
            opacity: renderMode === 'wireframe' ? 0.6 : 1,
          });
          const bondMesh = new THREE.Mesh(bondGeo, bondMat);

          const startWithOffset = v1.clone().add(perp);
          const endWithOffset = v2.clone().add(perp);
          const midWithOffset = new THREE.Vector3().addVectors(startWithOffset, endWithOffset).multiplyScalar(0.5);
          bondMesh.position.copy(midWithOffset);

          const axis = new THREE.Vector3(0, 1, 0);
          const bondDir = new THREE.Vector3().subVectors(endWithOffset, startWithOffset).normalize();
          bondMesh.quaternion.setFromUnitVectors(axis, bondDir);

          group.add(bondMesh);
        });
      });
    }

    // Atoms
    atoms.forEach((atom, i) => {
      const radius = getAtomRadius(atom.symbol, renderMode);
      const geo = new THREE.SphereGeometry(radius, 32, 32);
      const color = getAtomColor(atom.symbol);
      const isSelected = i === selectedAtom;
      const isHovered = i === hoveredAtom;

      const mat = new THREE.MeshPhongMaterial({
        color: isSelected ? 0xffff00 : color,
        emissive: isSelected ? 0x443300 : isHovered ? 0x222244 : 0x000000,
        shininess: 100,
        specular: 0x444444,
        transparent: renderMode === 'wireframe',
        opacity: renderMode === 'wireframe' ? 0.7 : 1,
        wireframe: false,
      });

      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(atom.x - cx, atom.y - cy, atom.z - cz);
      mesh.userData = { atomIndex: i };
      atomMeshes.current.push(mesh);
      group.add(mesh);

      // Outline for selected
      if (isSelected) {
        const outlineGeo = new THREE.SphereGeometry(radius * 1.15, 32, 32);
        const outlineMat = new THREE.MeshBasicMaterial({ color: 0xffff00, side: THREE.BackSide, transparent: true, opacity: 0.5 });
        const outline = new THREE.Mesh(outlineGeo, outlineMat);
        outline.position.copy(mesh.position);
        group.add(outline);
      }
    });

    scene.add(group);
  }, [atoms, bonds, renderMode, selectedAtom, hoveredAtom]);

  useEffect(() => {
    if (!mountRef.current) return;
    const w = mountRef.current.clientWidth;
    const h = mountRef.current.clientHeight;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(w, h);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;
    mountRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(50, w / h, 0.1, 1000);
    camera.position.z = 8;
    cameraRef.current = camera;

    buildScene();

    // Animation loop
    let t = 0;
    const animate = () => {
      frameRef.current = requestAnimationFrame(animate);
      t += 0.01;

      if (groupRef.current) {
        if (!isDragging.current && animated) {
          rotation.current.y += 0.005;
        }
        groupRef.current.rotation.x = rotation.current.x;
        groupRef.current.rotation.y = rotation.current.y;
      }

      renderer.render(scene, camera);
    };
    animate();

    // Resize
    const handleResize = () => {
      if (!mountRef.current) return;
      const w2 = mountRef.current.clientWidth;
      const h2 = mountRef.current.clientHeight;
      camera.aspect = w2 / h2;
      camera.updateProjectionMatrix();
      renderer.setSize(w2, h2);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(frameRef.current);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      mountRef.current?.removeChild(renderer.domElement);
    };
  }, []);

  useEffect(() => {
    if (sceneRef.current) buildScene();
  }, [buildScene]);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    lastMouse.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!mountRef.current) return;
    const rect = mountRef.current.getBoundingClientRect();
    mouse.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    if (isDragging.current) {
      const dx = e.clientX - lastMouse.current.x;
      const dy = e.clientY - lastMouse.current.y;
      rotation.current.y += dx * 0.01;
      rotation.current.x += dy * 0.01;
      lastMouse.current = { x: e.clientX, y: e.clientY };
    }
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    if (isDragging.current && Math.abs(e.clientX - lastMouse.current.x) < 3 && Math.abs(e.clientY - lastMouse.current.y) < 3) {
      // Click
      if (cameraRef.current && sceneRef.current) {
        raycaster.current.setFromCamera(mouse.current, cameraRef.current);
        const intersects = raycaster.current.intersectObjects(atomMeshes.current);
        if (intersects.length > 0) {
          const idx = intersects[0].object.userData.atomIndex;
          if (idx !== undefined) onAtomClick(idx);
        }
      }
    }
    isDragging.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (cameraRef.current) {
      cameraRef.current.position.z += e.deltaY * 0.01;
      cameraRef.current.position.z = Math.max(2, Math.min(30, cameraRef.current.position.z));
    }
  };

  return (
    <div
      ref={mountRef}
      className="w-full h-full cursor-grab active:cursor-grabbing"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={() => { isDragging.current = false; }}
      onWheel={handleWheel}
    />
  );
}
