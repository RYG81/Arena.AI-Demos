import { MoleculeData } from '../data/molecules';
import { PubChemProperties } from '../utils/pubchem';
import { Activity, Atom, Zap, Droplets, Scale, Info, ExternalLink } from 'lucide-react';

interface Props {
  molecule: MoleculeData | null;
  pubchemData?: PubChemProperties | null;
  selectedAtom: number | null;
  onAtomDeselect: () => void;
}

function PropertyRow({ label, value, color = 'text-cyan-300' }: { label: string; value: string | number; color?: string }) {
  return (
    <div className="flex justify-between items-center py-1.5 border-b border-slate-700/40 last:border-0">
      <span className="text-slate-400 text-xs">{label}</span>
      <span className={`text-xs font-semibold ${color}`}>{value}</span>
    </div>
  );
}

function Section({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/40">
      <div className="flex items-center gap-2 mb-2">
        <span className="text-cyan-400">{icon}</span>
        <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">{title}</span>
      </div>
      {children}
    </div>
  );
}

const ATOM_FULL_NAMES: Record<string, string> = {
  H: 'Hydrogen', C: 'Carbon', N: 'Nitrogen', O: 'Oxygen', F: 'Fluorine',
  P: 'Phosphorus', S: 'Sulfur', Cl: 'Chlorine', Br: 'Bromine', I: 'Iodine',
  Na: 'Sodium', K: 'Potassium', Ca: 'Calcium', Fe: 'Iron', Mg: 'Magnesium',
};

const ATOM_ELECTRONEG: Record<string, number> = {
  H: 2.20, C: 2.55, N: 3.04, O: 3.44, F: 3.98, P: 2.19, S: 2.58,
  Cl: 3.16, Br: 2.96, I: 2.66, Na: 0.93, K: 0.82, Ca: 1.00, Fe: 1.83, Mg: 1.31,
};

export default function PropertyPanel({ molecule, pubchemData, selectedAtom, onAtomDeselect }: Props) {
  if (!molecule) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-6">
        <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mb-4">
          <Atom size={32} className="text-slate-600" />
        </div>
        <p className="text-slate-500 text-sm">Select or search a molecule to see its properties</p>
      </div>
    );
  }

  const atomSymbol = selectedAtom !== null ? molecule.atoms[selectedAtom]?.symbol : null;
  const singleBonds = molecule.bonds.filter(b => b.order === 1).length;
  const doubleBonds = molecule.bonds.filter(b => b.order === 2).length;
  const tripleBonds = molecule.bonds.filter(b => b.order === 3).length;

  const atomCounts: Record<string, number> = {};
  molecule.atoms.forEach(a => { atomCounts[a.symbol] = (atomCounts[a.symbol] || 0) + 1; });

  return (
    <div className="space-y-3 overflow-y-auto h-full pr-1 scrollbar-thin">
      {/* Molecule Header */}
      <div className="bg-gradient-to-br from-violet-900/50 to-cyan-900/50 rounded-xl p-4 border border-slate-700/40">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">{molecule.name}</h2>
            <div className="text-2xl font-mono text-cyan-300 mt-1">{molecule.formula}</div>
          </div>
          <div className="text-right">
            <span className={`text-xs px-2 py-1 rounded-full font-medium ${
              molecule.difficulty === 'Beginner' ? 'bg-green-900/60 text-green-300' :
              molecule.difficulty === 'Intermediate' ? 'bg-yellow-900/60 text-yellow-300' :
              'bg-red-900/60 text-red-300'
            }`}>{molecule.difficulty}</span>
            <div className="text-xs text-slate-400 mt-1">{molecule.category}</div>
          </div>
        </div>
        <p className="text-xs text-slate-400 mt-2 leading-relaxed line-clamp-3">{molecule.description}</p>
        {pubchemData && (
          <a
            href={`https://pubchem.ncbi.nlm.nih.gov/compound/${pubchemData.CID}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 mt-2 transition-colors"
          >
            <ExternalLink size={10} /> PubChem CID {pubchemData.CID}
          </a>
        )}
      </div>

      {/* Selected Atom Detail */}
      {selectedAtom !== null && atomSymbol && (
        <div className="bg-yellow-900/30 rounded-xl p-3 border border-yellow-500/40">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-yellow-300 uppercase tracking-wider">Selected Atom #{selectedAtom + 1}</span>
            <button onClick={onAtomDeselect} className="text-xs text-slate-400 hover:text-white">✕</button>
          </div>
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-white text-sm"
              style={{ backgroundColor: molecule.atoms[selectedAtom]?.color || '#888' }}
            >
              {atomSymbol}
            </div>
            <div>
              <div className="text-white font-semibold">{ATOM_FULL_NAMES[atomSymbol] || atomSymbol}</div>
              <div className="text-xs text-slate-400">Electronegativity: {ATOM_ELECTRONEG[atomSymbol]?.toFixed(2) || 'N/A'}</div>
              <div className="text-xs text-slate-400">Position: ({molecule.atoms[selectedAtom].x.toFixed(2)}, {molecule.atoms[selectedAtom].y.toFixed(2)}, {molecule.atoms[selectedAtom].z.toFixed(2)}) Å</div>
            </div>
          </div>
        </div>
      )}

      {/* Geometry */}
      <Section title="Geometry & Shape" icon={<Activity size={14} />}>
        <PropertyRow label="Molecular Shape" value={molecule.geometry} />
        <PropertyRow label="Hybridization" value={molecule.hybridization} />
        <PropertyRow label="Bond Angles" value={molecule.bondAngles} />
        <PropertyRow label="Polarity" value={molecule.polarity} color={molecule.polarity === 'Polar' ? 'text-blue-400' : 'text-orange-400'} />
      </Section>

      {/* Bonding */}
      <Section title="Bonding" icon={<Zap size={14} />}>
        <PropertyRow label="Total Atoms" value={molecule.atoms.length} />
        <PropertyRow label="Total Bonds" value={molecule.bonds.length} />
        <PropertyRow label="Single bonds (σ)" value={singleBonds} />
        <PropertyRow label="Double bonds (σ+π)" value={doubleBonds} color="text-yellow-300" />
        <PropertyRow label="Triple bonds (σ+2π)" value={tripleBonds} color="text-red-400" />
        <div className="pt-1 mt-1 border-t border-slate-700/40">
          <div className="text-xs text-slate-400 mb-1">Atom composition:</div>
          <div className="flex flex-wrap gap-1">
            {Object.entries(atomCounts).map(([sym, count]) => (
              <span key={sym} className="text-xs bg-slate-700 px-2 py-0.5 rounded-full text-slate-200">
                {sym}: {count}
              </span>
            ))}
          </div>
        </div>
      </Section>

      {/* Physical Properties */}
      <Section title="Physical Properties" icon={<Scale size={14} />}>
        <PropertyRow label="Molar Mass" value={`${molecule.molarMass} g/mol`} />
        <PropertyRow
          label="LogP"
          value={molecule.logP}
          color={molecule.logP < 0 ? 'text-blue-400' : 'text-orange-400'}
        />
        <PropertyRow
          label="Character"
          value={molecule.logP < 0 ? 'Hydrophilic' : 'Lipophilic'}
          color={molecule.logP < 0 ? 'text-blue-400' : 'text-orange-400'}
        />
        {pubchemData && (
          <>
            <PropertyRow label="Heavy Atoms" value={pubchemData.HeavyAtomCount ?? 'N/A'} />
            <PropertyRow label="TPSA" value={pubchemData.TPSA ? `${pubchemData.TPSA} Ų` : 'N/A'} />
            <PropertyRow label="Rotatable Bonds" value={pubchemData.RotatableBondCount ?? 'N/A'} />
            <PropertyRow label="Complexity" value={pubchemData.Complexity?.toFixed(0) ?? 'N/A'} />
          </>
        )}
      </Section>

      {/* H-Bonding */}
      <Section title="Hydrogen Bonding" icon={<Droplets size={14} />}>
        <PropertyRow label="H-bond Donors" value={molecule.hBondDonors} color="text-blue-400" />
        <PropertyRow label="H-bond Acceptors" value={molecule.hBondAcceptors} color="text-purple-400" />
        <div className="mt-2">
          <div className="flex gap-1">
            {Array.from({ length: Math.min(molecule.hBondDonors, 5) }).map((_, i) => (
              <div key={i} className="w-3 h-3 rounded-full bg-blue-500" title="Donor" />
            ))}
            {Array.from({ length: Math.min(molecule.hBondAcceptors, 5) }).map((_, i) => (
              <div key={i} className="w-3 h-3 rounded-full bg-purple-500" title="Acceptor" />
            ))}
          </div>
          <div className="flex gap-3 mt-1">
            {molecule.hBondDonors > 0 && <span className="text-xs text-blue-400">● Donors</span>}
            {molecule.hBondAcceptors > 0 && <span className="text-xs text-purple-400">● Acceptors</span>}
          </div>
        </div>
      </Section>

      {/* IUPAC Name */}
      <Section title="IUPAC Name" icon={<Info size={14} />}>
        <div className="text-xs text-cyan-300 font-mono break-all leading-relaxed">
          {pubchemData?.IUPACName || molecule.iupacName}
        </div>
        {molecule.smiles && (
          <div className="mt-2">
            <div className="text-xs text-slate-400 mb-0.5">SMILES</div>
            <div className="text-xs text-green-300 font-mono break-all leading-relaxed">{pubchemData?.CanonicalSMILES || molecule.smiles}</div>
          </div>
        )}
      </Section>

      {/* Fun Fact */}
      <div className="bg-gradient-to-r from-amber-900/30 to-orange-900/30 rounded-xl p-3 border border-amber-600/30">
        <div className="text-xs text-amber-400 font-semibold mb-1">💡 Fun Fact</div>
        <p className="text-xs text-slate-300 leading-relaxed">{molecule.funFact}</p>
      </div>
    </div>
  );
}
