import { useState } from 'react';
import { PRESET_MOLECULES, MoleculeData } from '../data/molecules';
import { ArrowLeftRight, TrendingUp, TrendingDown, Minus } from 'lucide-react';

function CompareRow({ label, v1, v2, better }: { label: string; v1: string | number; v2: string | number; better?: 'lower' | 'higher' | 'equal' }) {
  const n1 = parseFloat(String(v1));
  const n2 = parseFloat(String(v2));
  const isNum = !isNaN(n1) && !isNaN(n2);
  let icon1 = null, icon2 = null;
  if (isNum && better) {
    if (better === 'higher') {
      icon1 = n1 > n2 ? <TrendingUp size={12} className="text-green-400" /> : n1 < n2 ? <TrendingDown size={12} className="text-red-400" /> : <Minus size={12} className="text-slate-400" />;
      icon2 = n2 > n1 ? <TrendingUp size={12} className="text-green-400" /> : n2 < n1 ? <TrendingDown size={12} className="text-red-400" /> : <Minus size={12} className="text-slate-400" />;
    } else if (better === 'lower') {
      icon1 = n1 < n2 ? <TrendingDown size={12} className="text-green-400" /> : n1 > n2 ? <TrendingUp size={12} className="text-red-400" /> : <Minus size={12} className="text-slate-400" />;
      icon2 = n2 < n1 ? <TrendingDown size={12} className="text-green-400" /> : n2 > n1 ? <TrendingUp size={12} className="text-red-400" /> : <Minus size={12} className="text-slate-400" />;
    }
  }

  return (
    <div className="grid grid-cols-3 gap-2 py-1.5 border-b border-slate-700/40 last:border-0 text-xs items-center">
      <div className="text-center text-slate-200 flex items-center justify-center gap-1 font-medium">
        {v1} {icon1}
      </div>
      <div className="text-center text-slate-400">{label}</div>
      <div className="text-center text-slate-200 flex items-center justify-center gap-1 font-medium">
        {v2} {icon2}
      </div>
    </div>
  );
}

export default function CompareView() {
  const [mol1, setMol1] = useState<MoleculeData>(PRESET_MOLECULES[0]);
  const [mol2, setMol2] = useState<MoleculeData>(PRESET_MOLECULES[1]);

  const differences: string[] = [];
  if (mol1.polarity !== mol2.polarity) differences.push(`Polarity differs: ${mol1.name} is ${mol1.polarity}, ${mol2.name} is ${mol2.polarity}`);
  if (mol1.hybridization !== mol2.hybridization) differences.push(`Hybridization differs: ${mol1.name} uses ${mol1.hybridization}, ${mol2.name} uses ${mol2.hybridization}`);
  if (mol1.geometry !== mol2.geometry) differences.push(`Geometry differs: ${mol1.name} is ${mol1.geometry}, ${mol2.name} is ${mol2.geometry}`);
  if (Math.abs(mol1.molarMass - mol2.molarMass) > 1) differences.push(`Mass difference: ${Math.abs(mol1.molarMass - mol2.molarMass).toFixed(1)} g/mol`);
  if (mol1.category !== mol2.category) differences.push(`Category: ${mol1.name} is ${mol1.category}, ${mol2.name} is ${mol2.category}`);

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4 scrollbar-thin">
      <div className="flex items-center gap-2 mb-2">
        <ArrowLeftRight size={20} className="text-cyan-400" />
        <h2 className="text-lg font-bold text-white">Molecule Comparison</h2>
      </div>

      {/* Selectors */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs text-slate-400 mb-1 block">Molecule A</label>
          <select
            value={mol1.name}
            onChange={e => setMol1(PRESET_MOLECULES.find(m => m.name === e.target.value) || PRESET_MOLECULES[0])}
            className="w-full bg-slate-800 border border-slate-700/50 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-cyan-500/70"
          >
            {PRESET_MOLECULES.map(m => <option key={m.name} value={m.name}>{m.name}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs text-slate-400 mb-1 block">Molecule B</label>
          <select
            value={mol2.name}
            onChange={e => setMol2(PRESET_MOLECULES.find(m => m.name === e.target.value) || PRESET_MOLECULES[1])}
            className="w-full bg-slate-800 border border-slate-700/50 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-cyan-500/70"
          >
            {PRESET_MOLECULES.map(m => <option key={m.name} value={m.name}>{m.name}</option>)}
          </select>
        </div>
      </div>

      {/* Molecule badges */}
      <div className="grid grid-cols-2 gap-3">
        {[mol1, mol2].map((mol, i) => (
          <div key={i} className={`bg-slate-800/70 rounded-xl p-3 border ${i === 0 ? 'border-violet-600/40' : 'border-cyan-600/40'}`}>
            <div className={`text-xs font-bold mb-0.5 ${i === 0 ? 'text-violet-400' : 'text-cyan-400'}`}>Molecule {i === 0 ? 'A' : 'B'}</div>
            <div className="text-white font-semibold">{mol.name}</div>
            <div className="text-sm font-mono text-slate-300">{mol.formula}</div>
            <div className="text-xs text-slate-400 mt-1">{mol.category} · {mol.difficulty}</div>
          </div>
        ))}
      </div>

      {/* Comparison Table */}
      <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/40">
        <div className="grid grid-cols-3 gap-2 py-2 border-b border-slate-600 mb-1">
          <div className="text-center text-xs font-bold text-violet-400">{mol1.name}</div>
          <div className="text-center text-xs text-slate-500 font-semibold">Property</div>
          <div className="text-center text-xs font-bold text-cyan-400">{mol2.name}</div>
        </div>
        <CompareRow label="Formula" v1={mol1.formula} v2={mol2.formula} />
        <CompareRow label="Geometry" v1={mol1.geometry} v2={mol2.geometry} />
        <CompareRow label="Polarity" v1={mol1.polarity} v2={mol2.polarity} />
        <CompareRow label="Hybridization" v1={mol1.hybridization} v2={mol2.hybridization} />
        <CompareRow label="Bond Angles" v1={mol1.bondAngles} v2={mol2.bondAngles} />
        <CompareRow label="Molar Mass" v1={`${mol1.molarMass} g/mol`} v2={`${mol2.molarMass} g/mol`} />
        <CompareRow label="LogP" v1={mol1.logP} v2={mol2.logP} />
        <CompareRow label="H-bond Donors" v1={mol1.hBondDonors} v2={mol2.hBondDonors} />
        <CompareRow label="H-bond Acceptors" v1={mol1.hBondAcceptors} v2={mol2.hBondAcceptors} />
        <CompareRow label="Atoms" v1={mol1.atoms.length} v2={mol2.atoms.length} />
        <CompareRow label="Bonds" v1={mol1.bonds.length} v2={mol2.bonds.length} />
        <CompareRow label="Difficulty" v1={mol1.difficulty} v2={mol2.difficulty} />
      </div>

      {/* Key Differences */}
      <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/40">
        <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Key Differences</div>
        {differences.length > 0 ? (
          <ul className="space-y-1.5">
            {differences.map((d, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-slate-300">
                <span className="text-yellow-400 mt-0.5">▸</span>
                {d}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-xs text-slate-500 italic">Molecules are very similar in these properties.</p>
        )}
      </div>

      {/* Similarity Score */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-800/60 rounded-xl p-3 border border-slate-700/40">
        <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Similarity Analysis</div>
        <div className="space-y-2">
          {[
            { label: 'Polarity', match: mol1.polarity === mol2.polarity },
            { label: 'Hybridization', match: mol1.hybridization === mol2.hybridization },
            { label: 'Geometry', match: mol1.geometry === mol2.geometry },
            { label: 'Category', match: mol1.category === mol2.category },
          ].map(({ label, match }) => (
            <div key={label} className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${match ? 'bg-green-400' : 'bg-red-400'}`} />
              <span className="text-xs text-slate-400 w-24">{label}</span>
              <span className={`text-xs font-medium ${match ? 'text-green-400' : 'text-red-400'}`}>
                {match ? 'Match' : 'Different'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
