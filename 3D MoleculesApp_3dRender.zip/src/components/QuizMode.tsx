import { useState } from 'react';
import { CheckCircle, XCircle, Trophy, RotateCcw, ChevronRight, Brain } from 'lucide-react';
import { QUIZ_QUESTIONS } from '../data/molecules';

export default function QuizMode() {
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [answers, setAnswers] = useState<(number | null)[]>(Array(QUIZ_QUESTIONS.length).fill(null));
  const [showExplanation, setShowExplanation] = useState(false);

  const question = QUIZ_QUESTIONS[currentQ];

  const handleSelect = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    const newAnswers = [...answers];
    newAnswers[currentQ] = idx;
    setAnswers(newAnswers);
    if (idx === question.answer) setScore(s => s + 1);
    setShowExplanation(true);
  };

  const next = () => {
    if (currentQ < QUIZ_QUESTIONS.length - 1) {
      setCurrentQ(c => c + 1);
      setSelected(null);
      setShowExplanation(false);
    } else {
      setFinished(true);
    }
  };

  const reset = () => {
    setCurrentQ(0);
    setSelected(null);
    setScore(0);
    setFinished(false);
    setAnswers(Array(QUIZ_QUESTIONS.length).fill(null));
    setShowExplanation(false);
  };

  const pct = Math.round((score / QUIZ_QUESTIONS.length) * 100);

  if (finished) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-8">
        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center mb-6 shadow-lg shadow-orange-500/30">
          <Trophy size={48} className="text-white" />
        </div>
        <h2 className="text-3xl font-bold text-white mb-2">Quiz Complete!</h2>
        <p className="text-slate-400 mb-6">You answered {score} out of {QUIZ_QUESTIONS.length} correctly</p>

        <div className="w-full max-w-xs bg-slate-800 rounded-2xl p-6 mb-6 border border-slate-700/50">
          <div className="text-6xl font-bold text-center mb-2 bg-gradient-to-r from-cyan-400 to-violet-400 bg-clip-text text-transparent">
            {pct}%
          </div>
          <div className="w-full bg-slate-700 rounded-full h-3 mb-3">
            <div
              className={`h-3 rounded-full transition-all duration-1000 ${pct >= 80 ? 'bg-green-500' : pct >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`}
              style={{ width: `${pct}%` }}
            />
          </div>
          <p className={`text-sm text-center font-medium ${pct >= 80 ? 'text-green-400' : pct >= 60 ? 'text-yellow-400' : 'text-red-400'}`}>
            {pct >= 80 ? '🎉 Outstanding! You\'re a chemistry expert!' :
             pct >= 60 ? '👍 Good work! Keep studying!' :
             '📚 Keep learning — you\'ll get there!'}
          </p>
        </div>

        {/* Answer Review */}
        <div className="w-full max-w-sm space-y-2 mb-6">
          {QUIZ_QUESTIONS.map((q, i) => (
            <div key={i} className={`flex items-center gap-3 p-2 rounded-lg text-sm ${
              answers[i] === q.answer ? 'bg-green-900/30 border border-green-700/40' : 'bg-red-900/30 border border-red-700/40'
            }`}>
              {answers[i] === q.answer
                ? <CheckCircle size={16} className="text-green-400 flex-shrink-0" />
                : <XCircle size={16} className="text-red-400 flex-shrink-0" />}
              <span className="text-slate-300 text-xs truncate">{q.question}</span>
            </div>
          ))}
        </div>

        <button
          onClick={reset}
          className="flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white px-6 py-3 rounded-xl font-semibold transition-all"
        >
          <RotateCcw size={18} /> Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Brain size={20} className="text-violet-400" />
          <span className="font-semibold text-white">Chemistry Quiz</span>
        </div>
        <div className="text-sm text-slate-400">
          {currentQ + 1} / {QUIZ_QUESTIONS.length}
        </div>
      </div>

      {/* Progress */}
      <div className="w-full bg-slate-700 rounded-full h-1.5 mb-6">
        <div
          className="h-1.5 bg-gradient-to-r from-violet-500 to-cyan-500 rounded-full transition-all duration-300"
          style={{ width: `${((currentQ) / QUIZ_QUESTIONS.length) * 100}%` }}
        />
      </div>

      {/* Score */}
      <div className="flex gap-3 mb-6">
        <div className="flex items-center gap-1.5 bg-green-900/40 border border-green-700/40 px-3 py-1.5 rounded-lg">
          <CheckCircle size={14} className="text-green-400" />
          <span className="text-sm font-semibold text-green-300">{score} correct</span>
        </div>
        <div className="flex items-center gap-1.5 bg-slate-800 border border-slate-700/50 px-3 py-1.5 rounded-lg">
          <span className="text-xs text-cyan-300 font-mono">{question.molecule}</span>
        </div>
      </div>

      {/* Question */}
      <div className="bg-slate-800/70 rounded-2xl p-5 border border-slate-700/50 mb-4 flex-shrink-0">
        <p className="text-white font-medium text-base leading-relaxed">{question.question}</p>
      </div>

      {/* Options */}
      <div className="space-y-2 flex-1">
        {question.options.map((opt, i) => {
          const isSelected = selected === i;
          const isCorrect = i === question.answer;
          const showResult = selected !== null;

          return (
            <button
              key={i}
              onClick={() => handleSelect(i)}
              disabled={selected !== null}
              className={`w-full text-left p-3.5 rounded-xl border text-sm font-medium transition-all duration-200 flex items-center gap-3 ${
                showResult
                  ? isCorrect
                    ? 'bg-green-900/40 border-green-500 text-green-200'
                    : isSelected
                      ? 'bg-red-900/40 border-red-500 text-red-200'
                      : 'bg-slate-800/40 border-slate-700/40 text-slate-500'
                  : 'bg-slate-800 border-slate-700/50 text-slate-200 hover:border-violet-500/60 hover:bg-slate-700/70 cursor-pointer'
              }`}
            >
              <span className={`w-6 h-6 rounded-full border flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                showResult && isCorrect ? 'bg-green-500 border-green-500 text-white' :
                showResult && isSelected && !isCorrect ? 'bg-red-500 border-red-500 text-white' :
                'border-slate-600 text-slate-400'
              }`}>
                {String.fromCharCode(65 + i)}
              </span>
              {opt}
              {showResult && isCorrect && <CheckCircle size={16} className="text-green-400 ml-auto" />}
              {showResult && isSelected && !isCorrect && <XCircle size={16} className="text-red-400 ml-auto" />}
            </button>
          );
        })}
      </div>

      {/* Explanation */}
      {showExplanation && (
        <div className={`mt-3 p-3 rounded-xl text-sm border ${
          selected === question.answer
            ? 'bg-green-900/30 border-green-700/40 text-green-200'
            : 'bg-red-900/30 border-red-700/40 text-red-200'
        }`}>
          <div className="font-semibold mb-1">
            {selected === question.answer ? '✅ Correct!' : '❌ Incorrect'}
          </div>
          <p className="text-xs leading-relaxed opacity-90">{question.explanation}</p>
        </div>
      )}

      {/* Next Button */}
      {selected !== null && (
        <button
          onClick={next}
          className="mt-3 w-full flex items-center justify-center gap-2 bg-violet-600 hover:bg-violet-500 text-white py-3 rounded-xl font-semibold transition-all"
        >
          {currentQ < QUIZ_QUESTIONS.length - 1 ? (
            <><ChevronRight size={18} /> Next Question</>
          ) : (
            <><Trophy size={18} /> See Results</>
          )}
        </button>
      )}
    </div>
  );
}
