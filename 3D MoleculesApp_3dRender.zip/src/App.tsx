import { useState, useCallback, useRef } from 'react';
import {
  Search, Atom, Layers, Play, Pause,
  FlaskConical, Brain, ArrowLeftRight, BookOpen, ChevronDown,
  Loader2, AlertCircle, Eye, Globe, Sparkles, Menu, X
} from 'lucide-react';
import MoleculeViewer3D from './components/MoleculeViewer3D';
import AIChat from './components/AIChat';
import PropertyPanel from './components/PropertyPanel';
import QuizMode from './components/QuizMode';
import CompareView from './components/CompareView';
import { PRESET_MOLECULES, MoleculeData, CPK_COLORS, ATOM_RADII } from './data/molecules';
import {
  searchMoleculeByName, searchMoleculeBySMILES, parseSDFToAtomsBonds,
  PubChemProperties
} from './utils/pubchem';
import { generateMoleculeExplanation, generatePubChemExplanation } from './utils/aiExplainer';

type RenderMode = 'ball-stick' | 'space-filling' | 'wireframe';
type Tab = 'viewer' | 'compare' | 'quiz' | 'learn';
type RightPanel = 'properties' | 'ai';

function StarField() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {Array.from({ length: 60 }).map((_, i) => (
        <div
          key={i}
          className="absolute rounded-full bg-white opacity-20 animate-pulse"
          style={{
            width: Math.random() * 2 + 1 + 'px',
            height: Math.random() * 2 + 1 + 'px',
            top: Math.random() * 100 + '%',
            left: Math.random() * 100 + '%',
            animationDuration: (Math.random() * 3 + 2) + 's',
            animationDelay: Math.random() * 3 + 's',
          }}
        />
      ))}
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('viewer');
  const [rightPanel, setRightPanel] = useState<RightPanel>('properties');
  const [selectedMolecule, setSelectedMolecule] = useState<MoleculeData | null>(PRESET_MOLECULES[0]);
  const [searchInput, setSearchInput] = useState('');
  const [searchMode, setSearchMode] = useState<'name' | 'smiles'>('name');
  const [renderMode, setRenderMode] = useState<RenderMode>('ball-stick');
  const [selectedAtom, setSelectedAtom] = useState<number | null>(null);
  const [animated, setAnimated] = useState(true);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [pubchemData, setPubchemData] = useState<PubChemProperties | null>(null);
  const [aiInitialMessage, setAiInitialMessage] = useState<string | undefined>(undefined);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [liveAtoms, setLiveAtoms] = useState(PRESET_MOLECULES[0].atoms);
  const [liveBonds, setLiveBonds] = useState(PRESET_MOLECULES[0].bonds);
  const [showPresetDropdown, setShowPresetDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleSelectPreset = useCallback((mol: MoleculeData) => {
    setSelectedMolecule(mol);
    setLiveAtoms(mol.atoms);
    setLiveBonds(mol.bonds);
    setSelectedAtom(null);
    setPubchemData(null);
    setSearchError(null);
    setAiInitialMessage(generateMoleculeExplanation(mol));
    setShowPresetDropdown(false);
    setActiveTab('viewer');
  }, []);

  const handleSearch = useCallback(async () => {
    if (!searchInput.trim()) return;
    setIsSearching(true);
    setSearchError(null);
    setSelectedAtom(null);

    try {
      const result = searchMode === 'name'
        ? await searchMoleculeByName(searchInput.trim())
        : await searchMoleculeBySMILES(searchInput.trim());

      if (!result) {
        setSearchError(`No results found for "${searchInput}". Try a different name or SMILES.`);
        setIsSearching(false);
        return;
      }

      setPubchemData(result.properties);

      // Try to use 3D SDF data
      if (result.sdf3d) {
        const parsed = parseSDFToAtomsBonds(result.sdf3d);
        if (parsed && parsed.atoms.length > 0) {
          const enrichedAtoms = parsed.atoms.map(a => ({
            ...a,
            color: CPK_COLORS[a.symbol] || CPK_COLORS.default,
            radius: ATOM_RADII[a.symbol] || ATOM_RADII.default,
          }));
          setLiveAtoms(enrichedAtoms);
          setLiveBonds(parsed.bonds);

          // Create a pseudo molecule for display
          const pseudoMol: MoleculeData = {
            name: result.properties.IUPACName?.split('-').slice(-1)[0] || searchInput,
            formula: result.properties.MolecularFormula,
            smiles: result.properties.CanonicalSMILES,
            cid: result.properties.CID,
            iupacName: result.properties.IUPACName || '',
            category: 'PubChem',
            difficulty: 'Intermediate',
            geometry: 'See 3D Structure',
            hybridization: 'Computed',
            polarity: result.properties.XLogP !== undefined ? (result.properties.XLogP < 0 ? 'Polar' : 'Nonpolar') : 'Unknown',
            molarMass: parseFloat(String(result.properties.MolecularWeight)) || 0,
            bondAngles: 'See 3D Structure',
            hBondDonors: result.properties.HBondDonorCount || 0,
            hBondAcceptors: result.properties.HBondAcceptorCount || 0,
            logP: result.properties.XLogP || 0,
            description: `This compound was fetched live from PubChem (CID: ${result.properties.CID}). Its 3D structure is computationally generated.`,
            funFact: `PubChem contains over 119 million chemical substances. This molecule's IUPAC name is: ${result.properties.IUPACName || 'Unknown'}.`,
            atoms: enrichedAtoms,
            bonds: parsed.bonds,
          };
          setSelectedMolecule(pseudoMol);
          setAiInitialMessage(generatePubChemExplanation(result.properties, true));
          setActiveTab('viewer');
        } else {
          fallbackToPreset(result.properties);
        }
      } else {
        fallbackToPreset(result.properties);
      }
    } catch (err) {
      setSearchError('Network error. Please check your connection and try again.');
    } finally {
      setIsSearching(false);
    }
  }, [searchInput, searchMode]);

  const fallbackToPreset = (props: PubChemProperties) => {
    const match = PRESET_MOLECULES.find(m => m.formula === props.MolecularFormula || m.smiles === props.CanonicalSMILES);
    if (match) {
      setSelectedMolecule(match);
      setLiveAtoms(match.atoms);
      setLiveBonds(match.bonds);
      setAiInitialMessage(generatePubChemExplanation(props, false));
    } else {
      setSearchError('3D structure not available for this molecule. Try a simpler compound.');
    }
  };

  const handleAtomClick = useCallback((idx: number) => {
    setSelectedAtom(prev => prev === idx ? null : idx);
    setRightPanel('properties');
  }, []);

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'viewer', label: '3D Viewer', icon: <Atom size={16} /> },
    { id: 'compare', label: 'Compare', icon: <ArrowLeftRight size={16} /> },
    { id: 'quiz', label: 'Quiz', icon: <Brain size={16} /> },
    { id: 'learn', label: 'Learn', icon: <BookOpen size={16} /> },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans flex flex-col overflow-hidden" style={{ fontFamily: 'Inter, sans-serif' }}>
      <StarField />

      {/* HEADER */}
      <header className="relative z-20 flex items-center gap-4 px-4 py-3 bg-slate-900/90 backdrop-blur border-b border-slate-700/50 flex-shrink-0">
        {/* Logo */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-cyan-500 rounded-lg flex items-center justify-center shadow-lg shadow-violet-500/30">
            <FlaskConical size={18} className="text-white" />
          </div>
          <div className="hidden sm:block">
            <div className="text-sm font-bold text-white leading-none">MolecularAI</div>
            <div className="text-xs text-slate-500">Chemistry Intelligence Lab</div>
          </div>
        </div>

        {/* Search */}
        <div className="flex-1 flex gap-2 max-w-xl">
          <div className="flex gap-0 rounded-lg border border-slate-700/70 overflow-hidden flex-shrink-0">
            <button
              onClick={() => setSearchMode('name')}
              className={`text-xs px-2.5 py-1.5 transition-all ${searchMode === 'name' ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
            >
              Name
            </button>
            <button
              onClick={() => setSearchMode('smiles')}
              className={`text-xs px-2.5 py-1.5 transition-all ${searchMode === 'smiles' ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
            >
              SMILES
            </button>
          </div>
          <div className="flex-1 relative flex gap-2">
            <input
              type="text"
              value={searchInput}
              onChange={e => setSearchInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSearch()}
              placeholder={searchMode === 'name' ? 'Search: aspirin, caffeine, glucose...' : 'Enter SMILES: CC(=O)Oc1ccccc1C(=O)O'}
              className="flex-1 bg-slate-800 border border-slate-700/50 text-sm text-white rounded-lg px-3 py-1.5 focus:outline-none focus:border-violet-500/70 placeholder-slate-500 transition-colors"
            />
            <button
              onClick={handleSearch}
              disabled={isSearching || !searchInput.trim()}
              className="bg-violet-600 hover:bg-violet-500 disabled:bg-slate-700 disabled:text-slate-500 text-white px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 text-sm font-medium whitespace-nowrap"
            >
              {isSearching ? <Loader2 size={15} className="animate-spin" /> : <Search size={15} />}
              <span className="hidden sm:inline">{isSearching ? 'Fetching...' : 'Search'}</span>
            </button>
          </div>
        </div>

        {/* Nav tabs */}
        <nav className="hidden lg:flex items-center gap-1 bg-slate-800/60 rounded-xl p-1">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-violet-600 text-white shadow-lg shadow-violet-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-700'
              }`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </nav>

        <button className="lg:hidden" onClick={() => setShowMobileMenu(!showMobileMenu)}>
          {showMobileMenu ? <X size={20} /> : <Menu size={20} />}
        </button>
      </header>

      {/* Mobile Menu */}
      {showMobileMenu && (
        <div className="relative z-20 bg-slate-900 border-b border-slate-700/50 p-3 flex gap-2 flex-wrap lg:hidden">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id); setShowMobileMenu(false); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab.id ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
      )}

      {/* Error Banner */}
      {searchError && (
        <div className="relative z-20 flex items-center gap-2 bg-red-900/40 border-b border-red-700/50 px-4 py-2 text-sm text-red-300">
          <AlertCircle size={16} className="flex-shrink-0" />
          {searchError}
          <button onClick={() => setSearchError(null)} className="ml-auto text-red-400 hover:text-white">✕</button>
        </div>
      )}

      {/* MAIN CONTENT */}
      <main className="relative z-10 flex-1 overflow-hidden flex">

        {/* === VIEWER TAB === */}
        {activeTab === 'viewer' && (
          <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">

            {/* Left: Preset Panel + 3D Viewer */}
            <div className="flex-1 flex flex-col min-h-0 overflow-hidden">

              {/* Preset Molecule Selector + Controls */}
              <div className="flex items-center gap-2 px-3 py-2 bg-slate-900/60 border-b border-slate-700/40 flex-shrink-0 flex-wrap gap-y-2">
                {/* Preset dropdown */}
                <div className="relative" ref={dropdownRef}>
                  <button
                    onClick={() => setShowPresetDropdown(!showPresetDropdown)}
                    className="flex items-center gap-2 bg-slate-800 border border-slate-700/50 hover:border-violet-500/60 text-sm text-white rounded-lg px-3 py-1.5 transition-all"
                  >
                    <Layers size={14} className="text-violet-400" />
                    <span>{selectedMolecule?.name || 'Presets'}</span>
                    <ChevronDown size={14} className={`text-slate-400 transition-transform ${showPresetDropdown ? 'rotate-180' : ''}`} />
                  </button>
                  {showPresetDropdown && (
                    <div className="absolute top-full left-0 mt-1 w-56 bg-slate-800 border border-slate-700/60 rounded-xl shadow-xl z-50 overflow-hidden">
                      {PRESET_MOLECULES.map(mol => (
                        <button
                          key={mol.name}
                          onClick={() => handleSelectPreset(mol)}
                          className={`w-full text-left px-3 py-2.5 text-sm hover:bg-slate-700 transition-colors flex items-center justify-between ${
                            selectedMolecule?.name === mol.name ? 'bg-slate-700 text-violet-300' : 'text-slate-200'
                          }`}
                        >
                          <span>{mol.name}</span>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-mono text-slate-400">{mol.formula}</span>
                            <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                              mol.difficulty === 'Beginner' ? 'bg-green-900/60 text-green-400' :
                              mol.difficulty === 'Intermediate' ? 'bg-yellow-900/60 text-yellow-400' :
                              'bg-red-900/60 text-red-400'
                            }`}>{mol.difficulty[0]}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Render Mode */}
                <div className="flex gap-0.5 bg-slate-800 rounded-lg p-0.5 border border-slate-700/50">
                  {(['ball-stick', 'space-filling', 'wireframe'] as RenderMode[]).map(mode => (
                    <button
                      key={mode}
                      onClick={() => setRenderMode(mode)}
                      className={`text-xs px-2 py-1 rounded-md transition-all capitalize ${
                        renderMode === mode ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {mode === 'ball-stick' ? 'Ball & Stick' : mode === 'space-filling' ? 'Space Fill' : 'Wire'}
                    </button>
                  ))}
                </div>

                {/* Animate toggle */}
                <button
                  onClick={() => setAnimated(!animated)}
                  className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg border transition-all ${
                    animated ? 'bg-cyan-900/50 border-cyan-700/50 text-cyan-300' : 'bg-slate-800 border-slate-700/50 text-slate-400'
                  }`}
                >
                  {animated ? <Pause size={13} /> : <Play size={13} />}
                  {animated ? 'Pause' : 'Rotate'}
                </button>

                {/* Data source badge */}
                {pubchemData && (
                  <div className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg bg-green-900/30 border border-green-700/40 text-green-300 ml-auto">
                    <Globe size={12} /> Live PubChem
                  </div>
                )}
              </div>

              {/* 3D Viewer */}
              <div className="flex-1 relative bg-gradient-to-b from-slate-950 to-slate-900 overflow-hidden min-h-0">
                {liveAtoms.length > 0 ? (
                  <MoleculeViewer3D
                    atoms={liveAtoms}
                    bonds={liveBonds}
                    renderMode={renderMode}
                    selectedAtom={selectedAtom}
                    onAtomClick={handleAtomClick}
                    animated={animated}
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-slate-600 text-center">
                      <Atom size={48} className="mx-auto mb-2 opacity-50" />
                      <p>No molecule loaded</p>
                    </div>
                  </div>
                )}

                {/* Overlay info */}
                {selectedAtom !== null && liveAtoms[selectedAtom] && (
                  <div className="absolute top-3 left-3 bg-slate-900/90 backdrop-blur border border-yellow-500/50 rounded-xl px-4 py-3 text-sm shadow-xl">
                    <div className="font-bold text-yellow-300">Atom #{selectedAtom + 1}: {liveAtoms[selectedAtom].symbol}</div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      Click atom again or press ESC to deselect
                    </div>
                  </div>
                )}

                {/* Molecule name overlay */}
                {selectedMolecule && (
                  <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-slate-900/80 backdrop-blur border border-slate-700/50 rounded-full px-4 py-1.5 text-sm text-white font-semibold pointer-events-none">
                    {selectedMolecule.name} — {selectedMolecule.formula}
                  </div>
                )}

                {/* Controls hint */}
                <div className="absolute bottom-3 right-3 text-xs text-slate-600 text-right">
                  Drag to rotate · Scroll to zoom · Click atom to select
                </div>

                {/* Loading overlay */}
                {isSearching && (
                  <div className="absolute inset-0 bg-slate-950/80 backdrop-blur flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-16 h-16 border-4 border-violet-500/30 border-t-violet-500 rounded-full animate-spin mx-auto mb-3" />
                      <p className="text-violet-300 font-semibold">Fetching from PubChem...</p>
                      <p className="text-slate-500 text-xs mt-1">Loading 3D molecular structure</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right Panel */}
            <div className="w-full lg:w-80 xl:w-96 flex flex-col border-t lg:border-t-0 lg:border-l border-slate-700/40 bg-slate-900/40 min-h-0 max-h-[45vh] lg:max-h-none">
              {/* Panel Tabs */}
              <div className="flex border-b border-slate-700/40 flex-shrink-0">
                <button
                  onClick={() => setRightPanel('properties')}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-sm font-medium transition-all border-b-2 ${
                    rightPanel === 'properties' ? 'border-violet-500 text-white' : 'border-transparent text-slate-400 hover:text-white'
                  }`}
                >
                  <Eye size={14} /> Properties
                </button>
                <button
                  onClick={() => setRightPanel('ai')}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-sm font-medium transition-all border-b-2 ${
                    rightPanel === 'ai' ? 'border-cyan-500 text-white' : 'border-transparent text-slate-400 hover:text-white'
                  }`}
                >
                  <Sparkles size={14} /> AI Tutor
                </button>
              </div>

              <div className="flex-1 overflow-hidden p-3">
                {rightPanel === 'properties' ? (
                  <PropertyPanel
                    molecule={selectedMolecule}
                    pubchemData={pubchemData}
                    selectedAtom={selectedAtom}
                    onAtomDeselect={() => setSelectedAtom(null)}
                  />
                ) : (
                  <AIChat
                    molecule={selectedMolecule}
                    pubchemData={pubchemData}
                    initialMessage={aiInitialMessage}
                  />
                )}
              </div>
            </div>
          </div>
        )}

        {/* === COMPARE TAB === */}
        {activeTab === 'compare' && (
          <div className="flex-1 overflow-hidden flex">
            <CompareView />
          </div>
        )}

        {/* === QUIZ TAB === */}
        {activeTab === 'quiz' && (
          <div className="flex-1 overflow-hidden flex max-w-2xl mx-auto w-full">
            <QuizMode />
          </div>
        )}

        {/* === LEARN TAB === */}
        {activeTab === 'learn' && (
          <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto w-full">
            <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
              <BookOpen className="text-cyan-400" /> Chemistry Learning Hub
            </h2>
            <p className="text-slate-400 text-sm mb-6">Master fundamental chemistry concepts with interactive explanations.</p>

            <div className="grid md:grid-cols-2 gap-4">
              {[
                {
                  title: 'VSEPR Theory',
                  icon: '🔮',
                  color: 'from-violet-900/50 to-purple-900/50',
                  border: 'border-violet-700/40',
                  content: 'Valence Shell Electron Pair Repulsion (VSEPR) theory predicts the 3D shape of molecules based on the number of electron pairs around the central atom. Lone pairs repel more strongly than bonding pairs, distorting bond angles.',
                  points: ['2 bonds, 0 lone pairs → Linear (180°)', '3 bonds, 0 lone pairs → Trigonal Planar (120°)', '4 bonds, 0 lone pairs → Tetrahedral (109.5°)', '3 bonds, 1 lone pair → Trigonal Pyramidal (~107°)', '2 bonds, 2 lone pairs → Bent (~104.5°)'],
                },
                {
                  title: 'Hybridization',
                  icon: '⚛️',
                  color: 'from-cyan-900/50 to-blue-900/50',
                  border: 'border-cyan-700/40',
                  content: 'Atomic orbitals mix (hybridize) to form new orbitals better suited for bonding. The type of hybridization determines the geometry and bond angles of the molecule.',
                  points: ['sp: 2 orbitals, 180° (Linear)', 'sp²: 3 orbitals, 120° (Trigonal Planar)', 'sp³: 4 orbitals, 109.5° (Tetrahedral)', 'sp³d: 5 orbitals, 90° & 120° (Trigonal Bipyramidal)', 'sp³d²: 6 orbitals, 90° (Octahedral)'],
                },
                {
                  title: 'Molecular Polarity',
                  icon: '⚡',
                  color: 'from-yellow-900/50 to-orange-900/50',
                  border: 'border-yellow-700/40',
                  content: 'A molecule is polar when it has a net dipole moment — meaning the bond dipoles don\'t cancel. This depends on both bond polarity (electronegativity difference) AND molecular geometry (symmetry).',
                  points: ['Polar bonds + asymmetric shape → Polar molecule', 'Polar bonds + symmetric shape → Nonpolar molecule', 'H₂O: bent + O is electronegative → Polar', 'CO₂: linear symmetry cancels dipoles → Nonpolar', 'Polarity affects solubility, boiling point, reactivity'],
                },
                {
                  title: 'Types of Bonds',
                  icon: '🔗',
                  color: 'from-green-900/50 to-emerald-900/50',
                  border: 'border-green-700/40',
                  content: 'Chemical bonds arise from the attraction between nuclei and electrons. The type of bond determines bond length, strength, and molecular properties.',
                  points: ['Single bond (σ): direct overlap, rotatable', 'Double bond (σ+π): one σ + one π, restricted rotation', 'Triple bond (σ+2π): one σ + two π, very strong & short', 'Ionic: complete electron transfer (Na⁺Cl⁻)', 'Hydrogen bond: N/O/F−H···N/O/F (intermolecular)'],
                },
                {
                  title: 'Electronegativity',
                  icon: '🧲',
                  color: 'from-red-900/50 to-pink-900/50',
                  border: 'border-red-700/40',
                  content: 'Electronegativity is an atom\'s tendency to attract electrons in a bond. The Pauling scale ranges from 0.7 (Cs) to 4.0 (F). Differences create polar bonds and partial charges.',
                  points: ['F: 3.98 (most electronegative)', 'O: 3.44', 'N: 3.04, Cl: 3.16', 'C: 2.55, H: 2.20', 'ΔEN < 0.5: nonpolar covalent', 'ΔEN 0.5–2.0: polar covalent', 'ΔEN > 2.0: ionic character'],
                },
                {
                  title: 'Aromaticity',
                  icon: '🌀',
                  color: 'from-indigo-900/50 to-violet-900/50',
                  border: 'border-indigo-700/40',
                  content: 'Aromatic compounds have delocalized π electron systems following Hückel\'s rule (4n+2 π electrons). This gives exceptional stability compared to non-aromatic equivalents.',
                  points: ['Hückel rule: 4n+2 π electrons (n=0,1,2...)', 'Benzene: 6π electrons (n=1) → aromatic', 'Must be cyclic, planar, fully conjugated', 'All C atoms sp² hybridized in benzene', 'Aromatic stabilization energy ~36 kcal/mol', 'Resists addition reactions, undergoes substitution'],
                },
              ].map((topic) => (
                <div key={topic.title} className={`bg-gradient-to-br ${topic.color} rounded-2xl p-5 border ${topic.border}`}>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-2xl">{topic.icon}</span>
                    <h3 className="text-lg font-bold text-white">{topic.title}</h3>
                  </div>
                  <p className="text-slate-300 text-sm leading-relaxed mb-3">{topic.content}</p>
                  <ul className="space-y-1">
                    {topic.points.map((p, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs text-slate-300">
                        <span className="text-cyan-400 mt-0.5 flex-shrink-0">›</span>
                        {p}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            {/* Molecule Gallery */}
            <div className="mt-8">
              <h3 className="text-lg font-bold text-white mb-4">🧪 Molecule Library</h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {PRESET_MOLECULES.map(mol => (
                  <button
                    key={mol.name}
                    onClick={() => { handleSelectPreset(mol); setActiveTab('viewer'); }}
                    className="bg-slate-800/70 hover:bg-slate-700/70 border border-slate-700/50 hover:border-violet-500/50 rounded-xl p-3 text-left transition-all group"
                  >
                    <div className="text-base font-bold text-white mb-0.5 group-hover:text-violet-300 transition-colors">{mol.name}</div>
                    <div className="text-xs font-mono text-cyan-400 mb-1">{mol.formula}</div>
                    <div className={`text-xs px-1.5 py-0.5 rounded-full inline-block ${
                      mol.difficulty === 'Beginner' ? 'bg-green-900/60 text-green-400' :
                      mol.difficulty === 'Intermediate' ? 'bg-yellow-900/60 text-yellow-400' :
                      'bg-red-900/60 text-red-400'
                    }`}>{mol.difficulty}</div>
                    <div className="text-xs text-slate-400 mt-1.5">{mol.geometry}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Periodic Table Legend */}
            <div className="mt-8 bg-slate-800/60 rounded-2xl p-5 border border-slate-700/40">
              <h3 className="text-lg font-bold text-white mb-4">🎨 CPK Color Convention</h3>
              <p className="text-xs text-slate-400 mb-3">Standard colors used in 3D molecular visualization to identify atom types at a glance.</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {Object.entries(CPK_COLORS).filter(([k]) => k !== 'default').map(([sym, color]) => (
                  <div key={sym} className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full flex-shrink-0 border border-white/20" style={{ backgroundColor: color }} />
                    <div>
                      <div className="text-xs font-bold text-white">{sym}</div>
                      <div className="text-xs text-slate-500">{color}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="relative z-20 flex items-center justify-between px-4 py-2 bg-slate-900/80 border-t border-slate-700/30 text-xs text-slate-600 flex-shrink-0">
        <span>MolecularAI Platform · Data from <span className="text-slate-500">PubChem</span></span>
        <span className="hidden sm:block">No AI hallucination · Truth-first chemistry data</span>
        <span className="text-slate-700">v2.0</span>
      </footer>
    </div>
  );
}
