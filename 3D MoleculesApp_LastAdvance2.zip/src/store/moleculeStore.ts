import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  MoleculeData,
  ChatMessage,
  AISettings,
  ViewMode,
  RenderStyle,
  ColorScheme,
  UserProgress,
} from '../types/molecule';

interface MoleculeStore {
  // Current molecule
  currentMolecule: MoleculeData | null;
  setCurrentMolecule: (mol: MoleculeData | null) => void;

  // Cache (self-growing DB)
  moleculeCache: Record<string, MoleculeData>;
  addToCache: (key: string, mol: MoleculeData) => void;
  getFromCache: (key: string) => MoleculeData | null;

  // Loading state
  isLoading: boolean;
  loadingMessage: string;
  error: string | null;
  setLoading: (loading: boolean, message?: string) => void;
  setError: (error: string | null) => void;

  // View
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  renderStyle: RenderStyle;
  setRenderStyle: (style: RenderStyle) => void;
  colorScheme: ColorScheme;
  setColorScheme: (scheme: ColorScheme) => void;
  showLabels: boolean;
  setShowLabels: (show: boolean) => void;
  showHydrogens: boolean;
  setShowHydrogens: (show: boolean) => void;
  showSurface: boolean;
  setShowSurface: (show: boolean) => void;

  // Selected atom
  selectedAtom: number | null;
  setSelectedAtom: (idx: number | null) => void;

  // AI Chat
  messages: ChatMessage[];
  addMessage: (msg: ChatMessage) => void;
  clearMessages: () => void;
  isAILoading: boolean;
  setAILoading: (loading: boolean) => void;

  // AI Settings
  aiSettings: AISettings;
  setAISettings: (settings: Partial<AISettings>) => void;

  // Sidebar
  activeSidebarTab: 'properties' | 'reactions' | 'quiz' | 'settings' | 'learn';
  setActiveSidebarTab: (tab: 'properties' | 'reactions' | 'quiz' | 'settings' | 'learn') => void;

  // Active reaction
  activeReactionId: string | null;
  setActiveReactionId: (id: string | null) => void;

  // Progress
  userProgress: UserProgress;
  updateProgress: (update: Partial<UserProgress>) => void;
  addViewedMolecule: (name: string) => void;

  // Lab state
  labActiveObject: string | null;
  setLabActiveObject: (id: string | null) => void;
  labReactionActive: boolean;
  setLabReactionActive: (active: boolean) => void;

  // Input history
  searchHistory: string[];
  addToHistory: (query: string) => void;

  // Panel visibility
  showChat: boolean;
  toggleChat: () => void;
  showSidebar: boolean;
  toggleSidebar: () => void;
}

export const useMoleculeStore = create<MoleculeStore>()(
  persist(
    (set, get) => ({
      currentMolecule: null,
      setCurrentMolecule: (mol) => set({ currentMolecule: mol }),

      moleculeCache: {},
      addToCache: (key, mol) =>
        set((state) => ({
          moleculeCache: {
            ...state.moleculeCache,
            [key.toLowerCase()]: mol,
          },
        })),
      getFromCache: (key) => get().moleculeCache[key.toLowerCase()] || null,

      isLoading: false,
      loadingMessage: '',
      error: null,
      setLoading: (loading, message = '') =>
        set({ isLoading: loading, loadingMessage: message, error: loading ? null : get().error }),
      setError: (error) => set({ error, isLoading: false }),

      viewMode: 'molecule',
      setViewMode: (mode) => set({ viewMode: mode }),
      renderStyle: 'stick',
      setRenderStyle: (style) => set({ renderStyle: style }),
      colorScheme: 'element',
      setColorScheme: (scheme) => set({ colorScheme: scheme }),
      showLabels: true,
      setShowLabels: (show) => set({ showLabels: show }),
      showHydrogens: false,
      setShowHydrogens: (show) => set({ showHydrogens: show }),
      showSurface: false,
      setShowSurface: (show) => set({ showSurface: show }),

      selectedAtom: null,
      setSelectedAtom: (idx) => set({ selectedAtom: idx }),

      messages: [],
      addMessage: (msg) =>
        set((state) => ({ messages: [...state.messages.slice(-49), msg] })),
      clearMessages: () => set({ messages: [] }),
      isAILoading: false,
      setAILoading: (loading) => set({ isAILoading: loading }),

      aiSettings: {
        provider: 'demo',
        model: 'gpt-4o',
        temperature: 0.7,
        maxTokens: 1024,
      },
      setAISettings: (settings) =>
        set((state) => ({ aiSettings: { ...state.aiSettings, ...settings } })),

      activeSidebarTab: 'properties',
      setActiveSidebarTab: (tab) => set({ activeSidebarTab: tab }),

      activeReactionId: null,
      setActiveReactionId: (id) => set({ activeReactionId: id }),

      userProgress: {
        moleculesViewed: [],
        reactionsStudied: [],
        quizzesCompleted: 0,
        totalScore: 0,
        streak: 1,
        level: 1,
      },
      updateProgress: (update) =>
        set((state) => ({ userProgress: { ...state.userProgress, ...update } })),
      addViewedMolecule: (name) =>
        set((state) => {
          const viewed = state.userProgress.moleculesViewed;
          if (!viewed.includes(name)) {
            const newViewed = [...viewed, name];
            const newLevel = Math.floor(newViewed.length / 5) + 1;
            return {
              userProgress: {
                ...state.userProgress,
                moleculesViewed: newViewed,
                totalScore: state.userProgress.totalScore + 10,
                level: newLevel,
              },
            };
          }
          return state;
        }),

      labActiveObject: null,
      setLabActiveObject: (id) => set({ labActiveObject: id }),
      labReactionActive: false,
      setLabReactionActive: (active) => set({ labReactionActive: active }),

      searchHistory: [],
      addToHistory: (query) =>
        set((state) => ({
          searchHistory: [query, ...state.searchHistory.filter((q) => q !== query)].slice(0, 20),
        })),

      showChat: true,
      toggleChat: () => set((state) => ({ showChat: !state.showChat })),
      showSidebar: true,
      toggleSidebar: () => set((state) => ({ showSidebar: !state.showSidebar })),
    }),
    {
      name: 'moleculab-storage',
      partialize: (state) => ({
        moleculeCache: state.moleculeCache,
        aiSettings: state.aiSettings,
        userProgress: state.userProgress,
        searchHistory: state.searchHistory,
        showLabels: state.showLabels,
        showHydrogens: state.showHydrogens,
        renderStyle: state.renderStyle,
        colorScheme: state.colorScheme,
      }),
    }
  )
);
