import { useState } from 'react';
import {
  FlaskConical, MessageSquare, Settings, ChevronLeft, ChevronRight,
  Beaker, Brain, Activity, Menu, X, Sparkles,
  Trophy, Atom, GraduationCap
} from 'lucide-react';
import { useMoleculeStore } from './store/moleculeStore';
import SearchBar from './components/SearchBar';
import MoleculeViewer3D from './components/MoleculeViewer3D';
import LabView from './components/LabView';
import PropertiesPanel from './components/PropertiesPanel';
import ReactionsPanel from './components/ReactionsPanel';
import ChatPanel from './components/ChatPanel';
import SettingsPanel from './components/SettingsPanel';
import ViewerControls from './components/ViewerControls';
import QuizPanel from './components/QuizPanel';
import LearnPanel from './components/LearnPanel';
import WelcomeScreen from './components/WelcomeScreen';

type SidebarTab = 'properties' | 'reactions' | 'quiz' | 'settings' | 'learn';

const SIDEBAR_TABS = [
  { id: 'properties' as SidebarTab, icon: Atom, label: 'Properties', emoji: '🔬' },
  { id: 'reactions' as SidebarTab, icon: FlaskConical, label: 'Reactions', emoji: '⚗️' },
  { id: 'learn' as SidebarTab, icon: GraduationCap, label: 'Learn', emoji: '📚' },
  { id: 'quiz' as SidebarTab, icon: Brain, label: 'Quiz', emoji: '🎓' },
  { id: 'settings' as SidebarTab, icon: Settings, label: 'Settings', emoji: '⚙️' },
];

function LoadingOverlay() {
  const { isLoading, loadingMessage } = useMoleculeStore();
  if (!isLoading) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="bg-[#0d1526] border border-cyan-500/30 rounded-2xl p-6 text-center shadow-2xl max-w-xs w-full mx-4">
        <div className="relative w-16 h-16 mx-auto mb-4">
          <div className="absolute inset-0 rounded-full border-4 border-cyan-500/20" />
          <div className="absolute inset-0 rounded-full border-4 border-t-cyan-500 animate-spin" />
          <div className="absolute inset-3 rounded-full border-2 border-t-blue-400 animate-spin" style={{ animationDirection: 'reverse', animationDuration: '0.8s' }} />
          <div className="absolute inset-0 flex items-center justify-center">
            <FlaskConical size={20} className="text-cyan-400" />
          </div>
        </div>
        <div className="text-white font-semibold mb-1">Loading Molecule</div>
        <div className="text-gray-400 text-sm">{loadingMessage || 'Fetching from PubChem...'}</div>
        <div className="mt-3 flex justify-center gap-1">
          {[0, 1, 2, 3].map(i => (
            <div
              key={i}
              className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-bounce"
              style={{ animationDelay: `${i * 0.15}s` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function Header({ onToggleMobile }: { onToggleMobile: () => void }) {
  const { currentMolecule, userProgress, showChat, toggleChat } = useMoleculeStore();

  return (
    <header className="flex items-center gap-3 px-4 py-2.5 bg-[#060d1f]/95 backdrop-blur border-b border-white/10 z-30 shrink-0">
      {/* Logo */}
      <div className="flex items-center gap-2 shrink-0">
        <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg">
          <Atom size={16} className="text-white" />
        </div>
        <div className="hidden sm:block">
          <div className="text-sm font-bold text-white leading-tight">MolecuLab AI</div>
          <div className="text-[9px] text-cyan-400 leading-tight">3D Molecular Platform</div>
        </div>
      </div>

      {/* Search */}
      <div className="flex-1 min-w-0">
        <SearchBar />
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-2 shrink-0">
        {/* Level badge */}
        <div className="hidden md:flex items-center gap-1.5 px-2 py-1 bg-white/5 border border-white/10 rounded-lg">
          <Trophy size={12} className="text-yellow-400" />
          <span className="text-xs text-gray-300">Lv.{userProgress.level}</span>
        </div>

        {/* XP */}
        <div className="hidden md:flex items-center gap-1.5 px-2 py-1 bg-white/5 border border-white/10 rounded-lg">
          <Sparkles size={12} className="text-purple-400" />
          <span className="text-xs text-gray-300">{userProgress.totalScore} XP</span>
        </div>

        {/* Chat toggle */}
        <button
          onClick={toggleChat}
          className={`p-2 rounded-lg border transition-all ${
            showChat
              ? 'bg-cyan-600/20 border-cyan-500/40 text-cyan-400'
              : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
          }`}
          title="Toggle AI Chat"
        >
          <MessageSquare size={16} />
        </button>

        {/* Mobile menu */}
        <button
          onClick={onToggleMobile}
          className="md:hidden p-2 rounded-lg bg-white/5 border border-white/10 text-gray-400"
        >
          <Menu size={16} />
        </button>
      </div>
    </header>
  );
}

export default function App() {
  const {
    viewMode,
    activeSidebarTab,
    setActiveSidebarTab,
    showChat,
    showSidebar,
    toggleSidebar,
    currentMolecule,
  } = useMoleculeStore();

  const [mobileOpen, setMobileOpen] = useState(false);

  const renderSidebarContent = () => {
    switch (activeSidebarTab) {
      case 'properties': return <PropertiesPanel />;
      case 'reactions': return <ReactionsPanel />;
      case 'learn': return <LearnPanel />;
      case 'quiz': return <QuizPanel />;
      case 'settings': return <SettingsPanel />;
      default: return <PropertiesPanel />;
    }
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-[#060d1f] text-white overflow-hidden font-['Inter',sans-serif]">
      <LoadingOverlay />

      {/* Header */}
      <Header onToggleMobile={() => setMobileOpen(!mobileOpen)} />

      {/* Controls bar */}
      <div className="flex items-center gap-3 px-4 py-2 bg-[#080f21] border-b border-white/5 shrink-0 overflow-x-auto">
        <ViewerControls />

        {/* Molecule stats */}
        {currentMolecule && (
          <div className="ml-auto flex items-center gap-3 shrink-0">
            <div className="hidden lg:flex items-center gap-1.5 text-xs text-gray-500">
              <Activity size={12} className="text-green-400" />
              <span className="text-green-400">{currentMolecule.atoms?.length || 0} atoms</span>
            </div>
            <div className="hidden lg:flex items-center gap-1.5 text-xs text-gray-500">
              <Beaker size={12} className="text-blue-400" />
              <span className="text-blue-400">{currentMolecule.reactions?.length || 0} reactions</span>
            </div>
          </div>
        )}
      </div>

      {/* Main content area */}
      <div className="flex flex-1 min-h-0 overflow-hidden">

        {/* Left Sidebar — properties/reactions/learn/quiz/settings */}
        <aside className={`
          ${showSidebar ? 'w-72' : 'w-0'}
          hidden md:flex flex-col
          bg-[#080f21] border-r border-white/8
          transition-all duration-200 overflow-hidden shrink-0
        `}>
          {showSidebar && (
            <>
              {/* Tabs */}
              <div className="flex border-b border-white/8 shrink-0">
                {SIDEBAR_TABS.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveSidebarTab(tab.id)}
                    className={`flex-1 py-2.5 text-center transition-all text-xs font-medium relative ${
                      activeSidebarTab === tab.id
                        ? 'text-cyan-400 bg-cyan-900/10'
                        : 'text-gray-500 hover:text-gray-300'
                    }`}
                    title={tab.label}
                  >
                    <span className="text-base">{tab.emoji}</span>
                    {activeSidebarTab === tab.id && (
                      <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-500" />
                    )}
                  </button>
                ))}
              </div>

              {/* Tab content */}
              <div className="flex-1 overflow-y-auto p-3 min-h-0">
                <div className="text-xs font-semibold text-gray-400 mb-3 flex items-center gap-1.5">
                  {SIDEBAR_TABS.find(t => t.id === activeSidebarTab)?.emoji}
                  {SIDEBAR_TABS.find(t => t.id === activeSidebarTab)?.label}
                </div>
                {renderSidebarContent()}
              </div>
            </>
          )}
        </aside>

        {/* Sidebar toggle */}
        <button
          onClick={toggleSidebar}
          className="hidden md:flex items-center justify-center w-4 bg-[#080f21] hover:bg-white/5 border-r border-white/8 shrink-0 text-gray-600 hover:text-gray-400 transition-all group"
        >
          {showSidebar
            ? <ChevronLeft size={12} className="group-hover:text-cyan-400 transition-colors" />
            : <ChevronRight size={12} className="group-hover:text-cyan-400 transition-colors" />}
        </button>

        {/* Main viewer */}
        <main className="flex-1 min-w-0 relative overflow-hidden">
          {viewMode === 'molecule' ? <MoleculeViewer3D /> : <LabView />}
          {!currentMolecule && <WelcomeScreen />}
        </main>

        {/* Right side — AI Chat */}
        {showChat && (
          <aside className="hidden md:flex flex-col w-72 bg-[#080f21] border-l border-white/8 shrink-0 overflow-hidden">
            <ChatPanel />
          </aside>
        )}
      </div>

      {/* Mobile bottom sheet */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-40 flex">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="relative ml-auto w-80 max-w-full h-full bg-[#080f21] border-l border-white/10 flex flex-col overflow-hidden">
            <div className="flex items-center justify-between p-3 border-b border-white/10">
              <div className="text-sm font-semibold text-white">MolecuLab Menu</div>
              <button onClick={() => setMobileOpen(false)} className="p-1.5 text-gray-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            {/* Mobile tabs */}
            <div className="flex border-b border-white/8">
              {SIDEBAR_TABS.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => { setActiveSidebarTab(tab.id); }}
                  className={`flex-1 py-2.5 text-center text-xs relative ${
                    activeSidebarTab === tab.id ? 'text-cyan-400' : 'text-gray-500'
                  }`}
                  title={tab.label}
                >
                  <span className="text-base">{tab.emoji}</span>
                  {activeSidebarTab === tab.id && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-500" />
                  )}
                </button>
              ))}
            </div>

            <div className="flex-1 overflow-y-auto p-3">
              {renderSidebarContent()}
            </div>

            {/* Mobile chat */}
            <div className="border-t border-white/10 h-72 overflow-hidden">
              <ChatPanel />
            </div>
          </div>
        </div>
      )}

      {/* Mobile bottom nav */}
      <div className="md:hidden flex border-t border-white/10 bg-[#060d1f] shrink-0">
        {SIDEBAR_TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => { setActiveSidebarTab(tab.id); setMobileOpen(true); }}
            className={`flex-1 py-2 text-center flex flex-col items-center gap-0.5 transition-colors ${
              activeSidebarTab === tab.id ? 'text-cyan-400' : 'text-gray-600'
            }`}
          >
            <span className="text-lg">{tab.emoji}</span>
            <span className="text-[9px]">{tab.label}</span>
          </button>
        ))}
        <button
          onClick={() => setMobileOpen(true)}
          className="flex-1 py-2 text-center flex flex-col items-center gap-0.5 text-gray-600"
        >
          <MessageSquare size={18} />
          <span className="text-[9px]">AI Chat</span>
        </button>
      </div>
    </div>
  );
}
