export interface MoleculeAtom {
  serial: number;
  name: string;
  elem: string;
  x: number;
  y: number;
  z: number;
  charge?: number;
  partialCharge?: number;
}

export interface MoleculeBond {
  atom1: number;
  atom2: number;
  order: number;
}

export interface MoleculeProperties {
  molecularFormula: string;
  molecularWeight: number;
  iupacName?: string;
  canonicalSmiles?: string;
  inchiKey?: string;
  xlogp?: number;
  hBondDonorCount?: number;
  hBondAcceptorCount?: number;
  rotatableBondCount?: number;
  topologicalPolarSurfaceArea?: number;
  heavyAtomCount?: number;
  charge?: number;
  complexity?: number;
  isomericSmiles?: string;
  cid?: number;
  description?: string;
}

export interface ReactionInfo {
  id: string;
  name: string;
  type: 'combustion' | 'substitution' | 'addition' | 'elimination' | 'oxidation' | 'reduction' | 'neutralization' | 'polymerization' | 'decomposition';
  description: string;
  reactants: string[];
  products: string[];
  conditions: string;
  equation: string;
  mechanismSteps?: string[];
  energyChange?: 'exothermic' | 'endothermic';
}

export interface FunctionalGroup {
  name: string;
  smarts: string;
  description: string;
  color: string;
}

export interface MoleculeData {
  id: string;
  name: string;
  formula: string;
  smiles?: string;
  inchiKey?: string;
  cid?: number;
  sdfData?: string;
  atoms?: MoleculeAtom[];
  bonds?: MoleculeBond[];
  properties?: MoleculeProperties;
  reactions?: ReactionInfo[];
  functionalGroups?: FunctionalGroup[];
  synonyms?: string[];
  loadedAt: number;
  source: 'cache' | 'pubchem' | 'builtin';
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  moleculeContext?: string;
}

export interface AISettings {
  provider: 'openai' | 'deepseek' | 'ollama' | 'demo';
  apiKey?: string;
  model: string;
  temperature: number;
  maxTokens: number;
  baseUrl?: string;
}

export interface LabObject {
  id: string;
  type: 'beaker' | 'testtube' | 'burner' | 'flask' | 'thermometer';
  x: number;
  y: number;
  label?: string;
  active?: boolean;
  color?: string;
}

export type ViewMode = 'molecule' | 'lab';
export type RenderStyle = 'stick' | 'sphere' | 'cartoon' | 'surface' | 'line';
export type ColorScheme = 'element' | 'residue' | 'spectrum' | 'charge' | 'chain';

export interface UserProgress {
  moleculesViewed: string[];
  reactionsStudied: string[];
  quizzesCompleted: number;
  totalScore: number;
  streak: number;
  level: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
}
