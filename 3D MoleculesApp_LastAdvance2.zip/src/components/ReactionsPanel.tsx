import { useState } from 'react';
import { useMoleculeStore } from '../store/moleculeStore';
import { ChevronDown, ChevronUp, Zap, Flame, ArrowRight, Play } from 'lucide-react';
import type { ReactionInfo } from '../types/molecule';

const REACTION_TYPE_COLORS: Record<string, string> = {
  combustion: '#ef4444',
  substitution: '#f59e0b',
  addition: '#10b981',
  elimination: '#6366f1',
  oxidation: '#f97316',
  reduction: '#3b82f6',
  neutralization: '#8b5cf6',
  polymerization: '#ec4899',
  decomposition: '#64748b',
};

const REACTION_ICONS: Record<string, string> = {
  combustion: '🔥',
  substitution: '🔄',
  addition: '➕',
  elimination: '💨',
  oxidation: '⬆️',
  reduction: '⬇️',
  neutralization: '⚖️',
  polymerization: '🔗',
  decomposition: '💥',
};

interface ReactionCardProps {
  reaction: ReactionInfo;
  isActive: boolean;
  onActivate: () => void;
  onSimulate: () => void;
}

function ReactionCard({ reaction, isActive, onActivate, onSimulate }: ReactionCardProps) {
  const color = REACTION_TYPE_COLORS[reaction.type] || '#6b7280';
  const icon = REACTION_ICONS[reaction.type] || '⚗️';

  return (
    <div
      className={`rounded-xl border transition-all duration-200 overflow-hidden ${
        isActive
          ? 'border-opacity-60 shadow-lg'
          : 'border-white/10 hover:border-white/20'
      }`}
      style={isActive ? { borderColor: color + '99', boxShadow: `0 0 20px ${color}22` } : {}}
    >
      <button
        className="w-full p-3 text-left flex items-start justify-between gap-2"
        onClick={onActivate}
      >
        <div className="flex items-start gap-2 flex-1 min-w-0">
          <span className="text-lg shrink-0">{icon}</span>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-semibold text-sm text-white">{reaction.name}</span>
              <span
                className="text-xs px-1.5 py-0.5 rounded-full font-medium capitalize"
                style={{ backgroundColor: color + '22', color, border: `1px solid ${color}44` }}
              >
                {reaction.type}
              </span>
              {reaction.energyChange && (
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                  reaction.energyChange === 'exothermic'
                    ? 'bg-red-900/30 text-red-400 border border-red-500/30'
                    : 'bg-blue-900/30 text-blue-400 border border-blue-500/30'
                }`}>
                  {reaction.energyChange === 'exothermic' ? '🔥 Exothermic' : '❄️ Endothermic'}
                </span>
              )}
            </div>
            <div className="text-xs text-gray-400 mt-0.5 truncate">{reaction.description}</div>
          </div>
        </div>
        {isActive ? <ChevronUp size={16} className="text-gray-400 shrink-0" /> : <ChevronDown size={16} className="text-gray-400 shrink-0" />}
      </button>

      {isActive && (
        <div className="px-3 pb-3 space-y-3 border-t border-white/5">
          {/* Equation */}
          <div className="bg-black/30 rounded-lg p-2.5 mt-2">
            <div className="text-xs text-gray-500 mb-1">Reaction Equation</div>
            <div className="text-sm font-mono text-yellow-300 break-all">{reaction.equation}</div>
          </div>

          {/* Reactants → Products */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex-1">
              <div className="text-xs text-gray-500 mb-1">Reactants</div>
              <div className="flex flex-wrap gap-1">
                {reaction.reactants.map((r, i) => (
                  <span key={i} className="px-2 py-0.5 bg-red-900/30 border border-red-500/30 text-red-300 rounded text-xs">
                    {r}
                  </span>
                ))}
              </div>
            </div>
            <ArrowRight size={16} className="text-gray-500 shrink-0 mt-4" />
            <div className="flex-1">
              <div className="text-xs text-gray-500 mb-1">Products</div>
              <div className="flex flex-wrap gap-1">
                {reaction.products.map((p, i) => (
                  <span key={i} className="px-2 py-0.5 bg-green-900/30 border border-green-500/30 text-green-300 rounded text-xs">
                    {p}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Conditions */}
          <div className="flex items-center gap-2">
            <Flame size={12} className="text-orange-400" />
            <span className="text-xs text-gray-400">{reaction.conditions}</span>
          </div>

          {/* Mechanism steps */}
          {reaction.mechanismSteps && reaction.mechanismSteps.length > 0 && (
            <div>
              <div className="text-xs text-gray-500 mb-1.5">Mechanism Steps</div>
              <div className="space-y-1">
                {reaction.mechanismSteps.map((step, i) => (
                  <div key={i} className="flex gap-2 text-xs text-gray-300">
                    <span className="shrink-0 w-5 h-5 rounded-full bg-white/10 flex items-center justify-center text-gray-400 font-bold text-[10px]">
                      {i + 1}
                    </span>
                    <span className="leading-relaxed">{step}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Simulate button */}
          <button
            onClick={onSimulate}
            className="w-full py-2 rounded-lg flex items-center justify-center gap-2 text-sm font-medium transition-all hover:opacity-90 active:scale-95"
            style={{ backgroundColor: color + '33', color, border: `1px solid ${color}55` }}
          >
            <Play size={14} />
            Simulate Reaction in Lab
          </button>
        </div>
      )}
    </div>
  );
}

export default function ReactionsPanel() {
  const { currentMolecule, activeReactionId, setActiveReactionId, setViewMode, setLabReactionActive } = useMoleculeStore();
  const [simulatingId, setSimulatingId] = useState<string | null>(null);

  if (!currentMolecule) {
    return (
      <div className="flex flex-col items-center justify-center h-40 text-gray-500 text-sm text-center">
        <div className="text-3xl mb-3">⚗️</div>
        <div>Load a molecule to see possible reactions</div>
      </div>
    );
  }

  const reactions = currentMolecule.reactions || [];

  if (reactions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-40 text-gray-500 text-sm text-center">
        <div className="text-3xl mb-3">🧪</div>
        <div>No reactions detected for this molecule</div>
        <div className="text-xs text-gray-600 mt-1">Try a different molecule with functional groups</div>
      </div>
    );
  }

  const handleSimulate = (reactionId: string) => {
    setSimulatingId(reactionId);
    setActiveReactionId(reactionId);
    setLabReactionActive(true);
    setViewMode('lab');
    setTimeout(() => setSimulatingId(null), 2000);
  };

  return (
    <div className="space-y-2 pb-4">
      <div className="flex items-center justify-between mb-3">
        <div>
          <div className="text-sm font-semibold text-white">Possible Reactions</div>
          <div className="text-xs text-gray-500">{reactions.length} reactions detected</div>
        </div>
        <div className="flex items-center gap-1 text-xs text-cyan-400">
          <Zap size={12} />
          <span>Click to expand</span>
        </div>
      </div>

      {reactions.map((reaction) => (
        <ReactionCard
          key={reaction.id}
          reaction={reaction}
          isActive={activeReactionId === reaction.id}
          onActivate={() => setActiveReactionId(activeReactionId === reaction.id ? null : reaction.id)}
          onSimulate={() => handleSimulate(reaction.id)}
        />
      ))}
    </div>
  );
}
