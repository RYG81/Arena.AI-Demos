import { useState } from 'react';
import { Search, Atom, FlaskConical, Brain, Zap, X } from 'lucide-react';
import { useMoleculeStore } from '../store/moleculeStore';
import { fetchMoleculeByName } from '../services/pubchemService';

const FEATURED = [
  { name: 'Caffeine', emoji: '☕', desc: 'The world\'s favorite stimulant', color: '#f59e0b' },
  { name: 'Aspirin', emoji: '💊', desc: 'First synthetic drug (1897)', color: '#3b82f6' },
  { name: 'Dopamine', emoji: '🧠', desc: 'The "feel good" neurotransmitter', color: '#a855f7' },
  { name: 'Glucose', emoji: '⚡', desc: 'Primary cellular energy source', color: '#10b981' },
  { name: 'Penicillin', emoji: '🦠', desc: 'Revolutionary antibiotic', color: '#ec4899' },
  { name: 'Benzene', emoji: '🔬', desc: 'Classic aromatic compound', color: '#06b6d4' },
];

export default function WelcomeScreen() {
  const [dismissed, setDismissed] = useState(false);
  const { setCurrentMolecule, setLoading, setError, addToCache, getFromCache, addViewedMolecule, addToHistory } = useMoleculeStore();

  if (dismissed) return null;

  const loadMolecule = async (name: string) => {
    setDismissed(true);
    const cached = getFromCache(name);
    if (cached) {
      setCurrentMolecule({ ...cached, source: 'cache' });
      return;
    }
    setLoading(true, `Loading ${name}...`);
    try {
      const mol = await fetchMoleculeByName(name);
      addToCache(name, mol);
      addToCache(mol.name.toLowerCase(), mol);
      setCurrentMolecule(mol);
      addViewedMolecule(name);
      addToHistory(name);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="absolute inset-0 z-20 bg-[#060d1f]/95 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-2xl shadow-cyan-500/30 animate-float">
              <Atom size={32} className="text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">
            Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">MolecuLab AI</span>
          </h1>
          <p className="text-gray-400 text-sm max-w-md mx-auto leading-relaxed">
            Your AI-powered 3D molecular visualization platform. Search any molecule, explore its 3D structure, simulate reactions, and learn with AI assistance.
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {[
            { icon: <Atom size={18} />, title: '3D Visualization', desc: 'Interactive WebGL rendering', color: '#06b6d4' },
            { icon: <FlaskConical size={18} />, title: 'Lab Simulation', desc: 'Virtual reactions & heating', color: '#a855f7' },
            { icon: <Brain size={18} />, title: 'AI Tutor', desc: 'Powered by GPT-4 & more', color: '#10b981' },
          ].map((f) => (
            <div key={f.title} className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
              <div className="w-8 h-8 rounded-lg mx-auto mb-2 flex items-center justify-center" style={{ backgroundColor: f.color + '22', color: f.color }}>
                {f.icon}
              </div>
              <div className="text-xs font-semibold text-white mb-0.5">{f.title}</div>
              <div className="text-[10px] text-gray-500">{f.desc}</div>
            </div>
          ))}
        </div>

        {/* Featured molecules */}
        <div className="mb-4">
          <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Zap size={10} />
            Quick Start — Click to explore
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {FEATURED.map((mol) => (
              <button
                key={mol.name}
                onClick={() => loadMolecule(mol.name)}
                className="flex items-center gap-3 p-3 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-opacity-60 rounded-xl text-left transition-all group"
                style={{ '--hover-color': mol.color } as any}
              >
                <span className="text-2xl shrink-0">{mol.emoji}</span>
                <div>
                  <div className="text-sm font-semibold text-white group-hover:text-cyan-300 transition-colors">{mol.name}</div>
                  <div className="text-[10px] text-gray-500 leading-tight">{mol.desc}</div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Search hint */}
        <div className="flex items-center gap-2 text-gray-600 justify-center">
          <Search size={14} />
          <span className="text-xs">Or use the search bar above to find any molecule by name, formula, or SMILES</span>
        </div>

        {/* Dismiss */}
        <button
          onClick={() => setDismissed(true)}
          className="absolute top-4 right-4 p-1.5 text-gray-600 hover:text-gray-400 transition-colors"
        >
          <X size={18} />
        </button>
      </div>
    </div>
  );
}
