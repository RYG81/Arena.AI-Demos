import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, Trash2, Sparkles } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { useMoleculeStore } from '../store/moleculeStore';
import { sendAIMessage } from '../services/aiService';
import type { ChatMessage } from '../types/molecule';

const QUICK_QUESTIONS = [
  'Explain this molecule',
  'What reactions can occur?',
  'Is it water soluble?',
  'What are the functional groups?',
  'How does it affect the body?',
  'Quiz me on this molecule',
];

function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === 'user';

  return (
    <div className={`flex gap-2.5 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
      {/* Avatar */}
      <div className={`shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-sm ${
        isUser ? 'bg-cyan-600' : 'bg-gradient-to-br from-purple-600 to-blue-600'
      }`}>
        {isUser ? <User size={14} /> : <Bot size={14} />}
      </div>

      {/* Bubble */}
      <div className={`max-w-[85%] rounded-2xl px-3 py-2.5 ${
        isUser
          ? 'bg-cyan-600/30 border border-cyan-500/30 text-white rounded-tr-sm'
          : 'bg-white/5 border border-white/10 text-gray-100 rounded-tl-sm'
      }`}>
        <div className={`text-sm leading-relaxed prose prose-sm prose-invert max-w-none ${
          isUser ? 'text-white' : 'text-gray-100'
        }`}>
          <ReactMarkdown
            components={{
              p: ({ children }) => <p className="mb-1.5 last:mb-0">{children}</p>,
              strong: ({ children }) => <strong className="text-cyan-300 font-semibold">{children}</strong>,
              em: ({ children }) => <em className="text-gray-300">{children}</em>,
              code: ({ children }) => <code className="bg-black/30 text-yellow-300 px-1 py-0.5 rounded text-xs font-mono">{children}</code>,
              ul: ({ children }) => <ul className="list-disc list-inside space-y-0.5 my-1">{children}</ul>,
              li: ({ children }) => <li className="text-gray-300">{children}</li>,
              h1: ({ children }) => <h1 className="text-base font-bold text-white mb-1">{children}</h1>,
              h2: ({ children }) => <h2 className="text-sm font-bold text-cyan-300 mb-1">{children}</h2>,
              h3: ({ children }) => <h3 className="text-sm font-semibold text-cyan-400 mb-0.5">{children}</h3>,
              blockquote: ({ children }) => <blockquote className="border-l-2 border-cyan-500 pl-2 text-gray-400 italic my-1">{children}</blockquote>,
            }}
          >
            {message.content}
          </ReactMarkdown>
        </div>
        <div className="text-[10px] text-gray-500 mt-1.5">
          {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>
    </div>
  );
}

export default function ChatPanel() {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const {
    messages,
    addMessage,
    clearMessages,
    isAILoading,
    setAILoading,
    aiSettings,
    currentMolecule,
  } = useMoleculeStore();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isAILoading]);

  const sendMessage = async (text?: string) => {
    const content = (text || input).trim();
    if (!content || isAILoading) return;

    setInput('');

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: Date.now(),
      moleculeContext: currentMolecule?.name,
    };
    addMessage(userMsg);
    setAILoading(true);

    try {
      const response = await sendAIMessage(content, messages, currentMolecule, aiSettings);
      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: Date.now(),
        moleculeContext: currentMolecule?.name,
      };
      addMessage(aiMsg);
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `⚠️ **AI Error:** ${err.message}\n\nTip: Check your API settings or switch to Demo mode in Settings.`,
        timestamp: Date.now(),
      };
      addMessage(errorMsg);
    } finally {
      setAILoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center">
            <Sparkles size={14} />
          </div>
          <div>
            <div className="text-sm font-semibold text-white">MolecuLab AI</div>
            <div className="text-[10px] text-gray-500 capitalize">
              {aiSettings.provider === 'demo' ? '🟡 Demo Mode' : `🟢 ${aiSettings.provider}`}
            </div>
          </div>
        </div>
        {messages.length > 0 && (
          <button
            onClick={clearMessages}
            className="p-1.5 text-gray-500 hover:text-red-400 transition-colors rounded-lg hover:bg-red-900/20"
            title="Clear chat"
          >
            <Trash2 size={14} />
          </button>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 min-h-0">
        {messages.length === 0 && (
          <div className="text-center py-6">
            <div className="text-4xl mb-3">🤖</div>
            <div className="text-sm text-gray-400 font-medium mb-1">MolecuLab AI Tutor</div>
            <div className="text-xs text-gray-600 mb-4">
              Ask anything about molecules, chemistry, or reactions!
            </div>
            {/* Quick questions */}
            <div className="grid grid-cols-2 gap-1.5">
              {QUICK_QUESTIONS.map((q) => (
                <button
                  key={q}
                  onClick={() => sendMessage(q)}
                  className="text-left text-xs px-2 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-cyan-500/30 rounded-lg text-gray-400 hover:text-gray-200 transition-all"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} />
        ))}

        {isAILoading && (
          <div className="flex gap-2.5">
            <div className="shrink-0 w-7 h-7 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center">
              <Bot size={14} />
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl rounded-tl-sm px-3 py-2.5">
              <div className="flex items-center gap-1.5">
                <Loader2 size={12} className="animate-spin text-cyan-400" />
                <span className="text-xs text-gray-400">Thinking...</span>
                <span className="flex gap-0.5">
                  {[0, 1, 2].map(i => (
                    <span
                      key={i}
                      className="w-1 h-1 rounded-full bg-cyan-400 animate-bounce"
                      style={{ animationDelay: `${i * 0.15}s` }}
                    />
                  ))}
                </span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick suggestions when there are messages */}
      {messages.length > 0 && messages.length < 6 && (
        <div className="flex gap-1 px-3 pb-2 flex-wrap shrink-0">
          {QUICK_QUESTIONS.slice(0, 3).map((q) => (
            <button
              key={q}
              onClick={() => sendMessage(q)}
              className="text-xs px-2 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-gray-400 hover:text-gray-200 transition-all"
            >
              {q}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="px-3 pb-3 shrink-0">
        <div className="flex gap-2 items-end bg-white/5 border border-white/10 focus-within:border-cyan-500/50 rounded-xl p-2 transition-all">
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={currentMolecule ? `Ask about ${currentMolecule.name}...` : 'Ask a chemistry question...'}
            rows={1}
            className="flex-1 bg-transparent text-white placeholder-gray-500 text-sm outline-none resize-none max-h-24 leading-relaxed"
            style={{ minHeight: '24px' }}
          />
          <button
            onClick={() => sendMessage()}
            disabled={!input.trim() || isAILoading}
            className="p-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-700 disabled:text-gray-500 text-white rounded-lg transition-all shrink-0 self-end"
          >
            <Send size={14} />
          </button>
        </div>
        <div className="text-[10px] text-gray-600 mt-1 text-center">
          Enter to send • Shift+Enter for newline
        </div>
      </div>
    </div>
  );
}
