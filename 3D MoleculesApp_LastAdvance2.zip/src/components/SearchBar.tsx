import { useState, useRef, useEffect } from 'react';
import { Search, Loader2, X, Clock, Zap } from 'lucide-react';
import { useMoleculeStore } from '../store/moleculeStore';
import { fetchMoleculeByName } from '../services/pubchemService';

const POPULAR_MOLECULES = [
  { name: 'Caffeine', formula: 'C₈H₁₀N₄O₂', emoji: '☕' },
  { name: 'Aspirin', formula: 'C₉H₈O₄', emoji: '💊' },
  { name: 'Ethanol', formula: 'C₂H₅OH', emoji: '🍷' },
  { name: 'Glucose', formula: 'C₆H₁₂O₆', emoji: '🍬' },
  { name: 'Benzene', formula: 'C₆H₆', emoji: '🔬' },
  { name: 'Penicillin', formula: 'C₁₆H₁₈N₂O₄S', emoji: '💉' },
  { name: 'Dopamine', formula: 'C₈H₁₁NO₂', emoji: '🧠' },
  { name: 'Cholesterol', formula: 'C₂₇H₄₆O', emoji: '🫀' },
  { name: 'Serotonin', formula: 'C₁₀H₁₂N₂O', emoji: '😊' },
  { name: 'Testosterone', formula: 'C₁₉H₂₈O₂', emoji: '💪' },
  { name: 'Water', formula: 'H₂O', emoji: '💧' },
  { name: 'Acetone', formula: 'C₃H₆O', emoji: '🧪' },
];

export default function SearchBar() {
  const [query, setQuery] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const {
    isLoading,
    setLoading,
    setError,
    setCurrentMolecule,
    addToCache,
    getFromCache,
    addToHistory,
    searchHistory,
    addViewedMolecule,
    setActiveSidebarTab,
    error,
  } = useMoleculeStore();

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node) &&
          inputRef.current && !inputRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const loadMolecule = async (searchQuery: string) => {
    if (!searchQuery.trim() || isLoading) return;

    const trimmed = searchQuery.trim();
    setShowDropdown(false);
    setQuery(trimmed);

    // Check cache first
    const cached = getFromCache(trimmed);
    if (cached) {
      setCurrentMolecule({ ...cached, source: 'cache' });
      addToHistory(trimmed);
      addViewedMolecule(trimmed);
      setActiveSidebarTab('properties');
      return;
    }

    // Check cache with lowercase
    const cachedLower = getFromCache(trimmed.toLowerCase());
    if (cachedLower) {
      setCurrentMolecule({ ...cachedLower, source: 'cache' });
      addToHistory(trimmed);
      addViewedMolecule(trimmed);
      setActiveSidebarTab('properties');
      return;
    }

    setLoading(true, `Fetching ${trimmed} from PubChem...`);
    setError(null);

    try {
      const mol = await fetchMoleculeByName(trimmed);

      // Cache the result
      addToCache(trimmed, mol);
      addToCache(mol.name.toLowerCase(), mol);
      if (mol.inchiKey) addToCache(mol.inchiKey, mol);

      setCurrentMolecule(mol);
      addToHistory(trimmed);
      addViewedMolecule(trimmed);
      setActiveSidebarTab('properties');
    } catch (err: any) {
      setError(err.message || 'Failed to load molecule. Please try another name.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadMolecule(query);
  };

  const filteredHistory = searchHistory.filter(h =>
    query ? h.toLowerCase().includes(query.toLowerCase()) : true
  ).slice(0, 5);

  const filteredPopular = POPULAR_MOLECULES.filter(m =>
    query ? m.name.toLowerCase().includes(query.toLowerCase()) : true
  ).slice(0, 6);

  return (
    <div className="relative w-full">
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative flex items-center">
          <Search size={18} className="absolute left-3 text-cyan-400 pointer-events-none z-10" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => { setQuery(e.target.value); setShowDropdown(true); }}
            onFocus={() => setShowDropdown(true)}
            placeholder="Search molecule: caffeine, aspirin, C₆H₁₂O₆, SMILES..."
            className="w-full bg-white/5 border border-white/10 hover:border-cyan-500/40 focus:border-cyan-500 text-white placeholder-gray-500 rounded-xl pl-10 pr-24 py-3 outline-none transition-all text-sm font-medium"
            disabled={isLoading}
          />
          {query && (
            <button
              type="button"
              onClick={() => { setQuery(''); setShowDropdown(false); }}
              className="absolute right-16 text-gray-500 hover:text-white transition-colors"
            >
              <X size={16} />
            </button>
          )}
          <button
            type="submit"
            disabled={isLoading || !query.trim()}
            className="absolute right-2 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-700 disabled:text-gray-500 text-white rounded-lg transition-all text-sm font-semibold flex items-center gap-1.5"
          >
            {isLoading ? (
              <Loader2 size={14} className="animate-spin" />
            ) : (
              <Zap size={14} />
            )}
            {isLoading ? 'Loading' : 'Load'}
          </button>
        </div>
      </form>

      {/* Error display */}
      {error && (
        <div className="mt-2 px-3 py-2 bg-red-900/30 border border-red-500/40 rounded-lg text-red-400 text-xs flex items-start gap-2">
          <span>⚠️</span>
          <span>{error}</span>
        </div>
      )}

      {/* Dropdown */}
      {showDropdown && (
        <div
          ref={dropdownRef}
          className="absolute top-full left-0 right-0 mt-2 bg-[#0d1526] border border-white/10 rounded-xl shadow-2xl z-50 overflow-hidden max-h-80 overflow-y-auto"
        >
          {/* History */}
          {filteredHistory.length > 0 && (
            <div>
              <div className="px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider border-b border-white/5">
                Recent Searches
              </div>
              {filteredHistory.map((h) => (
                <button
                  key={h}
                  onClick={() => loadMolecule(h)}
                  className="w-full px-3 py-2 text-left hover:bg-white/5 flex items-center gap-2 text-gray-300 hover:text-white transition-colors"
                >
                  <Clock size={14} className="text-gray-500 shrink-0" />
                  <span className="text-sm">{h}</span>
                </button>
              ))}
            </div>
          )}

          {/* Popular molecules */}
          {filteredPopular.length > 0 && (
            <div>
              <div className="px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider border-b border-white/5">
                {query ? 'Suggestions' : 'Popular Molecules'}
              </div>
              <div className="grid grid-cols-2 gap-1 p-2">
                {filteredPopular.map((mol) => (
                  <button
                    key={mol.name}
                    onClick={() => loadMolecule(mol.name)}
                    className="flex items-center gap-2 px-2 py-2 text-left hover:bg-white/5 rounded-lg transition-colors group"
                  >
                    <span className="text-xl shrink-0">{mol.emoji}</span>
                    <div>
                      <div className="text-sm text-gray-200 group-hover:text-white font-medium">{mol.name}</div>
                      <div className="text-xs text-gray-500">{mol.formula}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {filteredHistory.length === 0 && filteredPopular.length === 0 && (
            <div className="p-4 text-center text-gray-500 text-sm">
              Press Enter to search for "{query}"
            </div>
          )}
        </div>
      )}
    </div>
  );
}
