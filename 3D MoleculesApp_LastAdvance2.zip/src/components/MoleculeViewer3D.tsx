import React, { useEffect, useRef, useCallback, useState } from 'react';
import { useMoleculeStore } from '../store/moleculeStore';
import { RotateCcw, ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';

declare global {
  interface Window {
    $3Dmol: any;
  }
}

const ELEMENT_COLORS: Record<string, string> = {
  H: '#FFFFFF', C: '#404040', N: '#3050F8', O: '#FF0D0D',
  F: '#90E050', Cl: '#1FF01F', Br: '#A62929', I: '#940094',
  S: '#FFFF30', P: '#FF8000', Na: '#AB5CF2', K: '#8F40D4',
  Ca: '#3DFF00', Fe: '#E06633', Mg: '#8AFF00', Zn: '#7D80B0',
  Si: '#F0C8A0', default: '#FF69B4',
};

const ELEMENT_RADII: Record<string, number> = {
  H: 0.31, C: 0.77, N: 0.75, O: 0.73, F: 0.64,
  Cl: 0.99, Br: 1.14, I: 1.33, S: 1.03, P: 1.06,
  default: 0.80,
};

export default function MoleculeViewer3D() {
  const containerRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<any>(null);
  const { currentMolecule, renderStyle, colorScheme, showLabels, showHydrogens, showSurface } = useMoleculeStore();
  const [is3DmolLoaded, setIs3DmolLoaded] = useState(false);
  const [viewerError, setViewerError] = useState<string | null>(null);
  const [hoveredAtom, setHoveredAtom] = useState<{ elem: string; x: number; y: number } | null>(null);

  // Load 3Dmol.js script
  useEffect(() => {
    if (window.$3Dmol) {
      setIs3DmolLoaded(true);
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://3dmol.org/build/3Dmol-min.js';
    script.async = true;
    script.onload = () => setIs3DmolLoaded(true);
    script.onerror = () => setViewerError('Failed to load 3D engine');
    document.head.appendChild(script);

    return () => {
      if (script.parentNode) script.parentNode.removeChild(script);
    };
  }, []);

  const getStyleConfig = useCallback(() => {
    const style: any = {};
    if (renderStyle === 'stick') {
      style.stick = { radius: 0.15, colorscheme: colorScheme === 'element' ? 'Jmol' : colorScheme };
    } else if (renderStyle === 'sphere') {
      style.sphere = { scale: 0.4, colorscheme: colorScheme === 'element' ? 'Jmol' : colorScheme };
    } else if (renderStyle === 'line') {
      style.line = { linewidth: 2, colorscheme: colorScheme === 'element' ? 'Jmol' : colorScheme };
    } else if (renderStyle === 'cartoon') {
      style.cartoon = { color: 'spectrum' };
      style.stick = { radius: 0.1 };
    } else if (renderStyle === 'surface') {
      style.sphere = { scale: 0.35, colorscheme: colorScheme === 'element' ? 'Jmol' : colorScheme };
    }
    return style;
  }, [renderStyle, colorScheme]);

  const renderMolecule = useCallback(() => {
    if (!viewerRef.current || !currentMolecule || !window.$3Dmol) return;

    const viewer = viewerRef.current;
    viewer.clear();

    if (currentMolecule.sdfData) {
      try {
        viewer.addModel(currentMolecule.sdfData, 'sdf');
        const styleConfig = getStyleConfig();

        if (!showHydrogens) {
          viewer.setStyle({ elem: 'H' }, { sphere: { hidden: true }, stick: { hidden: true }, line: { hidden: true } });
          viewer.setStyle({ not: { elem: 'H' } }, styleConfig);
        } else {
          viewer.setStyle({}, styleConfig);
        }

        // Add surface if enabled
        if (showSurface) {
          viewer.addSurface(window.$3Dmol.SurfaceType.VDW, {
            opacity: 0.6,
            colorscheme: 'whiteCarbon',
          });
        }

        // Add atom labels
        if (showLabels) {
          const atoms = currentMolecule.atoms || [];
          atoms.forEach((atom) => {
            if (!showHydrogens && atom.elem === 'H') return;
            if (!atom.elem || atom.elem === 'C') return; // Skip carbon labels for clarity

            const color = ELEMENT_COLORS[atom.elem] || ELEMENT_COLORS.default;
            viewer.addLabel(atom.elem, {
              position: { x: atom.x, y: atom.y, z: atom.z },
              fontSize: 11,
              fontColor: color,
              backgroundColor: 'rgba(0,0,0,0.6)',
              backgroundOpacity: 0.7,
              borderColor: color,
              borderThickness: 1,
              padding: 2,
              inFront: true,
              showBackground: true,
            });
          });
        }

        // Click handler for atoms
        viewer.setClickable({}, true, (atom: any) => {
          if (atom?.elem) {
            setHoveredAtom({ elem: atom.elem, x: atom.x || 0, y: atom.y || 0 });
            useMoleculeStore.getState().setSelectedAtom(atom.serial || 0);
          }
        });

        viewer.zoomTo();
        viewer.zoom(0.85);
        viewer.render();
      } catch (err) {
        console.error('3D render error:', err);
        setViewerError('Failed to render molecule structure');
      }
    }
  }, [currentMolecule, showLabels, showHydrogens, showSurface, getStyleConfig]);

  // Initialize viewer
  useEffect(() => {
    if (!is3DmolLoaded || !containerRef.current) return;

    try {
      const config = {
        backgroundColor: '0x0a0f1e',
        antialias: true,
        cartoonQuality: 10,
      };
      viewerRef.current = window.$3Dmol.createViewer(containerRef.current, config);
      viewerRef.current.setBackgroundColor(0x0a0f1e);

      if (currentMolecule) {
        renderMolecule();
      }
    } catch (err) {
      setViewerError('Failed to initialize 3D viewer');
    }

    return () => {
      if (viewerRef.current) {
        try { viewerRef.current.clear(); } catch {}
      }
    };
  }, [is3DmolLoaded]);

  // Re-render when molecule or settings change
  useEffect(() => {
    if (viewerRef.current && is3DmolLoaded && currentMolecule) {
      renderMolecule();
    }
  }, [currentMolecule, renderStyle, colorScheme, showLabels, showHydrogens, showSurface, is3DmolLoaded]);

  const resetView = () => {
    if (viewerRef.current) {
      viewerRef.current.zoomTo();
      viewerRef.current.zoom(0.85);
      viewerRef.current.render();
    }
  };

  const zoomIn = () => {
    if (viewerRef.current) {
      viewerRef.current.zoom(1.3);
      viewerRef.current.render();
    }
  };

  const zoomOut = () => {
    if (viewerRef.current) {
      viewerRef.current.zoom(0.7);
      viewerRef.current.render();
    }
  };

  if (viewerError) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-[#0a0f1e]">
        <div className="text-center text-red-400">
          <div className="text-4xl mb-3">⚠️</div>
          <div className="font-semibold">{viewerError}</div>
          <div className="text-sm text-gray-500 mt-2">Check console for details</div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full bg-[#0a0f1e]">
      {/* 3D Canvas */}
      <div ref={containerRef} className="w-full h-full" />

      {/* No molecule placeholder */}
      {!currentMolecule && (
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <div className="text-center animate-pulse">
            <div className="text-7xl mb-4">⚗️</div>
            <div className="text-xl font-semibold text-cyan-400 mb-2">MolecuLab AI</div>
            <div className="text-gray-400 text-sm">Search for a molecule to begin</div>
            <div className="text-gray-600 text-xs mt-2">Try: caffeine, aspirin, water, ethanol...</div>
          </div>
        </div>
      )}

      {/* Loading overlay */}
      {!is3DmolLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0a0f1e] z-20">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <div className="text-cyan-400 font-medium">Loading 3D Engine...</div>
          </div>
        </div>
      )}

      {/* Controls */}
      {currentMolecule && (
        <div className="absolute bottom-4 right-4 flex flex-col gap-2 z-10">
          <button
            onClick={resetView}
            className="p-2 bg-black/60 hover:bg-black/80 text-gray-300 hover:text-white rounded-lg border border-white/10 backdrop-blur transition-all"
            title="Reset View"
          >
            <RotateCcw size={16} />
          </button>
          <button
            onClick={zoomIn}
            className="p-2 bg-black/60 hover:bg-black/80 text-gray-300 hover:text-white rounded-lg border border-white/10 backdrop-blur transition-all"
            title="Zoom In"
          >
            <ZoomIn size={16} />
          </button>
          <button
            onClick={zoomOut}
            className="p-2 bg-black/60 hover:bg-black/80 text-gray-300 hover:text-white rounded-lg border border-white/10 backdrop-blur transition-all"
            title="Zoom Out"
          >
            <ZoomOut size={16} />
          </button>
        </div>
      )}

      {/* Molecule info badge */}
      {currentMolecule && (
        <div className="absolute top-3 left-3 z-10">
          <div className="px-3 py-1.5 bg-black/70 backdrop-blur rounded-lg border border-cyan-500/30">
            <div className="text-cyan-400 font-semibold text-sm">{currentMolecule.name}</div>
            <div className="text-gray-400 text-xs">{currentMolecule.formula}</div>
          </div>
        </div>
      )}

      {/* Hovered atom info */}
      {hoveredAtom && (
        <div
          className="absolute bottom-4 left-4 z-10 px-3 py-2 bg-black/80 backdrop-blur rounded-lg border border-white/10 text-sm"
          onClick={() => setHoveredAtom(null)}
        >
          <div className="text-white font-semibold">Atom: {hoveredAtom.elem}</div>
          <div className="text-gray-400 text-xs">
            x:{hoveredAtom.x.toFixed(2)} y:{hoveredAtom.y.toFixed(2)}
          </div>
          <div className="text-xs text-gray-500 mt-1">Click to dismiss</div>
        </div>
      )}

      {/* Source badge */}
      {currentMolecule && (
        <div className="absolute top-3 right-3 z-10">
          <span className={`text-xs px-2 py-1 rounded-full border ${
            currentMolecule.source === 'cache'
              ? 'bg-green-900/40 border-green-500/40 text-green-400'
              : currentMolecule.source === 'pubchem'
              ? 'bg-blue-900/40 border-blue-500/40 text-blue-400'
              : 'bg-purple-900/40 border-purple-500/40 text-purple-400'
          }`}>
            {currentMolecule.source === 'cache' ? '⚡ Cache' : currentMolecule.source === 'pubchem' ? '🌐 PubChem' : '📦 Built-in'}
          </span>
        </div>
      )}
    </div>
  );
}
