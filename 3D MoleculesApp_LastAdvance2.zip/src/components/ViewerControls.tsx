import { useMoleculeStore } from '../store/moleculeStore';
import { FlaskConical, Eye, Layers, Atom } from 'lucide-react';

const RENDER_STYLES = [
  { id: 'stick', label: 'Stick', icon: '🔗' },
  { id: 'sphere', label: 'Sphere', icon: '🔵' },
  { id: 'line', label: 'Wire', icon: '📐' },
  { id: 'surface', label: 'Surface', icon: '🫧' },
] as const;

const COLOR_SCHEMES = [
  { id: 'element', label: 'Element' },
  { id: 'residue', label: 'Residue' },
  { id: 'spectrum', label: 'Spectrum' },
] as const;

export default function ViewerControls() {
  const {
    viewMode, setViewMode,
    renderStyle, setRenderStyle,
    colorScheme, setColorScheme,
    showLabels, setShowLabels,
    showHydrogens, setShowHydrogens,
    showSurface, setShowSurface,
    currentMolecule,
  } = useMoleculeStore();

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {/* View mode toggle */}
      <div className="flex bg-white/5 border border-white/10 rounded-lg p-0.5">
        <button
          onClick={() => setViewMode('molecule')}
          className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-1.5 ${
            viewMode === 'molecule'
              ? 'bg-cyan-600 text-white'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <Atom size={12} />
          Molecule
        </button>
        <button
          onClick={() => setViewMode('lab')}
          className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-1.5 ${
            viewMode === 'lab'
              ? 'bg-cyan-600 text-white'
              : 'text-gray-400 hover:text-white'
          }`}
          disabled={!currentMolecule}
        >
          <FlaskConical size={12} />
          Lab
        </button>
      </div>

      {/* Render style */}
      {viewMode === 'molecule' && (
        <div className="flex bg-white/5 border border-white/10 rounded-lg p-0.5">
          {RENDER_STYLES.map((s) => (
            <button
              key={s.id}
              onClick={() => setRenderStyle(s.id)}
              className={`px-2 py-1.5 rounded-md text-xs font-medium transition-all ${
                renderStyle === s.id
                  ? 'bg-white/10 text-white'
                  : 'text-gray-500 hover:text-gray-300'
              }`}
              title={s.label}
            >
              {s.icon}
            </button>
          ))}
        </div>
      )}

      {/* Color scheme */}
      {viewMode === 'molecule' && (
        <select
          value={colorScheme}
          onChange={(e) => setColorScheme(e.target.value as any)}
          className="bg-white/5 border border-white/10 text-gray-300 text-xs rounded-lg px-2 py-1.5 outline-none"
        >
          {COLOR_SCHEMES.map((c) => (
            <option key={c.id} value={c.id}>{c.label}</option>
          ))}
        </select>
      )}

      {/* Toggle buttons */}
      {viewMode === 'molecule' && (
        <div className="flex gap-1">
          <button
            onClick={() => setShowLabels(!showLabels)}
            className={`px-2 py-1.5 rounded-lg text-xs flex items-center gap-1 border transition-all ${
              showLabels
                ? 'bg-blue-600/30 border-blue-500/40 text-blue-300'
                : 'bg-white/5 border-white/10 text-gray-500 hover:text-gray-300'
            }`}
            title="Toggle atom labels"
          >
            <Eye size={11} />
            Labels
          </button>

          <button
            onClick={() => setShowHydrogens(!showHydrogens)}
            className={`px-2 py-1.5 rounded-lg text-xs flex items-center gap-1 border transition-all ${
              showHydrogens
                ? 'bg-green-600/30 border-green-500/40 text-green-300'
                : 'bg-white/5 border-white/10 text-gray-500 hover:text-gray-300'
            }`}
            title="Toggle hydrogen atoms"
          >
            H
          </button>

          <button
            onClick={() => setShowSurface(!showSurface)}
            className={`px-2 py-1.5 rounded-lg text-xs flex items-center gap-1 border transition-all ${
              showSurface
                ? 'bg-purple-600/30 border-purple-500/40 text-purple-300'
                : 'bg-white/5 border-white/10 text-gray-500 hover:text-gray-300'
            }`}
            title="Toggle surface"
          >
            <Layers size={11} />
            Surface
          </button>
        </div>
      )}
    </div>
  );
}
