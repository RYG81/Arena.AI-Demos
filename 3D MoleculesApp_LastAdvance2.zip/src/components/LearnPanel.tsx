import { useState } from 'react';
import { BookOpen, ChevronRight, Star, Lock, CheckCircle2, Zap } from 'lucide-react';
import { useMoleculeStore } from '../store/moleculeStore';

interface Lesson {
  id: string;
  title: string;
  description: string;
  emoji: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  topics: string[];
  molecule?: string;
  locked?: boolean;
  completed?: boolean;
}

const LESSONS: Lesson[] = [
  {
    id: 'intro',
    title: 'Introduction to Molecules',
    description: 'Learn what molecules are and how atoms bond together',
    emoji: '⚛️',
    difficulty: 'beginner',
    topics: ['Atoms & Elements', 'Chemical Bonds', 'Molecular Formula'],
    molecule: 'water',
  },
  {
    id: 'functional-groups',
    title: 'Functional Groups',
    description: 'Discover how different groups determine molecular behavior',
    emoji: '🔗',
    difficulty: 'beginner',
    topics: ['Hydroxyl', 'Carboxyl', 'Amine', 'Carbonyl'],
    molecule: 'ethanol',
  },
  {
    id: 'polarity',
    title: 'Polarity & Solubility',
    description: 'Understand why some molecules mix and others don\'t',
    emoji: '💧',
    difficulty: 'intermediate',
    topics: ['Electronegativity', 'Dipole Moments', 'Hydrogen Bonds', 'LogP'],
    molecule: 'glucose',
  },
  {
    id: 'reactions',
    title: 'Chemical Reactions',
    description: 'Explore how molecules transform and interact',
    emoji: '⚗️',
    difficulty: 'intermediate',
    topics: ['Combustion', 'Addition', 'Substitution', 'Reaction Mechanisms'],
    molecule: 'benzene',
  },
  {
    id: 'drugs',
    title: 'Drug Design Principles',
    description: 'Learn how molecular structure affects drug activity',
    emoji: '💊',
    difficulty: 'advanced',
    topics: ['Lipinski Rules', 'ADMET', 'Binding', 'Pharmacophore'],
    molecule: 'aspirin',
    locked: true,
  },
  {
    id: 'bio-molecules',
    title: 'Biomolecules',
    description: 'Proteins, DNA, and the chemistry of life',
    emoji: '🧬',
    difficulty: 'advanced',
    topics: ['Amino Acids', 'Peptide Bonds', 'DNA Bases', 'Enzyme Catalysis'],
    molecule: 'caffeine',
    locked: true,
  },
];

const CHEMISTRY_FACTS = [
  { fact: 'A teaspoon of water contains about 1.67 × 10²³ molecules', emoji: '💧' },
  { fact: 'Diamond and graphite are both pure carbon — just arranged differently', emoji: '💎' },
  { fact: 'Caffeine is structurally similar to adenine — a DNA base!', emoji: '☕' },
  { fact: 'The aspirin molecule was first synthesized in 1897 from willow bark extract', emoji: '💊' },
  { fact: 'Benzene\'s ring structure was discovered when Kekulé dreamed of a snake eating its tail', emoji: '🐍' },
  { fact: 'Dopamine and adrenaline share the same catecholamine base structure', emoji: '🧠' },
  { fact: 'Penicillin works by inhibiting bacterial cell wall synthesis enzymes', emoji: '💉' },
  { fact: 'The human body contains about 37 trillion cells, each with millions of molecules', emoji: '🫀' },
];

function DifficultyBadge({ level }: { level: string }) {
  return (
    <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium capitalize ${
      level === 'beginner' ? 'bg-green-900/30 text-green-400 border border-green-500/30' :
      level === 'intermediate' ? 'bg-yellow-900/30 text-yellow-400 border border-yellow-500/30' :
      'bg-red-900/30 text-red-400 border border-red-500/30'
    }`}>
      {level}
    </span>
  );
}

export default function LearnPanel() {
  const { userProgress, setActiveSidebarTab } = useMoleculeStore();
  const [activeFact, setActiveFact] = useState(() => Math.floor(Math.random() * CHEMISTRY_FACTS.length));
  const [expandedLesson, setExpandedLesson] = useState<string | null>(null);

  const completedCount = LESSONS.filter(l => !l.locked).length;
  const xp = userProgress.totalScore;
  const level = userProgress.level;

  const nextFact = () => setActiveFact(f => (f + 1) % CHEMISTRY_FACTS.length);

  return (
    <div className="space-y-4 pb-4">
      {/* Progress card */}
      <div className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 rounded-xl p-3 border border-purple-500/20">
        <div className="flex items-center justify-between mb-2">
          <div>
            <div className="text-sm font-bold text-white">Level {level} Chemist</div>
            <div className="text-xs text-gray-400">{xp} XP total</div>
          </div>
          <div className="text-2xl">
            {level < 3 ? '🧪' : level < 6 ? '⚗️' : level < 10 ? '🔬' : '🏆'}
          </div>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-2">
          <div
            className="h-2 rounded-full bg-gradient-to-r from-purple-500 to-cyan-500 transition-all"
            style={{ width: `${Math.min(100, (xp % 50) * 2)}%` }}
          />
        </div>
        <div className="flex justify-between text-[10px] text-gray-500 mt-1">
          <span>{xp % 50} / 50 XP to next level</span>
          <span>{userProgress.moleculesViewed.length} molecules explored</span>
        </div>
      </div>

      {/* Chemistry fact */}
      <div className="bg-white/5 border border-white/10 rounded-xl p-3 cursor-pointer hover:bg-white/8 transition-all" onClick={nextFact}>
        <div className="flex items-start gap-2">
          <span className="text-2xl shrink-0">{CHEMISTRY_FACTS[activeFact].emoji}</span>
          <div>
            <div className="text-xs font-semibold text-cyan-400 mb-0.5 flex items-center gap-1">
              <Zap size={10} />
              Did You Know?
            </div>
            <div className="text-xs text-gray-300 leading-relaxed">{CHEMISTRY_FACTS[activeFact].fact}</div>
            <div className="text-[10px] text-gray-600 mt-1">Tap for next fact →</div>
          </div>
        </div>
      </div>

      {/* Lessons */}
      <div>
        <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <BookOpen size={12} />
            Learning Path
          </div>
          <span className="text-cyan-400">{completedCount}/{LESSONS.length}</span>
        </div>

        <div className="space-y-2">
          {LESSONS.map((lesson) => (
            <div
              key={lesson.id}
              className={`rounded-xl border transition-all ${
                lesson.locked
                  ? 'border-white/5 opacity-50'
                  : expandedLesson === lesson.id
                  ? 'border-cyan-500/30 bg-cyan-900/10'
                  : 'border-white/10 hover:border-white/20'
              }`}
            >
              <button
                className="w-full p-3 text-left flex items-start gap-2"
                onClick={() => !lesson.locked && setExpandedLesson(expandedLesson === lesson.id ? null : lesson.id)}
                disabled={lesson.locked}
              >
                <span className="text-xl shrink-0">{lesson.emoji}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-sm font-medium text-white">{lesson.title}</span>
                    <DifficultyBadge level={lesson.difficulty} />
                    {lesson.locked && <Lock size={10} className="text-gray-600" />}
                  </div>
                  <div className="text-xs text-gray-400 mt-0.5">{lesson.description}</div>
                </div>
                {!lesson.locked && (
                  <ChevronRight
                    size={14}
                    className={`text-gray-500 shrink-0 transition-transform ${expandedLesson === lesson.id ? 'rotate-90' : ''}`}
                  />
                )}
              </button>

              {expandedLesson === lesson.id && !lesson.locked && (
                <div className="px-3 pb-3 border-t border-white/5 pt-2">
                  <div className="text-xs text-gray-500 mb-2">Topics covered:</div>
                  <div className="flex flex-wrap gap-1 mb-3">
                    {lesson.topics.map((topic) => (
                      <span key={topic} className="px-2 py-0.5 bg-white/5 border border-white/10 rounded-full text-xs text-gray-300">
                        {topic}
                      </span>
                    ))}
                  </div>
                  {lesson.molecule && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          const { setActiveSidebarTab: setTab } = useMoleculeStore.getState();
                          setTab('quiz');
                        }}
                        className="flex-1 py-1.5 text-xs bg-cyan-600/20 border border-cyan-500/30 text-cyan-400 rounded-lg hover:bg-cyan-600/30 transition-all flex items-center justify-center gap-1"
                      >
                        <Star size={11} />
                        Take Quiz
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Achievement badges */}
      <div>
        <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Achievements</div>
        <div className="grid grid-cols-4 gap-1.5">
          {[
            { icon: '🔬', label: 'Explorer', unlocked: userProgress.moleculesViewed.length >= 1 },
            { icon: '⚗️', label: 'Chemist', unlocked: userProgress.moleculesViewed.length >= 5 },
            { icon: '🧪', label: 'Scientist', unlocked: userProgress.moleculesViewed.length >= 10 },
            { icon: '🏆', label: 'Master', unlocked: userProgress.moleculesViewed.length >= 20 },
            { icon: '🎓', label: 'Scholar', unlocked: userProgress.quizzesCompleted >= 1 },
            { icon: '📚', label: 'Bookworm', unlocked: userProgress.quizzesCompleted >= 5 },
            { icon: '💡', label: 'Genius', unlocked: userProgress.totalScore >= 100 },
            { icon: '⭐', label: 'Legend', unlocked: userProgress.level >= 5 },
          ].map((badge) => (
            <div
              key={badge.label}
              className={`flex flex-col items-center p-2 rounded-lg border text-center transition-all ${
                badge.unlocked
                  ? 'border-yellow-500/30 bg-yellow-900/10'
                  : 'border-white/5 opacity-30 grayscale'
              }`}
            >
              <span className="text-xl">{badge.icon}</span>
              <span className="text-[9px] text-gray-400 mt-0.5">{badge.label}</span>
              {badge.unlocked && <CheckCircle2 size={8} className="text-yellow-400 mt-0.5" />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
