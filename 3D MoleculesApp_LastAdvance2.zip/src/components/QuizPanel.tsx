import { useState, useEffect } from 'react';
import { useMoleculeStore } from '../store/moleculeStore';
import { CheckCircle2, XCircle, Trophy, RefreshCw, Brain } from 'lucide-react';
import type { QuizQuestion } from '../types/molecule';

function generateQuestions(molecule: any): QuizQuestion[] {
  if (!molecule) return [];

  const questions: QuizQuestion[] = [];
  const p = molecule.properties;

  // Formula question
  if (molecule.formula) {
    questions.push({
      id: 'q-formula',
      question: `What is the molecular formula of ${molecule.name}?`,
      options: [
        molecule.formula,
        molecule.formula.replace(/(\d+)/g, (m: string) => String(parseInt(m) + 1)),
        molecule.formula.replace(/(\d+)/g, (m: string) => String(Math.max(1, parseInt(m) - 1))),
        'C₆H₅OH',
      ].sort(() => Math.random() - 0.5),
      correctIndex: 0,
      explanation: `${molecule.name} has the molecular formula ${molecule.formula}. This tells us the exact number of each type of atom in the molecule.`,
      difficulty: 'easy',
    });
    // Fix correctIndex after shuffle
    questions[questions.length - 1].correctIndex =
      questions[questions.length - 1].options.indexOf(molecule.formula);
  }

  // Molecular weight question
  if (p?.molecularWeight) {
    const mw = p.molecularWeight;
    const options = [
      `${mw.toFixed(2)} g/mol`,
      `${(mw + 16).toFixed(2)} g/mol`,
      `${(mw - 14).toFixed(2)} g/mol`,
      `${(mw * 2).toFixed(2)} g/mol`,
    ].sort(() => Math.random() - 0.5);
    const correctAnswer = `${mw.toFixed(2)} g/mol`;
    questions.push({
      id: 'q-mw',
      question: `What is the molecular weight of ${molecule.name}?`,
      options,
      correctIndex: options.indexOf(correctAnswer),
      explanation: `The molecular weight of ${molecule.name} is ${mw.toFixed(2)} g/mol, calculated from the atomic masses of all atoms in the formula.`,
      difficulty: 'medium',
    });
  }

  // LogP / solubility question
  if (p?.xlogp !== undefined) {
    const logP = p.xlogp;
    const isHydrophilic = logP < 0;
    const isMixed = logP >= 0 && logP < 2;
    const isLipophilic = logP >= 2;

    const correct = isHydrophilic ? 'Highly water-soluble (hydrophilic)' :
                    isMixed ? 'Moderately soluble in both water and oils' :
                    'Lipid-soluble (lipophilic), poor water solubility';

    const options = [
      'Highly water-soluble (hydrophilic)',
      'Moderately soluble in both water and oils',
      'Lipid-soluble (lipophilic), poor water solubility',
      'Completely insoluble in all solvents',
    ].sort(() => Math.random() - 0.5);

    questions.push({
      id: 'q-logp',
      question: `Based on its LogP value of ${logP.toFixed(2)}, how would you classify ${molecule.name}'s solubility?`,
      options,
      correctIndex: options.indexOf(correct),
      explanation: `LogP (lipophilicity) of ${logP.toFixed(2)} indicates ${correct.toLowerCase()}. LogP < 0 = hydrophilic, 0-2 = mixed, >2 = lipophilic.`,
      difficulty: 'medium',
    });
  }

  // Functional groups question
  if (molecule.functionalGroups && molecule.functionalGroups.length > 0) {
    const fg = molecule.functionalGroups[0];
    const allGroups = ['Hydroxyl', 'Carboxyl', 'Amine', 'Ketone', 'Aldehyde', 'Aromatic Ring', 'Alkene', 'Ester', 'Amide'];
    const wrongGroups = allGroups.filter(g => g !== fg.name).slice(0, 3);
    const options = [fg.name, ...wrongGroups].sort(() => Math.random() - 0.5);

    questions.push({
      id: 'q-fg',
      question: `Which functional group is present in ${molecule.name} based on its structure?`,
      options,
      correctIndex: options.indexOf(fg.name),
      explanation: `${molecule.name} contains a ${fg.name} group (${fg.description}). Functional groups determine most of a molecule's chemical reactivity.`,
      difficulty: 'hard',
    });
  }

  // Reaction type question
  if (molecule.reactions && molecule.reactions.length > 0) {
    const rxn = molecule.reactions[0];
    const rxnTypes = ['combustion', 'substitution', 'addition', 'elimination', 'oxidation', 'reduction'];
    const wrongTypes = rxnTypes.filter(t => t !== rxn.type).slice(0, 3);
    const options = [rxn.type, ...wrongTypes].map(t => t.charAt(0).toUpperCase() + t.slice(1)).sort(() => Math.random() - 0.5);
    const correct = rxn.type.charAt(0).toUpperCase() + rxn.type.slice(1);

    questions.push({
      id: 'q-rxn',
      question: `The ${rxn.name} reaction of ${molecule.name} is best classified as which type?`,
      options,
      correctIndex: options.indexOf(correct),
      explanation: `${rxn.name} is a ${rxn.type} reaction. ${rxn.description}`,
      difficulty: 'hard',
    });
  }

  return questions.slice(0, 5);
}

export default function QuizPanel() {
  const { currentMolecule, userProgress, updateProgress } = useMoleculeStore();
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);

  useEffect(() => {
    if (currentMolecule) {
      const qs = generateQuestions(currentMolecule);
      setQuestions(qs);
      setCurrentQ(0);
      setSelected(null);
      setScore(0);
      setCompleted(false);
      setShowExplanation(false);
    }
  }, [currentMolecule]);

  const handleAnswer = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    setShowExplanation(true);
    if (idx === questions[currentQ].correctIndex) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (currentQ < questions.length - 1) {
      setCurrentQ(q => q + 1);
      setSelected(null);
      setShowExplanation(false);
    } else {
      setCompleted(true);
      updateProgress({
        quizzesCompleted: userProgress.quizzesCompleted + 1,
        totalScore: userProgress.totalScore + score * 5,
      });
    }
  };

  const handleRestart = () => {
    const qs = generateQuestions(currentMolecule);
    setQuestions(qs);
    setCurrentQ(0);
    setSelected(null);
    setScore(0);
    setCompleted(false);
    setShowExplanation(false);
  };

  if (!currentMolecule) {
    return (
      <div className="flex flex-col items-center justify-center h-40 text-gray-500 text-sm text-center">
        <Brain size={32} className="mb-3 opacity-30" />
        <div>Load a molecule to take a quiz</div>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-40 text-gray-500 text-sm text-center">
        <Brain size={32} className="mb-3 opacity-30" />
        <div>Not enough data to generate quiz</div>
      </div>
    );
  }

  if (completed) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <div className="flex flex-col items-center justify-center py-6 text-center space-y-4">
        <div className="text-5xl">
          {percentage >= 80 ? '🏆' : percentage >= 60 ? '🌟' : '📚'}
        </div>
        <div>
          <div className="text-xl font-bold text-white">{score}/{questions.length} Correct</div>
          <div className={`text-sm font-medium ${percentage >= 80 ? 'text-green-400' : percentage >= 60 ? 'text-yellow-400' : 'text-red-400'}`}>
            {percentage}% Score
          </div>
        </div>
        <div className="w-32 h-32 relative">
          <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
            <circle cx="18" cy="18" r="15.9" fill="none" stroke="#1e293b" strokeWidth="3" />
            <circle
              cx="18" cy="18" r="15.9"
              fill="none"
              stroke={percentage >= 80 ? '#10b981' : percentage >= 60 ? '#f59e0b' : '#ef4444'}
              strokeWidth="3"
              strokeDasharray={`${percentage} ${100 - percentage}`}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <Trophy size={24} className={percentage >= 80 ? 'text-yellow-400' : 'text-gray-500'} />
          </div>
        </div>
        <div className="text-sm text-gray-400">
          {percentage >= 80 ? 'Excellent! You know this molecule well!' :
           percentage >= 60 ? 'Good job! Keep studying to master it.' :
           'Keep learning! Review the properties panel.'}
        </div>
        <div className="text-xs text-cyan-400">+{score * 5} XP earned</div>
        <button
          onClick={handleRestart}
          className="flex items-center gap-2 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-sm font-medium transition-all"
        >
          <RefreshCw size={14} />
          Try Again
        </button>
      </div>
    );
  }

  const q = questions[currentQ];

  return (
    <div className="space-y-4 pb-4">
      {/* Progress */}
      <div>
        <div className="flex justify-between items-center mb-1.5">
          <span className="text-xs text-gray-500">Question {currentQ + 1} of {questions.length}</span>
          <div className="flex items-center gap-1">
            <span className={`text-xs px-1.5 py-0.5 rounded ${
              q.difficulty === 'easy' ? 'bg-green-900/30 text-green-400' :
              q.difficulty === 'medium' ? 'bg-yellow-900/30 text-yellow-400' :
              'bg-red-900/30 text-red-400'
            }`}>
              {q.difficulty}
            </span>
          </div>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-1">
          <div
            className="h-1 rounded-full bg-cyan-500 transition-all duration-500"
            style={{ width: `${((currentQ + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Question */}
      <div className="bg-white/5 border border-white/10 rounded-xl p-3">
        <div className="text-sm font-medium text-white leading-relaxed">{q.question}</div>
      </div>

      {/* Options */}
      <div className="space-y-2">
        {q.options.map((option, idx) => {
          const isCorrect = idx === q.correctIndex;
          const isSelected = idx === selected;
          const showResult = selected !== null;

          return (
            <button
              key={idx}
              onClick={() => handleAnswer(idx)}
              disabled={selected !== null}
              className={`w-full text-left px-3 py-2.5 rounded-xl text-sm transition-all border flex items-center gap-2 ${
                showResult
                  ? isCorrect
                    ? 'bg-green-900/30 border-green-500/50 text-green-200'
                    : isSelected
                    ? 'bg-red-900/30 border-red-500/50 text-red-200'
                    : 'bg-white/3 border-white/5 text-gray-500'
                  : 'bg-white/5 border-white/10 text-gray-200 hover:bg-white/10 hover:border-cyan-500/30 hover:text-white'
              }`}
            >
              <span className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 text-xs font-bold ${
                showResult && isCorrect ? 'border-green-500 bg-green-500/20' :
                showResult && isSelected ? 'border-red-500 bg-red-500/20' :
                'border-gray-600'
              }`}>
                {showResult && isCorrect ? <CheckCircle2 size={12} className="text-green-400" /> :
                 showResult && isSelected ? <XCircle size={12} className="text-red-400" /> :
                 String.fromCharCode(65 + idx)}
              </span>
              {option}
            </button>
          );
        })}
      </div>

      {/* Explanation */}
      {showExplanation && (
        <div className={`rounded-xl p-3 border text-sm ${
          selected === q.correctIndex
            ? 'bg-green-900/20 border-green-500/30 text-green-200'
            : 'bg-orange-900/20 border-orange-500/30 text-orange-200'
        }`}>
          <div className="font-semibold mb-1">
            {selected === q.correctIndex ? '✅ Correct!' : '❌ Not quite...'}
          </div>
          <div className="text-xs leading-relaxed opacity-90">{q.explanation}</div>
        </div>
      )}

      {/* Next button */}
      {selected !== null && (
        <button
          onClick={handleNext}
          className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-sm font-semibold transition-all"
        >
          {currentQ < questions.length - 1 ? 'Next Question →' : 'See Results 🏆'}
        </button>
      )}

      {/* Score tracker */}
      <div className="flex items-center justify-between text-xs text-gray-500">
        <span>Score: {score}/{currentQ + (selected !== null ? 1 : 0)}</span>
        <span>XP: {score * 5}</span>
      </div>
    </div>
  );
}
