import { useState } from 'react';
import { useMoleculeStore } from '../store/moleculeStore';
import { Eye, EyeOff, Save, CheckCircle2, AlertCircle, Cpu, Database } from 'lucide-react';

const OPENAI_MODELS = ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-3.5-turbo'];
const DEEPSEEK_MODELS = ['deepseek-chat', 'deepseek-reasoner'];
const OLLAMA_MODELS = ['llama3', 'llama3.1', 'mistral', 'mixtral', 'phi3', 'gemma2'];

export default function SettingsPanel() {
  const { aiSettings, setAISettings, moleculeCache, userProgress } = useMoleculeStore();
  const [showKey, setShowKey] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const cacheCount = Object.keys(moleculeCache).length;

  const getModels = () => {
    if (aiSettings.provider === 'openai') return OPENAI_MODELS;
    if (aiSettings.provider === 'deepseek') return DEEPSEEK_MODELS;
    if (aiSettings.provider === 'ollama') return OLLAMA_MODELS;
    return ['demo'];
  };

  return (
    <div className="space-y-5 pb-4">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-white/5 rounded-lg p-2 text-center">
          <div className="text-lg font-bold text-cyan-400">{userProgress.moleculesViewed.length}</div>
          <div className="text-xs text-gray-500">Molecules</div>
        </div>
        <div className="bg-white/5 rounded-lg p-2 text-center">
          <div className="text-lg font-bold text-green-400">{cacheCount}</div>
          <div className="text-xs text-gray-500">Cached</div>
        </div>
        <div className="bg-white/5 rounded-lg p-2 text-center">
          <div className="text-lg font-bold text-purple-400">Lv.{userProgress.level}</div>
          <div className="text-xs text-gray-500">Level</div>
        </div>
      </div>

      {/* AI Provider */}
      <div>
        <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <Cpu size={12} />
          AI Provider
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          {(['demo', 'openai', 'deepseek', 'ollama'] as const).map((provider) => (
            <button
              key={provider}
              onClick={() => setAISettings({ provider, model: getModels()[0] })}
              className={`py-2 px-3 rounded-lg text-sm font-medium transition-all border capitalize ${
                aiSettings.provider === provider
                  ? 'bg-cyan-600/30 border-cyan-500/50 text-cyan-300'
                  : 'bg-white/5 border-white/10 text-gray-400 hover:text-white hover:border-white/20'
              }`}
            >
              {provider === 'demo' ? '🎮 Demo' :
               provider === 'openai' ? '🤖 OpenAI' :
               provider === 'deepseek' ? '🧠 DeepSeek' :
               '🖥️ Ollama'}
            </button>
          ))}
        </div>

        {aiSettings.provider === 'demo' && (
          <div className="mt-2 p-2 bg-yellow-900/20 border border-yellow-500/30 rounded-lg text-xs text-yellow-400">
            Demo mode uses pre-written responses. Add an API key for full AI capabilities.
          </div>
        )}
      </div>

      {/* API Key */}
      {(aiSettings.provider === 'openai' || aiSettings.provider === 'deepseek') && (
        <div>
          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 block">
            API Key
          </label>
          <div className="relative">
            <input
              type={showKey ? 'text' : 'password'}
              value={aiSettings.apiKey || ''}
              onChange={(e) => setAISettings({ apiKey: e.target.value })}
              placeholder={`Enter your ${aiSettings.provider === 'openai' ? 'OpenAI' : 'DeepSeek'} API key...`}
              className="w-full bg-white/5 border border-white/10 focus:border-cyan-500/50 text-white placeholder-gray-600 rounded-lg px-3 py-2 text-sm pr-10 outline-none transition-all font-mono"
            />
            <button
              type="button"
              onClick={() => setShowKey(!showKey)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
            >
              {showKey ? <EyeOff size={14} /> : <Eye size={14} />}
            </button>
          </div>
          <div className="flex items-center gap-1.5 mt-1.5">
            {aiSettings.apiKey ? (
              <><CheckCircle2 size={12} className="text-green-400" /><span className="text-xs text-green-400">API key set</span></>
            ) : (
              <><AlertCircle size={12} className="text-yellow-400" /><span className="text-xs text-yellow-400">No API key — using demo mode</span></>
            )}
          </div>
        </div>
      )}

      {/* Ollama URL */}
      {aiSettings.provider === 'ollama' && (
        <div>
          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 block">
            Ollama Base URL
          </label>
          <input
            type="text"
            value={aiSettings.baseUrl || 'http://localhost:11434'}
            onChange={(e) => setAISettings({ baseUrl: e.target.value })}
            placeholder="http://localhost:11434"
            className="w-full bg-white/5 border border-white/10 focus:border-cyan-500/50 text-white placeholder-gray-600 rounded-lg px-3 py-2 text-sm outline-none transition-all font-mono"
          />
        </div>
      )}

      {/* Model selection */}
      {aiSettings.provider !== 'demo' && (
        <div>
          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 block">
            Model
          </label>
          <select
            value={aiSettings.model}
            onChange={(e) => setAISettings({ model: e.target.value })}
            className="w-full bg-[#0d1526] border border-white/10 focus:border-cyan-500/50 text-white rounded-lg px-3 py-2 text-sm outline-none transition-all"
          >
            {getModels().map((m) => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
        </div>
      )}

      {/* Parameters */}
      <div>
        <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Parameters</div>
        <div className="space-y-3">
          <div>
            <div className="flex justify-between mb-1">
              <label className="text-xs text-gray-400">Temperature</label>
              <span className="text-xs text-cyan-400 font-mono">{aiSettings.temperature.toFixed(1)}</span>
            </div>
            <input
              type="range"
              min="0"
              max="2"
              step="0.1"
              value={aiSettings.temperature}
              onChange={(e) => setAISettings({ temperature: parseFloat(e.target.value) })}
              className="w-full accent-cyan-500"
            />
            <div className="flex justify-between text-[10px] text-gray-600">
              <span>Precise</span>
              <span>Creative</span>
            </div>
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <label className="text-xs text-gray-400">Max Tokens</label>
              <span className="text-xs text-cyan-400 font-mono">{aiSettings.maxTokens}</span>
            </div>
            <input
              type="range"
              min="256"
              max="4096"
              step="256"
              value={aiSettings.maxTokens}
              onChange={(e) => setAISettings({ maxTokens: parseInt(e.target.value) })}
              className="w-full accent-cyan-500"
            />
          </div>
        </div>
      </div>

      {/* Save button */}
      <button
        onClick={handleSave}
        className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-all"
      >
        {saved ? <><CheckCircle2 size={14} /> Saved!</> : <><Save size={14} /> Save Settings</>}
      </button>

      {/* Cache info */}
      <div className="border-t border-white/5 pt-4">
        <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <Database size={12} />
          Local Cache ({cacheCount} molecules)
        </div>
        <div className="text-xs text-gray-500 leading-relaxed">
          Molecules are automatically cached locally for instant retrieval. The cache grows as you explore more molecules.
        </div>
        {cacheCount > 0 && (
          <div className="mt-2 flex flex-wrap gap-1">
            {Object.keys(moleculeCache).slice(0, 8).map((key) => (
              <span key={key} className="text-[10px] px-1.5 py-0.5 bg-white/5 border border-white/10 rounded text-gray-500 truncate max-w-[80px]">
                {key}
              </span>
            ))}
            {cacheCount > 8 && (
              <span className="text-[10px] px-1.5 py-0.5 bg-white/5 border border-white/10 rounded text-gray-500">
                +{cacheCount - 8} more
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
