import { useState, useEffect, useRef } from 'react';
import { useMoleculeStore } from '../store/moleculeStore';
import { Flame, Droplets, FlaskConical, Thermometer, Beaker, X, Zap } from 'lucide-react';

interface LabItem {
  id: string;
  type: string;
  x: number;
  y: number;
  label: string;
  active: boolean;
  color: string;
}

const LAB_ITEMS: LabItem[] = [
  { id: 'beaker1', type: 'beaker', x: 25, y: 60, label: 'Main Beaker', active: false, color: '#60a5fa' },
  { id: 'testtube1', type: 'testtube', x: 55, y: 55, label: 'Test Tube A', active: false, color: '#34d399' },
  { id: 'testtube2', type: 'testtube', x: 65, y: 52, label: 'Test Tube B', active: false, color: '#f472b6' },
  { id: 'flask1', type: 'flask', x: 75, y: 58, label: 'Erlenmeyer', active: false, color: '#a78bfa' },
  { id: 'burner1', type: 'burner', x: 42, y: 75, label: 'Bunsen Burner', active: false, color: '#f97316' },
];

function BunsenBurner({ active, onClick }: { active: boolean; onClick: () => void }) {
  return (
    <g onClick={onClick} style={{ cursor: 'pointer' }}>
      {/* Base */}
      <rect x="-18" y="20" width="36" height="8" rx="4" fill="#4b5563" />
      {/* Stand */}
      <rect x="-4" y="-20" width="8" height="40" rx="2" fill="#374151" />
      {/* Tube */}
      <rect x="-6" y="-25" width="12" height="10" rx="2" fill="#4b5563" />
      {/* Flame */}
      {active && (
        <g>
          <ellipse cx="0" cy="-35" rx="8" ry="15" fill="#f97316" opacity="0.9">
            <animate attributeName="ry" values="15;18;14;16;15" dur="0.5s" repeatCount="indefinite" />
          </ellipse>
          <ellipse cx="0" cy="-38" rx="5" ry="12" fill="#fbbf24" opacity="0.9">
            <animate attributeName="ry" values="12;14;11;13;12" dur="0.4s" repeatCount="indefinite" />
          </ellipse>
          <ellipse cx="0" cy="-42" rx="3" ry="8" fill="#fef3c7" opacity="0.8">
            <animate attributeName="ry" values="8;10;7;9;8" dur="0.3s" repeatCount="indefinite" />
          </ellipse>
        </g>
      )}
      {/* Label */}
      <text x="0" y="40" textAnchor="middle" fill="#9ca3af" fontSize="10">Burner</text>
    </g>
  );
}

function Beaker3D({ active, color, label, onClick }: { active: boolean; color: string; label: string; onClick: () => void }) {
  return (
    <g onClick={onClick} style={{ cursor: 'pointer' }}>
      {/* Beaker body */}
      <path d="M-20,-30 L-24,30 L24,30 L20,-30 Z" fill={color + '33'} stroke={color} strokeWidth="2" />
      {/* Spout */}
      <path d="M-20,-30 L-24,-35 L-16,-35" fill="none" stroke={color} strokeWidth="2" />
      {/* Liquid */}
      {active && (
        <>
          <path d="M-22,10 L22,10 L20,28 L-20,28 Z" fill={color + '66'}>
            <animate attributeName="d" values="M-22,10 L22,10 L20,28 L-20,28 Z;M-22,8 L22,12 L20,28 L-20,28 Z;M-22,10 L22,10 L20,28 L-20,28 Z" dur="1s" repeatCount="indefinite" />
          </path>
          {/* Bubbles */}
          <circle cx="-5" cy="18" r="2" fill={color + '88'}>
            <animate attributeName="cy" values="28;5" dur="1s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="1;0" dur="1s" repeatCount="indefinite" />
          </circle>
          <circle cx="8" cy="20" r="1.5" fill={color + '88'}>
            <animate attributeName="cy" values="28;5" dur="0.8s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="1;0" dur="0.8s" repeatCount="indefinite" />
          </circle>
        </>
      )}
      {/* Measurement marks */}
      <line x1="15" y1="-10" x2="20" y2="-10" stroke={color} strokeWidth="1" opacity="0.5" />
      <line x1="15" y1="0" x2="20" y2="0" stroke={color} strokeWidth="1" opacity="0.5" />
      <line x1="15" y1="10" x2="20" y2="10" stroke={color} strokeWidth="1" opacity="0.5" />
      <text x="0" y="48" textAnchor="middle" fill="#9ca3af" fontSize="9">{label}</text>
    </g>
  );
}

function TestTube({ active, color, label, onClick }: { active: boolean; color: string; label: string; onClick: () => void }) {
  return (
    <g onClick={onClick} style={{ cursor: 'pointer' }}>
      {/* Tube */}
      <path d="M-8,-35 L-8,20 Q0,30 8,20 L8,-35 Z" fill={color + '22'} stroke={color} strokeWidth="1.5" />
      {/* Liquid */}
      {active && (
        <path d="M-7,10 L7,10 Q5,28 0,28 Q-5,28 -7,10 Z" fill={color + '77'}>
          <animate attributeName="d" values="M-7,10 L7,10 Q5,28 0,28 Q-5,28 -7,10 Z;M-7,8 L7,12 Q5,28 0,28 Q-5,28 -7,8 Z;M-7,10 L7,10 Q5,28 0,28 Q-5,28 -7,10 Z" dur="0.8s" repeatCount="indefinite" />
        </path>
      )}
      <text x="0" y="45" textAnchor="middle" fill="#9ca3af" fontSize="9">{label}</text>
    </g>
  );
}

function ErlenmeyerFlask({ active, color, label, onClick }: { active: boolean; color: string; label: string; onClick: () => void }) {
  return (
    <g onClick={onClick} style={{ cursor: 'pointer' }}>
      {/* Flask shape */}
      <path d="M-6,-40 L-6,-10 L-30,30 L30,30 L6,-10 L6,-40 Z" fill={color + '22'} stroke={color} strokeWidth="1.5" />
      {/* Neck rim */}
      <rect x="-8" y="-42" width="16" height="5" rx="2" fill={color + '44'} stroke={color} strokeWidth="1" />
      {/* Liquid */}
      {active && (
        <path d="M-25,15 L25,15 L28,28 L-28,28 Z" fill={color + '66'}>
          <animate attributeName="d" values="M-25,15 L25,15 L28,28 L-28,28 Z;M-25,13 L25,17 L28,28 L-28,28 Z;M-25,15 L25,15 L28,28 L-28,28 Z" dur="1.2s" repeatCount="indefinite" />
        </path>
      )}
      <text x="0" y="48" textAnchor="middle" fill="#9ca3af" fontSize="9">{label}</text>
    </g>
  );
}

export default function LabView() {
  const { currentMolecule, activeReactionId, labReactionActive, setLabReactionActive, setViewMode } = useMoleculeStore();
  const [activeItem, setActiveItem] = useState<string | null>(null);
  const [burnerOn, setBurnerOn] = useState(false);
  const [reactionProgress, setReactionProgress] = useState(0);
  const [reactionPhase, setReactionPhase] = useState<'idle' | 'mixing' | 'heating' | 'complete'>('idle');
  const progressRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const activeReaction = currentMolecule?.reactions?.find(r => r.id === activeReactionId);

  useEffect(() => {
    if (labReactionActive && activeReaction) {
      setReactionPhase('mixing');
      setReactionProgress(0);
      progressRef.current = setInterval(() => {
        setReactionProgress(p => {
          if (p >= 100) {
            clearInterval(progressRef.current!);
            setReactionPhase('complete');
            setLabReactionActive(false);
            return 100;
          }
          if (p === 30) setReactionPhase('heating');
          return p + 1;
        });
      }, 60);
    }
    return () => {
      if (progressRef.current) clearInterval(progressRef.current);
    };
  }, [labReactionActive, activeReaction]);

  const handleItemClick = (id: string) => {
    setActiveItem(activeItem === id ? null : id);
    if (id === 'burner1') {
      setBurnerOn(!burnerOn);
    }
  };

  const startReaction = () => {
    setLabReactionActive(true);
    setBurnerOn(true);
  };

  return (
    <div className="w-full h-full bg-[#0a0f1e] relative overflow-hidden flex flex-col">
      {/* Lab Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-black/40 border-b border-white/10 shrink-0 z-10">
        <div className="flex items-center gap-2">
          <FlaskConical size={16} className="text-cyan-400" />
          <span className="text-sm font-semibold text-white">Virtual Lab</span>
          {currentMolecule && (
            <span className="text-xs text-gray-400">— {currentMolecule.name}</span>
          )}
        </div>
        <button
          onClick={() => setViewMode('molecule')}
          className="flex items-center gap-1.5 px-2 py-1 text-xs text-gray-400 hover:text-white border border-white/10 hover:border-white/30 rounded-lg transition-all"
        >
          <X size={12} />
          Exit Lab
        </button>
      </div>

      {/* Reaction progress */}
      {reactionPhase !== 'idle' && (
        <div className="px-4 py-2 bg-orange-900/20 border-b border-orange-500/20 shrink-0">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2 text-sm text-orange-300">
              {reactionPhase === 'mixing' && <><Droplets size={14} className="animate-bounce" /> Mixing reagents...</>}
              {reactionPhase === 'heating' && <><Flame size={14} className="animate-pulse" /> Heating...</>}
              {reactionPhase === 'complete' && <><Zap size={14} className="text-green-400" /> Reaction complete!</>}
            </div>
            <span className="text-xs text-gray-400">{reactionProgress}%</span>
          </div>
          <div className="w-full bg-gray-800 rounded-full h-1.5">
            <div
              className="h-1.5 rounded-full transition-all duration-100"
              style={{
                width: `${reactionProgress}%`,
                background: reactionProgress < 50
                  ? 'linear-gradient(to right, #3b82f6, #60a5fa)'
                  : reactionProgress < 80
                  ? 'linear-gradient(to right, #f59e0b, #fbbf24)'
                  : 'linear-gradient(to right, #10b981, #34d399)',
              }}
            />
          </div>
        </div>
      )}

      {/* Lab bench scene */}
      <div className="flex-1 relative">
        <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet">
          {/* Lab background gradient */}
          <defs>
            <linearGradient id="benchGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0f172a" />
              <stop offset="100%" stopColor="#1e293b" />
            </linearGradient>
            <linearGradient id="tableGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#374151" />
              <stop offset="100%" stopColor="#1f2937" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="1" result="blur" />
              <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
          </defs>

          {/* Room background */}
          <rect width="100" height="100" fill="url(#benchGrad)" />

          {/* Wall */}
          <rect x="0" y="0" width="100" height="75" fill="#0f1729" />

          {/* Wall panels */}
          <rect x="5" y="5" width="90" height="40" rx="2" fill="#111827" stroke="#1e3a5f" strokeWidth="0.5" opacity="0.5" />

          {/* Lab bench surface */}
          <rect x="0" y="72" width="100" height="5" fill="url(#tableGrad)" />
          <rect x="0" y="72" width="100" height="0.5" fill="#6b7280" opacity="0.5" />

          {/* Bench legs */}
          <rect x="5" y="77" width="3" height="23" fill="#374151" />
          <rect x="92" y="77" width="3" height="23" fill="#374151" />

          {/* Shelf */}
          <rect x="0" y="30" width="100" height="2" fill="#374151" />

          {/* Shelf items */}
          <rect x="8" y="22" width="4" height="8" rx="1" fill="#1e40af" opacity="0.6" />
          <rect x="14" y="20" width="4" height="10" rx="1" fill="#7c3aed" opacity="0.6" />
          <rect x="20" y="23" width="3" height="7" rx="1" fill="#065f46" opacity="0.6" />
          <rect x="75" y="22" width="5" height="8" rx="1" fill="#991b1b" opacity="0.6" />
          <rect x="82" y="21" width="4" height="9" rx="1" fill="#78350f" opacity="0.6" />
          <text x="48" y="27" textAnchor="middle" fill="#1e3a5f" fontSize="3" fontFamily="monospace">DANGER — FLAMMABLE</text>

          {/* Main beaker */}
          <g transform="translate(25, 72)">
            <Beaker3D
              active={activeItem === 'beaker1' || reactionPhase !== 'idle'}
              color="#60a5fa"
              label="Main Beaker"
              onClick={() => handleItemClick('beaker1')}
            />
          </g>

          {/* Test tubes on rack */}
          <g>
            {/* Rack */}
            <rect x="50" y="55" width="20" height="2" rx="1" fill="#6b7280" />
            <rect x="51" y="57" width="1" height="14" fill="#6b7280" />
            <rect x="68" y="57" width="1" height="14" fill="#6b7280" />
          </g>

          <g transform="translate(56, 65)">
            <TestTube
              active={activeItem === 'testtube1' || reactionPhase === 'heating' || reactionPhase === 'complete'}
              color="#34d399"
              label="A"
              onClick={() => handleItemClick('testtube1')}
            />
          </g>

          <g transform="translate(66, 63)">
            <TestTube
              active={activeItem === 'testtube2'}
              color="#f472b6"
              label="B"
              onClick={() => handleItemClick('testtube2')}
            />
          </g>

          {/* Flask */}
          <g transform="translate(80, 72)">
            <ErlenmeyerFlask
              active={activeItem === 'flask1' || reactionPhase === 'complete'}
              color="#a78bfa"
              label="Flask"
              onClick={() => handleItemClick('flask1')}
            />
          </g>

          {/* Burner */}
          <g transform="translate(42, 70)">
            <BunsenBurner
              active={burnerOn || reactionPhase === 'heating'}
              onClick={() => handleItemClick('burner1')}
            />
          </g>

          {/* Thermometer */}
          <g transform="translate(12, 65)">
            <rect x="-2" y="-25" width="4" height="30" rx="2" fill="#1e3a5f" stroke="#3b82f6" strokeWidth="0.5" />
            <circle cx="0" cy="8" r="4" fill="#ef4444" />
            <rect x="-1" y={-25 + (burnerOn ? 15 : 25)} width="2" height={burnerOn ? 30 : 20} rx="1" fill="#ef4444">
              {burnerOn && <animate attributeName="height" values="20;30;25;30;20" dur="2s" repeatCount="indefinite" />}
            </rect>
            <text x="0" y="20" textAnchor="middle" fill="#9ca3af" fontSize="5">
              {burnerOn ? '85°C' : '22°C'}
            </text>
          </g>

          {/* Molecule label floating in beaker */}
          {currentMolecule && (reactionPhase !== 'idle' || activeItem === 'beaker1') && (
            <g transform="translate(25, 62)">
              <rect x="-15" y="-8" width="30" height="10" rx="3" fill="#1e3a5f" stroke="#60a5fa" strokeWidth="0.5" opacity="0.9" />
              <text x="0" y="-1" textAnchor="middle" fill="#60a5fa" fontSize="4" fontWeight="bold">
                {currentMolecule.formula}
              </text>
            </g>
          )}

          {/* Reaction equation overlay */}
          {activeReaction && reactionPhase !== 'idle' && (
            <g>
              <rect x="5" y="3" width="90" height="16" rx="3" fill="#000000" opacity="0.8" />
              <text x="50" y="9" textAnchor="middle" fill="#fbbf24" fontSize="4" fontWeight="bold">
                {activeReaction.name}
              </text>
              <text x="50" y="16" textAnchor="middle" fill="#9ca3af" fontSize="3.5">
                {activeReaction.equation.length > 45 ? activeReaction.equation.slice(0, 45) + '...' : activeReaction.equation}
              </text>
            </g>
          )}

          {/* Completion effect */}
          {reactionPhase === 'complete' && (
            <g>
              {[...Array(8)].map((_, i) => (
                <circle
                  key={i}
                  cx={20 + i * 10}
                  cy="50"
                  r="1.5"
                  fill={['#10b981', '#3b82f6', '#a78bfa', '#f59e0b'][i % 4]}
                  opacity="0.8"
                >
                  <animate attributeName="cy" values="50;20;50" dur={`${0.5 + i * 0.1}s`} repeatCount="3" />
                  <animate attributeName="opacity" values="0.8;0;0.8" dur={`${0.5 + i * 0.1}s`} repeatCount="3" />
                </circle>
              ))}
            </g>
          )}
        </svg>

        {/* Control panel */}
        <div className="absolute bottom-4 left-4 right-4 flex gap-2 flex-wrap justify-center">
          <button
            onClick={() => handleItemClick('burner1')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
              burnerOn
                ? 'bg-orange-500/30 border border-orange-500/50 text-orange-300'
                : 'bg-white/5 border border-white/10 text-gray-400 hover:text-white'
            }`}
          >
            <Flame size={12} />
            {burnerOn ? 'Turn Off Burner' : 'Light Burner'}
          </button>

          <button
            onClick={() => handleItemClick('beaker1')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
              activeItem === 'beaker1'
                ? 'bg-blue-500/30 border border-blue-500/50 text-blue-300'
                : 'bg-white/5 border border-white/10 text-gray-400 hover:text-white'
            }`}
          >
            <Beaker size={12} />
            Mix Beaker
          </button>

          {activeReaction && reactionPhase === 'idle' && (
            <button
              onClick={startReaction}
              className="px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 bg-cyan-600/30 border border-cyan-500/50 text-cyan-300 hover:bg-cyan-600/50 transition-all"
            >
              <Zap size={12} />
              Start: {activeReaction.name}
            </button>
          )}

          {reactionPhase === 'complete' && (
            <button
              onClick={() => { setReactionPhase('idle'); setReactionProgress(0); setBurnerOn(false); }}
              className="px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 bg-green-600/30 border border-green-500/50 text-green-300"
            >
              ✅ Reset Lab
            </button>
          )}
        </div>
      </div>

      {/* Active reaction info */}
      {activeReaction && (
        <div className="px-4 py-2 bg-black/40 border-t border-white/5 shrink-0">
          <div className="text-xs text-gray-400">
            <span className="text-cyan-400 font-medium">{activeReaction.name}:</span>{' '}
            {activeReaction.description}
          </div>
        </div>
      )}
    </div>
  );
}
