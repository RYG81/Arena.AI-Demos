import { useMoleculeStore } from '../store/moleculeStore';
import { ExternalLink, Copy, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';

const PropertyRow = ({ label, value, unit = '', highlight = false }: {
  label: string;
  value: string | number | undefined;
  unit?: string;
  highlight?: boolean;
}) => {
  if (value === undefined || value === null || value === '') return null;
  return (
    <div className={`flex justify-between items-center py-2 border-b border-white/5 ${highlight ? 'bg-cyan-900/10 -mx-2 px-2 rounded' : ''}`}>
      <span className="text-gray-400 text-xs">{label}</span>
      <span className="text-right text-sm font-medium text-gray-200 max-w-[60%] break-all">
        {value}{unit}
      </span>
    </div>
  );
};

export default function PropertiesPanel() {
  const { currentMolecule } = useMoleculeStore();
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(key);
      setTimeout(() => setCopied(null), 2000);
    });
  };

  if (!currentMolecule) {
    return (
      <div className="flex flex-col items-center justify-center h-40 text-gray-500 text-sm text-center">
        <div className="text-3xl mb-3">🔬</div>
        <div>Load a molecule to see its properties</div>
      </div>
    );
  }

  const p = currentMolecule.properties;

  const getLogPClass = (logP: number | undefined) => {
    if (logP === undefined) return '';
    if (logP < 0) return 'text-blue-400';
    if (logP < 2) return 'text-green-400';
    if (logP < 5) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getDrugScore = () => {
    if (!p) return null;
    let score = 0;
    let max = 0;
    if (p.molecularWeight !== undefined) { max++; if (p.molecularWeight <= 500) score++; }
    if (p.xlogp !== undefined) { max++; if (p.xlogp <= 5) score++; }
    if (p.hBondDonorCount !== undefined) { max++; if (p.hBondDonorCount <= 5) score++; }
    if (p.hBondAcceptorCount !== undefined) { max++; if (p.hBondAcceptorCount <= 10) score++; }
    return max > 0 ? Math.round((score / max) * 100) : null;
  };

  const drugScore = getDrugScore();

  return (
    <div className="space-y-4 pb-4">
      {/* Header */}
      <div className="bg-gradient-to-r from-cyan-900/30 to-blue-900/30 rounded-xl p-3 border border-cyan-500/20">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-bold text-white text-base">{currentMolecule.name}</h3>
            <div className="text-cyan-400 font-mono text-sm mt-0.5">{currentMolecule.formula}</div>
          </div>
          {currentMolecule.cid && (
            <a
              href={`https://pubchem.ncbi.nlm.nih.gov/compound/${currentMolecule.cid}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 mt-1"
            >
              PubChem <ExternalLink size={10} />
            </a>
          )}
        </div>
        {p?.iupacName && (
          <div className="text-gray-400 text-xs mt-1 italic">{p.iupacName}</div>
        )}
      </div>

      {/* Drug-likeness score */}
      {drugScore !== null && (
        <div className="bg-white/5 rounded-lg p-3">
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-xs text-gray-400">Lipinski Drug-likeness</span>
            <span className="text-sm font-semibold text-white">{drugScore}%</span>
          </div>
          <div className="w-full bg-gray-800 rounded-full h-1.5">
            <div
              className={`h-1.5 rounded-full transition-all ${
                drugScore >= 75 ? 'bg-green-500' : drugScore >= 50 ? 'bg-yellow-500' : 'bg-red-500'
              }`}
              style={{ width: `${drugScore}%` }}
            />
          </div>
          <div className="text-xs text-gray-500 mt-1">
            {drugScore >= 75 ? 'Good drug candidate' : drugScore >= 50 ? 'Moderate drug-likeness' : 'Poor drug-likeness (Ro5 violations)'}
          </div>
        </div>
      )}

      {/* Core Properties */}
      <div>
        <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Physical Properties</div>
        <div className="space-y-0">
          <PropertyRow label="Molecular Weight" value={p?.molecularWeight?.toFixed(3)} unit=" g/mol" highlight />
          <PropertyRow label="Heavy Atoms" value={p?.heavyAtomCount} />
          <PropertyRow label="Formal Charge" value={p?.charge} />
          <PropertyRow label="Complexity" value={p?.complexity?.toFixed(0)} />
          <PropertyRow label="Rotatable Bonds" value={p?.rotatableBondCount} />
        </div>
      </div>

      {/* ADMET Properties */}
      <div>
        <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">ADMET Properties</div>
        <div className="space-y-0">
          <div className="flex justify-between items-center py-2 border-b border-white/5">
            <span className="text-gray-400 text-xs">LogP (lipophilicity)</span>
            <span className={`text-sm font-semibold ${getLogPClass(p?.xlogp)}`}>
              {p?.xlogp !== undefined ? p.xlogp.toFixed(2) : 'N/A'}
            </span>
          </div>
          <PropertyRow label="H-Bond Donors" value={p?.hBondDonorCount} />
          <PropertyRow label="H-Bond Acceptors" value={p?.hBondAcceptorCount} />
          <PropertyRow label="TPSA" value={p?.topologicalPolarSurfaceArea?.toFixed(1)} unit=" Ų" />
        </div>
      </div>

      {/* Identifiers */}
      <div>
        <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Identifiers</div>
        <div className="space-y-2">
          {currentMolecule.smiles && (
            <div className="bg-white/3 rounded-lg p-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-gray-500">Canonical SMILES</span>
                <button
                  onClick={() => copyToClipboard(currentMolecule.smiles!, 'smiles')}
                  className="text-gray-500 hover:text-cyan-400 transition-colors"
                >
                  {copied === 'smiles' ? <CheckCircle2 size={12} className="text-green-400" /> : <Copy size={12} />}
                </button>
              </div>
              <div className="text-xs text-gray-300 font-mono break-all leading-relaxed">
                {currentMolecule.smiles}
              </div>
            </div>
          )}
          {currentMolecule.inchiKey && (
            <div className="bg-white/3 rounded-lg p-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-gray-500">InChIKey</span>
                <button
                  onClick={() => copyToClipboard(currentMolecule.inchiKey!, 'inchi')}
                  className="text-gray-500 hover:text-cyan-400 transition-colors"
                >
                  {copied === 'inchi' ? <CheckCircle2 size={12} className="text-green-400" /> : <Copy size={12} />}
                </button>
              </div>
              <div className="text-xs text-gray-300 font-mono break-all">{currentMolecule.inchiKey}</div>
            </div>
          )}
          {currentMolecule.cid && (
            <PropertyRow label="PubChem CID" value={currentMolecule.cid} />
          )}
        </div>
      </div>

      {/* Functional Groups */}
      {currentMolecule.functionalGroups && currentMolecule.functionalGroups.length > 0 && (
        <div>
          <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Functional Groups</div>
          <div className="flex flex-wrap gap-1.5">
            {currentMolecule.functionalGroups.map((fg) => (
              <div
                key={fg.name}
                className="group relative px-2 py-1 rounded-full text-xs font-medium cursor-help"
                style={{ backgroundColor: fg.color + '22', border: `1px solid ${fg.color}66`, color: fg.color }}
              >
                {fg.name}
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block w-40 bg-gray-900 text-gray-200 text-xs rounded-lg p-2 z-10 text-center shadow-xl">
                  {fg.description}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Synonyms */}
      {currentMolecule.synonyms && currentMolecule.synonyms.length > 0 && (
        <div>
          <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Known Names</div>
          <div className="flex flex-wrap gap-1">
            {currentMolecule.synonyms.slice(0, 6).map((syn) => (
              <span key={syn} className="px-2 py-0.5 bg-white/5 border border-white/10 rounded text-xs text-gray-400">
                {syn}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
