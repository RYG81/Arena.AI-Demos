import type { MoleculeData, MoleculeProperties, ReactionInfo, FunctionalGroup } from '../types/molecule';

const PUBCHEM_BASE = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug';
const PUBCHEM_VIEW = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug_view';

// Detect functional groups from SMILES
function detectFunctionalGroups(smiles: string): FunctionalGroup[] {
  const groups: FunctionalGroup[] = [];
  const s = smiles || '';

  if (s.includes('OH') || s.includes('O)') || /[^C]O[^C(]/.test(s)) {
    groups.push({ name: 'Hydroxyl', smarts: '[OH]', description: 'Polar, forms hydrogen bonds', color: '#3b82f6' });
  }
  if (s.includes('C=O') && (s.includes('OC') || s.includes('CO'))) {
    groups.push({ name: 'Ester', smarts: '[C](=O)O', description: 'Found in fats and fragrances', color: '#f59e0b' });
  }
  if (s.includes('C(=O)O') || s.includes('COOH')) {
    groups.push({ name: 'Carboxyl', smarts: '[CX3](=O)[OX2H1]', description: 'Acidic functional group', color: '#ef4444' });
  }
  if (/C\(=O\)N|NC\(=O\)/.test(s)) {
    groups.push({ name: 'Amide', smarts: '[CX3](=O)[NX3]', description: 'Found in proteins (peptide bonds)', color: '#8b5cf6' });
  }
  if (/N/.test(s) && !/NC\(=O\)/.test(s)) {
    groups.push({ name: 'Amine', smarts: '[NX3;H2,H1,H0;!$(NC=O)]', description: 'Basic nitrogen group', color: '#10b981' });
  }
  if (s.includes('C=O') && !s.includes('OC(=O)') && !s.includes('NC(=O)')) {
    if (/C\(=O\)C|CC\(=O\)/.test(s)) {
      groups.push({ name: 'Ketone', smarts: '[CX3](=O)[#6]', description: 'Carbonyl between carbons', color: '#f97316' });
    }
  }
  if (s.startsWith('O=C') || /\[C@@H\].*C=O/.test(s)) {
    groups.push({ name: 'Aldehyde', smarts: '[CX3H1](=O)', description: 'Terminal carbonyl group', color: '#ec4899' });
  }
  if (/c1ccccc1|c1cccc/.test(s.toLowerCase())) {
    groups.push({ name: 'Aromatic Ring', smarts: 'c1ccccc1', description: 'Delocalized π electrons', color: '#6366f1' });
  }
  if (/C=C/.test(s)) {
    groups.push({ name: 'Alkene', smarts: 'C=C', description: 'Carbon-carbon double bond', color: '#14b8a6' });
  }
  if (/C#C/.test(s)) {
    groups.push({ name: 'Alkyne', smarts: 'C#C', description: 'Carbon-carbon triple bond', color: '#a855f7' });
  }
  if (/F|Cl|Br|I/.test(s)) {
    groups.push({ name: 'Halogen', smarts: '[F,Cl,Br,I]', description: 'Electronegative substituent', color: '#64748b' });
  }
  if (/P/.test(s)) {
    groups.push({ name: 'Phosphate', smarts: '[P]', description: 'Found in DNA/RNA backbone', color: '#d97706' });
  }
  if (/S/.test(s)) {
    groups.push({ name: 'Thiol/Sulfide', smarts: '[S]', description: 'Sulfur-containing group', color: '#fbbf24' });
  }

  return groups;
}

// Generate reactions based on functional groups and molecule type
function generateReactions(smiles: string, formula: string, name: string): ReactionInfo[] {
  const reactions: ReactionInfo[] = [];
  const s = smiles || '';
  const isOrganic = /C/.test(formula);
  const hasOxygen = /O/.test(formula);
  const hasNitrogen = /N/.test(formula);
  const hasHydrogen = /H/.test(formula);
  const isAromatic = /c1ccccc1|c1cccc/.test(s.toLowerCase());

  // Combustion - for organic molecules
  if (isOrganic && hasHydrogen) {
    reactions.push({
      id: 'combustion',
      name: 'Combustion',
      type: 'combustion',
      description: `${name} undergoes complete combustion with oxygen to produce CO₂ and H₂O.`,
      reactants: [name, 'O₂'],
      products: ['CO₂', 'H₂O'],
      conditions: 'High temperature, ignition source',
      equation: `${name} + O₂ → CO₂ + H₂O + Energy`,
      mechanismSteps: [
        'Initiation: Free radicals form at high temperature',
        'Propagation: Chain reaction consumes fuel molecules',
        'Termination: Radicals combine, reaction ends',
      ],
      energyChange: 'exothermic',
    });
  }

  // Hydroxyl group reactions
  if (s.includes('OH') || /O[^C(=O)]/.test(s)) {
    reactions.push({
      id: 'esterification',
      name: 'Esterification',
      type: 'substitution',
      description: 'Reaction with a carboxylic acid to form an ester and water.',
      reactants: [name, 'Carboxylic Acid (RCOOH)'],
      products: ['Ester (RCOOR\')', 'H₂O'],
      conditions: 'Acid catalyst, heat',
      equation: `${name}-OH + RCOOH ⇌ ${name}-OOCR + H₂O`,
      mechanismSteps: [
        'Protonation of the carboxyl group by acid catalyst',
        'Nucleophilic attack by alcohol oxygen',
        'Proton transfer and water elimination',
      ],
      energyChange: 'endothermic',
    });

    reactions.push({
      id: 'dehydration',
      name: 'Dehydration',
      type: 'elimination',
      description: 'Elimination of water to form an alkene (if applicable).',
      reactants: [name],
      products: ['Alkene', 'H₂O'],
      conditions: 'Concentrated H₂SO₄, 170°C',
      equation: `${name} → Alkene + H₂O`,
      energyChange: 'endothermic',
    });
  }

  // Aromatic reactions
  if (isAromatic) {
    reactions.push({
      id: 'electrophilic-substitution',
      name: 'Electrophilic Aromatic Substitution',
      type: 'substitution',
      description: 'Aromatic ring substitution by an electrophile. Classic reaction of benzene rings.',
      reactants: [name, 'Electrophile (E⁺)'],
      products: [`${name}-E`, 'H⁺'],
      conditions: 'Lewis acid catalyst (AlCl₃, FeBr₃)',
      equation: `ArH + E⁺ → ArE + H⁺`,
      mechanismSteps: [
        'Electrophile attacks the aromatic π system',
        'Formation of arenium ion (σ-complex)',
        'Deprotonation restores aromaticity',
      ],
      energyChange: 'exothermic',
    });

    reactions.push({
      id: 'nitration',
      name: 'Nitration',
      type: 'substitution',
      description: 'Introduction of a nitro group (-NO₂) into the aromatic ring.',
      reactants: [name, 'HNO₃'],
      products: [`Nitro-${name}`, 'H₂O'],
      conditions: 'Mixed HNO₃/H₂SO₄, 50°C',
      equation: `ArH + HNO₃ → ArNO₂ + H₂O`,
      mechanismSteps: [
        'Generation of nitronium ion (NO₂⁺) from HNO₃/H₂SO₄',
        'Electrophilic attack on aromatic ring',
        'Loss of proton restores aromaticity',
      ],
      energyChange: 'exothermic',
    });
  }

  // Alkene reactions
  if (/C=C/.test(s)) {
    reactions.push({
      id: 'hydrogenation',
      name: 'Hydrogenation',
      type: 'addition',
      description: 'Addition of hydrogen across the double bond to form an alkane.',
      reactants: [name, 'H₂'],
      products: ['Saturated compound'],
      conditions: 'Pt, Pd, or Ni catalyst, moderate pressure',
      equation: `${name} (C=C) + H₂ → Alkane`,
      mechanismSteps: [
        'H₂ adsorbs onto catalyst surface',
        'Alkene adsorbs and binds to catalyst',
        'Hydrogen atoms add to each carbon of double bond',
      ],
      energyChange: 'exothermic',
    });

    reactions.push({
      id: 'halogenation',
      name: 'Halogenation',
      type: 'addition',
      description: 'Addition of a halogen (Br₂, Cl₂) across the double bond.',
      reactants: [name, 'Br₂'],
      products: [`Dibromo-${name}`],
      conditions: 'Room temperature, no catalyst',
      equation: `${name} (C=C) + Br₂ → Dibromide`,
      mechanismSteps: [
        'Bromine molecule polarizes near double bond',
        'Electrophilic addition forms bromonium ion',
        'Br⁻ attacks anti to bromonium',
      ],
      energyChange: 'exothermic',
    });
  }

  // Carboxyl group reactions
  if (s.includes('C(=O)O') || s.includes('COOH')) {
    reactions.push({
      id: 'acid-base',
      name: 'Acid-Base Reaction',
      type: 'neutralization',
      description: 'Reaction with a base to form a carboxylate salt.',
      reactants: [name, 'NaOH'],
      products: ['Carboxylate salt', 'H₂O'],
      conditions: 'Aqueous solution, room temperature',
      equation: `RCOOH + NaOH → RCOONa + H₂O`,
      mechanismSteps: [
        'Proton transfer from carboxyl group to hydroxide',
        'Formation of carboxylate ion',
        'Ion pairing with Na⁺',
      ],
      energyChange: 'exothermic',
    });
  }

  // Amine reactions
  if (hasNitrogen && /N/.test(s) && !s.includes('NO')) {
    reactions.push({
      id: 'amide-formation',
      name: 'Amide Formation',
      type: 'substitution',
      description: 'Reaction with a carboxylic acid to form an amide bond (peptide bond).',
      reactants: [name, 'Carboxylic Acid'],
      products: ['Amide', 'H₂O'],
      conditions: 'Heat, or activated acid derivative',
      equation: `R-NH₂ + RCOOH → RCONHR + H₂O`,
      mechanismSteps: [
        'Nucleophilic attack of amine on carbonyl carbon',
        'Proton transfer',
        'Elimination of water',
      ],
      energyChange: 'endothermic',
    });
  }

  // Oxidation for alcohols
  if ((s.includes('OH') || /[OX2H]/.test(s)) && isOrganic) {
    reactions.push({
      id: 'oxidation',
      name: 'Oxidation',
      type: 'oxidation',
      description: 'Oxidation to form aldehydes, ketones, or carboxylic acids.',
      reactants: [name, 'Oxidizing agent (KMnO₄, K₂Cr₂O₇)'],
      products: ['Carbonyl compound'],
      conditions: 'Acidic conditions, room temperature',
      equation: `${name} + [O] → Carbonyl compound`,
      energyChange: 'exothermic',
    });
  }

  return reactions;
}

// Parse SDF data to extract atoms and bonds
export function parseSDF(sdfText: string) {
  const lines = sdfText.split('\n');
  const atoms: any[] = [];
  const bonds: any[] = [];

  let atomCount = 0;
  let bondCount = 0;
  let countsParsed = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Counts line (line 4 in SDF)
    if (i === 3 && !countsParsed) {
      const parts = line.trim().split(/\s+/);
      atomCount = parseInt(parts[0]) || 0;
      bondCount = parseInt(parts[1]) || 0;
      countsParsed = true;
      continue;
    }

    if (countsParsed && i >= 4 && i < 4 + atomCount) {
      const parts = line.trim().split(/\s+/);
      if (parts.length >= 4) {
        atoms.push({
          serial: i - 3,
          name: parts[3],
          elem: parts[3],
          x: parseFloat(parts[0]) || 0,
          y: parseFloat(parts[1]) || 0,
          z: parseFloat(parts[2]) || 0,
        });
      }
    } else if (countsParsed && i >= 4 + atomCount && i < 4 + atomCount + bondCount) {
      const parts = line.trim().split(/\s+/);
      if (parts.length >= 3) {
        bonds.push({
          atom1: parseInt(parts[0]) - 1,
          atom2: parseInt(parts[1]) - 1,
          order: parseInt(parts[2]) || 1,
        });
      }
    }
  }

  return { atoms, bonds };
}

// Main fetch function
export async function fetchMoleculeByName(query: string): Promise<MoleculeData> {
  const trimmed = query.trim();

  // Step 1: Get CID from name
  let cid: number | null = null;

  try {
    const cidUrl = `${PUBCHEM_BASE}/compound/name/${encodeURIComponent(trimmed)}/cids/JSON`;
    const cidRes = await fetch(cidUrl);
    if (!cidRes.ok) throw new Error(`CID lookup failed: ${cidRes.status}`);
    const cidData = await cidRes.json();
    cid = cidData?.IdentifierList?.CID?.[0] || null;
  } catch {
    // Try SMILES if name fails
    try {
      const smilesUrl = `${PUBCHEM_BASE}/compound/smiles/${encodeURIComponent(trimmed)}/cids/JSON`;
      const smilesRes = await fetch(smilesUrl);
      if (smilesRes.ok) {
        const sData = await smilesRes.json();
        cid = sData?.IdentifierList?.CID?.[0] || null;
      }
    } catch {
      throw new Error(`Molecule "${trimmed}" not found in PubChem database.`);
    }
  }

  if (!cid) {
    throw new Error(`Molecule "${trimmed}" not found. Try a different name or SMILES.`);
  }

  // Step 2: Fetch properties
  const propsUrl = `${PUBCHEM_BASE}/compound/cid/${cid}/property/MolecularFormula,MolecularWeight,IUPACName,CanonicalSMILES,IsomericSMILES,InChIKey,XLogP,HBondDonorCount,HBondAcceptorCount,RotatableBondCount,TPSA,HeavyAtomCount,FormalCharge,Complexity/JSON`;
  const propsRes = await fetch(propsUrl);
  const propsData = await propsRes.json();
  const props = propsData?.PropertyTable?.Properties?.[0] || {};

  // Step 3: Fetch 3D SDF
  let sdfData = '';
  let atoms: any[] = [];
  let bonds: any[] = [];

  try {
    const sdfUrl = `${PUBCHEM_BASE}/compound/cid/${cid}/record/SDF?record_type=3d`;
    const sdfRes = await fetch(sdfUrl);
    if (sdfRes.ok) {
      sdfData = await sdfRes.text();
      const parsed = parseSDF(sdfData);
      atoms = parsed.atoms;
      bonds = parsed.bonds;
    }
  } catch {
    // 3D not available, try 2D
    try {
      const sdf2dUrl = `${PUBCHEM_BASE}/compound/cid/${cid}/record/SDF`;
      const sdf2dRes = await fetch(sdf2dUrl);
      if (sdf2dRes.ok) {
        sdfData = await sdf2dRes.text();
        const parsed = parseSDF(sdfData);
        atoms = parsed.atoms;
        bonds = parsed.bonds;
      }
    } catch {
      // No structure data available
    }
  }

  // Step 4: Fetch synonyms
  let synonyms: string[] = [];
  try {
    const synUrl = `${PUBCHEM_BASE}/compound/cid/${cid}/synonyms/JSON`;
    const synRes = await fetch(synUrl);
    if (synRes.ok) {
      const synData = await synRes.json();
      synonyms = (synData?.InformationList?.Information?.[0]?.Synonym || []).slice(0, 10);
    }
  } catch {
    // No synonyms
  }

  const smiles = props.CanonicalSMILES || props.IsomericSMILES || '';
  const formula = props.MolecularFormula || '';
  const iupacName = props.IUPACName || trimmed;

  const functionalGroups = detectFunctionalGroups(smiles);
  const reactions = generateReactions(smiles, formula, iupacName || trimmed);

  const properties: MoleculeProperties = {
    molecularFormula: formula,
    molecularWeight: props.MolecularWeight || 0,
    iupacName: iupacName,
    canonicalSmiles: smiles,
    isomericSmiles: props.IsomericSMILES,
    inchiKey: props.InChIKey,
    xlogp: props.XLogP,
    hBondDonorCount: props.HBondDonorCount,
    hBondAcceptorCount: props.HBondAcceptorCount,
    rotatableBondCount: props.RotatableBondCount,
    topologicalPolarSurfaceArea: props.TPSA,
    heavyAtomCount: props.HeavyAtomCount,
    charge: props.FormalCharge,
    complexity: props.Complexity,
    cid,
  };

  const displayName = synonyms[0] || iupacName || trimmed;

  return {
    id: `pubchem-${cid}`,
    name: displayName,
    formula,
    smiles,
    inchiKey: props.InChIKey,
    cid,
    sdfData,
    atoms,
    bonds,
    properties,
    reactions,
    functionalGroups,
    synonyms,
    loadedAt: Date.now(),
    source: 'pubchem',
  };
}

// Fetch molecule description from PubChem
export async function fetchMoleculeDescription(cid: number): Promise<string> {
  try {
    const url = `${PUBCHEM_VIEW}/data/compound/${cid}/JSON?heading=Description`;
    const res = await fetch(url);
    if (!res.ok) return '';
    const data = await res.json();
    const sections = data?.Record?.Section || [];
    for (const section of sections) {
      if (section.TOCHeading === 'Names and Identifiers' || section.TOCHeading === 'Description') {
        const info = section?.Section?.[0]?.Information?.[0]?.Value?.StringWithMarkup?.[0]?.String;
        if (info) return info;
      }
    }
    return '';
  } catch {
    return '';
  }
}

// Get related/similar molecules
export async function fetchRelatedMolecules(cid: number): Promise<string[]> {
  try {
    const url = `${PUBCHEM_BASE}/compound/fastsimilarity_2d/cid/${cid}/cids/JSON?MaxRecords=5`;
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();
    return (data?.IdentifierList?.CID || []).map((id: number) => id.toString());
  } catch {
    return [];
  }
}
