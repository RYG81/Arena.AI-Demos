import type { AISettings, ChatMessage, MoleculeData } from '../types/molecule';

const DEMO_RESPONSES: Record<string, string> = {
  default: `I'm MolecuLab AI, your chemistry tutor! I can help you understand molecular structures, reactions, properties, and more. Ask me anything about the molecule you're viewing!`,
  what: `Great question! This molecule has fascinating properties. The molecular structure determines its physical and chemical behavior. Look at the 3D model to see how atoms are arranged in space — this geometry directly influences reactivity and biological activity.`,
  how: `Chemical reactions occur when molecules interact and their bonds rearrange. The mechanism depends on the functional groups present, reaction conditions (temperature, pressure, catalysts), and the energy profile of the transformation.`,
  why: `The behavior of this molecule is governed by fundamental principles: electronegativity differences create polar bonds, molecular geometry follows VSEPR theory, and intermolecular forces determine physical properties like boiling point and solubility.`,
};

function getDemoResponse(userMessage: string, molecule: MoleculeData | null): string {
  const msg = userMessage.toLowerCase();

  if (msg.includes('what is') || msg.includes('tell me about') || msg.includes('explain')) {
    if (molecule) {
      return `**${molecule.name}** (${molecule.formula}) is a fascinating molecule!\n\n` +
        `🔬 **Molecular Weight:** ${molecule.properties?.molecularWeight?.toFixed(2) || 'Unknown'} g/mol\n` +
        `⚗️ **SMILES:** \`${molecule.smiles || 'N/A'}\`\n` +
        `🧪 **Functional Groups:** ${molecule.functionalGroups?.map(g => g.name).join(', ') || 'None detected'}\n\n` +
        `${molecule.properties?.iupacName ? `The IUPAC name is **${molecule.properties.iupacName}**. ` : ''}` +
        `This molecule exhibits properties typical of its functional group class. ` +
        `${molecule.properties?.xlogp !== undefined ? `Its LogP of ${molecule.properties.xlogp} indicates ${molecule.properties.xlogp > 0 ? 'lipophilic (fat-soluble)' : 'hydrophilic (water-soluble)'} character.` : ''}\n\n` +
        `💡 *Enable AI by adding your API key in Settings to get detailed AI explanations!*`;
    }
    return `Please load a molecule first, then I can explain its properties in detail! Use the search bar to find any molecule by name or SMILES.`;
  }

  if (msg.includes('reaction') || msg.includes('react')) {
    if (molecule) {
      const rxns = molecule.reactions?.slice(0, 3) || [];
      return `**${molecule.name}** can undergo these key reactions:\n\n` +
        rxns.map(r => `⚗️ **${r.name}**: ${r.description}\n  *Equation:* ${r.equation}`).join('\n\n') +
        `\n\n💡 Click on a reaction in the Reactions tab to see it animated!`;
    }
    return 'Load a molecule to see its possible reactions!';
  }

  if (msg.includes('bond') || msg.includes('structure')) {
    if (molecule) {
      return `**${molecule.name}** structure analysis:\n\n` +
        `🔗 **Heavy Atoms:** ${molecule.properties?.heavyAtomCount || 'N/A'}\n` +
        `🔄 **Rotatable Bonds:** ${molecule.properties?.rotatableBondCount || 0}\n` +
        `💧 **H-Bond Donors:** ${molecule.properties?.hBondDonorCount || 0}\n` +
        `🎯 **H-Bond Acceptors:** ${molecule.properties?.hBondAcceptorCount || 0}\n\n` +
        `The 3D structure is determined by bond angles and molecular geometry. Rotate the molecule in the viewer to explore it!`;
    }
    return 'Load a molecule to analyze its bond structure!';
  }

  if (msg.includes('solub') || msg.includes('water')) {
    if (molecule) {
      const logP = molecule.properties?.xlogp;
      const tpsa = molecule.properties?.topologicalPolarSurfaceArea;
      return `**Solubility Analysis for ${molecule.name}:**\n\n` +
        `💧 **LogP:** ${logP !== undefined ? logP : 'N/A'} — ${logP !== undefined ? (logP < 0 ? 'Highly water-soluble' : logP < 2 ? 'Moderately soluble' : logP < 5 ? 'Slightly soluble' : 'Poorly water-soluble (lipophilic)') : ''}\n` +
        `📐 **TPSA:** ${tpsa !== undefined ? tpsa + ' Ų' : 'N/A'} — ${tpsa !== undefined ? (tpsa < 20 ? 'Very low polarity' : tpsa < 60 ? 'Moderate polarity' : 'High polarity, good absorption') : ''}\n\n` +
        `Solubility is governed by the "like dissolves like" principle. Polar molecules dissolve in water; nonpolar in organic solvents.`;
    }
    return 'Load a molecule to check its solubility properties!';
  }

  if (msg.includes('safe') || msg.includes('toxic') || msg.includes('danger')) {
    return `⚠️ **Safety Information:**\n\nFor accurate safety data, always consult:\n- **SDS (Safety Data Sheets)** from manufacturers\n- **PubChem Hazard Classification** at pubchem.ncbi.nlm.nih.gov\n- **ChemBL** for bioactivity data\n\nNever rely solely on AI for chemical safety decisions. Always follow laboratory safety protocols!`;
  }

  if (msg.includes('help') || msg.includes('what can you')) {
    return `🧪 **MolecuLab AI Can Help You:**\n\n` +
      `📌 **Explain** molecular properties and structures\n` +
      `⚗️ **Describe** chemical reactions and mechanisms\n` +
      `🔬 **Analyze** functional groups and polarity\n` +
      `📚 **Teach** chemistry concepts interactively\n` +
      `🎯 **Quiz** you on molecular knowledge\n\n` +
      `🔑 **Pro Tip:** Add your OpenAI or DeepSeek API key in Settings for full AI power!\n\n` +
      `Try asking: *"Explain the reactions of this molecule"* or *"What makes benzene aromatic?"*`;
  }

  if (msg.includes('quiz') || msg.includes('test me')) {
    if (molecule) {
      return `🎓 **Quick Quiz on ${molecule.name}:**\n\n` +
        `**Q1:** What is the molecular formula of ${molecule.name}?\n` +
        `*(Answer: ${molecule.formula})*\n\n` +
        `**Q2:** How many heavy atoms does it have?\n` +
        `*(Answer: ${molecule.properties?.heavyAtomCount || 'check the properties tab'})*\n\n` +
        `**Q3:** Is ${molecule.name} more water-soluble or lipid-soluble?\n` +
        `*(Hint: Check the LogP value — positive = lipophilic, negative = hydrophilic)*\n\n` +
        `Go to the **Quiz** tab for full interactive quizzes!`;
    }
    return 'Load a molecule first, then I can quiz you on its properties!';
  }

  // Context-based responses
  const keys = Object.keys(DEMO_RESPONSES);
  const match = keys.find(k => msg.includes(k) && k !== 'default');
  return DEMO_RESPONSES[match || 'default'];
}

export async function sendAIMessage(
  userMessage: string,
  history: ChatMessage[],
  molecule: MoleculeData | null,
  settings: AISettings
): Promise<string> {
  if (settings.provider === 'demo') {
    await new Promise(r => setTimeout(r, 800 + Math.random() * 600));
    return getDemoResponse(userMessage, molecule);
  }

  const systemPrompt = `You are MolecuLab AI, an expert chemistry tutor and molecular scientist. You help users understand molecular structures, chemical reactions, and chemistry concepts.

${molecule ? `Current molecule being studied:
- Name: ${molecule.name}
- Formula: ${molecule.formula}
- SMILES: ${molecule.smiles || 'N/A'}
- Molecular Weight: ${molecule.properties?.molecularWeight || 'N/A'} g/mol
- IUPAC Name: ${molecule.properties?.iupacName || 'N/A'}
- LogP: ${molecule.properties?.xlogp || 'N/A'}
- H-Bond Donors: ${molecule.properties?.hBondDonorCount || 0}
- H-Bond Acceptors: ${molecule.properties?.hBondAcceptorCount || 0}
- Functional Groups: ${molecule.functionalGroups?.map(g => g.name).join(', ') || 'None'}
- Possible Reactions: ${molecule.reactions?.map(r => r.name).join(', ') || 'None'}
` : 'No molecule currently loaded.'}

Be educational, clear, and engaging. Use chemical notation when appropriate. Format responses with markdown.
Always ground your answers in chemistry facts. If you're not certain, say so.`;

  const messages = [
    { role: 'system', content: systemPrompt },
    ...history.slice(-10).map(m => ({ role: m.role as 'user' | 'assistant', content: m.content })),
    { role: 'user', content: userMessage },
  ];

  try {
    let apiUrl = '';
    let headers: Record<string, string> = { 'Content-Type': 'application/json' };
    let body: any = {};

    if (settings.provider === 'openai') {
      apiUrl = 'https://api.openai.com/v1/chat/completions';
      headers['Authorization'] = `Bearer ${settings.apiKey}`;
      body = {
        model: settings.model || 'gpt-4o',
        messages,
        temperature: settings.temperature,
        max_tokens: settings.maxTokens,
      };
    } else if (settings.provider === 'deepseek') {
      apiUrl = 'https://api.deepseek.com/chat/completions';
      headers['Authorization'] = `Bearer ${settings.apiKey}`;
      body = {
        model: settings.model || 'deepseek-chat',
        messages,
        temperature: settings.temperature,
        max_tokens: settings.maxTokens,
      };
    } else if (settings.provider === 'ollama') {
      apiUrl = `${settings.baseUrl || 'http://localhost:11434'}/api/chat`;
      body = {
        model: settings.model || 'llama3',
        messages,
        stream: false,
        options: {
          temperature: settings.temperature,
          num_predict: settings.maxTokens,
        },
      };
    }

    const res = await fetch(apiUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || `API error: ${res.status}`);
    }

    const data = await res.json();

    if (settings.provider === 'ollama') {
      return data?.message?.content || 'No response';
    }
    return data?.choices?.[0]?.message?.content || 'No response';
  } catch (err: any) {
    throw new Error(err.message || 'AI request failed');
  }
}
